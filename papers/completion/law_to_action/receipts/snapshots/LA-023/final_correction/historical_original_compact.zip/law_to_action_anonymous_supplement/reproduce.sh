#!/bin/sh
# One-command bounded reproduction and analysis for LA-023.
# Uses the sealed validation PATH and /usr/bin/python3.12 only.
set -eu

export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin"
export PYTHONDONTWRITEBYTECODE=1
export PYTHONHASHSEED=0
export SOURCE_DATE_EPOCH=0
unset PYTHONPATH PYTHONHOME PYTHONUSERBASE || true

PYTHON="/usr/bin/python3.12"
if [ ! -x "$PYTHON" ]; then
  echo "LA-023: required interpreter missing: $PYTHON" >&2
  exit 1
fi

HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)

exec "$PYTHON" - "$HERE" <<'PY'
from __future__ import annotations

import os
import stat
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

SEALED_PATH = "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin"
PYTHON = "/usr/bin/python3.12"
ZIP_PREFIX = "law_to_action_anonymous_supplement/"

here = Path(sys.argv[1]).resolve()
os.environ["PATH"] = SEALED_PATH
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
os.environ["PYTHONHASHSEED"] = "0"

if os.environ.get("PATH") != SEALED_PATH:
    raise SystemExit("LA-023: failed to pin sealed PATH")
if Path(sys.executable).resolve() != Path(PYTHON).resolve():
    raise SystemExit(f"LA-023: interpreter must be {PYTHON}, got {sys.executable}")

checker = here / "scripts" / "check_artifact.py"
zip_path = here / "anonymous_supplement.zip"
artifact_dir = here if (here / "manifest.json").is_file() or zip_path.is_file() else None
tmpdir = None
try:
    if checker.is_file():
        bundle = here
        argv = [PYTHON, str(checker), "--bundle", str(bundle)]
        if artifact_dir is not None:
            argv.extend(["--artifact", str(artifact_dir)])
    elif zip_path.is_file():
        tmpdir = tempfile.TemporaryDirectory(prefix="la023-repro-")
        with zipfile.ZipFile(zip_path) as archive:
            archive.extractall(tmpdir.name)
        bundle = Path(tmpdir.name) / "law_to_action_anonymous_supplement"
        checker = bundle / "scripts" / "check_artifact.py"
        if not checker.is_file():
            raise SystemExit("LA-023: zip is missing scripts/check_artifact.py")
        mode = checker.stat().st_mode
        if not mode & stat.S_IRUSR:
            raise SystemExit("LA-023: checker is not readable")
        argv = [PYTHON, str(checker), "--bundle", str(bundle), "--artifact", str(here), "--zip", str(zip_path)]
    else:
        raise SystemExit("LA-023: neither unpacked bundle nor anonymous_supplement.zip is present")
    completed = subprocess.run(argv, check=False)
    raise SystemExit(completed.returncode)
finally:
    if tmpdir is not None:
        tmpdir.cleanup()
PY
