"""Recheck three separate anonymous components and their offline numerical CLIs.

Only the three exact allowlisted reproducer programs execute. No original
signatures, hidden tests, scientific services or native qualifications replay.
"""
import argparse, datetime as dt, hashlib, json, os, signal, stat, subprocess, sys, time
from pathlib import Path, PurePosixPath
MAX_FILES=8192
MAX_MEMBER=16_000_000
MAX_EXPANDED=64<<20
COMPONENTS={
 'final32':('release_manifest.json','files','ns-final32-anonymous-release-manifest/v1','reproduce.py','cb3515b57f0d8a85ed12bfb4af67fca4d53a4eef7a7b23e81b8e3d3b48430f48'),
 'prior':('manifest.json','members','ns-anonymous-prior-component/v1','source/reproduce.py','00eee4b415239dca9eb994604a08152bc814b3a31c0c7fc2d1c4ca7325df78b1'),
 'boundary':('manifest.json','members','ns020-public-boundary-component/v1','reproduce.py','2eccc3e8dbff00398b52d4ecfb1a29c330d8b30a62b5ddd594549a1517725dfc')}
FIXED_MANIFESTS={'prior':'1d00715d05bbea2c7cab0ef1892f039153cc12ea0820bd556a13452ffe6b70a7','boundary':'8addd3465f79791a1126d6fb4bf08c77107fa5a4e5b1ddf844d8b78b48271369'}
def require(ok,message):
 if not ok:raise ValueError(message)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def encoded(value):return (json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
def decode(raw):
 def pairs(items):
  d={}
  for k,v in items:require(k not in d,'duplicate JSON key');d[k]=v
  return d
 return json.loads(raw,object_pairs_hook=pairs,parse_constant=lambda _:(_ for _ in ()).throw(ValueError('nonfinite JSON')))
def relative(name):
 require(isinstance(name,str) and name and ':' not in name and '\\' not in name and not any(ord(c)<32 for c in name),'invalid relative path')
 p=PurePosixPath(name);require(not p.is_absolute() and str(p)==name and not any(x in ('.','..','.git') for x in p.parts),'unsafe relative path');return name
def read(path,expected=None,maximum=MAX_MEMBER):
 p=Path(path);require(p.is_absolute() and p.resolve()==p,'canonical nonsymlink input required')
 fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW)
 try:
  a=os.fstat(fd);require(stat.S_ISREG(a.st_mode) and a.st_size<=maximum,'regular bounded file required')
  with os.fdopen(fd,'rb',closefd=False) as f:raw=f.read(maximum+1)
  b=os.fstat(fd)
 finally:os.close(fd)
 require((a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns)==(b.st_dev,b.st_ino,b.st_size,b.st_mtime_ns) and len(raw)==a.st_size,'input changed while reading')
 require(expected is None or sha(raw)==expected,'file hash mismatch');return raw
def inventory(root):
 require(root.is_absolute() and root.resolve()==root and root.is_dir(),'canonical component directory required')
 found={};nodes=0;total=0
 for base,dirs,files in os.walk(root,followlinks=False):
  nodes+=len(dirs)+len(files);require(nodes<=2*MAX_FILES,'directory/member quota')
  for name in dirs:require(not (Path(base)/name).is_symlink(),'symlink directory')
  for name in files:
   p=Path(base)/name;n=relative(p.relative_to(root).as_posix());m=p.lstat();require(stat.S_ISREG(m.st_mode),'nonregular inventory member');total+=m.st_size
   require(len(found)<MAX_FILES and m.st_size<=MAX_MEMBER and total<=MAX_EXPANDED,'input inventory quota');found[n]=m.st_size
 return found
def component(root,kind,expected):
 filename,key,schema,script,script_sha=COMPONENTS[kind];raw=read(root/filename,expected,4<<20);m=decode(raw)
 require(m['schema']==schema,'component schema')
 if kind=='final32':require(m['complete_actual32'] is True and m['original_signatures_authenticate_derivatives'] is False and len(m['ordered_cells'])==len(set(m['ordered_cells']))==32,'actual complete32 component required')
 elif kind=='prior':require(expected==FIXED_MANIFESTS[kind] and m['unsigned_data_replay_only'] is True and m['signature_authentication_of_derived_records'] is False,'exact unsigned prior component required')
 else:require(expected==FIXED_MANIFESTS[kind] and m['unsigned_derivatives'] is True and m['final_scientific_rows']==0,'exact historical boundary component required')
 members=m[key];require(isinstance(members,dict) and 0<len(members)<MAX_FILES and filename not in members,'manifest member map')
 require(set(inventory(root))==set(members)|{filename},'exact child inventory required')
 result={filename:raw}
 for name,record in members.items():
  relative(name);require(type(record['bytes']) is int and 0<=record['bytes']<=MAX_MEMBER,'member byte quota')
  data=read(root/name,record['sha256']);require(len(data)==record['bytes'],'member byte count');result[name]=data
 require(script in result and sha(result[script])==script_sha,'exact reviewed child reproducer required')
 require(sum(map(len,result.values()))<=MAX_EXPANDED,'component aggregate quota');return result

def verify(root):
 raw=read(root/'manifest.json',maximum=4<<20);m=decode(raw)
 require(m['schema']=='ns-combined-anonymous-supplement/v1' and set(m['components'])==set(COMPONENTS),'combined manifest schema/namespaces')
 require(m['no_outcome_pooling'] is True and m['no_cross_scope_cost_sum'] is True and m['original_signature_replay'] is False,'combined scope')
 expected={}
 for kind,spec in m['components'].items():
  require(spec['manifest']==kind+'/'+COMPONENTS[kind][0],'component manifest location')
  data=component(root/kind,kind,spec['sha256']);require(type(spec['files_including_manifest']) is int and spec['files_including_manifest']==len(data) and type(spec['bytes_including_manifest']) is int and spec['bytes_including_manifest']==sum(map(len,data.values())),'child count/byte declaration differs')
  for name,raw in data.items():expected[kind+'/'+name]={'sha256':sha(raw),'bytes':len(raw)}
 for name in ('README.md','reproduce.py'):
  data=read(root/name);expected[name]={'sha256':sha(data),'bytes':len(data)}
 require(m['files']==expected and set(inventory(root))==set(expected)|{'manifest.json'},'exact combined inventory')
 require(expected['reproduce.py']['sha256']==sha(Path(__file__).read_bytes()),'portable reproducer differs')
 return m

def run_child(kind,root,out):
 script=COMPONENTS[kind][3];argv=[sys.executable,'-B','-s',str(root/script)]
 argv+=['--release',str(root),'--output',str(out/'numerical')] if kind=='final32' else [str(root)] if kind=='prior' else ['--root',str(root)]
 out.mkdir();started=dt.datetime.now(dt.timezone.utc).isoformat();clock=time.monotonic();timed_out=False
 env={'PATH':'/usr/bin:/bin','LC_ALL':'C.UTF-8','PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1'}
 with (out/'stdout.json').open('xb') as so,(out/'stderr.log').open('xb') as se:
  process=subprocess.Popen(argv,cwd=root,env=env,stdout=so,stderr=se,start_new_session=True)
  try:code=process.wait(timeout=120)
  except subprocess.TimeoutExpired:
   timed_out=True
   try:os.killpg(process.pid,signal.SIGKILL)
   except ProcessLookupError:pass
   code=process.wait(timeout=10)
  so.flush();se.flush();os.fsync(so.fileno());os.fsync(se.fileno())
 record={'argv':argv,'started_at':started,'finished_at':dt.datetime.now(dt.timezone.utc).isoformat(),'elapsed_host_wall_seconds':time.monotonic()-clock,'exit_code':code,'timed_out':timed_out,'stdout_sha256':sha((out/'stdout.json').read_bytes()),'stderr_sha256':sha((out/'stderr.log').read_bytes())}
 (out/'execution.json').write_bytes(encoded(record));require(code==0 and not timed_out,'child reproducer failed: '+kind)
 result=decode(read(out/'stdout.json',maximum=4<<20))
 if kind=='final32':
  s=decode(read(out/'numerical/summary.json'));require(result['success'] is True and s['complete'] is True and s['planned_cells']==s['terminal_cells']==32,'final32 replay scope')
 elif kind=='prior':require(result['success'] is True and result['pilot_cells']==24 and result['families']==4 and result['new_provider_scorer_native_calls']==0,'pilot replay scope')
 else:require(result['table_rows']==6 and result['final_outcome_rows']==0 and result['original_claims']==32 and result['native_qualification_reexecuted'] is False,'historical boundary replay scope')
 return {'result':result,'execution':record}
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
 require(sys.version_info[:2]==(3,12),'Python3.12 required for frozen arithmetic');os.umask(0o077)
 require(a.output.is_absolute() and a.output.resolve()==a.output and not a.output.exists() and not a.output.is_relative_to(a.root),'fresh output outside supplement required')
 manifest=verify(a.root);a.output.mkdir(parents=False);results={kind:run_child(kind,a.root/kind,a.output/kind) for kind in COMPONENTS};require(verify(a.root)==manifest,'child altered supplement')
 r={'schema':'ns-combined-anonymous-offline-reproduction/v1','success':True,'manifest_sha256':sha(read(a.root/'manifest.json')),'components':results,'scopes':{'final32':'32 A/B cold cells; eight families and two nested repetitions','prior':'Separate 24-cell developmental pilot; four families and three nested repetitions, plus original separated cost ledgers','boundary':'Six historical boundary rows and retained qualification counts; no final outcomes or new qualifications'},'outcomes_pooled':False,'cost_scopes_summed':False,'signature_authentication_performed':False,'new_scientific_or_native_calls':0,'network_isolation_claimed':False,'offline_scope':'Exact reviewed local numerical/file programs only; no networking program or API is invoked.'}
 (a.output/'reproduction.json').write_bytes(encoded(r));print(json.dumps({'success':True,'manifest_sha256':r['manifest_sha256'],'components':list(results)}))
if __name__=='__main__':main()
