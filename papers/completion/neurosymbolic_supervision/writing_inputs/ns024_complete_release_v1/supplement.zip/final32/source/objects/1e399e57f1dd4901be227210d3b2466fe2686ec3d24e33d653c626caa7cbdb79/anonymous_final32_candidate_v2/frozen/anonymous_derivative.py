"""Off-live first-eight public-record preparation. No service imports or effects.

This is deliberately not a complete-cohort publication/export command. It never
signs, verifies, replays or dispatches scientific receipts. Private originals are
read from exact public-export/source bindings and are never rewritten.
"""
import argparse
import ast
import hashlib
import io
import json
import os
from pathlib import Path
import re
import stat
import tokenize

SCHEMA = 'ns-anonymous-unsigned-record/v1'
MAPS = {'source_bindings', 'frozen_source_bindings',
        'effective_source_bindings', 'original_frozen_source_bindings'}
REF_ROLES = {'authority', 'successor_resource_reservation', 'original_activation',
             'original_batch', 'original_freeze', 'delegated_root_authority'}
NAMES = {'manifest.json', 'offer.json', 'request.json', 'proposal.json',
         'response.json', 'disposition.json'}
HEX = re.compile(r'[0-9a-f]{64}\Z')
HOME = re.compile(r'(?:/(?:home|Users)/[^/\s"\'<>]+|[A-Za-z]:[\\/]Users[\\/][^\\/\s"\'<>]+)')
PROJECT = re.compile(r'https?://(?:www\.)?overleaf\.com/project/[^\s"\'<>]+', re.I)
KEY = re.compile(r'-----BEGIN [A-Z ]*PRIVATE KEY-----')
EMAIL = re.compile(r'(?<![\w.-])[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}')

def require(ok, code):
    if not ok:
        raise ValueError(code)  # Never include original values/paths in diagnostics.

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def canonical(x):
    return json.dumps(x, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()

def serialized(x):
    return (json.dumps(x, sort_keys=True, indent=2, allow_nan=False)+'\n').encode()

def strict_json(raw):
    def pairs(xs):
        d = {}
        for k, v in xs:
            require(k not in d, 'duplicate_json_key')
            d[k] = v
        return d
    def invalid(_):
        raise ValueError('nonfinite_json')
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=invalid)

def bound_read(ref, maximum=1 << 20):
    p = Path(ref['path'])
    require(p.is_absolute() and p.resolve() == p, 'noncanonical_or_symlink_input')
    fd = os.open(p, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        before = os.fstat(fd)
        require(stat.S_ISREG(before.st_mode) and before.st_size <= maximum, 'input_size_or_type')
        with os.fdopen(fd, 'rb', closefd=False) as f:
            raw = f.read(maximum+1)
        after = os.fstat(fd)
    finally:
        os.close(fd)
    require((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) ==
            (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns), 'input_changed')
    require(len(raw) <= maximum and sha(raw) == ref['sha256'], 'input_hash')
    return raw

def marker_counts(text):
    return {k: len(p.findall(text)) for k, p in
            [('author_home', HOME), ('private_project_link', PROJECT),
             ('private_key_marker', KEY), ('email_like_needs_attribution_review', EMAIL)]
            if p.search(text)}

def safe_text(text):
    require(not HOME.search(text), 'unhandled_author_home')
    require(not PROJECT.search(text), 'unhandled_private_project_link')
    require(not KEY.search(text), 'private_key_marker_forbidden')

def transport_projection(x):
    """Remove only declared transport paths/map labels and outer signature.

All other scalars, strings, nested values and original digest references remain
exact. This is an equality check, not a scientific outcome reducer.
"""
    if isinstance(x, dict):
        out = {}
        for k, v in x.items():
            if k == 'signature':
                continue
            if k in MAPS:
                out[k] = sorted(v.values())
            elif k == 'path' and HEX.fullmatch(str(x.get('sha256', ''))):
                continue
            else:
                out[k] = transport_projection(v)
        return out
    if isinstance(x, list):
        return [transport_projection(v) for v in x]
    return x

# Additional public provenance links are admitted only at exact record-type and
# structural locations. REF_ROLES remains unchanged; a matching leaf name alone
# is insufficient. Referenced private files are never opened by this projection.
TYPED_PUBLIC_REFS = {
    ('operator_disposition.json', 'operator-final-failure-accounting-review/v1'): {
        'delegated_root_operator_authority', 'auth_gap',
        'auth_gap_reconciliation', 'provider_absence', 'relative_http_metadata'},
    ('operator_review.json', 'operator-historical-final-candidate-review/v1'): {
        'delegated_root_operator_authority', 'proposal_compliance_review',
        'provider_absence_review'},
}


def typed_public_reference(original, public_record_name, location, ref):
    """Return True only for reviewed two-field metadata reference locations.

This labels a digest commitment to a private original. It confers no approval,
signature verification or authority on the derived public record or target.
"""
    if (set(ref) != {'path', 'sha256'} or
            not isinstance(ref.get('sha256'), str) or
            HEX.fullmatch(ref['sha256']) is None or
            not isinstance(ref.get('path'), str)):
        return False
    path = ref['path']
    # A literal canonical POSIX host path, not a URL, sentence or traversal.
    p = Path(path)
    if (not path.startswith(('/home/', '/Users/')) or not p.is_absolute() or
            str(p) != path or '..' in p.parts):
        return False
    schema = original.get('schema')
    roles = TYPED_PUBLIC_REFS.get((public_record_name, schema), set())
    if len(location) == 2 and location[0] in roles and location[1] == 'path':
        return True
    if (public_record_name != 'disposition.json' or
            set(original) != {'signature', 'receipt', 'public_key_sha256'} or
            not isinstance(original.get('signature'), str) or
            not isinstance(original.get('public_key_sha256'), str) or
            HEX.fullmatch(original['public_key_sha256']) is None):
        return False
    receipt = original.get('receipt')
    if (not isinstance(receipt, dict) or
            receipt.get('schema') != 'operator-final-failure-disposition/v1'):
        return False
    operator = receipt.get('operator_record')
    if (not isinstance(operator, dict) or
            operator.get('schema') != 'operator-final-failure-accounting-review/v1'):
        return False
    roles = TYPED_PUBLIC_REFS[('operator_disposition.json', operator['schema'])]
    return (len(location) == 4 and location[:2] == ('receipt', 'operator_record')
            and location[2] in roles and location[3] == 'path')


def derive_record(raw, *, public_record_name=None):
    original = strict_json(raw)
    require(isinstance(original, dict), 'record_not_object')
    changes = []
    def visit(x, role='', location=()):
        if isinstance(x, dict):
            out = {}
            for k, v in x.items():
                safe_text(k) if role not in MAPS else None
                require(role in MAPS or not EMAIL.search(k), 'metadata_email_key_requires_attribution_review')
                newkey = k
                if role in MAPS:
                    require(HEX.fullmatch(str(v)) is not None, 'source_map_digest')
                    if HOME.search(k):
                        name = Path(k).name
                        require(re.fullmatch(r'[a-z_]+\.py', name) is not None, 'source_role_name')
                        newkey = 'sources/'+v+'/'+name
                        changes.append('source_map_key')
                if k == 'path' and isinstance(v, str) and HOME.search(v):
                    require((role in REF_ROLES and HEX.fullmatch(str(x.get('sha256', '')))) or
                            typed_public_reference(original, public_record_name, location+(k,), x),
                            'unapproved_path_location')
                    newvalue = 'private-original:sha256:'+x['sha256']
                    changes.append('provenance_reference_path')
                else:
                    newvalue = visit(v, k, location+(k,))
                require(newkey not in out, 'derived_key_collision')
                out[newkey] = newvalue
            return out
        if isinstance(x, list):
            return [visit(v, role, location+(i,)) for i, v in enumerate(x)]
        if isinstance(x, str):
            safe_text(x)
            require(not EMAIL.search(x), 'metadata_email_requires_explicit_attribution_review')
        return x
    payload = visit(original)
    if not changes:
        return raw, {'representation': 'byte_exact_original', 'changes': [],
                     'signature_replay': 'Original bytes retained; no new verification performed.'}
    signed = 'signature' in original
    if signed:
        require(set(original) == {'signature', 'receipt', 'public_key_sha256'}, 'unknown_signed_envelope')
        payload.pop('signature')
        require(isinstance(original['receipt'], dict), 'signed_body_type')
    require(transport_projection(payload) == transport_projection(original), 'nontransport_change')
    proof = {'original_sha256': sha(raw), 'original_bytes': len(raw),
             'original_canonical_document_sha256': sha(canonical(original)),
             'original_canonical_receipt_sha256': sha(canonical(original['receipt'])) if signed else None,
             'original_public_key_sha256': original.get('public_key_sha256') if signed else None,
             'original_signature_present': signed,
             'signature_status': 'unsigned_derivative',
             'original_signature_authenticates_derived_bytes': False,
             'new_signature_verification_performed': False,
             'transport_only_projection_sha256': sha(canonical(transport_projection(original))),
             'change_categories': {k: changes.count(k) for k in sorted(set(changes))}}
    wrapper = {'schema': SCHEMA, 'provenance': proof, 'payload': payload,
               'scope': 'Unsigned anonymous metadata derivative. Hash references in payload name original objects, not replacement objects. Private signed originals retain signature replay custody. No admission, effect or scientific completion authority.'}
    derived = serialized(wrapper)
    safe_text(derived.decode())
    return derived, {'representation': 'unsigned_derivative', 'changes': proof['change_categories'],
                     'signature_replay': 'Unavailable from derivative; original signature omitted and private originals preserved.'}

def derive_source(raw):
    """Only the known SHARED Path literal may change; every other byte stays exact.

These are reference derivatives, not the executed source or a replay launcher.
Upstream notices/comments are never edited.
"""
    text = raw.decode('utf-8')
    require(not KEY.search(text) and not PROJECT.search(text), 'source_forbidden_marker')
    if not HOME.search(text):
        return raw, 'byte_exact_executed_source'
    tree = ast.parse(text)
    candidates = []
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'SHARED' for t in node.targets):
            call = node.value
            if isinstance(call, ast.Call) and isinstance(call.func, ast.Name) and call.func.id == 'Path' and call.args:
                arg = call.args[0]
                if isinstance(arg, ast.Constant) and isinstance(arg.value, str) and HOME.search(arg.value):
                    candidates.append(arg)
    require(len(candidates) == 1, 'source_identity_not_approved_shared_literal')
    arg = candidates[0]
    toks = [t for t in tokenize.generate_tokens(io.StringIO(text).readline)
            if t.type == tokenize.STRING and t.start == (arg.lineno, arg.col_offset)]
    require(len(toks) == 1 and ast.literal_eval(toks[0].string) == arg.value, 'source_literal_token')
    tok = toks[0]
    lines = text.splitlines(keepends=True)
    require(tok.start[0] == tok.end[0], 'multiline_source_literal')
    i = tok.start[0]-1
    lines[i] = lines[i][:tok.start[1]] + repr('/anonymous-runtime/shared/host_gateway.py') + lines[i][tok.end[1]:]
    out = ''.join(lines)
    safe_text(out)
    # Reversing this one literal is a byte equality proof, including notices.
    changed = repr('/anonymous-runtime/shared/host_gateway.py')
    require(out.count(changed) == 1 and out.replace(changed, tok.string, 1) == text, 'source_delta_not_exact')
    ast.parse(out)
    return out.encode(), 'public_source_reference_derivative_not_executed'

def decoded_record(raw):
    """Read for numerical/scalar reproduction only; never an authenticity API."""
    x = strict_json(raw)
    if x.get('schema') != SCHEMA:
        return x
    p = x['provenance']
    require(p['signature_status'] == 'unsigned_derivative' and
            p['original_signature_authenticates_derived_bytes'] is False and
            'signature' not in x['payload'], 'invalid_unsigned_wrapper')
    require(sha(canonical(transport_projection(x['payload']))) == p['transport_only_projection_sha256'],
            'derived_projection_hash')
    return x['payload']

def write_new(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'wb') as f:
        f.write(raw); f.flush(); os.fsync(f.fileno())

def build(admission, output):
    require(admission['schema'] == 'ns-anonymous-prefix8-preparation-admission/v1', 'preparation_schema')
    require(admission['complete_cohort'] is False and admission['publication_approved'] is False, 'scope')
    require({r['cell_number'] for r in admission['records']} == set(range(1, 9)), 'exact_first_eight_only')
    require(not output.exists() and output.is_absolute() and output.resolve() == output, 'fresh_output')
    for ref in admission['historical_public_export_location_bindings']:
        bound_read(ref)
    prepared = []; seen = set(); total = 0; originals = {}
    for r in admission['records']:
        name = r['filename']; p = Path(r['input']['path'])
        require(name in NAMES and p.name == name and p.parent.name == 'public_evidence', 'public_record_allowlist')
        key = (r['cell_number'], name); require(key not in seen, 'duplicate_member'); seen.add(key)
        raw = bound_read(r['input']); total += len(raw); originals[key] = raw
        out, meta = derive_record(raw)
        require(transport_projection(decoded_record(out)) == transport_projection(strict_json(raw)), 'scalar_equality')
        member = 'records/cell%03d/%s' % (r['cell_number'], name)
        prepared.append((member, out, {'original_sha256': sha(raw), 'original_bytes': len(raw), **meta}))
    for cell in range(1, 9):
        require((cell, 'manifest.json') in originals, 'missing_public_manifest')
        declared = strict_json(originals[(cell, 'manifest.json')])['files']
        actual = {n for i, n in originals if i == cell and n != 'manifest.json'}
        require(set(declared) == actual, 'public_manifest_coverage')
        for n, expected in declared.items():
            digest = expected['sha256'] if isinstance(expected, dict) else expected
            require(sha(originals[(cell, n)]) == digest, 'public_manifest_member_hash')
    contract_raw = bound_read(admission['public_contract'])
    contract = strict_json(contract_raw)
    declared_sources = {**contract['original_frozen_source_bindings'], **contract['effective_source_bindings']}
    require({(r['role'], r['input']['sha256']) for r in admission['sources']} ==
            {(Path(p).name, h) for p, h in declared_sources.items()}, 'source_map_coverage')
    for r in admission['sources']:
        require(declared_sources.get(r['input']['path']) == r['input']['sha256'], 'undeclared_source_path')
        raw = bound_read(r['input']); total += len(raw)
        require(Path(r['input']['path']).name == r['role'] and re.fullmatch(r'[a-z_]+\.py', r['role']), 'source_role')
        out, kind = derive_source(raw)
        member = 'sources/'+sha(raw)+'/'+r['role']
        require(member not in {x[0] for x in prepared}, 'duplicate_source')
        prepared.append((member, out, {'original_sha256': sha(raw), 'original_bytes': len(raw),
                         'representation': kind, 'source_role': r['role'], 'runtime_epochs': r['runtime_epochs'],
                         'attribution_markers_retained': marker_counts(out.decode())}))
    raw = bound_read(admission['public_contract']); total += len(raw)
    out, meta = derive_record(raw)
    prepared.append(('metadata/runtime_contract.unsigned.json', out,
                     {'original_sha256': sha(raw), 'original_bytes': len(raw), **meta}))
    require(total <= 64 << 20, 'aggregate_preparation_size')
    index = {}
    for member, data, meta in prepared:
        safe_text(data.decode())
        index[member] = {**meta, 'derived_sha256': sha(data), 'derived_bytes': len(data)}
    manifest = {'schema': 'ns-anonymous-prefix8-preparation-manifest/v1',
                'complete_cohort': False, 'publication_approved': False,
                'source_admission_sha256': sha(serialized(admission)),
                'derivation_source_sha256': sha(Path(__file__).read_bytes()), 'members': index,
                'scope': 'Original prefix1–7 and first continued cell8 public JSON, client-admitted public contract and its declared service source versions only. Preparation fixture, not final32 results.',
                'signed_originals_modified': False, 'new_signature_verifications': 0,
                'source_originals_modified': False, 'scientific_calls': 0, 'native_calls': 0,
                'payload_hash_references': 'All retained scientific/request/candidate/patch and signed-object digests name unchanged originals. Per-member derived hashes are separate.',
                'limitations': ['No signature authenticity claim for unsigned derivatives.',
                  'Identifying executed source versions remain private; public derivatives are explicitly not executed versions.',
                  'No complete-cohort numerical reproduction, PDF/archive anonymity or publication admission is established by this fixture.',
                  'Hash lineage deliberately permits correlation with originals; external de-identification cannot be guaranteed.',
                  'Upstream copyright/license notices and ordinary third-party attribution are not paper-author identity and remain intact.']}
    output.mkdir(mode=0o700)
    for member, data, _ in prepared:
        write_new(output/member, data)
    write_new(output/'manifest.json', serialized(manifest))
    return manifest

def main():
    p = argparse.ArgumentParser(); p.add_argument('--admission', type=Path, required=True)
    p.add_argument('--admission-sha256', required=True); p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    raw = bound_read({'path': str(a.admission), 'sha256': a.admission_sha256}, 2 << 20)
    doc = strict_json(raw); require(raw == serialized(doc), 'admission_serialization')
    result = build(doc, a.output)
    print(json.dumps({'manifest_sha256': sha(serialized(result)), 'members': len(result['members']),
                      'complete_cohort': False, 'publication_approved': False}))

if __name__ == '__main__':
    main()
