"""Future actual32-only anonymous artifact builder. No model/native/runtime API.

No partial/fixture CLI exists. Constructed tests exercise pure guards, never the
production materializer. Private signature replay stays with the reviewed
strict export; public records and numerical reproduction explicitly separate it.
"""
import argparse
import ast
import hashlib
import importlib.util
import io
import tokenize
import json
import math
import os
from pathlib import Path
import re
import stat
import tempfile
import zipfile
import reproduce as R

HERE=Path(__file__).resolve().parent
DERIVATIVE_SHA='1e399e57f1dd4901be227210d3b2466fe2686ec3d24e33d653c626caa7cbdb79'
ADOPTION_SHA='1dfad27e6c55e98fe6ca5460e5a2b18a8ddf62de2d617fa9c5a8ddff0741ac08'
ANALYSIS_PACKAGE_SHA='c62063240596d38c574f587e83a39ac2191e8aed4be1e27310dcac7f73587b8e'
ADOPTION_PACKAGE_SHA='3573eea6f9ec60e77ab2a10def7de87001b68f5aaebcd49a74cf9b3aa45dc682'
ACTIVATION_SHA='a79cb456abf20fef034e70261509075c181540ce13aa1a588fced63cae934b05'
FREEZE_FILE_SHA='7175ca68247d958dabf83a97441fe6042d3b88feafa74f95c76e1720cc74fa1a'
FREEZE_CANONICAL_SHA='ac605b5de8b58cc41c5c3609e7752e5e4441ab627dbbe6d31f4d8d086b33732d'
POLICY_SHA='a0edbc1cdf13f1d5aab4170dd60fcb3a3b2ef26d192f6dbbdce9b6a26ff700d3'
EXPORTER_SHA='b62c6283bcfcfb5afc3f8289ea273a82101aee117275dfce91c18960deebd081'
CANDIDATE_EXPORTER_SHA='83ac49c3d79bc99ad73adb6defdc24c3866837eedc02a9c3bc462fc5139bb5bb'
REVIEW_KEYS=('activation','analysis','analysis_bindings','export_manifest','candidate_payload_manifest','public_baseline_manifest',
             'continuation_contract','validation_disclosures','operator_phase_cost_manifest')
PUBLIC_NAMES={'request.json','offer.json','proposal.json','response.json','disposition.json','operator_review.json','operator_disposition.json','client_export_manifest.json'}
ROLES={'original_service','continued_service','native_overlay','phase_helper','client_driver','input_preparation','runtime_profile','analysis','adoption'}
MAX_BYTES=100_000_000  # strict decimal artifact cap, not an unmeasured promise

def require(ok,code):
    if not ok: raise ValueError(code)

def digest(raw): return hashlib.sha256(raw).hexdigest()
def canonical(x): return R.canonical(x)
def encoded(x): return R.encoded(x)

# Load only the exact reviewed derivative utility, never a service/plugin.
p=HERE/'frozen/anonymous_derivative.py'
require(digest(p.read_bytes())==DERIVATIVE_SHA,'reviewed_derivative_source')
spec=importlib.util.spec_from_file_location('anonymous_release_derivative_frozen',p)
D=importlib.util.module_from_spec(spec);spec.loader.exec_module(D)


def bound(ref,maximum=16<<20): return D.strict_json(D.bound_read(ref,maximum))
def safe_rel(name):
    p=Path(name)
    require(isinstance(name,str) and name and not p.is_absolute() and str(p)==name and
            not any(t in ('.','..','.git')for t in p.parts) and '\\'not in name and
            not any(ord(c)<32 or ord(c)==127 for c in name),'unsafe_relative_member')
    D.safe_text(name);return name

def actual_gate(adm,activation,analysis,export,review,freeze):
    require(adm['schema']=='ns-final32-anonymous-artifact-admission/v1' and adm['approved']is True and adm['authority']=='root_operator','root_release_admission')
    require(adm['input_kind']=='actual_signed_complete_final32' and adm['fixture']is False and adm['allow_partial']is False,'no_fixture_partial_materialization')
    require(adm['publication_approved']is False and adm['activation']['sha256']==ACTIVATION_SHA,'local_only_actual_activation')
    require(adm['analysis_package']['sha256']==ANALYSIS_PACKAGE_SHA and adm['adoption_package']['sha256']==ADOPTION_PACKAGE_SHA,'frozen_continuation_packages')
    # Execute just the exact previously reviewed pure metadata gate. No imports,
    # custody functions, candidate parsing, source discovery or service API run.
    src=(HERE/'frozen/adoption_build_bundle.py').read_bytes();require(digest(src)==ADOPTION_SHA,'frozen_adoption_gate_source')
    tree=ast.parse(src);node=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='metadata_guard')
    stats=R.statistics((HERE/'frozen/analyze.py').read_bytes())
    g={'require':require,'digest':digest,'canonical':canonical,'FREEZE_FILE_SHA':FREEZE_FILE_SHA,
       'FREEZE_CANONICAL_SHA':FREEZE_CANONICAL_SHA,'POLICY_SHA':POLICY_SHA,'EXPORTER_SHA':EXPORTER_SHA,
       'UNITS':stats['UNITS'],'REPS':stats['REPS']}
    exec(compile(ast.Module(body=[node],type_ignores=[]),'<qualified-metadata-gate>','exec'),g)
    g['metadata_guard'](adm,activation,analysis,export,review,freeze)
    require(all(review[k]==adm[k]for k in REVIEW_KEYS),'root_complete_review_exact_inputs')
    require(adm['ordered_cells']==activation['ordered_cells'],'release_order')
    require(type(adm['max_artifact_bytes'])is int and 0<adm['max_artifact_bytes']<=MAX_BYTES,'artifact_quota')
    rows=R.project_rows(analysis['rows']);computed=R.reduce_rows(rows,(HERE/'frozen/analyze.py').read_bytes())
    require(canonical({k:analysis.get(k)for k in computed})==canonical(computed),'private_analysis_arithmetic_mismatch')
    return rows,computed


def source_guard(allow,adm,contract,freeze):
    require(allow['schema']=='ns-final32-anonymous-source-allowlist/v1' and allow['approved']is True and
            allow['analysis']==adm['analysis'] and allow['continuation_contract']==adm['continuation_contract'] and
            allow['immutable_pins']==freeze['immutable_pins'],'root_reviewed_source_allowlist')
    require(set(allow['required_roles'])==ROLES and {r['category']for r in allow['files']}>=ROLES,'actual_executed_source_categories')
    require(allow['hidden_oracle_reference_or_credentials_included']is False,'source_custody_scope')
    declared={**contract['original_frozen_source_bindings'],**contract['effective_source_bindings']}
    actual={(r['source']['path'],r['source']['sha256'])for r in allow['files']}
    require(set(declared.items())<=actual,'both_actual_service_epoch_maps_required')
    require(len({(r['source']['path'],r['source']['sha256'],r['category'])for r in allow['files']})==len(allow['files']),'duplicate_source_role')
    for r in allow['files']:
        safe_rel(r['role'])
        require(r['kind']in ('python','json','text') and r['category']in ROLES,'source_type_category')
        require(r['mode']in ('exact_or_known_shared_literal','root_reviewed_reference_derivative','private_original_only'),'explicit_source_representation')
        if r['mode']!='exact_or_known_shared_literal':
            require(r['category']not in ('original_service','continued_service'),'preserve_qualified14_service_versions')
            require(isinstance(r['limitation'],str) and r['limitation'] and len(r['limitation'])<=4096,'source_limitation_required')
    return declared


def prepare_public(adm,analysis,export):
    root=Path(adm['export_manifest']['path']).parent
    actual={str(p.relative_to(root))for p in root.rglob('*')if p.is_file()}
    require(actual==set(export['files'])|{'root_cells.proposed.private.json','export_manifest.private.json'},'strict_export_directory_coverage')
    records={};documents={r['cell_id']:{}for r in analysis['rows']}
    for rel,h in export['files'].items():
        safe_rel(rel);raw=D.bound_read({'path':str(root/rel),'sha256':h},4<<20)
        parts=Path(rel).parts
        if rel in ('public_runtime_continuation_contract.json','continuation_verification_bindings.private.json'):
            if rel=='public_runtime_continuation_contract.json':require(digest(raw)==adm['continuation_contract']['sha256'],'export_contract_hash')
            continue  # Private path maps are custody only; contract released separately.
        require(len(parts)==3 and parts[0]=='host_receipts' and parts[1]in documents and parts[2]in PUBLIC_NAMES,'public_export_allowlist')
        documents[parts[1]][parts[2]]=D.strict_json(raw)
        new,meta=D.derive_record(raw,public_record_name=parts[2]);records['evidence/'+rel]=(new,raw,meta['representation'])
        require(sum(len(x[0])for x in records.values())<=MAX_BYTES,'public_evidence_quota')
    for row in analysis['rows']:
        docs=documents[row['cell_id']]
        require({'request.json','offer.json','response.json','proposal.json','client_export_manifest.json'}<=set(docs),'public_cell_coverage')
        request=docs['request.json'];require(request==docs['offer.json']['request'] and request['cell_id']==row['cell_id'],'public_request_join')
        original='proposal.json'if row['original_receipt_filename']=='proposal_result.json'else'response.json'
        member='host_receipts/'+row['cell_id']+'/'+original
        require(export['files'][member]==row['original_signed_receipt_sha256'],'signed_original_identity')
        body=docs[original]['receipt']
        require(body['cell_id']==row['cell_id'] and body['inert_qualification']is False and body['final_scientific_run']is True,'actual_signed_body_type')
        require(body['request_sha256']==analysis['request_profile_lineage'][row['unit']][row['arm']]['request_sha256'],'scientific_request_hash')
    return records,documents


def candidate_gate(adm,analysis,candidates,documents):
    require(candidates['schema']=='ns-final32-reviewed-candidate-payloads/v1' and candidates['actual_complete32']is True and
            candidates['public_edit_payloads_only']is True and candidates['analysis']==adm['analysis'] and
            candidates['ordered_cells']==adm['ordered_cells'] and set(candidates['cells'])==set(adm['ordered_cells']) and
            candidates['exporter_sha256']==CANDIDATE_EXPORTER_SHA,'reviewed_complete32_candidates')
    root=Path(adm['candidate_payload_manifest']['path']).parent
    expected_files=candidates['files'];actual={str(p.relative_to(root))for p in root.rglob('*')if p.is_file()}
    require(actual==set(expected_files)|{'candidate_payload_manifest.private.json'},'candidate_directory_coverage')
    payload={};seen=set();manifest_cells={}
    for row in analysis['rows']:
        cid=row['cell_id'];entry=candidates['cells'][cid];docs=documents[cid]
        name='proposal.json'if row['original_receipt_filename']=='proposal_result.json'else'response.json'
        body=docs[name]['receipt'];candidate_sha=body.get('candidate_sha256')
        if candidate_sha is None:
            require(entry=={'candidate_present':False,'reason':'no_candidate_in_original_signed_receipt'},'candidate_absence')
            manifest_cells[cid]=entry;continue
        require(entry['candidate_present']is True and entry['public_edit_payloads_only']is True,'candidate_required_bytes')
        cbraw=D.bound_read(entry['candidate_binding'],4<<20);cb=D.strict_json(cbraw)
        require(cb['sha256']==candidate_sha==digest(canonical(cb['files'])),'candidate_inventory_hash')
        require(set(entry['changed_files'])==set(cb['changed_paths']) and len(cb['changed_paths'])==len(set(cb['changed_paths'])),'candidate_changed_file_set')
        require(sum(cb['files'][p]['bytes']for p in cb['changed_paths'])<=64<<20,'candidate_cell_byte_quota')
        patch=D.bound_read(entry['patch'],16384)
        require(digest(patch)==cb['patch_sha256'] and len(patch)==cb['patch_bytes'],'signed_patch_hash')
        if 'operator_review.json'in docs:
            rb=docs['operator_review.json']['binding']
            require(rb['candidate_sha256']==candidate_sha and rb['patch_sha256']==cb['patch_sha256'] and rb['candidate_binding_sha256']==digest(canonical(cb)),'pre_score_review_candidate_join')
        else:
            require(row['disposition_class']=='known_proposal_failure' and entry['review_scope']=='no_candidate_review_before_original_proposal_failure','absent_candidate_review_scope')
        values={'candidate_binding.json':(cbraw,entry['candidate_binding']),'candidate.patch':(patch,entry['patch'])}
        for rel,ref in entry['changed_files'].items():
            safe_rel(rel);raw=D.bound_read(ref,16<<20);spec=cb['files'][rel]
            require(spec['kind']=='file' and len(raw)==spec['bytes'] and digest(raw)==spec['sha256'],'sealed_changed_file_bytes')
            values['changed/'+rel]=(raw,ref)
        for rel,(raw,ref)in values.items():
            member='candidates/'+cid+'/'+rel;safe_rel(member)
            require(Path(ref['path'])==root/member and expected_files[member]=={'sha256':digest(raw),'bytes':len(raw)},'candidate_export_member_join')
            D.safe_text(raw.decode('utf-8'));seen.add(member);payload[member]=(raw,raw,'byte_exact_public_candidate')
            require(sum(len(x[0])for x in payload.values())<=MAX_BYTES,'candidate_payload_quota')
        manifest_cells[cid]={'candidate_present':True,'candidate_sha256':candidate_sha,'patch_sha256':cb['patch_sha256'],
                             'patch_bytes':cb['patch_bytes'],'changed_paths':cb['changed_paths'],'review_scope':entry['review_scope']}
    require(seen==set(expected_files),'all_candidate_members_covered')
    return payload,manifest_cells


def portable_phases(costs,adm,analysis):
    require(costs['schema']=='ns-final32-operator-host-phase-costs/v1' and costs['actual_complete32']is True and
            costs['analysis']==adm['analysis'] and costs['continuation_contract']==adm['continuation_contract'] and
            costs['ordered_cells']==adm['ordered_cells'] and set(costs['cells'])==set(adm['ordered_cells']) and
            costs['all_signed_clocks_unchanged']is True and costs['frozen_analysis_policy_changed']is False,'phase_cost_complete_scope')
    # Keep all phase scalar fields; replace only execution path with an original
    # digest identifier. No sum, imputation or new resource-compliance verdict.
    helper_source=(HERE/'frozen/export_operator_phase_costs.py').read_bytes()
    require(digest(helper_source)=='efc9a050dc3c89f73bda163d1c15753c0df5c25308fece3bf369534b9bff36e1','frozen_phase_projection_source')
    nodes=[n for n in ast.parse(helper_source).body if (isinstance(n,ast.FunctionDef) and n.name=='measured_record') or
           (isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ('SCOPE','PHASES'))]
    g={'math':math};exec(compile(ast.Module(body=nodes,type_ignores=[]),'<frozen-phase-projection>','exec'),g)
    cells={}
    for row in analysis['rows']:
        cell=costs['cells'][row['cell_id']];require(cell['number']==row['number'] and cell['runtime_source_provenance']==row['runtime_source_provenance'],'phase_order_runtime')
        require(set(g['PHASES'])<=set(cell['records']) and all(p in g['PHASES'] or re.fullmatch(r'poll_command[0-9]{3}',p)for p in cell['records']),'phase_name_coverage')
        records={}
        for phase,item in cell['records'].items():
            require(item['phase']==phase and item['summed_with_nested_clocks']is False and item['changes_signed_compliance']is False,'phase_timer_scope')
            value=dict(item)
            if item['execution']is not None:
                ref=item['execution'];e=bound(ref,1<<20)
                require(g['measured_record'](e,ref,phase)==item,'phase_measured_scalar')
                value['execution']={'original_sha256':ref['sha256'],'private_original_only':True}
            else:require(item['elapsed_host_wall_seconds']is None and item['measured']is False,'missing_phase_not_zero')
            records[phase]=value
        cells[row['cell_id']]={'number':row['number'],'records':records}
    return {'schema':'ns-final32-portable-phase-cost-projection/v1','original_manifest_sha256':adm['operator_phase_cost_manifest']['sha256'],
            'scope':costs['scope'],'cells':cells,'signed_clocks_unchanged':True,'no_clock_sums_added':True}


def extract_release(archive,destination,maximum):
    require(not destination.exists(),'fresh_extraction')
    with zipfile.ZipFile(archive)as z:
        infos=z.infolist();require(0<len(infos)<=4096 and len({i.filename for i in infos})==len(infos),'zip_member_count_or_duplicate')
        require(sum(i.file_size for i in infos)<=maximum,'zip_expanded_quota')
        for info in infos:
            safe_rel(info.filename)
            require(not info.is_dir() and stat.S_IFMT(info.external_attr>>16)in (0,stat.S_IFREG),'zip_nonregular_member')
        destination.mkdir()
        for info in infos:
            raw=z.read(info);require(len(raw)==info.file_size,'zip_member_size_crc')
            D.write_new(destination/info.filename,raw)


def build(adm,output):
    # Complete metadata gates run before public/candidate reads or output writes.
    require(adm.get('approved')is True and adm.get('fixture')is False and adm.get('allow_partial')is False,'actual_root_admission_first')
    require(adm['builder_sha256']==digest(Path(__file__).read_bytes()) and adm['reproducer_sha256']==digest((HERE/'reproduce.py').read_bytes()),'release_source_binding')
    a=bound(adm['activation']);an=bound(adm['analysis']);ex=bound(adm['export_manifest']);review=bound(adm['root_complete_review']);freeze=bound(a['freeze'])
    rows,summary=actual_gate(adm,a,an,ex,review,freeze)
    for key in ('analysis_package','adoption_package','analysis_bindings','public_baseline_manifest','validation_disclosures','operator_phase_cost_manifest','continuation_contract','source_allowlist'):
        bound(adm[key])
    # Recheck all exact bounded metadata inputs already retained by strict analysis.
    for path,h in bound(adm['analysis_bindings']).items():D.bound_read({'path':path,'sha256':h},16<<20)
    contract=bound(adm['continuation_contract']);allow=bound(adm['source_allowlist'])
    declared=source_guard(allow,adm,contract,freeze)
    records,documents=prepare_public(adm,an,ex)
    payload,cells=candidate_gate(adm,an,bound(adm['candidate_payload_manifest']),documents);records.update(payload)
    original_input_hashes={k:adm[k]['sha256']for k in REVIEW_KEYS}
    def add(member,raw,original=None,kind='derived_portable_projection'):
        safe_rel(member);require(member not in records,'duplicate_release_member')
        D.safe_text(raw.decode());require(sum(len(x[0])for x in records.values())+len(raw)<=adm['max_artifact_bytes'],'incremental_artifact_quota')
        records[member]=(raw,original,kind)
    add('data/statistical_rows.json',encoded({'schema':'ns-final32-exact-statistical-input-projection/v1','analysis_original_sha256':adm['analysis']['sha256'],'rows':rows}))
    add('tables/expected_summary.json',encoded(summary))
    context_keys=('observed_api_usage','actual_provider_posts','actual_cold_completed','scorer_reservations_observed','boundary_unqualified_cells','unknown_external_charge_cells','comparison_scope','statistical_scope','cost_scope','request_profile_lineage')
    add('data/analysis_context.json',encoded({k:an[k]for k in context_keys}))
    add('data/candidate_manifest.json',encoded({'schema':'ns-final32-portable-candidate-inventory/v1','original_manifest_sha256':adm['candidate_payload_manifest']['sha256'],'cells':cells}))
    add('data/operator_phase_costs.json',encoded(portable_phases(bound(adm['operator_phase_cost_manifest']),adm,an)))
    raw=D.bound_read(adm['continuation_contract']);out,meta=D.derive_record(raw)
    add('metadata/runtime_contract.unsigned.json',out,raw,meta['representation'])
    source_index=[];written={}
    for entry in allow['files']:
        raw=D.bound_read(entry['source'],16<<20);h=digest(raw)
        if entry['mode']=='private_original_only':
            source_index.append({'role':entry['role'],'category':entry['category'],'original_sha256':h,'member':None,
                                 'representation':'private_executed_original_not_released','limitation':entry['limitation']});continue
        if entry['mode']=='root_reviewed_reference_derivative':
            out=D.bound_read(entry['derived'],16<<20);kind='root_reviewed_public_source_reference_not_executed'
            if entry['kind']=='python':
                def comments(data):return [t.string for t in tokenize.generate_tokens(io.StringIO(data.decode()).readline)if t.type==tokenize.COMMENT]
                require(comments(raw)==comments(out),'root_source_derivative_comments_notices_changed')
            if entry['kind']=='json':
                checked,_=D.derive_record(out);require(checked==out,'derived_json_still_identifying')
        elif entry['kind']=='python':out,kind=D.derive_source(raw)
        elif entry['kind']=='json':out,meta=D.derive_record(raw);kind=meta['representation']
        else:out=raw;kind='byte_exact_executed_source';D.safe_text(out.decode())
        member='source/objects/'+h+'/'+safe_rel(entry['role'])
        if member not in written:add(member,out,raw,kind);written[member]=digest(out)
        else:require(written[member]==digest(out),'source_alias_conflict')
        source_index.append({'role':entry['role'],'category':entry['category'],'original_sha256':h,'derived_sha256':digest(out),
                             'member':member,'representation':kind,'limitation':entry.get('limitation')})
    # Required exact12 and labeled2 service source versions cannot silently vanish.
    service_hashes=set(declared.values());service_entries={e['original_sha256']:e for e in source_index if e['original_sha256']in service_hashes}
    require(len(service_entries)==14 and sum(e['representation']=='public_source_reference_derivative_not_executed'for e in service_entries.values())==2 and
            sum(e['original_sha256']==e.get('derived_sha256')for e in service_entries.values())==12,'qualified14_service_representations')
    add('metadata/source_provenance.json',encoded({'schema':'ns-final32-portable-source-lineage/v1','sources':source_index,'original_immutable_pins':freeze['immutable_pins'],'original_signature_source_replay_limitations_explicit':True}))
    baselines=bound(adm['public_baseline_manifest']);require(baselines['schema']=='ns-final8-public-baseline-reproduction/v1' and set(baselines['units'])==set(R.statistics((HERE/'frozen/analyze.py').read_bytes())['UNITS']),'baseline8')
    retrieval={}
    for unit,b in baselines['units'].items():
        require(b['public_repository_source_only']is True and b['oracle_or_reference_patch_included']is False and b['archive']['sha256']==b['source_archive_sha256'],'baseline_public_scope')
        url=b['public_retrieval_url'];require(url.startswith('https://') and '@'not in url,'public_retrieval_url')
        item={k:b[k]for k in ('source_archive_sha256','public_retrieval_url','upstream_revision','license_status')}
        if b['license_status']=='retained_license':
            raw=D.bound_read(b['license']);member='licenses/'+unit+'.txt';add(member,raw,raw,'byte_exact_upstream_license');item['license_member']=member
        else:require(b['license_status']=='explicit_redistribution_limitation' and b['license_limitation'],'license_scope');item['license_limitation']=b['license_limitation']
        retrieval[unit]=item
    add('metadata/baseline_retrieval.json',encoded({'schema':'ns-final8-public-baseline-retrieval-projection/v1','units':retrieval,'archives_downloaded_by_this_tool':False,'hidden_oracle_or_reference_payloads_released':False}))
    # Preserve additive disclosed validation categories without raw private logs.
    disclosures=bound(adm['validation_disclosures']);require(disclosures['actual_complete32']is True and disclosures['analysis']==adm['analysis'] and disclosures['changes_signed_outcomes']is False and disclosures['changes_protocol_or_denominator']is False,'disclosure_scope')
    clean=[];byid={r['cell_id']:r for r in an['rows']}
    for x in disclosures['records']:
        row=byid[x['cell_id']];require(x['sanitized_only']is True and x['hidden_names_source_or_raw_logs_included']is False and x['signed_outcome']==row['outcome'] and x['useful_completion']is row['useful_completion'],'disclosure_signed_outcome')
        y=dict(x);y['evidence']=[{'original_sha256':r['sha256'],'private_original_only':True}for r in x['evidence']]
        if x['category']=='incomplete_hidden_validation_import_failure':require(row['hidden_collected']==0 and row['useful_completion']is False and x['hidden_assertion_failure_observed']is False and x['infrastructure_fault_proven']is False,'incomplete_hidden_validation_not_assertion')
        clean.append(y)
    add('data/validation_disclosures.json',encoded({'schema':'ns-final32-portable-validation-disclosure-projection/v1','original_sha256':adm['validation_disclosures']['sha256'],'records':clean}))
    # Previously charged ledgers remain referenced and explicitly not pooled.
    add('metadata/prior_cost_lineage.json',encoded({'scope':an['cost_scope'],'ledgers':[{k:v for k,v in x.items()if k!='path'}for x in an['prior_and_preparation_cost_ledgers']],
        'original_analysis_sha256':adm['analysis']['sha256'],'prior_measurements_not_fabricated_or_pooled':True,'limitation':'Prior signed originals and detailed private custody remain separate; this projection does not turn missing settlement into zero.'}))
    for src,rel in [('reproduce.py','reproduce.py'),('frozen/analyze.py','source/frozen/analyze.py'),('RELEASE_README.md','README.md')]:add(rel,(HERE/src).read_bytes(),(HERE/src).read_bytes(),'byte_exact_reproduction_source')
    require(digest(records['source/frozen/analyze.py'][0])==R.ANALYZER_SHA,'frozen_statistics_export')
    output=Path(output);require(output.is_absolute() and output.resolve()==output and not output.exists(),'fresh_output')
    index={rel:{'sha256':digest(raw),'bytes':len(raw),'original_sha256':None if original is None else digest(original),'representation':kind}
           for rel,(raw,original,kind)in records.items()}
    manifest={'schema':'ns-final32-anonymous-release-manifest/v1','complete_actual32':True,'publication_approved':False,
              'original_signatures_authenticate_derivatives':False,'private_original_signature_replay_performed':False,
              'numerical_replay_authenticates_unsigned_data':False,'original_signature_replay_requires_private_original_bodies':True,
              'hidden_oracle_or_reference_payloads_released':False,'original_identifying_executed_sources_retained_privately':True,
              'public_source_reference_derivatives_are_executed_versions':False,
              'builder_sha256':adm['builder_sha256'],'reproducer_sha256':adm['reproducer_sha256'],'original_input_hashes':original_input_hashes,
              'files':index,'ordered_cells':adm['ordered_cells'],'frozen_statistics_sha256':R.ANALYZER_SHA,'original_freeze_sha256':FREEZE_FILE_SHA,
              'actual_scientific_calls':0,'native_calls':0,'archive_originals_and_source_derivatives_distinguished':True,
              'scope':'Local anonymous candidate artifact from root-reviewed actual32. Numerical reproduction is separate from private original signatures, held-out oracle replay and executed-source identity.'}
    total=sum(len(v[0])for v in records.values())+len(encoded(manifest));require(total<=adm['max_artifact_bytes'],'measured_uncompressed_artifact_quota')
    # All science, privacy and size guards have passed before materialization.
    output.mkdir(mode=0o700);release=output/'release';release.mkdir()
    for rel,(raw,_,_)in records.items():D.write_new(release/rel,raw)
    D.write_new(release/'release_manifest.json',encoded(manifest))
    R.check_expected(*R.load_release(release))
    archive=output/'supplement.zip'
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
        for p in sorted(release.rglob('*')):
            if p.is_file():
                rel=str(p.relative_to(release));info=zipfile.ZipInfo(rel,date_time=(1980,1,1,0,0,0));info.external_attr=0o100600<<16
                z.writestr(info,p.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
    require(archive.stat().st_size<=adm['max_artifact_bytes'],'measured_zip_quota')
    with tempfile.TemporaryDirectory(prefix='release-clean-extract-',dir=output)as temp:
        extracted=Path(temp)/'release'
        extract_release(archive,extracted,adm['max_artifact_bytes'])
        R.check_expected(*R.load_release(extracted))
    result={'schema':'ns-final32-anonymous-local-artifact-result/v1','success':True,'release_manifest_sha256':digest(encoded(manifest)),
            'zip_sha256':digest(archive.read_bytes()),'zip_bytes':archive.stat().st_size,'uncompressed_bytes':total,'members':len(index)+1,
            'complete_table_equality':True,'fresh_zip_extraction_reproduction_passed':True,'publication_approved':False,'scientific_calls':0,'native_calls':0}
    D.write_new(output/'result.private.json',encoded(result));return result


def main():
    p=argparse.ArgumentParser();p.add_argument('--admission',type=Path,required=True);p.add_argument('--sha256',required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();adm=bound({'path':str(a.admission),'sha256':a.sha256});print(json.dumps(build(adm,a.output)))

if __name__=='__main__':main()
