"""Assemble only saved successful native final preparation; no new native execution."""
import sys
sys.dont_write_bytecode=True
import json,hashlib,os
from pathlib import Path
Q=Path(__file__).resolve().parent
RUNS={'ns-hist-09-tomlkit':'ns-hist-09-tomlkit-v2','ns-hist-10-installer':'ns-hist-10-installer-v1','ns-hist-11-tornado':'ns-hist-11-tornado-v1','ns-hist-12-more-itertools':'ns-hist-12-more-itertools-v1','ns-hist-13-charset_normalizer':'ns-hist-13-charset-normalizer-v1','ns-hist-14-iniconfig':'ns-hist-14-iniconfig-v1','ns-hist-15-wheel':'ns-hist-15-wheel-v1','ns-hist-16-jinja':'ns-hist-16-jinja-v1'}
PINS={'external/ipfs_accelerate':'60baee769d39a53c52142c56fbf6ed7483773aa3','external/ipfs_datasets':'b9686e09beb4973fea13a9c6d93d40b6d2741366','external/ipfs_kit':'6196017ca3df016c7159dce43af60f2a0d96a9ae'}
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
canon=lambda x:json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def load(p):return json.loads(Path(p).read_bytes())
def ref(p):return {'path':str(p),'sha256':sha(p)}
def save(p,x):
 raw=(json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode();fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 with os.fdopen(fd,'wb')as f:f.write(raw);f.flush();os.fsync(f.fileno())
def main():
 os.umask(0o077);assert sha(Q/'run_context_preparation_caveat_v2.py')=='171fbc492df3c9e7231e954674cf1fde0a5fec1eda733a107d5d5a147e420a4e';source=Q/'service_native_v2/final_service/semantic_context.py';source_sha=sha(source);im=Q/'public_inputs_v1/manifest.private.json';inputs=load(im);assert set(inputs['units'])==set(RUNS)
 packets={};records={};effective=[]
 for unit,attempt in RUNS.items():
  root=Q/'context_runs'/attempt;out=root/'output';qp=root/'qualification.private.json';q=load(qp);r=load(out/'result.json');plan=load(root/'plan.json');inv=load(root/'invocation.json');final=load(root/'final_inspect.json');cleanup=load(root/'cleanup.json');boundary=load(root/'boundary.json');h=boundary['HostConfig']
  assert q['success'] and q['pending'] is None and q['cleanup_exit_code']==q['exit_code']==0 and q['plan_sha256']==sha(root/'plan.json') and q['receipt_sha256']==sha(out/'result.json') and q['log_sha256']==sha(out/'context_execution.log')
  assert r['success'] and not r['preflight_only'] and r['native_source_pins']==PINS and r['semantic_source_sha256']==source_sha and not r['provider_calls'] and not r['scorer_calls'] and not r['target_source_executed'] and not r['oracle_read']
  assert inv['unit']==unit and inv['native_source_pins']==PINS and inv['input_manifest']==ref(im) and inv['semantic_source_sha256']==source_sha and plan['native_dependency_pins']==PINS
  assert final['Id']==boundary['Id']==cleanup['cid'] and not final['State']['Running'] and not final['State']['OOMKilled'] and final['State']['ExitCode']==cleanup['returncode']==0
  assert h['NetworkMode']=='none' and h['NanoCpus']==1000000000 and h['Memory']==h['MemorySwap']==2147483648 and h['PidsLimit']==32 and h['ReadonlyRootfs'] and h['CapDrop']==['ALL'] and not h['Privileged']
  assert plan['wall_seconds']==600 and not plan['scientific_calls'] and plan['runtime_profile_sha256']=='1bc2c65388bc5a79ae61e762653d336ae5401e7b0d592d265884d2ab166a8f84'
  assert plan['script_sha256']==q['script_sha256']==sha(Q/'context_prepare_child.py')
  effective.append({'native_source_pins':PINS,'semantic_source_sha256':source_sha,'runtime_profile_sha256':plan['runtime_profile_sha256'],'runtime_manifest_sha256':plan['runtime_manifest_sha256'],'image':boundary['Image'],'context_prepare_child_sha256':plan['script_sha256']})
  prepared=load(out/'native_preparation.json');assert prepared['schema']=='ns-native-semantic-context-preparation/v1' and 1<=len(prepared['records'])<=4 and prepared['index_counts']['records_selected']==len(prepared['records']) and prepared['source_before_after_equal'] and not prepared['target_source_executed'] and not prepared['oracle_read']
  assert r['units'][0]['unit']==unit and r['units'][0]['native_preparation_sha256']==sha(out/'native_preparation.json')
  meta=inputs['units'][unit];assert sha(meta['path'])==meta['sha256'];v=load(meta['path']);bindings={a:load(out/(a+'_binding.json'))for a in ('A','B')}
  for a in ('A','B'):
   req=load(out/(a+'_request.json'));assert hashlib.sha256(canon(req)).hexdigest()==bindings[a]['request_sha256'] and len(canon(req))==bindings[a]['request_bytes']<=65536
  assert bindings['A']['selected_spans']==bindings['B']['selected_spans'] and bindings['A']['omitted_spans']==bindings['B']['omitted_spans'] and bindings['A']['request_sha256']!=bindings['B']['request_sha256']
  provenance={'container_report':ref(qp),'native_execution':ref(out/'result.json'),'native_source_pins':PINS,'native_overlays':{},'research_profile_sha256':plan['runtime_profile_sha256'],'research_manifest_sha256':plan['runtime_manifest_sha256'],'native_builder_source_commit':PINS['external/ipfs_datasets'],'native_context_pack_source_sha256':'5724b1e870b28875a073cd84e836af9312ff9b4d5a742271486ae64ff32a9168','boundary':ref(root/'boundary.json'),'cleanup':ref(root/'cleanup.json')}
  packets[unit]={'schema':'ns-pilot-AB-prepared-public-context/v1','unit_id':unit,'source_archive_sha256':v['archive_sha256'],'semantic_source_sha256':source_sha,'preparation_source_provenance':provenance,'native_preparation':prepared,'bindings':bindings,'request_sha256':{a:bindings[a]['request_sha256']for a in ('A','B')}}
  records[unit]={'attempt':attempt,'container_report':ref(qp),'execution':ref(out/'result.json'),'native_preparation':ref(out/'native_preparation.json'),'requests':{a:ref(out/(a+'_request.json'))for a in ('A','B')},'bindings':{a:ref(out/(a+'_binding.json'))for a in ('A','B')},'analysis_paths':prepared['analysis_paths'],'unindexed_public_paths':prepared['unindexed_public_paths'],'records_selected':len(prepared['records']),'native_dependency_frontier_rows':len(prepared['native_analysis_dependency_frontier']),'source_unchanged':True,'child_cpu_seconds':r['cpu_seconds'],'child_wall_seconds':r['wall_seconds'],'host_wall_seconds':q['wall_seconds'],'peak_rss_kib':r['peak_rss_kib']}
 assert all(x==effective[0]for x in effective)
 history=[]
 for root in sorted((Q/'context_runs').iterdir()):
  p=root/'qualification.private.json'
  if not p.exists():continue
  q=load(p);item={'attempt':root.name,'qualification':ref(p),'success':q['success'],'cleanup_exit_code':q.get('cleanup_exit_code'),'host_wall_seconds':q.get('wall_seconds'),'pending':q.get('pending'),'scientific_calls':0}
  for name in ['result.json','failure.json']:
   f=root/'output'/name
   if f.exists():
    r=load(f);item[name]=ref(f);item['child_cpu_seconds']=r.get('cpu_seconds');item['child_wall_seconds']=r.get('wall_seconds')
  history.append(item)
 dest=Q/'prepared_contexts_v1';assert not dest.exists();dest.mkdir(mode=0o700);manifest={'schema':'ns-final-native-context-preparation-manifest/v1','units':{}}
 for unit,packet in sorted(packets.items()):
  p=dest/(unit+'.private.json');save(p,packet);assert p.stat().st_size<=16*1024*1024;manifest['units'][unit]=ref(p)
 mp=dest/'manifest.private.json';save(mp,manifest)
 report={'schema':'ns-final-eight-actual-native-context-qualification/v1','success':True,'units':records,'manifest':ref(mp),'public_input_manifest':ref(im),'semantic_source':ref(source),'identical_effective_native_sources_for_all_eight':True,'effective_native_source':effective[0],'preparation_launcher':ref(Q/'run_context_preparation_caveat_v2.py'),'preparation_child':ref(Q/'context_prepare_child.py'),'assembler':ref(Path(__file__).resolve()),'preparation_attempts':history,'repair_qualification_package':ref(Q/'native_caveat_union_recovery_v1/package.private.json'),'shared_preparation_across_repetitions':True,'preparation_costs_separate_from_fresh_cold_scoring':True,'cost_rule':'Each preparation attempt retained once; per-unit records index the same successful attempts and are not additive duplicates. Host and child clocks overlap. Input preflight and failed setup/repair controls remain separately retained.','per_unit_setup_wall_cap_seconds':600,'actual_provider_calls':0,'actual_scorer_calls':0,'hidden_oracle_payloads_read':False,'target_source_executed':False,'final_model_or_score_outcomes_observed':0,'limits':['No whole-repository semantic-analysis claim; complete unchanged public universe remains bound and semantic analysis paths are explicit.','No capsule/frontier/proof data omitted from prepared packets.','Raw public spans are identical across both arms; model request policy and population remain unchanged.','Preparation is setup, not final scientific outcome or admission.']}
 rp=Q/'actual_final_context_qualification.private.json';save(rp,report);print(json.dumps({'manifest':ref(mp),'qualification':ref(rp)}))
if __name__=='__main__':main()
