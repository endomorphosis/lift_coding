"""Actual native public preparation; never imports target code or oracle data."""
import sys
sys.dont_write_bytecode = True
import hashlib, json, os, resource, time, traceback
from pathlib import Path

Q = Path('/qualification-output')
CFG = json.loads(Path('/qualification/invocation.json').read_text())
os.environ.update(IPFS_ACCEL_SKIP_CORE='1', IPFS_AUTO_INSTALL='false',
                  IPFS_DATASETS_AUTO_INSTALL='false', IPFS_KIT_AUTO_INSTALL='false',
                  PYTHONDONTWRITEBYTECODE='1')
sys.path[:0] = [CFG[k] for k in ('service_source', 'accelerate_source',
                                'datasets_source', 'kit_source', 'runtime_python')]
import semantic_context as C

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(name, obj):
    raw = (json.dumps(obj, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()
    fd = os.open(Q/name, os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'wb') as f: f.write(raw); f.flush(); os.fsync(f.fileno())

def main():
    start, cpu = time.monotonic(), time.process_time()
    assert sha(C.__file__) == CFG['semantic_source_sha256']
    manifest = json.loads(Path(CFG['input_manifest']['path']).read_text())
    assert sha(CFG['input_manifest']['path']) == CFG['input_manifest']['sha256']
    selected = list(manifest['units']) if CFG['preflight_only'] else [CFG['unit']]
    records = []
    def phase(name):
        row = {'phase':name,'wall_seconds':time.monotonic()-start,
               'cpu_seconds':time.process_time()-cpu,'unit':CFG['unit']}
        with (Q/'phase_times.jsonl').open('a') as f:
            f.write(json.dumps(row)+'\n'); f.flush(); os.fsync(f.fileno())
        print(json.dumps(row), flush=True)
    try:
        for unit in selected:
            meta = manifest['units'][unit]
            assert sha(meta['path']) == meta['sha256']
            value = json.loads(Path(meta['path']).read_text())
            args = [value[k] for k in ('instruction','files','allowed_edit_paths','public_test_paths')]
            if CFG['preflight_only']:
                _, _, contract = C.native_input_contract(*args)
                records.append({'unit':unit,'coverage_satisfied':contract.coverage_satisfied,
                                'budget_exceeded':contract.budget_exceeded,'pack_cid':contract.pack_cid})
                continue
            inventory = C.validate_files(value['files'],value['allowed_edit_paths'],value['public_test_paths'])
            prepared = C.prepare_native(Path('/tmp/ns-pilot-native-context')/C.digest(inventory), *args, phase=phase)
            requests, bindings = {}, {}
            for arm in ('A','B'):
                requests[arm], bindings[arm] = C.request(*args,arm,prepared if arm=='B' else None)
                save(arm+'_request.json',requests[arm]); save(arm+'_binding.json',bindings[arm])
            assert requests['A'] != requests['B']
            assert all(len(C.canon(r)) <= 65536 for r in requests.values())
            assert bindings['A']['selected_spans'] == bindings['B']['selected_spans']
            assert bindings['A']['omitted_spans'] == bindings['B']['omitted_spans']
            save('native_preparation.json', prepared)
            records.append({'unit':unit,'request_bytes':{a:len(C.canon(r))for a,r in requests.items()},
                            'records_selected':len(prepared['records']),
                            'native_preparation_sha256':sha(Q/'native_preparation.json'),
                            'common_raw_spans_equal':True,'native_counts':prepared['index_counts']})
        result = {'schema':'ns-final-actual-native-context-execution/v1','success':True,
                  'preflight_only':CFG['preflight_only'],'units':records,
                  'wall_seconds':time.monotonic()-start,'cpu_seconds':time.process_time()-cpu,
                  'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                  'semantic_source_sha256':sha(C.__file__),'native_source_pins':CFG['native_source_pins'],
                  'provider_calls':0,'scorer_calls':0,'target_source_executed':False,'oracle_read':False}
        save('result.json',result); print(json.dumps(result),flush=True)
    except BaseException as exc:
        save('failure.json',{'error':str(exc),'traceback':traceback.format_exc(),
                             'wall_seconds':time.monotonic()-start,'cpu_seconds':time.process_time()-cpu})
        raise

if __name__ == '__main__': main()
