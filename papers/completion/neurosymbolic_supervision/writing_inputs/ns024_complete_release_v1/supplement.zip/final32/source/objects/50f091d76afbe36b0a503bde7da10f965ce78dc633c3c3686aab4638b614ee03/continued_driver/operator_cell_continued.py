"""Root operator orchestration of the separately admitted fixed final32 cohort.

Each invocation performs one named phase. Candidate approval is deliberately
absent: the coordinating AI operator must read the sealed patch and write its bound review.
This helper creates no approval of its own; the root supplies exact activation authority.
Existing host/client implementations retain all scientific validation/effects.
"""
import sys
sys.dont_write_bytecode = True
import argparse
import datetime as dt
import hashlib
import json
import os
import re
import stat
import time
from pathlib import Path
import subprocess
import importlib.util

ROUTE = Path(__file__).resolve().parent
HERE = ROUTE.parents[1] / "actual_final_v1"
DRIVER = ROUTE / 'offline_client'
PY = '/anonymous-runtime/operator-root/lift_coding/.venvs/ipfs-datasets-duckdb-quack/bin/python'
HOST = Path('/anonymous-runtime/operator-root/.local/state/ipfs_accelerate_py/vericodegen-2026/research-inputs/neurosymbolic_supervision/final-host-ab-cold-20260913-v1')
NATIVE_HEAD = '60baee769d39a53c52142c56fbf6ed7483773aa3'
ORIGINAL_PLAN_SHA = '6ed6e590479d7d71bdcc9cc67fc7cccf51b05230c0f6761fcd7c520bece2ac80'
PAPER = Path('papers/completion/neurosymbolic_supervision')
SERVICE = PAPER / 'qualification/production_provider/pilot_service/final_service'
UNITS = ('ns-hist-09-tomlkit','ns-hist-10-installer','ns-hist-11-tornado',
         'ns-hist-12-more-itertools','ns-hist-13-charset_normalizer','ns-hist-14-iniconfig',
         'ns-hist-15-wheel','ns-hist-16-jinja')
ACTIVATION = None
PACKAGE = None


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_json_bytes(path):
    path = Path(path)
    require(path.is_absolute() and path.resolve() == path, 'canonical input required')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        info = os.fstat(fd)
        require(stat.S_ISREG(info.st_mode) and info.st_size <= 16*1024*1024, 'bounded JSON input required')
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            raw = stream.read(16*1024*1024+1)
    finally:
        os.close(fd)
    require(len(raw) <= 16*1024*1024, 'JSON input grew')
    return raw


def load(path):
    return json.loads(read_json_bytes(path))


def bound(binding):
    require(isinstance(binding, dict) and set(binding) >= {'path','sha256'}
            and re.fullmatch('[a-f0-9]{64}', binding['sha256']) is not None, 'exact path/hash binding required')
    raw = read_json_bytes(binding['path'])
    require(hashlib.sha256(raw).hexdigest() == binding['sha256'], 'input changed: '+binding['path'])
    return json.loads(raw)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',',':'), allow_nan=False).encode()


def cell_id(unit, arm, repetition):
    require(unit in UNITS and arm in ('A','B') and type(repetition) is int
            and repetition in (104729,130363), 'fixed final cell identity differs')
    return hashlib.sha256(canonical({'unit':unit,'arm':arm,'cache':'local_cold',
                                     'repetition':repetition,'record_kind':'final'})).hexdigest()


CONTINUATION = None
ROUTE_PACKAGE = None
ACCOUNTING_ONLY = False

def checked_activation(path, expected):
    # Historical bytes retain their actual identities. The routing view below is
    # explicitly derived and is never written back as the original activation.
    original = HERE / 'operator_cell.py'
    require(sha(original) == '1b7c3db5492d9e389134cffb0ca97d03f7e7a64b1d4fbf6baad0c03fc7b5edc9', 'original operator changed')
    spec = importlib.util.spec_from_file_location('unchanged_original_operator', original)
    old = importlib.util.module_from_spec(spec); spec.loader.exec_module(old)
    a, historical_pkg = old.checked_activation(path, expected)
    plan = bound(ROUTE_PACKAGE)
    require(plan.get('schema') == 'ns-final-continuation-driver-admission/v1'
            and plan.get('approved') is True and plan.get('authority') == 'root_operator'
            and plan['original_activation'] == {'path': str(path), 'sha256': expected}
            and plan['continuation'] == CONTINUATION, 'exact continued driver admission required')
    require(plan['operator_source'] == {'path': str(Path(__file__).resolve()), 'sha256': sha(__file__)}, 'actual operator source differs')
    for ref in plan['source_files'].values():
        require(sha(ref['path']) == ref['sha256'], 'continued orchestration source drift')
    service = Path(plan['effective_service'])
    require(service.is_absolute() and service.resolve() == service, 'canonical effective service required')
    validator = service / 'lease_continuation.py'
    require(plan['lease_validator'] == {'path': str(validator), 'sha256': sha(validator)}, 'continuation validator differs')
    sys.path.insert(0, str(service))
    spec = importlib.util.spec_from_file_location('continued_operator_authority', validator)
    L = importlib.util.module_from_spec(spec); spec.loader.exec_module(L)
    authority = L.checked_authority(CONTINUATION['path'], CONTINUATION['sha256'], accounting_only=ACCOUNTING_ONLY)
    require(authority['effective_service'] == str(service), 'effective service routing differs')
    require(authority['original_activation'] == plan['original_activation'], 'continuation belongs to different activation')
    pause = HERE / 'final_execution_pause.private.json'
    require(sha(pause) == '28ccf69b1d26e912491b367ba651c7020521b54fe1da0ff1d384d5ebb1edd00b', 'original pause must remain preserved')
    pkg = bound(plan['offline_package'])
    review = bound(plan['offline_review'])
    require(review.get('accepted_for_continuation_offline_use') is True
            and review['package_sha256'] == plan['offline_package']['sha256'], 'actual continued offline qualification required')
    for rel, digest in pkg['package_files'].items():
        require(not Path(rel).is_absolute() and '..' not in Path(rel).parts and sha(DRIVER / rel) == digest, 'continued offline source drift')
    require(pkg['original_package'] == a['driver_package'] and pkg['source5'] == historical_pkg['source5']
            and pkg['batch'] == a['batch'] and pkg['worker_root'] == a['workspace']
            and pkg['queue_root'] == a['queue_root'] and pkg['ordered_cells'] == historical_pkg['ordered_cells']
            and pkg['host_package_sha256'] == historical_pkg['host_package_sha256']
            and pkg['image'] == historical_pkg['image']
            and pkg['profile_relative'] == historical_pkg['profile_relative']
            and pkg['profile_sha256'] == historical_pkg['profile_sha256']
            and pkg['record_kind'] == historical_pkg['record_kind'] == 'final'
            and pkg['root_operator_driver_amendment'] == historical_pkg['root_operator_driver_amendment'], 'original client/batch/scientific configuration changed')
    contract = bound(pkg['continuation_public_contract'])
    require(contract == L.public_contract(authority, CONTINUATION['path'], CONTINUATION['sha256']), 'public continuation contract differs')
    require(pkg['continuation_verifier']['sha256'] == authority['effective_source_bindings'][str(service / 'pilot_client.py')]
            and sha(pkg['continuation_verifier']['path']) == pkg['continuation_verifier']['sha256'], 'extra verifier is not actual host verifier')
    routing = dict(a)
    routing.update(host_service=str(service), host_source_files=authority['effective_source_bindings'],
                   offer_builder=plan['offer_builder'], driver_package=plan['offline_package'])
    require(plan['offer_builder']['path'] == str(ROUTE / 'build_offer_drop_continued.py')
            and sha(plan['offer_builder']['path']) == plan['offer_builder']['sha256'], 'continued offer builder differs')
    return routing, pkg


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def write(path, raw, mode=0o600):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, mode)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    fd = os.open(Path(path).parent, os.O_RDONLY | os.O_DIRECTORY)
    os.fsync(fd)
    os.close(fd)


def record(path, value):
    value = dict(value)
    value['runtime_continuation_authority'] = CONTINUATION
    value['continued_driver_admission'] = ROUTE_PACKAGE
    write(path, (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode())


def run(name, argv):
    target = HERE / name
    target.mkdir(mode=0o700)
    record(target / 'plan.private.json', {
        'at': now(), 'argv': argv, 'operator_script_sha256': sha(__file__),
        'activation_sha256': ACTIVATION, 'automatic_retry': False,
        'authoring_claim_execution': False,
    })
    started = time.monotonic()
    with (target / 'stdout.private.json').open('xb') as out, (target / 'stderr.private.txt').open('xb') as err:
        try:
            result = subprocess.run(argv, stdout=out, stderr=err)
        except BaseException as exc:
            out.flush(); err.flush(); os.fsync(out.fileno()); os.fsync(err.fileno())
            record(target / 'execution.private.json', {
                'at': now(), 'exit_code': None, 'exception_class': type(exc).__name__,
                'elapsed_host_wall_seconds': time.monotonic() - started,
                'pending': 'phase_outcome_unknown_requires_exact_reconciliation',
                'stdout_sha256': sha(target / 'stdout.private.json'),
                'stderr_sha256': sha(target / 'stderr.private.txt'),
                'automatic_retry': False,
            })
            raise
        out.flush(); err.flush()
        os.fsync(out.fileno()); os.fsync(err.fileno())
    record(target / 'execution.private.json', {
        'at': now(), 'exit_code': result.returncode,
        'elapsed_host_wall_seconds': time.monotonic() - started,
        'stdout_sha256': sha(target / 'stdout.private.json'),
        'stderr_sha256': sha(target / 'stderr.private.txt'),
        'automatic_retry': False,
    })
    require(result.returncode == 0, 'phase failed; retained evidence requires reconciliation, no replay: ' + name)
    return load(target / 'stdout.private.json')


def main():
    global ACTIVATION, PACKAGE, CONTINUATION, ROUTE_PACKAGE, ACCOUNTING_ONLY
    os.umask(0o077)
    parser = argparse.ArgumentParser()
    parser.add_argument('phase', choices=('prepare', 'poll', 'execute', 'review-template', 'score'))
    parser.add_argument('cell_number', type=int)
    parser.add_argument('--activation', type=Path, required=True)
    parser.add_argument('--activation-sha256', required=True)
    parser.add_argument('--check-only', action='store_true')
    parser.add_argument('--continuation', type=Path, required=True)
    parser.add_argument('--continuation-sha256', required=True)
    parser.add_argument('--continued-driver-admission', type=Path, required=True)
    parser.add_argument('--continued-driver-admission-sha256', required=True)
    args = parser.parse_args()
    if args.phase in ('prepare', 'execute', 'score'):
        require(not (HERE / 'continuation_execution_pause.private.json').exists(),
                'final batch is paused; preserve all consumed cells and reconcile before any new effect')
    require(8 <= args.cell_number <= 32, 'only the original unissued suffix8..32 may use this continuation')
    CONTINUATION = {'path': str(args.continuation), 'sha256': args.continuation_sha256}
    ROUTE_PACKAGE = {'path': str(args.continued_driver_admission), 'sha256': args.continued_driver_admission_sha256}
    ACCOUNTING_ONLY = args.phase in ('poll', 'review-template')
    index = args.cell_number - 1
    tag = 'cell%03d' % args.cell_number
    a, pkg = checked_activation(args.activation, args.activation_sha256)
    ACTIVATION = args.activation_sha256
    PACKAGE = a['driver_package']['sha256']
    cell = a['ordered_cells'][index]
    amendment = a['amendments'][cell]
    require(sha(amendment['path']) == amendment['sha256'], 'cell amendment changed')
    worker = Path(a['workspace'])
    private = Path(a['private_root']) / cell
    queue = Path(a['queue_root']) / cell
    profile = worker / pkg['profile_relative']
    gateway = Path(a['host_service']) / 'pilot_gateway.py'
    require(sha(gateway) == a['host_source_files'][str(gateway)], 'gateway changed')
    for rel, digest in pkg['source5'].items():
        require(sha(worker / rel) == digest, 'retained workspace scientific source changed')
    if index:
        prior = load(HERE / ('cell%03d_terminal.private.json' % index))
        require(prior['cell_id'] == a['ordered_cells'][index - 1]
                and prior['batch_sha256'] == a['batch']['sha256']
                and prior['terminal_verified'] is True, 'previous fixed cell not terminal')
        require(sha(prior['client_execution']['path']) == prior['client_execution']['sha256']
                and sha(prior['client_result']['path']) == prior['client_result']['sha256'],
                'previous terminal observation changed')
    if args.check_only:
        print(json.dumps({'phase':args.phase,'cell_id':cell,'cell_number':args.cell_number,
                          'activation_sha256':ACTIVATION,'effects_performed':False,
                          'scope':'source/admission/fixed-prefix check only; phase state/lease rechecked by actual service before effects'}))
        return
    if args.phase == 'prepare':
        require(not private.exists() and not queue.exists(), 'grant already prepared or consumed')
        builder = Path(a['offer_builder']['path'])
        require(sha(builder) == a['offer_builder']['sha256'], 'offer builder changed')
        before_raw = profile.read_bytes()
        before = json.loads(before_raw)
        old_drop = worker / before['final_host_handoff']['offer_drop_relative']
        old_drop_hash = sha(old_drop) if index else None
        if index:
            require(old_drop_hash == before['final_host_handoff']['offer_drop_sha256'], 'previous offer history changed')
            require({b['cell_id'] for b in load(old_drop)['bindings']} == set(a['ordered_cells'][:index]),
                    'previous offer history differs from fixed prefix')
        else:
            require(old_drop.parent.is_dir(), 'root must prepare exact empty final offer directory before grants')
            require(not old_drop.exists() and before['final_host_handoff']['offer_drop_sha256'] is None
                    and before['final_host_handoff']['scientific_activation_review_sha256'] is None
                    and before['final_host_handoff']['final_freeze_sha256'] is None,
                    'first cell requires fresh inactive profile and no old offer')
        result = run(tag + '_prepare', [PY, '-B', str(gateway), '--continuation', CONTINUATION['path'], '--continuation-sha256', CONTINUATION['sha256'], 'prepare',
            '--private', str(private), '--queue', str(queue), '--repo', a['native_repo'],
            '--registry', a['registry']['path'], '--registry-sha256', a['registry']['sha256'],
            '--unit', amendment['unit'], '--amendment', amendment['path'],
            '--amendment-sha256', amendment['sha256']])
        wave = HERE / ('wave%03d' % args.cell_number)
        built = run(tag + '_build_offer', [PY, '-B', str(builder), '--continuation', CONTINUATION['path'], '--continuation-sha256', CONTINUATION['sha256'], '--effective-service', a['host_service'], '--worker', str(worker),
            '--grant', str(private / 'grant.json'), '--review', a['scientific_review']['path'],
            '--review-sha256', a['scientific_review']['sha256'], '--out', str(wave)])
        after = load(wave / 'production_profile.proposed.json')
        drop = load(wave / 'offer_drop.json')
        require(drop['previous_drop_sha256'] == old_drop_hash and drop['batch_sha256'] == a['batch']['sha256'],
                'offer append changed batch/history')
        require({b['cell_id'] for b in drop['bindings']} == set(a['ordered_cells'][:index + 1]),
                'offer history is not exactly fixed prefix')
        old_base = dict(before); new_base = dict(after)
        old_base.pop('final_host_handoff'); new_base.pop('final_host_handoff')
        require(old_base == new_base, 'base scientific profile changed')
        expected = dict(before['final_host_handoff'])
        expected['offer_drop_sha256'] = sha(wave / 'offer_drop.json')
        if index == 0:
            expected['scientific_activation_review_sha256'] = a['scientific_review']['sha256']
            expected['final_freeze_sha256'] = a['freeze']['sha256']
        require(expected == after['final_host_handoff'], 'profile change exceeds new offer hash')
        require(profile.read_bytes() == before_raw and (sha(old_drop) == old_drop_hash if index else not old_drop.exists()), 'installation preimage changed')
        record(wave / 'installation_review.private.json', {
            'at': now(), 'operator_script_sha256': sha(__file__), 'activation_sha256': ACTIVATION,
            'fixed_prefix_verified': True, 'base_profile_unchanged': True, 'cell_id': cell,
            'grant_sha256': sha(private / 'grant.json'), 'previous_drop_sha256': old_drop_hash,
            'drop_sha256': sha(wave / 'offer_drop.json'), 'profile_sha256': sha(wave / 'production_profile.proposed.json'),
            'candidate_review_not_performed': True, 'provider_calls': 0, 'scorer_calls': 0,
        })
        write(wave / 'production_profile.preimage.json', before_raw)
        if index:
            write(wave / 'offer_drop.preimage.json', old_drop.read_bytes())
        for dest, source in ((old_drop, wave / 'offer_drop.json'), (profile, wave / 'production_profile.proposed.json')):
            temp = dest.with_name(dest.name + '.operator-' + tag)
            write(temp, source.read_bytes(), 0o644)
            os.replace(temp, dest)
            fd = os.open(dest.parent, os.O_RDONLY | os.O_DIRECTORY); os.fsync(fd); os.close(fd)
        record(HERE / (tag + '_client_admission.private.json'), {
            'schema': 'ns028-operator-final-client-admission/v1', 'approved': True, 'approved_at': now(),
            'authority': 'root_operator_scientific_driver', 'package_sha256': PACKAGE,
            'batch_sha256': a['batch']['sha256'], 'worker_root': str(worker),
            'cell_index': index, 'cell_id': cell, 'profile': {'path': str(profile), 'sha256': sha(profile)},
            'operator_driver_amendment_sha256': a['driver_amendment']['sha256'],
            'provider_calls_by_client': 0, 'scorer_calls_by_client': 0, 'authoring_claim_execution': False,
            'operator_script_sha256': sha(__file__), 'final_admitted': True,
        })
        print(json.dumps({'cell_id': cell, 'grant_sha256': result['grant_sha256'], 'offer': built}))
        return
    require(private.is_dir(), 'grant missing')
    grant_hash = sha(private / 'grant.json')
    grant = load(private / 'grant.json')
    require(grant.get('schema') == 'operator-historical-final-grant/v1'
            and grant.get('final_freeze_sha256') == a['freeze']['sha256']
            and grant.get('native_head') == NATIVE_HEAD
            and grant.get('batch_binding') == bound(amendment)['batch_binding']
            and grant.get('unit') == amendment['unit'] and grant.get('arm') == amendment['arm']
            and type(grant.get('repetition')) is int and grant['repetition'] == amendment['repetition'], 'grant final scope differs')
    if args.phase == 'poll':
        terminal = HERE / (tag + '_terminal.private.json')
        if terminal.exists():
            old = load(terminal)
            require(old.get('terminal_verified') is True and old.get('cell_id') == cell
                    and old.get('batch_sha256') == a['batch']['sha256'], 'retained terminal scope differs')
            for key in ('client_execution', 'client_result'):
                require(sha(old[key]['path']) == old[key]['sha256'], 'retained terminal observation changed')
            print(json.dumps({'terminal': True, 'retained_record': str(terminal), 'sha256': sha(terminal),
                              'new_client_execution': False, 'new_provider_calls': 0, 'new_scorer_calls': 0}))
            return
        admission = HERE / (tag + '_client_admission.private.json')
        n = 1
        while (HERE / (tag + '_client_poll%03d' % n)).exists():
            n += 1
        output = HERE / (tag + '_client_poll%03d' % n)
        value = run(tag + '_poll_command%03d' % n, [PY, '-B', str(DRIVER / 'launch.py'),
            '--package-sha256', PACKAGE, '--admission', str(admission), '--admission-sha256', sha(admission),
            '--output', str(output)])
        execution = load(output / 'execution.private.json')
        body = load(output / 'work/result.json')
        require(execution['success'] is True and execution['cleanup_exit_code'] == 0, 'client cleanup unproven')
        if body.get('terminal') is True:
            require(body['batch_sha256'] == a['batch']['sha256'] and len(body['results']) == 1
                    and body['results'][0]['cell_id'] == cell, 'terminal cell differs')
            verified = body['results'][0]['result']['host_verified']
            require(verified.get('signature_and_scope_verified') is True
                    and (verified.get('terminal_failure') is True or verified.get('admitted_historical_final') is True),
                    'client did not verify terminal accounting')
            record(HERE / (tag + '_terminal.private.json'), {
                'at': now(), 'cell_id': cell, 'batch_sha256': a['batch']['sha256'], 'terminal_verified': True,
                'client_execution': {'path': str(output / 'execution.private.json'), 'sha256': sha(output / 'execution.private.json')},
                'client_result': {'path': str(output / 'work/result.json'), 'sha256': sha(output / 'work/result.json')},
                'terminal_failure': verified.get('terminal_failure', False),
                'cold_scalar_result': body['results'][0]['result'].get('cold_scalar_result'),
                'operator_driver': True, 'native_task_completed': False, 'final_admitted': not verified.get('terminal_failure', False),
            })
        print(json.dumps({'client': value, 'terminal': body.get('terminal'), 'result_path': str(output / 'work/result.json')}))
        return
    request = load(queue / 'request.json')
    require(request.get('schema') == 'operator-final-request/v1'
            and request.get('record_kind') == 'final'
            and request.get('final_freeze_sha256') == a['freeze']['sha256']
            and request == load(private / 'expected_request.json'), 'exact typed final request missing')
    argv = [PY, '-B', str(gateway), '--continuation', CONTINUATION['path'], '--continuation-sha256', CONTINUATION['sha256']]
    if args.phase == 'execute':
        require(not (private / 'reservation.json').exists(), 'provider phase consumed; no replay')
        argv += ['execute']
    elif args.phase == 'review-template':
        argv += ['review-template']
    else:
        review = private / 'operator_review.json'
        require(load(review).get('schema') == 'operator-historical-final-candidate-review/v1'
                and load(review).get('approved') is True, 'actual AI operator candidate approval required')
        require(not (private / 'score_reservation.json').exists(), 'scorer phase consumed; no replay')
        argv += ['score-reviewed', '--review-sha256', sha(review)]
    argv += ['--private', str(private), '--grant-sha256', grant_hash]
    value = run(tag + '_' + args.phase, argv)
    body = value.get('receipt', value)
    print(json.dumps({'cell_id': cell, 'phase': args.phase, **{k: body.get(k) for k in
        ('status', 'approved', 'error', 'candidate_sha256', 'patch_bytes', 'elapsed_seconds', 'scorer')}}))


if __name__ == '__main__':
    main()
