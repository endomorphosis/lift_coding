"""Future complete32-only public candidate exporter; no private-tree discovery.

Read only root-reviewed exact candidate_binding/changed-file paths. Reconstruct
the deterministic patch from frozen public preimages. Do not execute candidate
source, load an oracle/reference, or access a provider/scorer/native API.
"""
import argparse,hashlib,importlib.util,json,os,stat,sys
from pathlib import Path
sys.dont_write_bytecode=True

def initial_read(path,maximum=1<<20):
    p=Path(path)
    if not p.is_absolute() or p.resolve()!=p:raise ValueError('Canonical source/admission required')
    fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW)
    try:
        before=os.fstat(fd)
        if not stat.S_ISREG(before.st_mode) or before.st_size>maximum:raise ValueError('Bounded regular source/admission required')
        with os.fdopen(fd,'rb',closefd=False) as stream:raw=stream.read(maximum+1)
        after=os.fstat(fd)
        if (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns)!=(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns) or len(raw)!=before.st_size:raise ValueError('Source/admission changed')
        return raw
    finally:os.close(fd)

def export(admission,admission_sha,output):
    # Establish exact local source before importing the shared pure gate code.
    raw=initial_read(admission)
    if hashlib.sha256(raw).hexdigest()!=admission_sha:raise ValueError('Admission hash differs')
    adm=json.loads(raw);source=Path(__file__).resolve().with_name('build_bundle.py')
    if hashlib.sha256(initial_read(source)).hexdigest()!=adm['builder_sha256']:raise ValueError('Builder source differs')
    spec=importlib.util.spec_from_file_location('ns017_candidate_export_shared',source);B=importlib.util.module_from_spec(spec);spec.loader.exec_module(B)
    B.require(adm['operation']=='export_actual_candidate_bytes_only' and adm['candidate_exporter_sha256']==B.digest(B.read_bytes(Path(__file__).resolve())),'Exact candidate exporter admission required')
    B.admission_guard(adm);B.require(B.read_bytes(Path(admission),admission_sha)==raw,'Admission changed')
    a=B.bound(adm['activation']);an=B.bound(adm['analysis']);ex=B.bound(adm['export_manifest']);review=B.bound(adm['root_complete_review']);freeze=B.bound(a['freeze'])
    B.metadata_guard(adm,a,an,ex,review,freeze)
    allow=B.bound(adm['candidate_source_allowlist']);baselines=B.bound(adm['public_baseline_manifest'])
    B.require(allow['schema']=='ns-final32-candidate-source-allowlist/v1' and allow['actual_complete32'] is True and allow['analysis']==adm['analysis'] and
              allow['ordered_cells']==a['ordered_cells'] and set(allow['cells'])==set(a['ordered_cells']) and allow['public_edit_payloads_only'] is True,
              'Exact complete32 public candidate allowlist required')
    B.require(review['candidate_source_allowlist']==adm['candidate_source_allowlist'] and review['public_baseline_manifest']==adm['public_baseline_manifest'],'Root source custody review differs')
    B.require(baselines['schema']=='ns-final8-public-baseline-reproduction/v1' and set(baselines['units'])==set(B.UNITS),'Exact public baseline manifest required')
    public,verified=B.verified_public(adm,a,an,ex)
    for unit,baseline in baselines['units'].items():B.baseline_guard(unit,baseline,an['rows'],verified)
    out=Path(output);B.require(out.is_absolute() and out.resolve()==out and not out.exists(),'Fresh canonical output required')
    quota=adm['max_candidate_export_bytes'];B.require(type(quota) is int and 0<quota<=128<<20,'Exact bounded candidate export quota required')
    files={};cells={};total=0
    for row in an['rows']:
        cid=row['cell_id'];body=verified[cid]['receipt'];entry=allow['cells'][cid];baseline=baselines['units'][row['unit']]
        if body.get('candidate_sha256') is None:
            B.candidate_guard(row,body,entry,baseline,public[cid]);cells[cid]=dict(entry);continue
        # No recursive seal/grant read. Hashes/pathlist originate in reviewed input.
        cb=B.bound(entry['candidate_binding']);changed={}
        B.require(set(entry['changed_files'])==set(cb['changed_paths']),'Exact changed-file allowlist required')
        B.require(sum(cb['files'][p]['bytes'] for p in cb['changed_paths'])<=64<<20,'Per-cell changed-byte cap exceeded')
        for rel,ref in entry['changed_files'].items():
            B.safe_rel(rel);changed['changed/'+rel]=B.read_bytes(ref['path'],ref['sha256'],16<<20)
        patch=B.reconstruct_patch(cb,changed,baseline)
        payload=B.candidate_guard(row,body,entry,baseline,public[cid],patch_raw=patch)
        derived={**entry,'patch':None,'changed_files':{}}
        for name,data in payload.items():
            rel='candidates/'+cid+'/'+name;B.safe_rel(rel);total+=len(data);B.require(total<=quota,'Measured candidate quota exceeded');files[rel]=data
            ref={'path':str(out/rel),'sha256':B.digest(data)}
            if name=='candidate_binding.json':derived['candidate_binding']=ref
            elif name=='candidate.patch':derived['patch']=ref
            else:derived['changed_files'][name[len('changed/'):]]=ref
        cells[cid]=derived
    # All32 cryptographic/custody/payload checks completed before output creation.
    manifest={'schema':'ns-final32-reviewed-candidate-payloads/v1','actual_complete32':True,'ordered_cells':a['ordered_cells'],
              'analysis':adm['analysis'],'public_edit_payloads_only':True,'cells':cells,'admission_file':{'path':str(admission),'sha256':admission_sha},
              'exporter_sha256':adm['candidate_exporter_sha256'],'builder_sha256':adm['builder_sha256'],
              'source_allowlist':adm['candidate_source_allowlist'],'new_provider_calls':0,'new_scorer_calls':0,'new_native_calls':0,
              'anonymous_release_admitted':False,'files':{rel:{'sha256':B.digest(data),'bytes':len(data)} for rel,data in files.items()},'payload_bytes':total}
    files['candidate_payload_manifest.private.json']=B.encoded(manifest)
    B.require(sum(map(len,files.values()))<=quota,'Final measured candidate export quota exceeded');out.mkdir(mode=0o700)
    for rel,data in files.items():
        p=out/B.safe_rel(rel);p.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
        with os.fdopen(os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600),'wb') as stream:stream.write(data);stream.flush();os.fsync(stream.fileno())
    return manifest

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--admission',type=Path,required=True);p.add_argument('--sha256',required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();os.umask(0o077)
    result=export(a.admission,a.sha256,a.output);print(json.dumps({'complete32':True,'candidate_cells':sum(v['candidate_present'] for v in result['cells'].values()),'payload_bytes':result['payload_bytes']}))
if __name__=='__main__':main()
