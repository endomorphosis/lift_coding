"""One fresh offline container for fixed final public context preparation."""
import sys
sys.dont_write_bytecode=True
import argparse,hashlib,json,os,pathlib,re,subprocess,time
P=pathlib.Path
Q=P(__file__).resolve().parent
RUN=None
NS=P('/anonymous-runtime/operator-root/lift_coding/.worktrees/vericodegen-neurosymbolic_supervision-2026')
IMAGE='sha256:74c4a6ff67f397f8a10b058851d218896b2f1ee0f2cddf47741219b734de93a6'
D=['/usr/bin/docker','--host','unix:///var/run/docker.sock']
def sha(p):return hashlib.sha256(P(p).read_bytes()).hexdigest()
def require(x,m):
 if not x:raise ValueError(m)
def save(p,d):
 fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 with os.fdopen(fd,'w')as f:json.dump(d,f,sort_keys=True,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
 fd=os.open(P(p).parent,os.O_DIRECTORY);os.fsync(fd);os.close(fd)
def cmd(a,timeout=30):return subprocess.run(a,capture_output=True,stdin=subprocess.DEVNULL,timeout=timeout,env={'PATH':'/usr/bin:/bin'})
def inspect(cid):
 r=cmd(D+['inspect',cid]);require(r.returncode==0,'container identity unavailable');return json.loads(r.stdout)[0]
def main():
 global RUN
 ap=argparse.ArgumentParser();ap.add_argument('--attempt',required=True);ap.add_argument('--unit',default='');ap.add_argument('--preflight-only',action='store_true');a=ap.parse_args();require(re.fullmatch('[a-z0-9-]+',a.attempt),'safe attempt required');require(a.preflight_only != bool(a.unit),'one preparation mode required');RUN=Q/'context_runs'/a.attempt;RUN.parent.mkdir(mode=0o700,exist_ok=True)
 os.umask(0o077);require(not RUN.exists(),'fresh qualification required')
 profile=NS/'papers/completion/toolchains/research_profile.json';require(sha(profile)=='1bc2c65388bc5a79ae61e762653d336ae5401e7b0d592d265884d2ab166a8f84','runtime profile differs');rt=json.loads(profile.read_text());require(sha(rt['manifest'])==rt['manifest_sha256'],'runtime manifest differs')
 pins={'external/ipfs_accelerate':'60baee769d39a53c52142c56fbf6ed7483773aa3','external/ipfs_datasets':'b9686e09beb4973fea13a9c6d93d40b6d2741366','external/ipfs_kit':'6196017ca3df016c7159dce43af60f2a0d96a9ae'}
 for rel,pin in pins.items():require(subprocess.check_output(['git','-C',str(NS/rel),'rev-parse','HEAD']).decode().strip()==pin,'native dependency pin differs')
 source=NS/'external/ipfs_accelerate/ipfs_accelerate_py/agent_supervisor/semantic_state/harness.py';require(sha(source)=='1423e6b98b2ef397e3d8ad7b0f1099535b5b307ea8e04f29421642d429db6fa3','retained draft source differs')
 require(sha(NS/'external/ipfs_accelerate/ipfs_accelerate_py/agent_supervisor/semantic_state/context_pack.py')=='5724b1e870b28875a073cd84e836af9312ff9b4d5a742271486ae64ff32a9168','qualified native raw-caveat source differs')
 RUN.mkdir(mode=0o700)
 for d in ['output','home','docker-config']:(RUN/d).mkdir(mode=0o700)
 actual_python=['/usr/bin/python3','-I','-B','/qualification/context_prepare_child.py']
 invocation={'accelerate_source':str(NS/'external/ipfs_accelerate'),'datasets_source':str(NS/'external/ipfs_datasets'),'kit_source':str(NS/'external/ipfs_kit'),'runtime_python':str(P(rt['root'])/'python'),'source_sha256':sha(source),'actual_python_argv':actual_python,'semantic_source_sha256':sha(Q/'service_native_v2/final_service/semantic_context.py'),'service_source':str(Q/'service_native_v2/final_service'),'input_manifest':{'path':str(Q/'public_inputs_v1/manifest.private.json'),'sha256':sha(Q/'public_inputs_v1/manifest.private.json')},'native_source_pins':pins,'unit':a.unit,'preflight_only':a.preflight_only}
 save(RUN/'invocation.json',invocation)
 name='ns028-final-context-'+a.attempt+'-'+sha(Q/'context_prepare_child.py')[:8]
 mounts=[(Q/'context_prepare_child.py','/qualification/context_prepare_child.py',True),(RUN/'invocation.json','/qualification/invocation.json',True),(NS/'external/ipfs_accelerate',str(NS/'external/ipfs_accelerate'),True),(Q/'service_native_v2/final_service/semantic_context.py',str(Q/'service_native_v2/final_service/semantic_context.py'),True),(Q/'service_native_v2/final_service/context_selection.py',str(Q/'service_native_v2/final_service/context_selection.py'),True),(Q/'service_native_v2/final_service/http_proposer.py',str(Q/'service_native_v2/final_service/http_proposer.py'),True),(Q/'public_inputs_v1',str(Q/'public_inputs_v1'),True),(NS/'external/ipfs_datasets',str(NS/'external/ipfs_datasets'),True),(NS/'external/ipfs_kit',str(NS/'external/ipfs_kit'),True),(P(rt['root']),rt['root'],True),(RUN/'output','/qualification-output',False),(RUN/'home','/qualification-home',False)]
 argv=D+['--config',str(RUN/'docker-config'),'create','--pull=never','--name',name,'--cidfile',str(RUN/'container.cid'),'--label','ns028.native-harness-source='+sha(source),'--network=none','--read-only','--cap-drop=ALL','--security-opt=no-new-privileges','--runtime=runc','--cpus=1','--memory=2147483648','--memory-swap=2147483648','--pids-limit=32','--user',str(os.getuid())+':'+str(os.getgid()),'--tmpfs','/tmp:rw,nosuid,nodev,noexec,size=536870912','--entrypoint','/usr/bin/env']
 for s,d,ro in mounts:argv+=['--mount','type=bind,src='+str(s)+',dst='+d+(',readonly'if ro else'')]
 argv += [IMAGE,'-i','PATH=/usr/bin:/bin','HOME=/qualification-home','PYTHONDONTWRITEBYTECODE=1',*actual_python]
 save(RUN/'plan.json',{'argv':argv,'mounts':[{'Source':str(s),'Destination':d,'RW':not ro}for s,d,ro in mounts],'source_sha256':sha(source),'script_sha256':sha(Q/'context_prepare_child.py'),'runtime_profile_sha256':sha(profile),'runtime_manifest_sha256':rt['manifest_sha256'],'native_dependency_pins':pins,'wall_seconds':600,'scientific_calls':0})
 result={'schema':'ns028-native-harness-container-qualification/v1','success':False,'pending':None,'provider_calls':0,'scorer_calls':0,'native_state_mutations':0,'automatic_retry':False,'source_sha256':sha(source),'script_sha256':sha(Q/'context_prepare_child.py'),'plan_sha256':sha(RUN/'plan.json')};cid=None;attempted=False;start=time.monotonic()
 try:
  absent=cmd(D+['inspect',name]);save(RUN/'precreate.json',{'returncode':absent.returncode,'stdout':absent.stdout.decode(),'stderr':absent.stderr.decode()});require(absent.returncode==1 and absent.stdout.strip()==b'[]' and absent.stderr.decode().strip().casefold()=='error: no such object: '+name,'exact absence required')
  attempted=True;result['pending']='create_unknown';create=cmd(argv,60);save(RUN/'created.json',{'returncode':create.returncode,'stdout':create.stdout.decode(),'stderr':create.stderr.decode()});require(create.returncode==0,'create failed');cid=create.stdout.decode().strip();require(re.fullmatch('[a-f0-9]{64}',cid)and(RUN/'container.cid').read_text().strip()==cid,'CID differs')
  data=inspect(cid);h=data['HostConfig'];actual=sorted([{'Source':m['Source'],'Destination':m['Destination'],'RW':m['RW']}for m in data['Mounts']if m['Type']=='bind'],key=lambda x:x['Destination']);expected=sorted([{'Source':str(s),'Destination':d,'RW':not ro}for s,d,ro in mounts],key=lambda x:x['Destination'])
  require(data['Image']==IMAGE and data['Name']=='/'+name and actual==expected and h['NanoCpus']==1000000000 and h['Memory']==2147483648 and h['MemorySwap']==2147483648 and h['PidsLimit']==32 and h['NetworkMode']=='none'and h['ReadonlyRootfs']and h['CapDrop']==['ALL']and not h['Privileged']and not h['PidMode']and h['Runtime']=='runc'and any(x.startswith('no-new-privileges')for x in h['SecurityOpt']),'native boundary differs');require(data['State']['Status']=='created'and not data['State']['Running'],'unexpected running container');save(RUN/'boundary.json',data)
  result['pending']='running';ran=cmd(D+['start','--attach',cid],600)
  for name_,raw in [('context_execution.log',ran.stdout),('stderr.log',ran.stderr)]:
   fd=os.open(RUN/'output'/name_,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
   with os.fdopen(fd,'wb')as f:f.write(raw);f.flush();os.fsync(f.fileno())
  final=inspect(cid);save(RUN/'final_inspect.json',final);require(ran.returncode==0 and final['State']['ExitCode']==0 and not final['State']['Running']and not final['State']['OOMKilled'],'native controls failed')
  receipt=json.loads((RUN/'output/result.json').read_text());require(receipt['success']and receipt['native_source_pins']==pins,'native context receipt differs');result.update(success=True,exit_code=ran.returncode,receipt_sha256=sha(RUN/'output/result.json'),log_sha256=sha(RUN/'output/context_execution.log'))
 except BaseException as exc:
  result['error']=type(exc).__name__+': '+str(exc)
  if isinstance(exc,subprocess.TimeoutExpired):
   result['timeout_seconds']=exc.timeout
   save(RUN/'timeout_output.json',{'stdout':(exc.stdout or b'').decode(errors='replace'),'stderr':(exc.stderr or b'').decode(errors='replace'),'timeout_seconds':exc.timeout})
 finally:
  if attempted:
   try:
    data=inspect(cid or name);require(data['Image']==IMAGE and data['Name']=='/'+name and data['Config']['Labels'].get('ns028.native-harness-source')==sha(source),'cleanup identity differs');clean=cmd(D+['rm','-f',data['Id']],30);save(RUN/'cleanup.json',{'cid':data['Id'],'returncode':clean.returncode,'stdout':clean.stdout.decode(),'stderr':clean.stderr.decode()});result['cleanup_exit_code']=clean.returncode;result['pending']=None if clean.returncode==0 else'cleanup_uncertain'
   except BaseException as exc:result['pending']='operator_reconciliation_required';result['cleanup_error']=type(exc).__name__+': '+str(exc)
  result['wall_seconds']=time.monotonic()-start;result['success']=result['success']and result['pending']is None;save(RUN/'qualification.private.json',result)
 print(json.dumps({'path':str(RUN/'qualification.private.json'),'sha256':sha(RUN/'qualification.private.json'),'success':result['success'],'pending':result['pending']}));return 0 if result['success']else 1
if __name__=='__main__':raise SystemExit(main())
