"""Offline scalar/table reproduction. No receipt-authenticity or service API.

The exact frozen statistics definitions are selected by AST from the original
hash-bound analyzer. No analyzer imports, filesystem custody functions, main(),
private path resolution or service/client functions execute.
"""
import argparse
import ast
import collections
import hashlib
import json
import math
from pathlib import Path
import random

ANALYZER_SHA = '9868efad4a8029edd7d1b4d0f7b0ff2ff3ed453420fa86b9d6c1a2999bd3193f'
FUNCS = {'require','canon','finite','measured','quantile','cell_id','validate_rows','summarize'}
CONSTANTS = {'UNITS','REPS','METRICS'}
ROW_KEYS = ('number','cell_id','unit','arm','repetition','cache','terminal','outcome','useful_completion',
            'provider_child_elapsed_seconds','http_wrapper_elapsed_seconds','gateway_proposal_elapsed_seconds',
            'gateway_score_elapsed_seconds','grant_to_terminal_elapsed_seconds','client_poll_wall_seconds','client_poll_cpu_seconds')

def require(ok, code):
    if not ok: raise ValueError(code)

def sha(raw): return hashlib.sha256(raw).hexdigest()

def canonical(x): return json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False).encode()

def encoded(x): return json.dumps(x,sort_keys=True,indent=2,allow_nan=False).encode()+b'\n'

def statistics(source):
    require(sha(source)==ANALYZER_SHA,'frozen_statistics_source_hash')
    tree=ast.parse(source); nodes=[];found=set()
    for node in tree.body:
        if isinstance(node,ast.FunctionDef) and node.name in FUNCS:
            nodes.append(node);found.add(node.name)
        elif isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name) and node.targets[0].id in CONSTANTS:
            nodes.append(node);found.add(node.targets[0].id)
    require(found==FUNCS|CONSTANTS,'frozen_statistics_definition_set')
    # No import statement or source-side statement outside the exact whitelist.
    g={'collections':collections,'hashlib':hashlib,'json':json,'math':math,'random':random}
    exec(compile(ast.Module(body=nodes,type_ignores=[]),'<frozen-statistics-only>','exec'),g)
    return g

def project_rows(rows):
    return [{k:r[k] if k not in ROW_KEYS[9:] else r.get(k) for k in ROW_KEYS} for r in rows]

def reduce_rows(rows,source):
    s=statistics(source)
    require(len(rows)==32 and [r['number']for r in rows]==list(range(1,33)),'complete_ordered32')
    require(all(r['terminal']is True and r['cache']=='local_cold' and type(r['repetition'])is int for r in rows),'actual_terminal_rows_only')
    require(all(set(r)==set(ROW_KEYS)for r in rows),'statistical_row_schema')
    result=s['summarize'](rows)
    require(result['complete']is True and result['terminal_cells']==32,'complete_statistics')
    return result

def check_expected(rows,expected,source):
    result=reduce_rows(rows,source)
    require(canonical(result)==canonical(expected),'reproduced_tables_differ')
    return result

def load_release(root):
    manifest=json.loads((root/'release_manifest.json').read_bytes())
    require(manifest['schema']=='ns-final32-anonymous-release-manifest/v1' and manifest['complete_actual32']is True,'complete_release_manifest')
    require(manifest['original_signatures_authenticate_derivatives']is False,'signature_scope')
    members=manifest['files']
    actual={str(p.relative_to(root))for p in root.rglob('*')if p.is_file()}
    require(actual==set(members)|{'release_manifest.json'},'exact_release_members')
    for rel,record in members.items():
        path=root/rel
        require(not path.is_symlink() and path.resolve().is_relative_to(root.resolve()),'unsafe_member')
        data=path.read_bytes();require(len(data)==record['bytes'] and sha(data)==record['sha256'],'release_member_hash')
    rows=json.loads((root/'data/statistical_rows.json').read_bytes())['rows']
    require([r['cell_id']for r in rows]==manifest['ordered_cells'],'released_frozen_order')
    return rows,json.loads((root/'tables/expected_summary.json').read_bytes()),(root/'source/frozen/analyze.py').read_bytes()

def main():
    p=argparse.ArgumentParser();p.add_argument('--release',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();require(not a.output.exists(),'fresh_reproduction_output')
    rows,expected,source=load_release(a.release)
    summary=check_expected(rows,expected,source)
    a.output.mkdir(parents=False)
    (a.output/'summary.json').write_bytes(encoded(summary))
    (a.output/'verification.json').write_bytes(encoded({'schema':'ns-final32-portable-numerical-reproduction/v1','success':True,
        'summary_sha256':sha(encoded(summary)),'frozen_statistics_sha256':ANALYZER_SHA,
        'original_signature_replay_performed':False,'hidden_rescoring_performed':False,'scientific_calls':0,'native_calls':0}))
    print(json.dumps({'success':True,'summary_sha256':sha(encoded(summary))}))

if __name__=='__main__':main()
