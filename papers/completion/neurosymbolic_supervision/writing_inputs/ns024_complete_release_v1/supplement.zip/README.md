# Anonymous numerical supplement

The components retain separate populations and evidence scopes:

- `final32/`: the complete frozen A/B cold comparison, 32 cells in eight families with two nested repetitions per arm. The anonymous numerical replay does not authenticate signed originals or rescore hidden tests.
- `prior/`: the separate 24-cell developmental pilot in four families with three nested repetitions, plus original preparation/protocol cost ledgers. Pilot usefulness is not retrospectively reclassified using the final resource policy.
- `boundary/`: six historical boundary rows and retained qualification counts. These are historical controls, including failures, rather than extra final trials or new native qualification runs.

Run with Python 3.12 from a fresh local directory:

```
python3 -B reproduce.py --root /absolute/path/to/combined --output /absolute/path/to/new-reproduction
```

The wrapper checks every manifest, path, size and hash, then invokes each exact child numerical reproducer. It performs local file and scalar computation only; it does not invoke providers, scorers, native services, hidden tests, proof engines or network programs. No network-namespace isolation is claimed. Original signed custody and private operational evidence remain separate; anonymous derivatives do not acquire original signatures. Human fidelity and expert time remain unmeasured.

The three populations are never pooled. Nested clocks and cost scopes are never summed into a grand total; missing costs and unsettled charges remain unknown. C/D, warm-cache, routing, reuse and publication benefits are not established by this A/B comparison.

The build record reports the measured archive size against a 16,000,000-byte ZIP limit. Fresh extraction is bounded to 64 MiB, 8,192 regular files and 16,000,000 bytes per file. Each of the three numerical reproducers runs once before ZIP creation and once after extraction, giving six recorded offline commands. Their invocation clocks remain separate from prior scientific measurements. This packaging adds no scientific trials or completion authority.
