"""Restore reviewed published opt-in runtime; preserve exact old owner bytes."""
from pathlib import Path
import hashlib,json,os,subprocess
R=Path(__file__).resolve().parents[1];W=R.parents[1];P=W/'external/ipfs_datasets';A=W/'artifacts/autoencoder-progress-reconcile-20261006/branches/pr1271-canonical-proposal'
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git','-C',str(P),*a],stderr=subprocess.PIPE)
def state():
 index=Path(git('rev-parse','--git-path','index').decode().strip());index=index if index.is_absolute() else P/index
 return {'head':git('rev-parse','HEAD').decode().strip(),'index_sha256':sha(index.read_bytes())}
review=json.loads((A/'proposal-review.json').read_bytes());assert review['passed'] is True and not review['findings']
plan=json.loads((A/'missing-only-restoration-plan.json').read_bytes());pin=json.loads((A/'registry-preimage.json').read_bytes())
owner=Path(pin['path']);pre=owner.read_bytes();proposed=(A/'canonical-registry-proposed.py').read_bytes()
assert sha(pre)==pin['sha256'] and sha(proposed)==pin['proposed_sha256'] and len(proposed)==pin['proposed_bytes']
assert proposed==git('show',pin['published_target_commit']+':'+str(owner.relative_to(P)))
staged=[]
for row in plan['paths']:
 p=P/row['path'];assert str(p)==row['destination']
 assert not p.exists() and not p.is_symlink(),str(p)
 for parent in p.parents:
  if parent==P:break
  assert not parent.is_symlink()
 data=git('cat-file','blob',row['source_blob']);assert len(data)==row['bytes'] and sha(data)==row['sha256']
 staged.append((p,data,row))
assert len(staged)==15
before=state()
with (R/'registry-recovery/runtime-registry-preimage.py').open('xb') as f:f.write(pre)
rows=[]
for p,data,row in staged:
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
 os.chmod(p,0o755 if row['mode']=='100755' else 0o644)
 assert p.read_bytes()==data
 rows.append(row)
assert owner.read_bytes()==pre
# Authenticated whole-owner replacement is exact published main; no other hunks.
tmp=owner.with_name(owner.name+'.grouped-main.tmp')
with tmp.open('xb') as f:f.write(proposed);f.flush();os.fsync(f.fileno())
os.chmod(tmp,owner.stat().st_mode&0o777);assert owner.read_bytes()==pre;os.replace(tmp,owner)
assert owner.read_bytes()==proposed and state()==before
report={'schema':'published-grouped-runtime-canonical-restoration/v1','passed':True,'findings':[],'created_absent':15,'new_bytes':sum(len(b) for _,b,_ in staged),'owner_sha256':sha(proposed),'owner_previous_sha256':sha(pre),'owner_matches_published_main':True,'source_revision':pin['published_target_commit'],'paths':rows,'normal_before':before,'normal_after':state(),'normal_state_preserved':True,'default_runtime_activated':False,'model_executed':False,'training_executed':False,'Lake_executed':False,'semantic_qualification_granted':False}
with (R/'registry-recovery/restoration-receipt.json').open('x') as f:json.dump(report,f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps({'created_absent':15,'runtime_exact_main':True,'normal_state_preserved':True}))
