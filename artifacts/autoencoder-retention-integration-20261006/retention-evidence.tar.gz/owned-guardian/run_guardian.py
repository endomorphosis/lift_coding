"""Run one independently reviewed owned phase and retain the actual outer exit."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

R = Path(__file__).resolve().parent


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--phase',choices=('preparation','preflight','training','evaluation'),required=True)
    parser.add_argument('--attempt',required=True)
    parser.add_argument('--dimension',type=int,choices=(384,768))
    parser.add_argument('--review',type=Path,required=True)
    args=parser.parse_args()
    if Path(args.attempt).name!=args.attempt or args.attempt in ('','.','..'):
        raise ValueError('fresh single-component attempt required')
    ready=json.loads(args.review.read_bytes())
    if ready.get('passed') is not True or ready.get('findings'):
        raise ValueError('clean independent phase readiness required')
    if ready.get('phase') != args.phase or ready.get('run_root') != str(R.resolve()) \
            or 'dimension' not in ready or ready['dimension'] != args.dimension:
        raise ValueError('readiness phase, width or owned run directory differs')
    for name,record in ready['artifacts'].items():
        path=Path(name); wanted=record if type(record)is str else record['sha256']
        digest=hashlib.sha256();size=0
        with path.open('rb') as stream:
            for data in iter(lambda:stream.read(1048576),b''):
                digest.update(data);size+=len(data)
        if digest.hexdigest()!=wanted:
            raise ValueError('reviewed artifact changed: '+name)
        if type(record)is dict and 'bytes'in record and size!=record['bytes']:
            raise ValueError('reviewed size changed: '+name)
    receipt=R/(args.attempt+'-guardian-exit.json')
    if receipt.exists():raise ValueError('completed outer evidence is immutable')
    command=[sys.executable,str(R/'run_reserved.py'),'--phase',args.phase,'--attempt',args.attempt]
    if args.dimension is not None:command+=['--dimension',str(args.dimension)]
    started=time.monotonic()
    with (R/(args.attempt+'-guardian.log')).open('x') as stream:
        result=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT)
    record=dict(returncode=result.returncode,elapsed_seconds=time.monotonic()-started)
    with receipt.open('x') as stream:json.dump(record,stream,indent=2);stream.write('\n')
    print(json.dumps(record),flush=True)
    raise SystemExit(result.returncode)


if __name__=='__main__':main()
