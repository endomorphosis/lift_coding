#!/usr/bin/env python3
"""Private postfit retention observation of four NEW normative selected states on exposed-v3 cached48sources.
Adapted from the exact frozen normative observer; numerical owners unchanged.
No training, encoder, downloads, solver, Lake, promotion or fresh holdout.
All four traces/predictions are durable before v3 reference parsing.
"""
import argparse
from copy import deepcopy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import time
from types import SimpleNamespace

TRAINER = 'scripts/ops/autoencoder/benchmark_normative_wording_training.py'
AUTO = 'ipfs_datasets_py/logic/formalization/autoencoder/'
PREFIX = 'ipfs_datasets_py.logic.formalization.autoencoder.'
OBSERVER = AUTO+'generated_scalar_observation.py'
OBSERVER_SHA256 = '1f1d35f7fd90df0396f3222676f2ffd11f17e2b1b2c79c0a79f1600488eb08d8'
TRACE_FALSE_FLAGS = ('qualified','admitted','proof_authority','source_semantics_verified',
    'production_checkpoint','native_family_validation_performed','lake_executed',
    'checkpoint_promoted','convergence_proven','fresh_holdout')
ARMS = ('normative-wording-zero', 'normative-wording-ce')
ROLES = ('selected',)
FALSE = dict(qualified=False, admitted=False, proof_authority=False, formalized=False,
    roundtrip_ok=False, checkpoint_promoted=False, convergence_proven=False,
    lake_executed=False, fresh_holdout=False, source_semantics_verified=False,
    encoder_executed=False, training_executed=False, downloads_performed=False,
    used_for_selection=False, independent_semantic_holdout=False)
FIXED = dict(schema='normative-wording-retention-plan/v1', dimensions=[384,768],
    arms=list(ARMS), roles=list(ROLES), panel_count=4, samples_per_panel=48,
    seed=1729, all_predictions_before_reference_load=True,
    predictions_fsynced_before_reference_load=True, greedy_passes_per_model=1,
    context_tokens=512, output_tokens=512, temperature=0, vocabulary_size=32,
    batch_size=8, workers=1, max_seconds_per_panel=30, max_seconds_entire_run=600,
    distribution='previously_exposed_authored_modality_holdout_v3',
    original_meanings_previously_exposed=True, postfit_observation_only=True, previously_exposed=True,
    comparison_seal='4e09fd75f40e410d1a53f7f13d01c034c1b0bcae5254a5f7f195754d7db16eac',
    no_training_or_selection_from_development=True, bridge_names=[],
    source_head_trace_same_greedy_pass=True, extra_source_head_evaluations=0,
    full_vocabulary_source_recurrent_combined_logits=True,
    source_head_and_formula_join_after_reference_barrier=True,
    unvisited_source_sites_counted_correct=False, observer_sha256=OBSERVER_SHA256,
    max_trace_memory_bytes=134217728,
    legal_ir_evaluate_provers=False, metric_disk_cache_used=False,
    cache_scope='warm authenticated source vectors; no encoder forward', **FALSE)


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            h.update(block)
    return h.hexdigest()


def bound(manifest, path):
    path = Path(path).resolve()
    raw = path.read_bytes()
    require(manifest['inputs'].get(str(path)) == hashlib.sha256(raw).hexdigest(),
        'unbound or changed development observer input')
    return json.loads(raw)


def validate_plan(plan):
    require(type(plan) is dict and all(type(plan.get(k)) is type(v) and
        plan[k] == v for k,v in FIXED.items()), 'fixed development observer recipe differs')


def check_deadline(deadline):
    if time.monotonic() >= deadline:
        raise TimeoutError('normative wording development observer deadline')


def durable_save(save, path, value):
    """Persist through the established owner, then fsync file and directory."""
    reference = save(path, value)
    require(Path(reference['path']).resolve() == Path(path).resolve() and
        sha(path) == reference['sha256'], 'durable save reference differs')
    with Path(path).open('rb') as stream:
        os.fsync(stream.fileno())
    descriptor = os.open(Path(path).parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)
    return reference


def restore_before_deadline(owner, lane, run, role, deadline):
    check_deadline(deadline)
    model = owner.restore_endpoint(lane, run, role)
    check_deadline(deadline)
    return model


def frozen_scalar_observer(ctx, manifest):
    """Reuse the already authenticated numerical closure without replacing it."""
    candidates = sorted(path for path,wanted in manifest['inputs'].items()
        if path.endswith('/'+OBSERVER) and wanted == OBSERVER_SHA256)
    require(candidates, 'authenticated scalar observation owner required')
    path = Path(candidates[0]).resolve()
    require(sha(path) == OBSERVER_SHA256 and
        ctx['paraphrase_manifest']['producer_pins'].get(str(path)) == OBSERVER_SHA256,
        'scalar observer source absent from frozen training closure')
    boundary = ctx['owners']['contextual_generated_boundary_training']
    fields = ctx['owners']['generated_field_training']
    require(sys.modules.get(PREFIX+'contextual_generated_boundary_training') is boundary and
        sys.modules.get(PREFIX+'generated_field_training') is fields,
        'resident scalar observer dependencies differ')
    canonical = PREFIX+'generated_scalar_observation'
    observer = sys.modules.get(canonical)
    if observer is None:
        observer = ctx['helpers'].extension(path.parents[4],OBSERVER,canonical,
            {OBSERVER:OBSERVER_SHA256})
    else:
        require(Path(observer.__file__).resolve() == path and sha(path) == OBSERVER_SHA256,
            'different scalar observer already resident')
    require(observer.boundary is boundary and observer.fields is fields and observer.core is ctx['core'],
        'scalar observer changed numerical owner identities')
    return observer


def prediction_from_trace(trace):
    """Expose the existing greedy result without a second model execution."""
    return dict(schema='normative-wording-retention-source-predictions/v1',complete=trace['complete'],
        predictions=trace['predictions'],model_tensor_sha256=trace['model_tensor_sha256'],
        source_rows_sha256=trace['source_rows_sha256'],source_contexts_sha256=trace['source_contexts_sha256'],
        generation_reference_access=False,greedy_passes_per_row=1,generation_temperature=0,
        max_target_tokens=512,batch_size=8,elapsed_seconds=trace['elapsed_seconds'],
        same_pass_scalar_trace_sha256=trace['trace_sha256'],
        reconstructed_input_mse_measured=False,**FALSE)


def verify_predictions(records, runs, lanes, digest):
    expected = {(d,a,r) for d in FIXED['dimensions'] for a in ARMS for r in ROLES}
    require(type(records) is list and len(records) == 4 and
        {(r['dimension'],r['arm'],r['role']) for r in records} == expected,
        'all four durable selected endpoint predictions required before development references')
    for record in records:
        lane = lanes[record['dimension']]
        run = runs[record['dimension'],record['arm']]
        ref = record['predictions_ref']
        require(record.get('prediction_fsynced') is True and sha(ref['path']) == ref['sha256'],
            'prediction is not unchanged and durable')
        panel = json.loads(Path(ref['path']).read_bytes())
        trace_ref = record['source_head_trace_ref']
        require(record.get('source_head_trace_fsynced') is True and sha(trace_ref['path']) == trace_ref['sha256'],
            'same-pass source-head trace is not unchanged and durable')
        trace = json.loads(Path(trace_ref['path']).read_bytes())
        require(trace.get('schema') == 'generated-contextual-scalar-trace/v1' and
            trace.get('trace_sha256') == digest({k:v for k,v in trace.items() if k != 'trace_sha256'})
            and trace.get('complete') is True and trace.get('sample_count') == 48
            and trace.get('dimension') == record['dimension'] and
            trace.get('model_tensor_sha256') == record['state_ref']['tensor_sha256']
            and trace.get('source_rows_sha256') == digest(lane['fresh_rows'])
            and trace.get('source_contexts_sha256') == digest(lane['fresh_contexts'])
            and trace.get('codec_sha256') == digest(lane['donor']['codec'])
            and trace.get('input_transform_sha256') == digest(lane['donor']['input_transform'])
            and trace.get('vocabulary_size') == 32 and trace.get('generation_temperature') == 0
            and trace.get('max_target_tokens') == 512 and trace.get('batch_size') == 8
            and trace.get('predictions') == panel.get('predictions')
            and panel.get('same_pass_scalar_trace_sha256') == trace['trace_sha256']
            and all(trace.get(k) is True for k in ('source_only','full_vocabulary_retained',
                'decomposition_exact','caller_state_preserved','hooks_removed',
                'complete_rollout_before_reference_scoring'))
            and all(trace.get(k) is False for k in ('reference_count_access','reference_prefix_access',
                'reference_documents_passed_to_model','inventory_access','source_context_target_access',
                'syntax_mask','forced_closure','model_copied',*TRACE_FALSE_FLAGS))
            and all(type(trace.get(k)) is int and trace[k] == 0 for k in
                ('extra_model_passes','source_head_extra_evaluations','optimizer_steps')),
            'source-head trace reference/generation/provenance policy differs')
        require(record['state_ref'] == run['states'][record['role']] and
            panel.get('complete') is True and panel.get('model_tensor_sha256') ==
            record['state_ref']['tensor_sha256'] and panel.get('source_rows_sha256') ==
            digest(lane['fresh_rows']) and panel.get('source_contexts_sha256') ==
            digest(lane['fresh_contexts']) and len(panel.get('predictions',[])) == 48 and
            [r['id'] for r in panel['predictions']] == [r['id'] for r in lane['fresh_rows']] and
            panel.get('generation_reference_access') is False and panel.get('greedy_passes_per_row') == 1
            and panel.get('generation_temperature') == 0 and panel.get('max_target_tokens') == 512,
            'incomplete or mismatched source-only development predictions')


def load_references(manifest, records, runs, lanes, codec, digest):
    verify_predictions(records, runs, lanes, digest)
    verify_zero_archives(manifest, records, lanes, digest)
    refs = bound(manifest, manifest['references'])
    receipt = bound(manifest, manifest['holdout_receipt'])
    source = [{k:r[k] for k in ('id','source_text')} for r in lanes[384]['fresh_rows']]
    require(source == [{k:r[k] for k in ('id','source_text')} for r in lanes[768]['fresh_rows']],
        'exposed-v3 source ordering differs by width')
    require(type(refs) is list and len(refs) == 48 and len(codec['target_vocabulary']) == 32
        and receipt.get('complete') is True and receipt.get('schema') == 'authored-modality-holdout/v3'
        and receipt.get('receipt_sha256') == digest({k:v for k,v in receipt.items() if k != 'receipt_sha256'})
        and receipt.get('references_sha256') == digest(refs) and receipt.get('source_rows_sha256') == digest(source)
        and receipt.get('codec_sha256') == digest(codec)
        and receipt.get('sealed_comparison_sha256') == FIXED['comparison_seal'],
        'authenticated unchanged exposed-v3 references required')
    for ref,row in zip(refs,source):
        ids=ref['target_ids']
        require(ref['id']==row['id'] and ref['source_text']==row['source_text']
            and ref['source_sha256']==hashlib.sha256(row['source_text'].encode()).hexdigest()
            and ref['target_sha256']==digest(ref['target']) and ref['codec_sha256']==digest(codec)
            and type(ids) is list and 3<=len(ids)<=512 and ids[0]==1 and ids[-1]==2
            and all(type(t) is int and 3<=t<32 for t in ids[1:-1])
            and json.loads(''.join(codec['target_vocabulary'][t] for t in ids[1:-1]))==ref['target'],
            'complete unchanged exposed-v3 source/target binding required')
    require(sum(len(ref['target']['rules']) for ref in refs)==180,
        'unchanged180-rule exposed-v3 denominator required')
    return refs,receipt

def verify_zero_archives(manifest,records,lanes,digest):
    """Only the two numerically identical M2 zero controls have old outputs."""
    keys=('id','token_ids','generation_status','eos_reached')
    zero=[r for r in records if r['arm']=='normative-wording-zero']
    require(len(zero)==2 and {r['dimension'] for r in zero}=={384,768},
        'two distinct zero controls required')
    for record in zero:
        d=record['dimension']; lane=lanes[d]
        oldref=manifest['archived_zero_predictions'][str(d)]
        old=bound(manifest,oldref['path'])
        require(sha(oldref['path'])==oldref['sha256'] and
            Path(oldref['path']).stat().st_size==oldref['bytes'] and
            old.get('complete') is True and
            old.get('model_tensor_sha256')==record['state_ref']['tensor_sha256'] and
            old.get('source_rows_sha256')==digest(lane['fresh_rows']) and
            old.get('source_contexts_sha256')==digest(lane['fresh_contexts']) and
            old.get('generation_reference_access') is False and
            old.get('generation_temperature')==0 and old.get('max_target_tokens')==512,
            'old zero archived source/tensor/generation bindings differ')
        ref=record['predictions_ref']; require(sha(ref['path'])==ref['sha256'],'new zero prediction changed')
        new=json.loads(Path(ref['path']).read_bytes())
        require([{k:r[k] for k in keys} for r in new['predictions']]==
            [{k:r[k] for k in keys} for r in old['predictions']],
            'new zero differs from exact archived M2 output')




def scoring_references(references,receipt):
    return deepcopy(references)




def join_source_heads_and_formula(scalar_score,fidelity,references):
    """Keep all180 authored rule slots and unvisited sites in denominators."""
    fields=('actor','action','modality','object')
    require(scalar_score.get('complete') is True and len(references)==48
        and len(fidelity['rows'])==48,'complete48-row paired evidence required')
    require([r['id'] for r in references]==[r['id'] for r in fidelity['rows']],
        'head/formula reference ordering differs')
    wanted={(ref['id'],slot,field) for ref in references
        for slot in range(len(ref['target']['rules'])) for field in fields}
    require(len(wanted)==720 and len({r['id'] for r in references})==48,
        'exact180-rule720-scalar denominator required')
    events={}
    for event in scalar_score['events']:
        key=(event['id'],event['slot'],event['field'])
        require(key in wanted and key not in events,'duplicate or foreign scalar event')
        events[key]=event
    unvisited={(r['id'],r['slot'],r['field']) for r in scalar_score['unvisited_reference_sites']}
    unavailable={(r['id'],r['slot'],r['field']) for r in scalar_score['unscored_sites']
        if (r['id'],r['slot'],r['field']) in wanted}
    extra_unavailable=[r for r in scalar_score['unscored_sites']
        if (r['id'],r['slot'],r['field']) not in wanted]
    # The observer also labels unavailable reference slots unvisited because
    # only scored events enter its visited set. Keep one denominator category.
    require(len(unvisited)==len(scalar_score['unvisited_reference_sites']) and unavailable<=unvisited,
        'original unvisited reference accounting differs')
    unvisited-=unavailable
    require(
        len(unavailable)+len(extra_unavailable)==len(scalar_score['unscored_sites']) and
        not(set(events)&unvisited) and not(set(events)&unavailable) and
        not(unvisited&unavailable) and set(events)|unvisited|unavailable==wanted,
        'every scalar site must be scored, unavailable or unvisited exactly once')
    counts={field:dict(reference_sites=180,visited=0,unvisited=0,unavailable=0,
        source_correct=0,source_incorrect=0,source_correct_formula_wrong=0,
        source_wrong_formula_correct=0) for field in fields}
    rows=[]
    for reference,formula in zip(references,fidelity['rows']):
        generated=formula.get('generated_ir')
        generated_rules=generated.get('rules',[]) if isinstance(generated,dict) else []
        for slot,target in enumerate(reference['target']['rules']):
            produced=generated_rules[slot] if slot<len(generated_rules) else None
            joined={}
            for field in fields:
                key=(reference['id'],slot,field);event=events.get(key);bucket=counts[field]
                formula_correct=isinstance(produced,dict) and produced.get(field)==target[field]
                if event is None:
                    status='unvisited' if key in unvisited else 'unavailable'
                    bucket[status]+=1
                    joined[field]=dict(status=status,source_correct=None,formula_field_correct=formula_correct)
                else:
                    correct=event['source']['argmax_token_id']==event['target_token_id']
                    bucket['visited']+=1;bucket['source_correct' if correct else 'source_incorrect']+=1
                    bucket['source_correct_formula_wrong']+=int(correct and not formula_correct)
                    bucket['source_wrong_formula_correct']+=int(not correct and formula_correct)
                    joined[field]=dict(status='visited',source_correct=correct,
                        formula_field_correct=formula_correct,target_token_id=event['target_token_id'],
                        actual_next_token_id=event['actual_next_token_id'],position=event['position'],
                        source=event['source'],recurrent=event['recurrent'],combined=event['combined'])
            rows.append(dict(id=reference['id'],slot=slot,source_sha256=reference['source_sha256'],
                expected_rule=target,generated_rule=produced,fields=joined))
    require(len(rows)==180 and all(b['visited']+b['unvisited']+b['unavailable']==180
        and b['source_correct']+b['source_incorrect']==b['visited'] for b in counts.values()),
        'fixed per-field180-site denominators differ')
    return dict(schema='normative-wording-retention-source-head-formula-join/v1',complete=True,
        rows=rows,per_field=counts,source_head_scored_only_at_visited_available_sites=True,
        unvisited_counted_correct=False,unavailable_counted_correct=False,
        extra_generated_unavailable_sites=extra_unavailable,
        reference_labels_applied_after_durable_barrier=True,**FALSE)




def execute(args):
    started = time.monotonic()
    deadline = started+FIXED['max_seconds_entire_run']
    manifest = json.loads(args.manifest.read_bytes())
    plan = json.loads(args.plan.read_bytes())
    validate_plan(plan)
    manifest_sha = sha(args.manifest)
    require(plan['input_sha256'] == manifest['inputs'], 'development input seal differs')
    def recheck():
        check_deadline(deadline)
        require(sha(args.manifest) == manifest_sha and sha(args.plan) == manifest['plan_sha256'],
            'development observer seal differs')
        for path,wanted in manifest['inputs'].items():
            check_deadline(deadline)
            require(sha(path) == wanted, 'sealed development input changed')
        for relative,wanted in manifest['extensions'].items():
            check_deadline(deadline)
            require(sha(args.extension_root/relative) == wanted, 'frozen development source changed')
    recheck()
    require(not args.output.exists(), 'fresh development observer output required')
    parent = bound(manifest, manifest['training_manifest'])
    root = Path(manifest['training_extension_root'])
    require(sha(root/TRAINER) == parent['extensions'][TRAINER], 'frozen normative trainer differs')
    spec = importlib.util.spec_from_file_location('_normative_wording_training_observer', root/TRAINER)
    runner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runner)
    previous = SimpleNamespace(**vars(args))
    previous.manifest = Path(manifest['training_manifest'])
    previous.plan = Path(manifest['training_plan'])
    previous.extension_root = root
    previous.dimension = 384
    ctx = runner.load_context(previous, deadline)
    before = runner.source_inventory(previous, ctx)
    scalar_observer = frozen_scalar_observer(ctx,manifest)
    runs = {}
    for dimension in FIXED['dimensions']:
        terminal = manifest['training_terminals'][str(dimension)]
        require(bound(manifest,terminal['child_exit'])['returncode'] == 0 and
            bound(manifest,terminal['resources_final'])['status'] == 'released',
            'completed released training required')
        summary = bound(manifest, manifest['training_summaries'][str(dimension)])
        require(summary['complete'] is True and summary['phase'] == 'training'
            and summary['dimension'] == dimension and len(summary['runs']) == 2
            and {r['arm'] for r in summary['runs']} == set(ARMS), 'both complete training arms required')
        for item in summary['runs']:
            run = bound(manifest,item['summary_path'])
            require(sha(item['summary_path']) == item['summary_sha256'] and run['dimension'] == dimension
                and run['arm'] == item['arm'] and run['budget_completed'] is True and run['seed'] == 1729
                and all(run[k] is False for k in ('qualified','admitted','checkpoint_promoted')),
                'training endpoint identity differs')
            for role in ROLES:
                ref = run['states'][role]
                require(manifest['inputs'].get(str(Path(ref['path']).resolve())) == ref['sha256'],
                    'endpoint must be bound before generation')
            require(run['states']['selected'] == manifest['selected_states'][f'{dimension}-{run["arm"]}'],
                'exact newly sealed selected state required')
            runs[dimension,run['arm']] = run
    lanes = {}
    digest = ctx['core'].digest
    for dimension in FIXED['dimensions']:
        check_deadline(deadline)
        lane = ctx['mixture_owner'].prepare_lane(ctx,dimension)
        lane['continuation_manifest'] = manifest
        require(str(Path(manifest['source_inputs'][str(dimension)]).resolve()) not in
            {str(Path(manifest[k]).resolve()) for k in ('references','holdout_receipt')},
            'source and reference artifacts must be separate')
        data = bound(manifest,manifest['source_inputs'][str(dimension)])
        require(data['schema'] == 'fresh-scalar-source-inputs-single/v1' and data['complete'] is True
            and data['dimension'] == dimension and data['inputs_sha256'] ==
            digest({k:v for k,v in data.items() if k != 'inputs_sha256'}),
            'authenticated prospective source-only cache required')
        rows = data['rows']
        require(len(rows) == 48 and all(set(r) == {'id','source_text','input'} for r in rows)
            and len({r['id'] for r in rows}) == 48
            and all(set(r) == {'id','source_text','input'} for r in data['clause_cache']),
            'closed48-source exposed-v3 rows and clause cache required')
        for row in rows:
            ctx['core']._vector(row['input'],dimension)
        owner = ctx['owners']['clause_source_context']
        contexts = owner.build_source_contexts([{k:r[k] for k in ('id','source_text')} for r in rows],
            data['clause_cache'])
        require(contexts == data['source_contexts'] and owner.validate_contexts(rows,contexts)['dimension']
            == dimension, 'prospective source contexts differ')
        lane.update(fresh_rows=rows, fresh_contexts=contexts)
        lanes[dimension] = lane
    args.output.mkdir(parents=True)
    save = ctx['helpers'].save
    owner = ctx['exposed_evaluator']
    records = []
    durable_save(save,args.output/'sealed-recipe.json',dict(manifest=manifest,plan=plan,**FALSE))
    for dimension in FIXED['dimensions']:
        for arm in ARMS:
            run = runs[dimension,arm]
            alias = run['states']['selected']['tensor_sha256'] == run['states']['last-attempt']['tensor_sha256']
            for role in ROLES:
                lane = lanes[dimension]
                model = restore_before_deadline(ctx['mixture_owner'],lane,run,role,deadline)
                trace = scalar_observer.collect_source_scalar_trace(model,lane['fresh_rows'],
                    codec=lane['donor']['codec'],input_transform=lane['donor']['input_transform'],
                    source_contexts=lane['fresh_contexts'],max_target_tokens=512,batch_size=8,
                    deadline=min(deadline,time.monotonic()+30.),max_memory_bytes=FIXED['max_trace_memory_bytes'])
                trace_ref = durable_save(save,args.output/f'{dimension}-{arm}'/(role+'-source-head-trace.json'),trace)
                panel = prediction_from_trace(trace)
                panel.update(distribution=FIXED['distribution'],original_meanings_previously_exposed=True,
                    selected_last_identical_tensor_alias=alias,**FALSE)
                ref = durable_save(save,args.output/f'{dimension}-{arm}'/(role+'-predictions.json'),panel)
                check_deadline(deadline)
                records.append(dict(dimension=dimension,arm=arm,role=role,state_ref=run['states'][role],
                    predictions_ref=ref,prediction_fsynced=True,generation_seconds=panel['elapsed_seconds'],
                    source_head_trace_ref=trace_ref,source_head_trace_fsynced=True,
                    selected_last_identical_tensor_alias=alias))
                del model,panel,trace
    durable_save(save,args.output/'predictions-complete.json',dict(complete=True,records=records,
        development_reference_json_loaded=False,all_predictions_fsynced=True,**FALSE))
    refs,receipt = load_references(manifest,records,runs,lanes,ctx['donor']['codec'],digest)
    scoring_refs = scoring_references(refs,receipt)
    results = []
    for record in records:
        lane = lanes[record['dimension']]
        run = runs[record['dimension'],record['arm']]
        model = restore_before_deadline(ctx['mixture_owner'],lane,run,record['role'],deadline)
        ref = record['predictions_ref']
        require(sha(ref['path']) == ref['sha256'], 'saved development prediction changed')
        prediction = json.loads(Path(ref['path']).read_bytes())
        trace_ref = record['source_head_trace_ref']
        require(sha(trace_ref['path']) == trace_ref['sha256'], 'saved source-head trace changed')
        trace = json.loads(Path(trace_ref['path']).read_bytes())
        remaining = min(deadline,time.monotonic()+30.-record['generation_seconds'])
        scalar_score_started = time.monotonic()
        scalar_score = scalar_observer.score_scalar_trace(trace,
            [dict(row,target_ids=reference['target_ids']) for row,reference in zip(lane['fresh_rows'],refs)],
            refs,split='exposed_development',codec=lane['donor']['codec'],
            input_transform=lane['donor']['input_transform'],source_contexts=lane['fresh_contexts'],
            validate_rule=lane['validate_rule'],deadline=remaining)
        scalar_seconds = time.monotonic()-scalar_score_started
        scalar_ref = durable_save(save,args.output/f'{record["dimension"]}-{record["arm"]}'/
            (record['role']+'-source-head-score.json'),scalar_score)
        score = owner.score_panel(ctx,lane,model,prediction,scoring_refs,
            remaining)
        score.update(original_references_sha256=digest(refs),
            original_v3_grouping_metadata_preserved=True,
            distribution=FIXED['distribution'],**FALSE)
        scored = durable_save(save,args.output/f'{record["dimension"]}-{record["arm"]}'/
            (record['role']+'-score.json'),score)
        check_deadline(deadline)
        fields = score['fidelity']['by_facet']
        joined = join_source_heads_and_formula(scalar_score,score['fidelity'],refs)
        joined_ref = durable_save(save,args.output/f'{record["dimension"]}-{record["arm"]}'/
            (record['role']+'-source-head-formula-join.json'),joined)
        results.append(dict(record,score_ref=scored,scoring_seconds=score['elapsed_seconds'],
            source_head_score_ref=scalar_ref,source_head_scoring_seconds=scalar_seconds,
            source_head_formula_join_ref=joined_ref,source_head_by_field=joined['per_field'],
            ordered_exact=score['fidelity']['metrics']['ordered_exact'],
            syntax_valid=score['fidelity']['metrics']['syntax_valid'],
            field_exact={field:dict(correct=fields[field]['correct'],total=fields[field]['total'])
                for field in ('actor','action','modality','object')},
            token_cross_entropy=score['teacher_forced']['token_cross_entropy']))
        del model,prediction,score,trace,scalar_score,joined
    after = runner.source_inventory(previous,ctx)
    require(all(after.get(k) == v for k,v in before.items()), 'observer producer changed')
    recheck()
    result = dict(schema='normative-wording-retention-results/v1',complete=True,panels=results,
        source_dependencies=after,elapsed_seconds=time.monotonic()-started,
        original_meanings_previously_exposed=True,references_sha256=digest(refs),
        exposed_v3_receipt_sha256=digest(receipt), archived_zero_generation_parity_verified=True,
        all_predictions_persisted_before_reference_load=True,
        all_predictions_fsynced_before_reference_load=True,recipe=FIXED,**FALSE)
    durable_save(save,args.output/'summary.json',result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('dependency-root','extension-root','manifest','plan','output'):
        parser.add_argument('--'+name,type=Path,required=True)
    parser.add_argument('--phase',choices=['evaluation'],required=True)
    execute(parser.parse_args())


if __name__ == '__main__':
    main()
