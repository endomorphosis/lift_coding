"""Bind independently reviewed evaluation inputs to completed main publication."""
from pathlib import Path
import hashlib,json,subprocess
R=Path(__file__).resolve().parents[1];W=R.parents[1];P=W/'external/ipfs_datasets'
def digest(path):
 h=hashlib.sha256();size=0
 with path.open('rb') as f:
  for data in iter(lambda:f.read(1048576),b''):h.update(data);size+=len(data)
 return {'sha256':h.hexdigest(),'bytes':size}
def load(path):return json.loads(path.read_bytes())
def git(repo,*args):return subprocess.check_output(['git','-C',str(repo),*args],stderr=subprocess.PIPE)
output=R/'retention/execution-readiness.json';assert not output.exists()
artifacts={};checks=[]
for rel in ['retention/independent-runner-readiness.json','retention/guardian-readiness.json','pipeline/publication-scope-independent-review.json']:
 path=R/rel;review=load(path);assert review['passed'] is True and review['findings']==[]
 for name,wanted in review['artifacts'].items():
  actual=digest(Path(name));target=wanted if isinstance(wanted,str) else wanted['sha256'];assert actual['sha256']==target,name
  if isinstance(wanted,dict) and 'bytes' in wanted:assert actual['bytes']==wanted['bytes'],name
  if name in artifacts:assert artifacts[name]==actual
  artifacts[name]=actual
 artifacts[str(path)]=digest(path);checks.append({'id':rel,'passed':True})
for name,repo in [('datasets',P),('workspace',W)]:
 path=R/(name+'-publication.json');receipt=load(path)
 assert receipt['normal_state_preserved'] is True and receipt['force_push'] is False
 assert receipt['normal_before']==receipt['normal_after']
 head=git(repo,'ls-remote','origin','refs/heads/main').decode().split()[0]
 assert head==receipt['commit'],'publication must remain current main for launch: '+name
 git(repo,'merge-base','--is-ancestor',receipt['parent'],receipt['commit'])
 artifacts[str(path)]=digest(path);checks.append({'id':name+'-main-publication','passed':True,'commit':receipt['commit']})
ready=load(R/'retention/guardian-readiness.json')
ready.update(schema='published-retention-evaluation-execution-readiness/v1',artifacts=artifacts,checks=checks,execution_readiness_granted=True,numerical_execution_readiness_granted=True,integration_publication_receipt=str(R/'workspace-publication.json'),integration_package_publication_receipt=str(R/'datasets-publication.json'),integration_publication_required=True,execution_launched=False,passed=True,findings=[])
with output.open('x') as f:json.dump(ready,f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps({'passed':True,'phase':ready['phase'],'artifacts':len(artifacts),'execution_launched':False}))
