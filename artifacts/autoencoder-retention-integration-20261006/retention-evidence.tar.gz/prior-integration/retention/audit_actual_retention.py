"""Independent stdlib-only output audit, run only after root's completion signal."""
import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import struct
import time

R=Path(__file__).parent
RUN=Path('/home/barberb/lift_coding/external/ipfs_datasets/workspace/test-logs/decoder-normative-wording-retention-20261006')
FIELDS=('actor','action','modality','object')
FACETS=('modality','actor','action','object','conditions','exceptions','temporal')
FLAGS={'qualified','admitted','proof_authority','formalized','roundtrip_ok','checkpoint_promoted',
       'convergence_proven','lake_executed','fresh_holdout','source_semantics_verified',
       'encoder_executed','training_executed','downloads_performed','used_for_selection',
       'independent_semantic_holdout','production_checkpoint','native_family_validation_performed',
       'native_validation_executed','source_alignment_inferred','statutory_alignment_verified',
       'recurrent_clause_effect_causally_isolated'}

def raw(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
def digest(value):return hashlib.sha256(raw(value).encode()).hexdigest()
def f32(value):return struct.unpack('<f',struct.pack('<f',value))[0]
def metric(logits,target,emitted):
    maximum=max(logits)
    return {'argmax_token_id':max(range(len(logits)),key=logits.__getitem__),
            'target_minus_best_other':logits[target]-max(v for i,v in enumerate(logits) if i!=target),
            'target_minus_emitted':logits[target]-logits[emitted],
            'full_vocabulary_cross_entropy':maximum+math.log(sum(math.exp(v-maximum) for v in logits))-logits[target]}

def audit(completion_signaled):
    if completion_signaled is not True:raise ValueError('Root completion signal is required before parsing outputs or references')
    started=time.monotonic();attempt=RUN/'retention-r1';out=attempt/'results';artifacts={};checks=[]
    def check(name,condition,detail=None):
        if not condition:raise ValueError(name+': '+str(detail))
        checks.append({'id':name,'passed':True,**({'detail':detail} if detail is not None else {})})
    def pin(path):
        path=Path(path);before=path.stat();h=hashlib.sha256()
        with path.open('rb') as stream:
            for block in iter(lambda:stream.read(4*1024*1024),b''):h.update(block)
        after=path.stat()
        if (before.st_size,before.st_mtime_ns,before.st_ino)!=(after.st_size,after.st_mtime_ns,after.st_ino):raise ValueError('Audit input changed: '+str(path))
        value={'bytes':after.st_size,'sha256':h.hexdigest()};artifacts[str(path)]=value;return value
    def read(path):
        pin(path);return json.loads(Path(path).read_bytes())
    def referenced(ref):
        p=pin(ref['path']);check('artifact-reference-'+Path(ref['path']).name,p['sha256']==ref['sha256'] and ('bytes' not in ref or p['bytes']==ref['bytes']))
        return json.loads(Path(ref['path']).read_bytes())
    def false_masks(value,prefix):
        if isinstance(value,dict):
            for k,v in value.items():
                if k in FLAGS and v is not False:raise ValueError('Authority mask not false: '+prefix+'.'+k)
                false_masks(v,prefix+'.'+k)
        elif isinstance(value,list):
            for i,v in enumerate(value):false_masks(v,prefix+f'[{i}]')
    guardian=read(RUN/'retention-r1-guardian-exit.json');child=read(attempt/'child-exit.json');final=read(attempt/'resources-final.json')
    observations=read(attempt/'resource-observations.json');command=read(attempt/'command.json');lease=read(attempt/'lease-binding.json')
    check('terminal-run-complete',guardian['returncode']==child['returncode']==0 and child['leader_reaped'] is True and final['status']=='released' and final['cleanup_error'] is None)
    check('resource-scope',command['outer_cpu_slots']==command['outer_child_process_slots']==1 and command['outer_memory_mb']==1536 and command['storage_bytes']==100000000 and lease['own_fields']['requires_gpu'] is False)
    plan=read(RUN/'evaluation-plan.json');manifest=read(RUN/'evaluation-manifest.json');summary=read(out/'summary.json');barrier=read(out/'predictions-complete.json')
    check('complete-four-selected-panels',summary['complete'] is True and barrier['complete'] is True and len(summary['panels'])==len(barrier['records'])==4 and {(x['dimension'],x['arm'],x['role']) for x in summary['panels']}=={(d,a,'selected') for d in [384,768] for a in ['normative-wording-zero','normative-wording-ce']})
    check('barrier-flags',barrier['development_reference_json_loaded'] is False and barrier['all_predictions_fsynced'] is True and summary['all_predictions_fsynced_before_reference_load'] is True and summary['all_predictions_persisted_before_reference_load'] is True)
    check('fixed-generation-policy',plan['context_tokens']==plan['output_tokens']==512 and plan['temperature']==0 and plan['vocabulary_size']==32 and plan['batch_size']==8 and plan['workers']==1 and plan['bridge_names']==[] and plan['legal_ir_evaluate_provers'] is False and plan['metric_disk_cache_used'] is False)
    source={d:read(manifest['source_inputs'][str(d)]) for d in [384,768]}
    check('closed-same-source-cohort',all(len(v['rows'])==48 and len({x['id'] for x in v['rows']})==48 and all(set(x)=={'id','input','source_text'} for x in v['rows']) for v in source.values()) and [{k:x[k] for k in ['id','source_text']} for x in source[384]['rows']]==[{k:x[k] for k in ['id','source_text']} for x in source[768]['rows']])
    saved={};zero_parity=[];full_logit_sites=0
    for record in summary['panels']:
        d=record['dimension'];arm=record['arm'];key=(d,arm)
        check('durable-panel-'+str(key),record['prediction_fsynced'] is True and record['source_head_trace_fsynced'] is True and record['state_ref']==manifest['selected_states'][f'{d}-{arm}'])
        state=referenced(record['state_ref']);prediction=referenced(record['predictions_ref']);trace=referenced(record['source_head_trace_ref'])
        expected_rows=source[d]['rows'];contexts=source[d]['source_contexts'];vocab=state['codec']['target_vocabulary']
        check('state-source-codec-transform-'+str(key),state['tensor_sha256']==trace['model_tensor_sha256']==prediction['model_tensor_sha256']==record['state_ref']['tensor_sha256'] and trace['source_rows_sha256']==prediction['source_rows_sha256']==digest(expected_rows) and trace['source_contexts_sha256']==prediction['source_contexts_sha256']==digest(contexts) and trace['codec_sha256']==digest(state['codec']) and trace['input_transform_sha256']==digest(state['input_transform']))
        check('trace-predictions-'+str(key),trace['trace_sha256']==digest({k:v for k,v in trace.items() if k!='trace_sha256'}) and trace['predictions']==prediction['predictions'] and prediction['same_pass_scalar_trace_sha256']==trace['trace_sha256'] and len(trace['rows'])==len(prediction['predictions'])==48 and [x['id'] for x in prediction['predictions']]==[x['id'] for x in expected_rows])
        check('same-pass-flags-'+str(key),all(trace[k] is True for k in ['complete','source_only','full_vocabulary_retained','decomposition_exact','caller_state_preserved','hooks_removed','complete_rollout_before_reference_scoring']) and all(trace[k] is False for k in ['reference_count_access','reference_prefix_access','reference_documents_passed_to_model','inventory_access','source_context_target_access','syntax_mask','forced_closure','model_copied']) and trace['extra_model_passes']==trace['source_head_extra_evaluations']==trace['optimizer_steps']==0 and trace['greedy_batch_steps']==trace['recurrent_readout_calls'] and trace['vocabulary_size']==32)
        sites={};batch_steps={}
        for row,pred in zip(trace['rows'],prediction['predictions']):
            if row['id']!=pred['id'] or row['consumed_prefix']!=[1]+pred['token_ids'][:len(row['consumed_prefix'])-1]:raise ValueError('Actual prefix/output identity mismatch')
            batch_steps[row['batch_offset']]=max(batch_steps.get(row['batch_offset'],0),len(row['consumed_prefix']))
            for site in row['scalar_sites']:
                for name in ['raw_recurrent_logits','applied_source_logits','combined_logits']:
                    if len(site[name])!=32 or not all(type(v) in (float,int) and math.isfinite(v) for v in site[name]):raise ValueError('Full finite logits missing')
                if any(f32(a+b)!=c for a,b,c in zip(site['raw_recurrent_logits'],site['applied_source_logits'],site['combined_logits'])):raise ValueError('Exact float32 decomposition mismatch')
                available=site['slot']<len(contexts[row['id']]['segments'])
                if site['source_slot_available'] is not available or (not available and any(v!=0 for v in site['applied_source_logits'])):raise ValueError('Unavailable source guidance mismatch')
                chosen=site['actual_next_token_id'];position=site['position'];tokens=pred['token_ids']
                if chosen!=max(range(32),key=site['combined_logits'].__getitem__):raise ValueError('Scalar argmax mismatch')
                expected=tokens[position] if position<len(tokens) else 2 if pred['generation_status']=='eos' else chosen if chosen in (0,1) and pred['generation_status']=='invalid_special_token' else None
                if chosen!=expected:raise ValueError('Actual emitted scalar token mismatch')
                sitekey=(row['id'],site['slot'],site['field'])
                if sitekey in sites:raise ValueError('Duplicate scalar site')
                sites[sitekey]=site;full_logit_sites+=1
        check('independent-full-logit-sites-'+str(key),len(sites)==trace['scalar_site_count'] and sum(batch_steps.values())==trace['greedy_batch_steps'])
        if arm=='normative-wording-zero':
            old=referenced(manifest['archived_zero_predictions'][str(d)]);keys=['id','token_ids','generation_status','eos_reached']
            matched=[{k:x[k] for k in keys} for x in old['predictions']]==[{k:x[k] for k in keys} for x in prediction['predictions']]
            check('archived-zero-parity-'+str(d),matched and old['model_tensor_sha256']==record['state_ref']['tensor_sha256'] and old['source_rows_sha256']==digest(expected_rows) and old['source_contexts_sha256']==digest(contexts));zero_parity.append({'dimension':d,'exact_token_status_eos_parity':matched,'archived_ref':manifest['archived_zero_predictions'][str(d)],'tensor_sha256':record['state_ref']['tensor_sha256']})
        for value,label in [(prediction,'prediction'),(trace,'trace')]:false_masks(value,label)
        saved[key]=(record,state,prediction,trace,sites)
    # The audited four-panel barrier precedes reference-body parsing in this audit too.
    refs=read(manifest['references']);receipt=read(manifest['holdout_receipt'])
    check('original-v3-reference-binding',len(refs)==48 and sum(len(x['target']['rules']) for x in refs)==180 and receipt['sealed_comparison_sha256']==plan['comparison_seal'] and receipt['references_sha256']==summary['references_sha256']==digest(refs) and receipt['receipt_sha256']==digest({k:v for k,v in receipt.items() if k!='receipt_sha256'}) and summary['exposed_v3_receipt_sha256']==digest(receipt))
    panels=[]
    for key,(record,state,prediction,trace,sites) in saved.items():
        score=referenced(record['score_ref']);scalar=referenced(record['source_head_score_ref']);joined=referenced(record['source_head_formula_join_ref']);fid=score['fidelity'];tf=score['teacher_forced'];vocab=state['codec']['target_vocabulary']
        check('score-trace-bindings-'+str(key),score['references_sha256']==scalar['references_sha256']==digest(refs) and scalar['trace_sha256']==trace['trace_sha256'] and scalar['score_sha256']==digest({k:v for k,v in scalar.items() if k!='score_sha256'}) and len(fid['rows'])==48 and len(joined['rows'])==180)
        exact=0;facets={f:0 for f in FACETS};missing=extra=0
        for reference,pred,row in zip(refs,prediction['predictions'],fid['rows']):
            if reference['id']!=pred['id'] or pred['id']!=row['id'] or row['expected_ir']!=reference['target']:raise ValueError('Ordered gold/fidelity/prediction join mismatch')
            try:generated=json.loads(''.join(vocab[t] for t in pred['token_ids']))
            except (ValueError,IndexError):generated=None
            if raw(generated)!=raw(row['generated_ir']):raise ValueError('Saved raw generated JSON mismatch')
            correct=bool(pred['eos_reached'] and raw(generated)==raw(reference['target']));exact+=correct
            if int(correct)!=row['counts']['ordered_exact']:raise ValueError('Independent ordered exact mismatch')
            generated_rules=generated.get('rules',[]) if isinstance(generated,dict) else []
            for f in FACETS:
                count=sum(slot<len(generated_rules) and isinstance(generated_rules[slot],dict) and f in generated_rules[slot] and raw(generated_rules[slot][f])==raw(gold[f]) for slot,gold in enumerate(reference['target']['rules']))
                if count!=row['by_facet'][f]['correct'] or row['by_facet'][f]['total']!=len(reference['target']['rules']):raise ValueError('Complete facet accounting mismatch')
                facets[f]+=count
            gold_counts=Counter(raw(x) for x in reference['target']['rules']);generated_counts=Counter(raw(x) for x in generated_rules);matched=sum((gold_counts&generated_counts).values());missing+=len(reference['target']['rules'])-matched;extra+=len(generated_rules)-matched
        check('independent-fidelity-counts-'+str(key),exact==record['ordered_exact']==fid['metrics']['ordered_exact'] and fid['metrics']['rows']==48 and fid['metrics']['expected_rules']==180 and fid['metrics']['whole_rules_missing']==missing and fid['metrics']['whole_rules_extra']==extra and all(fid['by_facet'][f]['total']==180 and fid['by_facet'][f]['correct']==facets[f] for f in FACETS))
        ce_sum=0;tokens=0
        for reference,row in zip(refs,tf['rows']):
            vals=row['token_cross_entropies'];n=len(reference['target_ids'])-1
            if row['id']!=reference['id'] or row['target_token_ids']!=reference['target_ids'][1:] or row['token_count']!=n or len(vals)!=n or not math.isclose(row['cross_entropy'],sum(vals)/n,rel_tol=1e-12,abs_tol=1e-12):raise ValueError('Teacher-forced CE count/row aggregation mismatch')
            ce_sum+=sum(vals);tokens+=n
        ce=ce_sum/tokens
        check('teacher-forced-CE-'+str(key),tokens==tf['valid_target_tokens'] and math.isclose(ce,tf['token_cross_entropy'],rel_tol=1e-12,abs_tol=1e-12) and ce==record['token_cross_entropy'] and tf['full_vocabulary_size']==32 and tf['reference_prefixes_used'] is True and tf['greedy_repeated'] is False and tf['used_for_selection'] is False)
        eventmap={};pure_metrics=0
        for event in scalar['events']:
            ek=(event['id'],event['slot'],event['field']);site=sites[ek]
            if ek in eventmap:raise ValueError('Duplicate scalar scored event')
            eventmap[ek]=event
            for label,vector in [('source','applied_source_logits'),('recurrent','raw_recurrent_logits'),('combined','combined_logits')]:
                recomputed=metric(site[vector],event['target_token_id'],event['actual_next_token_id'])
                for k,v in recomputed.items():
                    if type(v) is int:
                        if event[label][k]!=v:raise ValueError('Scalar argmax measure mismatch')
                    elif not math.isclose(event[label][k],v,rel_tol=1e-12,abs_tol=1e-12):raise ValueError('Scalar CE/margin measure mismatch')
                pure_metrics+=1
        expected_slots=[(ref['id'],slot,rule) for ref in refs for slot,rule in enumerate(ref['target']['rules'])]
        aggregate={f:{k:0 for k in joined['per_field'][f]} for f in FIELDS}
        for j,(identity,slot,gold) in zip(joined['rows'],expected_slots):
            if (j['id'],j['slot'],raw(j['expected_rule']))!=(identity,slot,raw(gold)):raise ValueError('180 ordered rule slot join mismatch')
            for f in FIELDS:
                value=j['fields'][f];bucket=aggregate[f];bucket['reference_sites']+=1;status=value['status'];bucket[status]+=1;event=eventmap.get((identity,slot,f))
                if event is None:
                    if status not in ('unvisited','unavailable') or value['source_correct'] is not None:raise ValueError('Missing site falsely correct')
                else:
                    correct=event['source']['argmax_token_id']==event['target_token_id'];formula_correct=isinstance(j['generated_rule'],dict) and raw(j['generated_rule'].get(f))==raw(gold[f])
                    if status!='visited' or value['source_correct'] is not correct or value['formula_field_correct'] is not formula_correct:raise ValueError('Source/formula field join mismatch')
                    bucket['source_correct' if correct else 'source_incorrect']+=1;bucket['source_correct_formula_wrong']+=int(correct and not formula_correct);bucket['source_wrong_formula_correct']+=int(not correct and formula_correct)
        check('full720-site-join-'+str(key),aggregate==joined['per_field']==record['source_head_by_field'] and all(v['reference_sites']==v['visited']+v['unvisited']+v['unavailable']==180 for v in aggregate.values()) and joined['unvisited_counted_correct'] is False and joined['unavailable_counted_correct'] is False and joined['reference_labels_applied_after_durable_barrier'] is True)
        for value,label in [(score,'score'),(scalar,'scalar-score'),(joined,'join')]:false_masks(value,label)
        panels.append({'dimension':key[0],'arm':key[1],'role':'selected','ordered_exact':exact,'paragraph_denominator':48,'syntax_valid':fid['metrics']['syntax_valid'],'eos_count':fid['metrics']['eos_count'],'rules':180,'generated_rules':fid['metrics']['generated_rules'],'whole_rule_multiset_missing':missing,'whole_rule_multiset_extra':extra,'scalar_sites':720,'by_facet':{f:{'correct':facets[f],'total':180} for f in FACETS},'source_head_by_field':aggregate,'scored_scalar_events':len(eventmap),'unvisited_sites':len(scalar['unvisited_reference_sites']),'unscored_sites':len(scalar['unscored_sites']),'extra_generated_unavailable_sites':len(joined['extra_generated_unavailable_sites']),'independent_scalar_distribution_metrics_checked':pure_metrics,'token_cross_entropy':ce,'teacher_forced_target_tokens_including_EOS':tokens,'generation_seconds':record['generation_seconds'],'scalar_scoring_seconds':record['source_head_scoring_seconds'],'formula_teacher_forced_scoring_seconds':record['scoring_seconds']})
    deltas=[]
    for d in [384,768]:
        z=next(x for x in panels if x['dimension']==d and x['arm']=='normative-wording-zero');a=next(x for x in panels if x['dimension']==d and x['arm']=='normative-wording-ce')
        deltas.append({'dimension':d,'exact_zero':z['ordered_exact'],'exact_auxiliary':a['ordered_exact'],'exact_paragraph_delta':a['ordered_exact']-z['ordered_exact'],'paragraph_denominator':48,'ce_zero':z['token_cross_entropy'],'ce_auxiliary':a['token_cross_entropy'],'ce_absolute_delta':a['token_cross_entropy']-z['token_cross_entropy'],'ce_relative_change_percent':100*(a['token_cross_entropy']/z['token_cross_entropy']-1),'modality_rule_correct_zero':z['by_facet']['modality']['correct'],'modality_rule_correct_auxiliary':a['by_facet']['modality']['correct'],'rule_denominator':180,'source_modality_correct_zero':z['source_head_by_field']['modality']['source_correct'],'source_modality_correct_auxiliary':a['source_head_by_field']['modality']['source_correct'],'source_modality_correct_formula_wrong_auxiliary':a['source_head_by_field']['modality']['source_correct_formula_wrong']})
    false_masks(summary,'summary');false_masks(barrier,'barrier')
    changed=[];hashed=0
    for path,wanted in manifest['inputs'].items():
        info=pin(path);hashed+=1
        if info['sha256']!=wanted:changed.append(path)
    check('post-run-input-preservation',not changed,{'inputs_hashed':hashed,'changed':changed})
    for path,wanted in summary['source_dependencies'].items():check('resident-owner-'+Path(path).name,pin(path)['sha256']==wanted)
    peak=max((x.get('group_rss',{}).get('rss_bytes',0) for x in observations),default=0)
    output_bytes=sum(p.stat().st_size for p in out.rglob('*') if p.is_file())
    result={'schema':'actual-retention-independent-review/v1','passed':True,'findings':[],'checks':checks,'artifacts':artifacts,'run_root':str(RUN),'attempt':'retention-r1','root_completion_signal_received':True,'panels':panels,'same_width_deltas':deltas,'archived_zero_exact_parity':zero_parity,'full_vocabulary_scalar_sites_independently_checked':full_logit_sites,'all_semantic_admission_masks_false':True,'timing':{'driver_elapsed_seconds':summary['elapsed_seconds'],'guardian_outer_seconds':guardian['elapsed_seconds'],'launch_return_through_reap_wall_seconds':child['launch_return_through_reap_wall_seconds'],'guardian_elapsed_through_child_exit_seconds':child['guardian_elapsed_through_child_exit_seconds'],'isolated_child_execution_seconds':child['isolated_child_execution_seconds'],'generation_sum_seconds':sum(x['generation_seconds'] for x in panels),'scalar_scoring_sum_seconds':sum(x['scalar_scoring_seconds'] for x in panels),'formula_teacher_forced_scoring_sum_seconds':sum(x['formula_teacher_forced_scoring_seconds'] for x in panels),'interpretation':'Driver includes setup/restoration/input hashes; guardian includes admission/monitoring/accounting/finalization. Timing is warm-cache observational host-shared data; no isolated-child time or speedup is inferred.'},'resources':{'sampled_peak_group_rss_bytes':peak,'sampled_peak_not_true_peak':True,'output_bytes':output_bytes,'storage_limit_bytes':100000000,'reserved_memory_mb':1536,'final_status':'released','enforcement':final['enforcement'],'continuous_lease_coverage_claimed':final['lease_watchdog']['continuous_lease_coverage_claimed']},'measurement_limits':['Previously exposed authored48-paragraph/180-rule empty-qualifier cohort; no fresh semantic holdout.','Whole-rule multiset missing/extra counts include substituted rules; they do not mean180ordered slots were omitted.','Scalar source/recurrent/combined logits are actual same-pass decompositions; recurrent clause effects are not causally isolated.','Teacher-forced CE uses full32-token vocabulary and reference prefixes only after generation, and is separate from generated formula/source fidelity.','No general UI/Deontic semantic floor, source-grounding, global convergence, checkpoint promotion, full-law formalization or proof admission follows.'],'audit_execution':{'read_only':True,'model_imported':False,'model_executed':False,'numerical_owner_imported':False,'encoder_executed':False,'native_validator_or_prover_or_lake_executed':False,'source_or_tensor_modified':False,'v3_references_parsed_only_after_completion_signal_and_four_panel_barrier_check':True,'elapsed_seconds':time.monotonic()-started}}
    (R/'actual-result-independent-review.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'passed':True,'panels':len(panels),'same_width_deltas':deltas,'full_scalar_sites':full_logit_sites,'post_run_inputs':hashed,'audit_seconds':result['audit_execution']['elapsed_seconds']}))

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--root-completion-signaled',action='store_true');args=parser.parse_args();audit(args.root_completion_signaled)
