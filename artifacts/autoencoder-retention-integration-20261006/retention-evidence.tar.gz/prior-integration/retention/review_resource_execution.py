"""Read-only independent audit of one completed retention guardian attempt.

This reads resource receipts, public watchdog events and summary metadata only.
It never imports the resource owner, scheduler, numerical runner or model code.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import stat
import time

W = Path('/home/barberb/lift_coding')
P = W / 'external/ipfs_datasets'
R = W / 'artifacts/autoencoder-progress-reconcile-20261006'
RUN = P / 'workspace/test-logs/decoder-normative-wording-retention-20261006'
ATTEMPT = RUN / 'retention-r1'
SOURCE = P / 'workspace/test-logs/ui-modal-coverage-20261002/validation-source-r2'
OWNER = P / 'workspace/test-logs/native4096-four-width-20261004/resource-cap/autoencoder_daemon_resources.py'
SCHEDULER = SOURCE / 'ipfs_datasets_py/optimizers/logic_theorem_optimizer/resource_scheduler.py'
OWNER_SHA = 'b00d2752ba852fe73760bba4fbd51b0e845742c3527642606a2a77ed9f8f5e2c'
SCHEDULER_SHA = 'a418e84f70ed8509ba0518feea69e7a8c27865139f83b6c81349eefdfd5893a4'


def stable_read(path: Path, maximum=32 * 1024 * 1024):
    for parent in (*reversed(path.parents), path):
        mode = parent.lstat().st_mode
        if stat.S_ISLNK(mode):
            raise ValueError(f'symlink in audit input: {parent}')
        if parent != path and not stat.S_ISDIR(mode):
            raise ValueError(f'non-directory audit input ancestor: {parent}')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        before = os.fstat(fd)
        if not stat.S_ISREG(before.st_mode) or before.st_size > maximum:
            raise ValueError(f'nonregular or oversized audit input: {path}')
        chunks = []
        size = 0
        while data := os.read(fd, min(1024 * 1024, maximum + 1 - size)):
            chunks.append(data)
            size += len(data)
            if size > maximum:
                raise ValueError(f'input exceeds audit bound: {path}')
        after = os.fstat(fd)
        visible = path.lstat()
        fields = ('st_dev', 'st_ino', 'st_mode', 'st_size', 'st_mtime_ns', 'st_ctime_ns', 'st_nlink')
        identity = lambda x: tuple(getattr(x, key) for key in fields)
        if identity(before) != identity(after) or identity(after) != identity(visible):
            raise ValueError(f'audit input changed during read: {path}')
        raw = b''.join(chunks)
        return raw, {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}
    finally:
        os.close(fd)


def process_snapshot(child):
    members = []
    skipped_disappeared = 0
    leader = None
    entries = list(Path('/proc').iterdir())
    if len(entries) > 100_000:
        raise ValueError('process inventory bound exceeded')
    for path in entries:
        if not path.name.isdecimal():
            continue
        try:
            raw = (path / 'stat').read_text()
        except (FileNotFoundError, ProcessLookupError):
            skipped_disappeared += 1
            continue
        fields = raw[raw.rfind(')') + 2:].split()
        if len(fields) < 22:
            raise ValueError('invalid process stat record')
        row = {'pid': int(path.name), 'birth': fields[19], 'state': fields[0],
               'group_pid': int(fields[2]), 'rss_bytes': int(fields[21]) * os.sysconf('SC_PAGE_SIZE')}
        if row['pid'] == child['pid']:
            leader = row
        if row['group_pid'] == child['pid']:
            members.append(row)
    return {'observed_at_unix': time.time(), 'scope': 'one fresh /proc identity/group snapshot; no command lines or environments',
            'leader': leader, 'members': members,
            'live_processes': sum(row['state'] != 'Z' for row in members),
            'live_rss_bytes': sum(row['rss_bytes'] for row in members if row['state'] != 'Z'),
            'processes_disappeared_during_scan': skipped_disappeared}


def inventory_snapshot(path):
    root_before = path.stat()
    records = []
    pending = [path]
    while pending:
        directory = pending.pop()
        with os.scandir(directory) as entries:
            for entry in entries:
                info = entry.stat(follow_symlinks=False)
                if len(records) >= 10_000:
                    raise ValueError('owned attempt inventory bound exceeded')
                if stat.S_ISDIR(info.st_mode):
                    records.append((entry.path, 'directory', 0))
                    pending.append(Path(entry.path))
                elif stat.S_ISREG(info.st_mode):
                    records.append((entry.path, 'regular', info.st_size))
                else:
                    raise ValueError('nonregular entry in owned attempt')
    root_after = path.stat()
    if (root_before.st_dev, root_before.st_ino) != (root_after.st_dev, root_after.st_ino):
        raise ValueError('owned attempt identity changed')
    return {'observed_at_unix': time.time(), 'scope': 'fresh metadata-only census; no file values read',
            'apparent_bytes': sum(row[2] for row in records), 'entry_count': len(records),
            'regular_file_count': sum(row[1] == 'regular' for row in records),
            'symlink_count': 0, 'special_file_count': 0,
            'root': {'path': str(path), 'device': root_after.st_dev, 'inode': root_after.st_ino}}


def main():
    artifacts = {}
    checks = []

    def load(path, *, bind=True):
        raw, receipt = stable_read(path)
        if bind:
            artifacts[str(path)] = receipt
        return json.loads(raw), receipt

    def check(identifier, passed, detail):
        checks.append({'id': identifier, 'passed': bool(passed), 'detail': detail})

    start, _ = load(ATTEMPT / 'resources-start.json')
    final, _ = load(ATTEMPT / 'resources-final.json')
    observations, _ = load(ATTEMPT / 'resource-observations.json')
    child, _ = load(ATTEMPT / 'child-identity.json')
    child_exit, _ = load(ATTEMPT / 'child-exit.json')
    command, _ = load(ATTEMPT / 'command.json')
    binding, _ = load(ATTEMPT / 'lease-binding.json')
    adoption, _ = load(RUN / 'retention-r1-scheduler-adoption.json')
    outer, _ = load(RUN / 'retention-r1-guardian-exit.json')
    reserved, _ = load(RUN / 'retention-r1-guardian.log')
    summary, _ = load(ATTEMPT / 'results/summary.json')
    ready, _ = load(R / 'retention/execution-readiness.json')
    manifest, _ = load(RUN / 'evaluation-manifest.json')
    plan, _ = load(RUN / 'evaluation-plan.json')
    workspace_pub, _ = load(Path(ready['integration_publication_receipt']))
    datasets_pub, _ = load(Path(ready['integration_package_publication_receipt']))
    for path in (Path(__file__), OWNER, SCHEDULER,
                 *(RUN / name for name in ('run_guardian.py', 'run_reserved.py', 'owned_lease_watchdog.py',
                                          'adopt_shared_scheduler.py', 'lazy_scheduler_adoption.py'))):
        _, artifacts[str(path)] = stable_read(path)
    raw, events_receipt = stable_read(RUN / 'retention-r1-lease-observations.jsonl')
    artifacts[str(RUN / 'retention-r1-lease-observations.jsonl')] = events_receipt
    events = [json.loads(line) for line in raw.splitlines()]
    samples = [event for event in events if event.get('schema') == 'guardian-owned-lease-observation/v1']
    present = [event for event in samples if event.get('expected') == 'present']
    absent = [event for event in samples if event.get('expected') == 'absent']
    monitors = [event for event in samples if event.get('stage') == 'monitor']
    record = final['record']
    usage = observations + [record['last_usage']]
    config_sha = binding['config_sha256']
    own_lease = binding['own_fields']['lease_id']
    own_reservation = final['reservation_id']
    ledger, ledger_receipt = load(Path(final['ledger_path']), bind=False)
    scheduler, scheduler_receipt = load(Path(binding['state_path']), bind=False)
    current_config_sha = hashlib.sha256(json.dumps(scheduler['config'], sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    processes = process_snapshot(child)
    inventory = inventory_snapshot(ATTEMPT)
    check('actual-complete-and-successful', outer['returncode'] == child_exit['returncode'] == reserved['returncode'] == 0
          and reserved['status'] == 'complete' and summary['complete'] is True,
          'Terminal outer receipt, reserved-wrapper log and reaped child exit all record success; summary complete metadata exists.')
    check('final-readiness-for-this-evaluation', ready['passed'] is True and not ready['findings']
          and ready['execution_readiness_granted'] is True and ready['phase'] == 'evaluation'
          and ready['dimension'] is None and ready['run_root'] == str(RUN),
          'The exact published integration prerequisite preceded this evaluation attempt; readiness was granted for this root and phase.')
    check('evaluation-command-and-limits', command['command'][command['command'].index('--phase') + 1] == 'evaluation'
          and '--dimension' not in command['command'] and command['outer_cpu_slots'] == 1
          and command['outer_memory_mb'] == 1536 and command['outer_child_process_slots'] == 1
          and command['storage_bytes'] == 100_000_000 and command['outer_admission_timeout_seconds'] == 600,
          'One CPU, 1536 MiB, one child slot, 100 MB attempt claim and a 600 s admission bound are explicit.')
    check('archived-owner-and-frozen-scheduler', artifacts[str(OWNER)]['sha256'] == OWNER_SHA
          and artifacts[str(SCHEDULER)]['sha256'] == SCHEDULER_SHA
          and adoption['producer_sha256']['ipfs_datasets_py/optimizers/logic_theorem_optimizer/autoencoder_daemon_resources.py'] == OWNER_SHA
          and adoption['producer_sha256']['ipfs_datasets_py/optimizers/logic_theorem_optimizer/resource_scheduler.py'] == SCHEDULER_SHA,
          'Admitted producer pins match independently rehashed archived owner and frozen dependency scheduler; no live scheduler substitution.')
    check('frozen-guardian-wrappers-still-match-readiness', all(artifacts[str(RUN / name)] == ready['artifacts'][str(RUN / name)]
          for name in ('run_guardian.py', 'run_reserved.py', 'owned_lease_watchdog.py', 'adopt_shared_scheduler.py', 'lazy_scheduler_adoption.py')),
          'All five executed guardian wrappers retain their exact final-readiness hashes and byte counts.')
    check('exact-owned-identity-chain', start['reservation_id'] == own_reservation == record['reservation_id']
          and start['record']['child'] == record['child'] == child
          and start['resource_lease']['lease_id'] == final['resource_lease']['lease_id'] == own_lease
          and binding['own_fields']['owner_pid'] == record['owner_pid'] == adoption['owner_pid'],
          'Reservation, own lease, guardian owner and child PID/birth agree across admission, use and release.')
    check('adoption-preserves-shared-policy', adoption['complete'] is True and all(adoption[key] is False
          for key in ('reset_performed', 'capacity_changed', 'proof_guards_changed', 'global_scheduler_cache_modified', 'stale_recovery_called_by_adoption'))
          and all(adoption[key] == 0 for key in ('leases_acquired_by_adoption', 'leases_cancelled_by_adoption', 'leases_released_by_adoption')),
          'The guardian-local adoption receipt records no reset, capacity/proof changes, foreign lease actions or global client replacement.')
    check('watchdog-log-hash', events_receipt['sha256'] == final['lease_watchdog']['events_sha256'],
          'The independently hashed public watchdog log matches the final resource receipt seal.')
    check('sampled-own-lease-healthy', len(present) == 37 and len(absent) == 1 and all(event['healthy'] is True for event in samples)
          and all(event['lease_present'] is True and event['cancelled'] is False and event['owned_identity_matches'] is True
                  and event['remaining_ttl_seconds'] > 0 for event in present),
          'Every present-lease sample is healthy, uncancelled, unexpired and matches the captured owner identity.')
    check('sampled-configuration-unchanged', all(event['configuration_matches'] is True
          and event['observed_config_sha256'] == event['expected_config_sha256'] == config_sha
          and event['changed_known_configuration_fields'] == [] and event['unknown_configuration_fields_present'] is False for event in samples),
          'Known shared scheduler configuration remains unchanged at all 38 observations.')
    check('monitor-gap-bounded', len(monitors) == 34 and all(event['observation_gap_seconds'] <= 5.0 for event in monitors),
          'All 34 child-monitor observations satisfy the reviewed 5 s observation-gap bound.')
    check('sampled-observer-read-only-and-no-continuous-claim', all(event['read_only'] is True
          and event['capability_persisted'] is False and event['continuous_coverage_claimed'] is False for event in samples)
          and final['lease_watchdog']['continuous_lease_coverage_claimed'] is False
          and final['lease_watchdog']['shared_state_mutated_by_observer'] is False,
          'Public events persist no capability and claim sampled coverage only; the observer does not mutate scheduler state.')
    check('lease-absent-after-release', absent[0]['stage'] == 'post_finalize' and absent[0]['lease_present'] is False
          and final['lease_watchdog']['post_release_observation'] == absent[0]
          and final['resource_lease']['released'] is True and own_lease not in scheduler['leases'],
          'Post-finalize observation and a fresh read-only scheduler snapshot both show this lease absent.')
    check('current-config-still-matches', current_config_sha == config_sha,
          'The current read-only scheduler configuration snapshot retains the adopted configuration hash.')
    check('released-owned-disk-record', final['status'] == record['status'] == 'released'
          and ledger['reservations'][own_reservation] == record and final['cleanup_error'] is None,
          'Current ledger own row equals the durable final receipt and is released without cleanup error; foreign rows were not edited by this audit.')
    check('durable-before-release', record['artifacts_durable_asserted'] is True
          and record['attempt_exceeded_reservation'] is False and record['prior_children'] == [],
          'The resource owner asserts artifact durability before release; no reservation overrun or replacement child is recorded.')
    check('all-resource-observations-bounded', len(observations) == 2 and all(item['group_rss']['available'] is True
          and item['group_rss']['rss_bytes'] <= 1536 * 1024 * 1024 and item['group_rss']['live_processes'] <= 1
          and item['process_slot_estimate_exceeded'] is False and item['total_attempt_charged_bytes'] <= 100_000_000
          and item['charged_bytes'] <= item['limit_bytes'] == 145_000_000_000 for item in usage),
          'Both runtime samples and the fresh final census stay within sampled RSS, child count, attempt and named-root charge limits.')
    check('owned-leader-reaped-and-group-empty', child_exit['leader_reaped'] is True
          and record['last_usage']['group_rss']['live_processes'] == record['last_usage']['group_rss']['rss_bytes'] == 0
          and processes['leader'] is None and processes['live_processes'] == processes['live_rss_bytes'] == 0,
          'Recorded final census and an independent current /proc snapshot show no owned leader or live process-group member.')
    check('one-fresh-final-census-and-full-claim-release', record['finalization_profile']['global_inventory_count'] == 1
          and record['finalization_profile']['strict_attempt_inventory_count'] == 1
          and record['last_usage']['charged_bytes'] - record['final_accounting']['charged_bytes'] == 100_000_000
          and record['last_usage']['outstanding_full_reservations_bytes'] - record['final_accounting']['outstanding_full_reservations_bytes'] == 100_000_000
          and record['last_usage']['observed_apparent_bytes'] == record['final_accounting']['observed_apparent_bytes'],
          'One fresh final global census checks the full own claim before exactly 100 MB of reservation arithmetic is removed.')
    check('attempt-census-identity-and-current-size', inventory['root'] == record['attempt_directory']
          and inventory['apparent_bytes'] <= 100_000_000 and inventory['apparent_bytes'] >= record['final_attempt_bytes'],
          'A fresh metadata-only owned-attempt census preserves identity and remains under 100 MB; later resource receipt writes are explicit.')
    check('honest-distinct-time-scopes', outer['elapsed_seconds'] >= reserved['elapsed_seconds']
          >= child_exit['guardian_elapsed_through_child_exit_seconds'] >= child_exit['launch_return_through_reap_wall_seconds']
          >= summary['elapsed_seconds'] > 0 and child_exit['isolated_child_execution_seconds'] is None,
          'Outer, reserved-wrapper, reap, monitored launch and driver times remain separate; no isolated CPU or inference time is inferred.')
    check('evaluation-does-not-grant-formalization-authority', all(summary[key] is False for key in
          ('proof_authority', 'formalized', 'qualified', 'checkpoint_promoted', 'training_executed', 'encoder_executed',
           'downloads_performed', 'lake_executed', 'source_semantics_verified', 'fresh_holdout', 'independent_semantic_holdout', 'convergence_proven')),
          'Summary metadata grants no training, fresh semantic holdout, qualification, proof or formalization authority.')
    failures = [entry for entry in checks if not entry['passed']]
    pre_finalize = next(event for event in samples if event['stage'] == 'pre_finalize')
    report = {'schema': 'retention-resource-execution-independent-review/v1', 'reviewed_at_unix': time.time(),
              'passed': not failures, 'findings': failures, 'checks': checks, 'artifacts': artifacts,
              'phase': 'evaluation', 'dimension': None, 'run_root': str(RUN), 'attempt_root': str(ATTEMPT),
              'completion_signal': 'Parent explicitly confirmed guardian session 30469 terminal exit 0 before this review.',
              'resource_policy': {'cpu_slots': 1, 'memory_mib': 1536, 'child_process_slots': 1,
                                  'attempt_reserved_bytes': 100_000_000, 'named_roots_limit_bytes': 145_000_000_000,
                                  'enforcement': final['enforcement']},
              'resource_summary': {'runtime_resource_sample_count': len(observations),
                                   'maximum_sampled_group_rss_bytes': max(item['group_rss']['rss_bytes'] for item in usage),
                                   'finalization_attempt_bytes': record['final_attempt_bytes'],
                                   'current_metadata_only_attempt_census': inventory,
                                   'pre_release_named_roots_charged_bytes': record['last_usage']['charged_bytes'],
                                   'post_release_named_roots_charged_bytes': record['final_accounting']['charged_bytes'],
                                   'finalization_profile': record['finalization_profile']},
              'watchdog_summary': {'event_count': len(events), 'observation_count': len(samples),
                                   'present_lease_observations': len(present), 'absent_lease_observations': len(absent),
                                   'monitor_observations': len(monitors),
                                   'maximum_monitor_gap_seconds': max(event['observation_gap_seconds'] for event in monitors),
                                   'maximum_all_sample_gap_seconds': max(b['observed_at_monotonic'] - a['observed_at_monotonic'] for a, b in zip(samples, samples[1:])),
                                   'minimum_sampled_remaining_ttl_seconds': min(event['remaining_ttl_seconds'] for event in present),
                                   'pre_finalize_remaining_ttl_seconds': pre_finalize['remaining_ttl_seconds'],
                                   'continuous_coverage_claimed': False},
              'timing_seconds': {'outer_guardian_subprocess_wall': outer['elapsed_seconds'],
                                 'reserved_wrapper_admission_through_finalize_wall': reserved['elapsed_seconds'],
                                 'reserved_wrapper_admission_through_child_reap_wall': child_exit['guardian_elapsed_through_child_exit_seconds'],
                                 'launch_return_through_child_reap_wall': child_exit['launch_return_through_reap_wall_seconds'],
                                 'retention_driver_self_reported_wall': summary['elapsed_seconds'],
                                 'isolated_child_execution': None},
              'fresh_owned_process_snapshot': processes,
              'current_shared_state_observations': {'read_only': True, 'scheduler_snapshot': scheduler_receipt,
                                                   'own_lease_present': own_lease in scheduler['leases'],
                                                   'scheduler_configuration_matches': current_config_sha == config_sha,
                                                   'disk_ledger_snapshot': ledger_receipt, 'own_disk_status': ledger['reservations'][own_reservation]['status'],
                                                   'snapshot_hashes_are_not_immutable_artifact_bindings': True},
              'limitations': ['Cooperative reservation and sampled usage checks are not kernel quotas or continuous peak-RSS proof.',
                             'Watchdog monitoring stops before finalization; the 14.815 s finalization interval has endpoint observations, not continuous lease coverage.',
                             'The finalization byte census precedes writing resources-final.json; the independent terminal metadata census reports both sizes.',
                             'Shared-state snapshots concern this reservation and configuration; concurrent foreign progress is permitted and no foreign-state immutability is claimed.',
                             'Prediction values, reference bodies and tensor values were not read; numerical result validity is reviewed separately.'],
              'audit_execution_flags': {'model_imported': False, 'model_executed': False, 'predictions_parsed': False,
                                        'reference_bodies_parsed': False, 'tensor_values_read': False,
                                        'leases_or_scheduler_state_mutated': False, 'source_modified': False,
                                        'Git_mutated': False, 'tests_rerun': False},
              'proof_authority': False, 'source_semantics_verified': False, 'teacher_qualified': False,
              'formalized': False, 'training_executed_by_audit': False}
    output = R / 'retention/resource-execution-independent-review.json'
    with output.open('x') as stream:
        json.dump(report, stream, sort_keys=True, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    print(json.dumps({'output': str(output), 'passed': report['passed'], 'check_count': len(checks),
                      'findings': failures, 'artifact_count': len(artifacts),
                      'current_attempt_bytes': inventory['apparent_bytes']}))
    raise SystemExit(0 if report['passed'] else 1)


if __name__ == '__main__':
    main()
