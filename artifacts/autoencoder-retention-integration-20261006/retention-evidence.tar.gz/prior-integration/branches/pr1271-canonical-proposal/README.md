# Bounded canonical restoration of published PR1271 work

The proposal restores the opt-in grouped runtime already published in
`0f36163a585a9bf514c41d8eabe202936c000705`. It preserves the dirty canonical
registry and proposes exclusive creation of 15 absent published paths. No
canonical file, Git index, model or runtime was changed while preparing it.

`published-registry-addition.diff` is the exact six-hunk a3f→0f Git patch: 97
inserted lines and one changed list line. `canonical-preimage-addition.diff`
describes the same addition over the current dirty owner. Both pass
`git apply --check` against that owner. `canonical-registry-proposed.py` is a
private review copy; its `GroupedFormulaRuntime` class matches main exactly.
Every existing line outside those published hunks is retained. The exact
current hash, mode, sizes and proposed hash are in `registry-preimage.json`.
Refuse application if that current preimage changes.

`missing-only-restoration-plan.json` pins the 15 absent Git blobs, 221,268
bytes in total: the grouped guide and findings, eleven historical handoff/index
files, and two integration/runtime test modules. Create only still-absent
regular paths with exact main bytes and modes. Preserve all six modified
paths. The registry is the sole proposed bounded change to an existing owner;
the older progress guide, our two adapted interface suites and two dirty span
boundary suites remain intact.

The grouped model, semantic renderer, projection-feature authority flags and
logic-requirements owners all currently match the required main bytes. Their
declared identities are recorded in `proposal-review.json`. Checkpoint opening
remains explicit by `legal_ir:source_conditioned_grouped_v2`, local path and
exact SHA256. Its strict owner also verifies producer identities and Torch
version. Discovery adds an experimental catalog entry. Existing profile
choices/defaults, source-tree pins and family requirements remain intact; no
model opens automatically and no training or promotion API is added.

The published runtime suite has an 11-case subset that avoids checkpoint and
runtime fixtures:

```text
test_explicit_profile_preserves_all_previous_runtime_selections
test_wrong_domain_or_version_never_opens_grouped_model             (7 cases)
test_duplicate_and_nonfinite_json_rejected_even_with_matching_file_hash (3 cases)
```

Those cases exercise discovery, unsupported profile rejection and malformed
JSON refusal. They call no model constructor/restore, training, native renderer
or Lake. The published module imports Torch and its autouse fixture temporarily
sets two CPU threads; an explicitly bounded test process is still required.
Do not run the full runtime or phase1 integration suites under a no-model
scope: other cases construct/restore tiny models, perform forwards or render
native structures. No test was executed in this proposal preparation.

This restoration adds no new main source behavior: main already contains the
runtime. A later publication needs only the accompanying findings and updated
documentation. Source-semantic verification, qualification and proof authority
remain false. Grouped source heads and the frozen normative vector-decoder
retention experiment retain separate inputs, checkpoints, losses and cohorts.
