# Remaining reconstruction gap on exposed v3 development

The 384D auxiliary state has 21 generated modality errors, all with gold O: 19 O→P and two O→F. Fifteen errors occur among 20 obligation clauses with “is obligated to”, and six among 20 with “is an obligation of”. All 20 norm-noun obligation clauses are correct. Nineteen errors already have a wrong source-head argmax; two have a correct source argmax but a wrong combined argmax. Actor and object remain 180/180. The sole action error is deliver→publish in “The prohibition is against the treasurer delivering the notice.” Both source and recurrent argmax choose publish there.

This is the previously exposed 48-paragraph/180-rule cohort. All qualifier fields are empty. Each of four selected states retains all 180 ordered rules and all 720 scalar sites; none is unavailable or unvisited. The audit authenticates 2,880 full32 source/recurrent/combined distributions, actual emitted tokens and prefix hashes, complete reference-rule labels, serialized state parameters and all 1,297 frozen inputs. No model or encoder is imported or executed.

| 384D auxiliary modality population | Errors / all reference rule sites | Source wrong / source correct among errors |
| --- | ---: | ---: |
| actor_normative_status | 15/60 | 14 / 1 |
| gerund_normative_subject | 6/60 | 5 / 1 |
| norm_noun_subject | 0/60 | 0 / 0 |

| Paragraph clause count | Modality errors / all reference rule sites |
| --- | ---: |
| 1 | 2/12 |
| 2 | 2/24 |
| 4 | 8/48 |
| 8 | 9/96 |

The two source-correct disagreements have small positive source margins. One occurs after an earlier generated modality error; the other has a reference-identical prefix. The source/recurrent causal effect is not isolated.

| Source-correct disagreement | Source gold-minus-best-other | Combined margin | Actual prefix equals reference prefix | First prespecified scale that flips this stored site |
| --- | ---: | ---: | --- | ---: |
| The notary is obligated to deliver the notice. | 0.303456545 | -0.131839752 | False | 1.5 |
| Preserving the archive is an obligation of the trustee. | 0.254672050 | -0.177920341 | True | 2 |

The fixed grid was recorded before calculation: `[0, 0.5, 1, 1.5, 2, 4]`. Only applied-source modality logits change; float32 multiplication precedes float32 addition to stored recurrent logits. Argmax ranges over all 32 tokens, including punctuation and specials. Other fields remain unchanged.

| State | 0 | 0.5 | 1 (actual) | 1.5 | 2 | 4 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 384D zero | 0 | 138 | 139 | 139 | 139 | 139 |
| 384D auxiliary | 0 | 158 | 159 | 160 | 161 | 161 |
| 768D zero | 14 | 178 | 178 | 178 | 178 | 178 |
| 768D auxiliary | 11 | 180 | 180 | 180 | 180 | 180 |

Every entry is modality correctness out of 180 at the original stored prefixes. These are not changed full-generation or paragraph-accuracy measurements. Scale zero produces non-modality argmax tokens at all 180 sites in both 384D states, and at 159/163 sites in the 768D zero/auxiliary states. These outcomes remain counted rather than masked.

The 384D auxiliary grid flips one source-correct disagreement at 1.5 and both at 2/4. All 19 source-wrong errors persist at every grid value. No actual-correct modality site regresses at 1.5/2/4 on these stored prefixes. Mean full32 reference-modality CE nevertheless rises from 0.293604265 at actual scale1 to 0.450821603 at scale2 and 0.820477695 at scale4. This posthoc CE uses generated stored prefixes and differs from full teacher-forced token CE. No scale is selected.

The diagnosis separates two questions for a prospective TRAIN-only protocol: source-local obligation separation from permission/prohibition, and combined-readout calibration when the source margin is small. The action confusion needs its own control. These observations choose no objective, hyperparameter or checkpoint, and the inspected development examples cannot become a fresh final benchmark. A controlled comparison must independently fix reviewed source/context pairs, source groups, architecture, initialization, update budget and decoding budget. Nonempty qualifier support and reviewed source-semantic targets remain unmet.

The [numeric report](numeric-diagnosis.json) retains every generated error in all four states and complete denominator breakdowns. The [site ledger](all-reference-sites.jsonl) contains all 2,880 authenticated reference sites. The standalone [auditor](diagnose_retention.py) uses only the Python standard library. Seventeen [pure controls](tests/test_numeric_diagnosis.py) cover full-vocabulary argmax/CE, float32 arithmetic, unchanged nonmodality fields, prefix and gold-label mismatches, complete source/formula truth-matrix counts, duplicates, invalid scales/vectors and false selection/authority flags. Their [receipt](pure-tests-receipt.json) binds the actual code and output.

```bash
python diagnose_retention.py \
  --run-root /home/barberb/lift_coding/external/ipfs_datasets/workspace/test-logs/decoder-normative-wording-retention-20261006 \
  --completed-run
```

All semantic/proof/admission/promotion masks remain false. No training, model selection, full generation, native validation, Lake build, weights download or existing source/tensor change occurs.
