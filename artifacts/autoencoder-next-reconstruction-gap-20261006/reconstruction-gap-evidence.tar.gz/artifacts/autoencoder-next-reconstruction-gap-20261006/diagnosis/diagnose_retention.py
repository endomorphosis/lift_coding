"""Read sealed retention artifacts; never import or run a numerical model.

The scale grid is a fixed-prefix arithmetic diagnostic. It is neither a new
greedy rollout nor evidence of what an altered decoder would generate.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import hashlib
import json
import math
from pathlib import Path
import statistics
import struct
import time


SCALES = (0, 0.5, 1, 1.5, 2, 4)
FIELDS = ("action", "actor", "modality", "object")
FACETS = FIELDS + ("conditions", "exceptions", "temporal")
STYLES = (
    "is obligated to", "is authorized to", "is barred from",
    "is an obligation of", "is authorized for", "is prohibited for",
    "The obligation is for", "The permission is for", "The prohibition is against",
)
FORBIDDEN_FLAGS = {
    "admitted", "qualified", "formalized", "roundtrip_ok", "proof_authority",
    "proof_ready", "checkpoint_promoted", "source_semantics_verified",
    "convergence_proven", "fresh_holdout", "independent_semantic_holdout",
    "training_executed", "encoder_executed", "downloads_performed", "lake_executed",
    "used_for_selection", "recurrent_clause_effect_causally_isolated",
}


def raw(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def digest(value):
    return hashlib.sha256(raw(value).encode()).hexdigest()


def f32(value):
    return struct.unpack("<f", struct.pack("<f", value))[0]


def vector32(values):
    if len(values) != 32 or any(type(v) not in (int, float) or not math.isfinite(v) for v in values):
        raise ValueError("Expected all 32 finite logits")
    return list(values)


def argmax(values):
    # PyTorch's first-index tie policy; no modality-only or syntax restriction.
    return max(range(len(values)), key=values.__getitem__)


def distribution_metrics(values, target, emitted=None):
    values = vector32(values)
    if type(target) is not int or not 0 <= target < 32:
        raise ValueError("Invalid reference token")
    emitted = argmax(values) if emitted is None else emitted
    peak = max(values)
    return {
        "argmax_token_id": argmax(values),
        "full_vocabulary_cross_entropy": peak + math.log(sum(math.exp(v - peak) for v in values)) - values[target],
        "target_minus_best_other": values[target] - max(v for i, v in enumerate(values) if i != target),
        "target_minus_emitted": values[target] - values[emitted],
    }


def scaled_site_logits(site, scale):
    """Keep other fields fixed; scale only modality source logits in float32."""
    if type(scale) not in (int, float) or not math.isfinite(scale) or scale < 0:
        raise ValueError("Scale must be finite and nonnegative")
    combined = vector32(site["combined_logits"])
    if site["field"] != "modality":
        return combined
    recurrent = vector32(site["raw_recurrent_logits"])
    source = vector32(site["applied_source_logits"])
    return vector32([f32(r + f32(scale * s)) for r, s in zip(recurrent, source)])


def assert_close_metrics(actual, expected):
    for key, value in expected.items():
        if type(value) is int:
            if actual[key] != value:
                raise ValueError("Full-vocabulary argmax mismatch")
        elif not math.isclose(actual[key], value, rel_tol=1e-12, abs_tol=1e-12):
            raise ValueError("Full-vocabulary CE/margin mismatch")


def validate_event(event, site, row, vocabulary, gold):
    if event["field"] != site["field"] or event["slot"] != site["slot"] or event["position"] != site["position"]:
        raise ValueError("Scalar event/trace position mismatch")
    if json.loads(vocabulary[event["target_token_id"]]) != gold[event["field"]]:
        raise ValueError("Reference label does not match complete ordered gold rule")
    prefix = row["consumed_prefix"][:site["position"] + 1]
    if event["prefix_sha256"] != digest(prefix):
        raise ValueError("Actual stored prefix mismatch")
    if event["actual_next_token_id"] != site["actual_next_token_id"]:
        raise ValueError("Emitted scalar token mismatch")
    for label, vector in (("source", "applied_source_logits"), ("recurrent", "raw_recurrent_logits"), ("combined", "combined_logits")):
        assert_close_metrics(event[label], distribution_metrics(site[vector], event["target_token_id"], event["actual_next_token_id"]))
    return prefix


def index_unique(items, key):
    result = {}
    for item in items:
        identity = key(item)
        if identity in result:
            raise ValueError("Duplicate ordered row or scalar site")
        result[identity] = item
    return result


def literal_style(text):
    hits = [style for style in STYLES if style in text]
    if len(hits) != 1:
        raise ValueError("Unclassified or ambiguous source cue; do not silently infer a style")
    return hits[0]


def assert_false_masks(value):
    if isinstance(value, dict):
        for key, child in value.items():
            if key in FORBIDDEN_FLAGS and child is not False:
                raise ValueError("Authority/selection flag is not false: " + key)
            assert_false_masks(child)
    elif isinstance(value, list):
        for child in value:
            assert_false_masks(child)


def margin_summary(values):
    if not values:
        return {"count": 0, "min": None, "median": None, "mean": None, "max": None}
    return {"count": len(values), "min": min(values), "median": statistics.median(values), "mean": statistics.mean(values), "max": max(values)}


def grouped_counts(sites, key):
    groups = defaultdict(list)
    for site in sites:
        groups[key(site)].append(site)
    output = []
    for identity, rows in sorted(groups.items(), key=lambda pair: str(pair[0])):
        source_correct = sum(x["source_correct"] for x in rows)
        correct = sum(x["formula_correct"] for x in rows)
        output.append({"group": identity, "reference_sites": len(rows), "source_correct": source_correct,
                       "generated_correct": correct, "generated_wrong": len(rows) - correct,
                       "source_wrong_generated_wrong": sum(not x["source_correct"] and not x["formula_correct"] for x in rows),
                       "source_correct_generated_wrong": sum(x["source_correct"] and not x["formula_correct"] for x in rows),
                       "source_wrong_generated_correct": sum(not x["source_correct"] and x["formula_correct"] for x in rows),
                       "source_margin_all": margin_summary([x["source"]["target_minus_best_other"] for x in rows]),
                       "source_margin_generated_wrong": margin_summary([x["source"]["target_minus_best_other"] for x in rows if not x["formula_correct"]])})
    return output


class ArtifactReader:
    def __init__(self):
        self.bindings = {}

    def read_bytes(self, path):
        path = Path(path)
        if path.is_symlink() or not path.is_file():
            raise ValueError("Input is not a regular, direct file: " + str(path))
        before = path.stat()
        body = path.read_bytes()
        after = path.stat()
        if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) != (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns):
            raise ValueError("Artifact changed during observation")
        self.bindings[str(path)] = {"bytes": len(body), "sha256": hashlib.sha256(body).hexdigest()}
        return body

    def json(self, path):
        return json.loads(self.read_bytes(path))

    def reference(self, ref):
        value = self.json(ref["path"])
        binding = self.bindings[ref["path"]]
        if binding != {k: ref[k] for k in ("bytes", "sha256")}:
            raise ValueError("Sealed file reference mismatch")
        return value


def diagnose(run_root, output_root, completed_run):
    if not completed_run:
        raise ValueError("An explicit completed-run signal is required")
    started = time.monotonic()
    output_root = Path(output_root)
    reader = ArtifactReader()
    plan = reader.json(output_root / "diagnosis-plan.json")
    if tuple(plan["source_scale_grid"]) != SCALES or plan["prespecified_by_parent_before_diagnostic_calculation"] is not True:
        raise ValueError("Prespecified grid changed")
    run_root = Path(run_root)
    outputs = run_root / "retention-r1/results"
    manifest = reader.json(run_root / "evaluation-manifest.json")
    summary = reader.json(outputs / "summary.json")
    barrier = reader.json(outputs / "predictions-complete.json")
    workspace = Path(__file__).resolve().parents[3]
    prior_path = workspace / "artifacts/autoencoder-progress-reconcile-20261006/retention/actual-result-independent-review.json"
    prior = reader.json(prior_path)
    if prior["passed"] is not True or prior["findings"] or prior["root_completion_signal_received"] is not True:
        raise ValueError("Original completed-result review is not clean")
    if summary["complete"] is not True or barrier["complete"] is not True or barrier["development_reference_json_loaded"] is not False:
        raise ValueError("Completed pre-reference barrier missing")
    expected_panels = {(d, a) for d in (384, 768) for a in ("normative-wording-zero", "normative-wording-ce")}
    if {(x["dimension"], x["arm"]) for x in summary["panels"]} != expected_panels or len(summary["panels"]) != 4:
        raise ValueError("Four selected states required")
    barrier_index = index_unique(barrier["records"], lambda x: (x["dimension"], x["arm"]))
    saved = {}
    # Verify all four durable source-only prediction/trace references first.
    for record in summary["panels"]:
        key = (record["dimension"], record["arm"])
        sealed = barrier_index[key]
        for field in ("state_ref", "predictions_ref", "source_head_trace_ref"):
            if sealed[field] != record[field]:
                raise ValueError("Barrier/summary reference mismatch")
        state = reader.reference(record["state_ref"])
        predictions = reader.reference(record["predictions_ref"])
        trace = reader.reference(record["source_head_trace_ref"])
        if record["role"] != "selected" or record["state_ref"] != manifest["selected_states"][f"{key[0]}-{key[1]}"]:
            raise ValueError("Endpoint identity mismatch")
        if state["weights_sha256"] != digest(state["model_state"]):
            raise ValueError("Actual serialized model parameters mismatch")
        if state["tensor_sha256"] != record["state_ref"]["tensor_sha256"] or state["tensor_sha256"] != trace["model_tensor_sha256"] or state["tensor_sha256"] != predictions["model_tensor_sha256"]:
            raise ValueError("Tensor lineage mismatch")
        if trace["trace_sha256"] != digest({k: v for k, v in trace.items() if k != "trace_sha256"}) or predictions["same_pass_scalar_trace_sha256"] != trace["trace_sha256"]:
            raise ValueError("Same-pass trace digest mismatch")
        if trace["predictions"] != predictions["predictions"] or trace["vocabulary_size"] != 32 or len(state["codec"]["target_vocabulary"]) != 32:
            raise ValueError("Prediction/full-vocabulary binding mismatch")
        true_flags = ("complete", "source_only", "full_vocabulary_retained", "decomposition_exact", "caller_state_preserved", "hooks_removed", "complete_rollout_before_reference_scoring")
        false_flags = ("reference_count_access", "reference_prefix_access", "reference_documents_passed_to_model", "inventory_access", "source_context_target_access", "syntax_mask", "forced_closure", "model_copied")
        if not all(trace[x] is True for x in true_flags) or not all(trace[x] is False for x in false_flags) or trace["extra_model_passes"] != 0 or trace["source_head_extra_evaluations"] != 0 or trace["optimizer_steps"] != 0 or trace["greedy_batch_steps"] != trace["recurrent_readout_calls"]:
            raise ValueError("Same-pass source-only contract violation")
        if not record["prediction_fsynced"] or not record["source_head_trace_fsynced"]:
            raise ValueError("Durability not recorded")
        saved[key] = (record, state, predictions, trace)
    refs = reader.json(manifest["references"])
    if digest(refs) != summary["references_sha256"] or len(refs) != 48 or sum(len(x["target"]["rules"]) for x in refs) != 180:
        raise ValueError("Reference cohort identity/denominator mismatch")
    reference_by_id = index_unique(refs, lambda x: x["id"])
    if not all(rule[field] == [] for row in refs for rule in row["target"]["rules"] for field in ("conditions", "exceptions", "temporal")):
        raise ValueError("Expected exposed empty-qualifier cohort")
    panels = []
    all_errors = []
    total_checked = 0
    for key, (record, state, predictions, trace) in saved.items():
        vocabulary = state["codec"]["target_vocabulary"]
        scalar = reader.reference(record["source_head_score_ref"])
        joined = reader.reference(record["source_head_formula_join_ref"])
        score = reader.reference(record["score_ref"])
        source = reader.json(manifest["source_inputs"][str(key[0])])
        if trace["source_rows_sha256"] != digest(source["rows"]) or trace["source_contexts_sha256"] != digest(source["source_contexts"]) or trace["codec_sha256"] != digest(state["codec"]) or trace["input_transform_sha256"] != digest(state["input_transform"]):
            raise ValueError("Source/cache/codec/transform identity mismatch")
        if scalar["references_sha256"] != digest(refs) or scalar["trace_sha256"] != trace["trace_sha256"] or scalar["score_sha256"] != digest({k: v for k, v in scalar.items() if k != "score_sha256"}):
            raise ValueError("Scored scalar artifact identity mismatch")
        prediction_index = index_unique(predictions["predictions"], lambda x: x["id"])
        trace_index = index_unique(trace["rows"], lambda x: x["id"])
        event_index = index_unique(scalar["events"], lambda x: (x["id"], x["slot"], x["field"]))
        join_index = index_unique(joined["rows"], lambda x: (x["id"], x["slot"]))
        fidelity_index = index_unique(score["fidelity"]["rows"], lambda x: x["id"])
        expected_keys = {(row["id"], slot, field) for row in refs for slot in range(len(row["target"]["rules"])) for field in FIELDS}
        if set(prediction_index) != set(reference_by_id) or set(trace_index) != set(reference_by_id) or set(event_index) != expected_keys or len(join_index) != 180:
            raise ValueError("Missing or extra rows/rules/scalar sites")
        details = []
        actual_sites = {}
        for row in trace["rows"]:
            pred = prediction_index[row["id"]]
            if row["consumed_prefix"] != [1] + pred["token_ids"][:len(row["consumed_prefix"]) - 1]:
                raise ValueError("Trace is not the actual generated prefix")
            for site in row["scalar_sites"]:
                identity = (row["id"], site["slot"], site["field"])
                if identity in actual_sites:
                    raise ValueError("Duplicate trace site")
                actual_sites[identity] = site
        if set(actual_sites) != expected_keys or trace["scalar_site_count"] != 720:
            raise ValueError("Full 180-rule/720-site trace required")
        for ref in refs:
            identity = ref["id"]
            row = trace_index[identity]
            pred = prediction_index[identity]
            generated = json.loads("".join(vocabulary[t] for t in pred["token_ids"]))
            if generated != fidelity_index[identity]["generated_ir"] or len(generated["rules"]) != len(ref["target"]["rules"]) or not pred["eos_reached"]:
                raise ValueError("Complete raw generated rules/EOS mismatch")
            contexts = source["source_contexts"][identity]["segments"]
            for slot, gold in enumerate(ref["target"]["rules"]):
                joined_row = join_index[(identity, slot)]
                if joined_row["expected_rule"] != gold or joined_row["generated_rule"] != generated["rules"][slot]:
                    raise ValueError("Full ordered rule join mismatch")
                clause = contexts[slot]["source_text"]
                clause_hash = hashlib.sha256(clause.encode()).hexdigest()
                if clause_hash != contexts[slot]["source_sha256"] or clause_hash != ref["components"][slot]["source_sha256"]:
                    raise ValueError("Literal source clause identity mismatch")
                for field in FIELDS:
                    event = event_index[(identity, slot, field)]
                    site = actual_sites[(identity, slot, field)]
                    if site["source_slot_available"] is not True or event["source_clause_sha256"] != clause_hash or site["source_clause_sha256"] != clause_hash:
                        raise ValueError("Actual source guidance is unavailable or misbound")
                    if [f32(r + s) for r, s in zip(vector32(site["raw_recurrent_logits"]), vector32(site["applied_source_logits"]))] != vector32(site["combined_logits"]):
                        raise ValueError("Actual float32 source/recurrent decomposition mismatch")
                    prefix = validate_event(event, site, row, vocabulary, gold)
                    if argmax(site["combined_logits"]) != site["actual_next_token_id"] or pred["token_ids"][site["position"]] != site["actual_next_token_id"]:
                        raise ValueError("Stored output differs from unrestricted full32 argmax")
                    source_correct = event["source"]["argmax_token_id"] == event["target_token_id"]
                    formula_correct = generated["rules"][slot][field] == gold[field]
                    value = joined_row["fields"][field]
                    if value["status"] != "visited" or value["source_correct"] is not source_correct or value["formula_field_correct"] is not formula_correct or formula_correct != (event["actual_next_token_id"] == event["target_token_id"]):
                        raise ValueError("Source/combined/generated field correctness mismatch")
                    earlier = [x for x in scalar["events"] if x["id"] == identity and x["position"] < event["position"] and x["actual_next_token_id"] != x["target_token_id"]]
                    detail = {"id": identity, "slot": slot, "field": field, "template_family": ref["template_family"], "declared_group_id": ref["group_id"], "literal_source_cue": literal_style(clause),
                              "paragraph_clause_count": len(ref["target"]["rules"]), "source_clause": clause, "source_clause_chars": len(clause), "source_clause_utf8_bytes": len(clause.encode()),
                              "gold": gold[field], "generated": generated["rules"][slot][field], "gold_modality": gold["modality"], "generated_modality": generated["rules"][slot]["modality"],
                              "source_argmax_token": vocabulary[event["source"]["argmax_token_id"]], "recurrent_argmax_token": vocabulary[event["recurrent"]["argmax_token_id"]],
                              "combined_argmax_token": vocabulary[event["combined"]["argmax_token_id"]], "source_correct": source_correct, "formula_correct": formula_correct,
                              "source": event["source"], "recurrent": event["recurrent"], "combined": event["combined"], "actual_position": event["position"], "actual_prefix_sha256": event["prefix_sha256"],
                              "actual_prefix_equal_reference_prefix": prefix == ref["target_ids"][:len(prefix)], "prior_reference_scalar_disagreements": [{"slot": x["slot"], "field": x["field"], "position": x["position"]} for x in earlier],
                              "classification": ("source_correct" if source_correct else "source_wrong") + ("_generated_correct" if formula_correct else "_generated_wrong")}
                    if field == "modality":
                        detail["prespecified_scale_grid"] = [{"source_scale": scale, **distribution_metrics(scaled_site_logits(site, scale), event["target_token_id"]), "argmax_token": vocabulary[argmax(scaled_site_logits(site, scale))], "correct_at_stored_prefix": argmax(scaled_site_logits(site, scale)) == event["target_token_id"]} for scale in SCALES]
                    details.append(detail)
                    total_checked += 1
        if scalar["unvisited_reference_sites"] or scalar["unscored_sites"] or joined["extra_generated_unavailable_sites"]:
            raise ValueError("Expected complete visited/available cohort; null sites must not disappear")
        by_field = {field: grouped_counts([x for x in details if x["field"] == field], lambda x: "all")[0] for field in FIELDS}
        for field, counts in by_field.items():
            recorded = joined["per_field"][field]
            if counts["reference_sites"] != 180 or counts["source_correct"] != recorded["source_correct"] or counts["generated_correct"] != score["fidelity"]["by_facet"][field]["correct"] or counts["source_correct_generated_wrong"] != recorded["source_correct_formula_wrong"]:
                raise ValueError("Independent complete denominator aggregation mismatch")
        modality = [x for x in details if x["field"] == "modality"]
        grid = []
        for scale in SCALES:
            measurements = [(x, next(y for y in x["prespecified_scale_grid"] if y["source_scale"] == scale)) for x in modality]
            grid.append({"source_scale": scale, "reference_modality_sites": 180, "correct_at_original_stored_prefix": sum(y["correct_at_stored_prefix"] for x, y in measurements),
                         "wrong_at_original_stored_prefix": sum(not y["correct_at_stored_prefix"] for x, y in measurements), "non_modality_argmax_tokens": sum(y["argmax_token"] not in ('"O"', '"P"', '"F"') for x, y in measurements),
                         "repairs_relative_to_actual_scale1": sum(not x["formula_correct"] and y["correct_at_stored_prefix"] for x, y in measurements), "regressions_relative_to_actual_scale1": sum(x["formula_correct"] and not y["correct_at_stored_prefix"] for x, y in measurements),
                         "source_wrong_sites_correct_at_stored_prefix": sum(not x["source_correct"] and y["correct_at_stored_prefix"] for x, y in measurements),
                         "source_correct_sites_wrong_at_stored_prefix": sum(x["source_correct"] and not y["correct_at_stored_prefix"] for x, y in measurements),
                         "mean_full32_reference_modality_CE_at_stored_prefix": statistics.mean(y["full_vocabulary_cross_entropy"] for x, y in measurements),
                         "all720_scalar_sites_correct_at_original_prefix": sum(by_field[f]["generated_correct"] for f in FIELDS if f != "modality") + sum(y["correct_at_stored_prefix"] for x, y in measurements),
                         "other_fields_scaled": False, "full_generation_executed": False, "paragraph_exactness_measured": False})
        if next(x for x in grid if x["source_scale"] == 1)["correct_at_original_stored_prefix"] != by_field["modality"]["generated_correct"]:
            raise ValueError("Scale1 does not reproduce actual unrestricted modality output")
        errors = [{"dimension": key[0], "arm": key[1], **x} for x in details if not x["formula_correct"]]
        all_errors.extend(errors)
        panels.append({"dimension": key[0], "arm": key[1], "tensor_sha256": state["tensor_sha256"], "actual_model_state_sha256": state["weights_sha256"], "state_ref": record["state_ref"],
                       "paragraphs": 48, "ordered_rules": 180, "reference_scalar_sites": 720, "visited_scalar_sites": 720, "unvisited_scalar_sites": 0, "unavailable_scalar_sites": 0, "extra_scalar_sites": 0,
                       "original_ordered_exact_paragraphs": record["ordered_exact"], "by_field": by_field, "generated_error_sites": len(errors),
                       "modality_breakdowns": {"by_template": grouped_counts(modality, lambda x: x["template_family"]), "by_literal_source_cue": grouped_counts(modality, lambda x: x["literal_source_cue"]), "by_paragraph_clause_count": grouped_counts(modality, lambda x: x["paragraph_clause_count"]), "by_gold_modality": grouped_counts(modality, lambda x: x["gold_modality"]), "by_slot": grouped_counts(modality, lambda x: x["slot"])},
                       "prespecified_source_scale_grid_at_original_prefixes": grid, "all_reference_sites": details})
        for artifact in (predictions, trace, scalar, joined, score):
            assert_false_masks(artifact)
    auxiliary384 = next(x for x in panels if x["dimension"] == 384 and x["arm"] == "normative-wording-ce")
    target_errors = [x for x in all_errors if x["dimension"] == 384 and x["arm"] == "normative-wording-ce"]
    modality_errors = [x for x in target_errors if x["field"] == "modality"]
    action_errors = [x for x in target_errors if x["field"] == "action"]
    if len(modality_errors) != 21 or len(action_errors) != 1 or sum(not x["source_correct"] for x in modality_errors) != 19 or sum(x["source_correct"] for x in modality_errors) != 2:
        raise ValueError("Expected all21 modality and1 action errors, including19/2 split")
    input_hashes = {}
    for path, expected_hash in manifest["inputs"].items():
        body = Path(path).read_bytes()
        observed = hashlib.sha256(body).hexdigest()
        if observed != expected_hash:
            raise ValueError("Frozen input changed: " + path)
        input_hashes[path] = {"sha256": observed, "bytes": len(body)}
    if len(input_hashes) != 1297:
        raise ValueError("Frozen source/input closure count changed")
    reader.read_bytes(__file__)
    assert_false_masks(summary)
    ledger_path = output_root / "all-reference-sites.jsonl"
    with ledger_path.open("w") as ledger:
        for panel in panels:
            for detail in panel.pop("all_reference_sites"):
                ledger.write(raw({"dimension": panel["dimension"], "arm": panel["arm"], **detail}) + "\n")
    reader.read_bytes(ledger_path)
    report = {"schema": "retention-next-reconstruction-gap-diagnosis/v1", "passed": True, "findings": [], "artifacts": reader.bindings,
              "source_scale_grid_prespecified": list(SCALES), "plan_sha256": reader.bindings[str(output_root / "diagnosis-plan.json")]["sha256"],
              "full32_scalar_sites_independently_authenticated": total_checked, "frozen_input_preservation": {"count": len(input_hashes), "aggregate_binding_sha256": digest(input_hashes), "all_unchanged": True},
              "complete_reference_site_ledger": {"path": str(ledger_path), **reader.bindings[str(ledger_path)], "rows": total_checked},
              "panels": panels, "all_generated_error_sites": all_errors,
              "auxiliary384_complete_error_classification": {"modality_errors": 21, "action_errors": 1, "modality_source_wrong": 19, "modality_source_correct_combined_wrong": 2, "errors": target_errors,
                  "modality_error_confusions": [{"gold": gold, "generated": generated, "count": count} for (gold, generated), count in sorted(Counter((x["gold"], x["generated"]) for x in modality_errors).items())],
                  "source_wrong_modality_margin_summary": margin_summary([x["source"]["target_minus_best_other"] for x in modality_errors if not x["source_correct"]]),
                  "source_correct_combined_wrong_modality_margin_summary": margin_summary([x["source"]["target_minus_best_other"] for x in modality_errors if x["source_correct"]]),
                  "by_template_and_field": grouped_counts(target_errors, lambda x: (x["template_family"], x["field"])), "by_source_cue_and_field": grouped_counts(target_errors, lambda x: (x["literal_source_cue"], x["field"])), "by_length_and_field": grouped_counts(target_errors, lambda x: (x["paragraph_clause_count"], x["field"])), "by_modality_and_field": grouped_counts(target_errors, lambda x: (x["gold_modality"], x["field"]))},
              "measurement_limits": ["Exposed authored48-paragraph/180-rule development cohort; empty qualifiers and no reviewed legal-semantic authority.", "Full32 argmax includes punctuation and special tokens; no modality-only vocabulary renormalization or mask.", "Scale changes use original actual prefixes. Earlier outputs and recurrence are frozen, so these numbers do not predict any changed full rollout or paragraph accuracy.", "Source/recurrent logits are an exact arithmetic decomposition, not a causal isolation of recurrent clause effects.", "No scale, checkpoint, model or objective is selected or promoted from this development calculation. A prospective TRAIN-only controlled experiment requires a separately fixed protocol and new reviewed evaluation groups.", "Reported scale-grid CE is posthoc reference-modality CE at generated stored prefixes, distinct from full teacher-forced token CE and generated formula/source fidelity."],
              "authority": {"admitted": False, "qualified": False, "formalized": False, "source_semantics_verified": False, "proof_ready": False, "proof_authority": False, "roundtrip_ok": False, "used_for_selection": False, "checkpoint_promoted": False, "convergence_proven": False, "fresh_holdout": False, "recurrent_clause_effect_causally_isolated": False},
              "audit_execution": {"stdlib_only": True, "model_imported": False, "model_executed": False, "encoder_executed": False, "training_executed": False, "full_generation_executed": False, "model_selection": False, "checkpoint_promotion": False, "reference_labels_sent_to_model": False, "native_or_Lake_executed": False, "existing_source_or_tensor_modified": False, "recurrent_clause_effect_causally_isolated": False, "elapsed_seconds": time.monotonic() - started}}
    output = output_root / "numeric-diagnosis.json"
    output.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    display_panels = []
    for panel in panels:
        display_grid = [{"scale": item["source_scale"], "correct": item["correct_at_original_stored_prefix"], "nonmodal": item["non_modality_argmax_tokens"]} for item in panel["prespecified_source_scale_grid_at_original_prefixes"]]
        display_panels.append({"dimension": panel["dimension"], "arm": panel["arm"], "grid": display_grid})
    print(json.dumps({"passed": True, "report": str(output), "authenticated_sites": total_checked, "384_auxiliary_modality_errors": len(modality_errors), "384_auxiliary_action_errors": len(action_errors), "panels": display_panels}))
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-root", required=True, type=Path)
    parser.add_argument("--output-root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--completed-run", action="store_true")
    arguments = parser.parse_args()
    diagnose(arguments.run_root, arguments.output_root, arguments.completed_run)
