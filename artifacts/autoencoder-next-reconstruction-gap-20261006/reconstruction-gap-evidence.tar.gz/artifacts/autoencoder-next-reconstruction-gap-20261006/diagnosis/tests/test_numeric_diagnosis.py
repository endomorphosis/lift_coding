"""Arithmetic and leakage-boundary controls; no project/model imports."""
from pathlib import Path
import importlib.util
import json
import math
import unittest

SPEC = importlib.util.spec_from_file_location("standalone_retention_diagnosis", Path(__file__).resolve().parents[1] / "diagnose_retention.py")
D = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(D)


def site(field="modality"):
    recurrent = [0.0] * 32
    source = [0.0] * 32
    recurrent[28] = 20.0
    source[4] = 10.0
    return {"field": field, "slot": 0, "position": 1, "actual_next_token_id": 28,
            "raw_recurrent_logits": recurrent, "applied_source_logits": source,
            "combined_logits": [r + s for r, s in zip(recurrent, source)]}


def event_fixture():
    s = site()
    row = {"consumed_prefix": [1, 31, 28]}
    vocabulary = [json.dumps(str(i)) for i in range(32)]
    vocabulary[4] = '"O"'
    event = {"field": "modality", "slot": 0, "position": 1, "target_token_id": 4,
             "actual_next_token_id": 28, "prefix_sha256": D.digest([1, 31])}
    for key, field in (("source", "applied_source_logits"), ("recurrent", "raw_recurrent_logits"), ("combined", "combined_logits")):
        event[key] = D.distribution_metrics(s[field], 4, 28)
    return event, s, row, vocabulary, {"modality": "O"}


class NumericControls(unittest.TestCase):
    def test_prespecified_grid_is_fixed_without_selection(self):
        self.assertEqual(D.SCALES, (0, 0.5, 1, 1.5, 2, 4))

    def test_full32_argmax_does_not_mask_punctuation(self):
        s = site()
        self.assertEqual(D.argmax(D.scaled_site_logits(s, 1)), 28)
        self.assertEqual(D.argmax(D.scaled_site_logits(s, 4)), 4)

    def test_scale_zero_keeps_actual_prefix_recurrent_values(self):
        s = site()
        self.assertEqual(D.scaled_site_logits(s, 0), s["raw_recurrent_logits"])

    def test_other_fields_are_never_scaled(self):
        for field in ("action", "actor", "object"):
            s = site(field)
            for scale in D.SCALES:
                self.assertEqual(D.scaled_site_logits(s, scale), s["combined_logits"])

    def test_float32_multiply_then_add_matches_rounding_boundary(self):
        s = site()
        s["raw_recurrent_logits"][4] = 16777216.0
        s["applied_source_logits"][4] = 1.0
        s["combined_logits"][4] = 16777216.0
        self.assertEqual(D.scaled_site_logits(s, 1)[4], 16777216.0)
        self.assertEqual(D.scaled_site_logits(s, 2)[4], 16777218.0)

    def test_argmax_tie_uses_first_index(self):
        values = [0.0] * 32
        values[3] = values[4] = 10.0
        self.assertEqual(D.argmax(values), 3)

    def test_stable_full32_ce_and_margins_have_known_values(self):
        values = [-1000.0] * 32
        values[4], values[5] = 1000.0, 999.0
        actual = D.distribution_metrics(values, 4, 5)
        self.assertAlmostEqual(actual["full_vocabulary_cross_entropy"], math.log1p(math.exp(-1)), places=12)
        self.assertEqual(actual["target_minus_best_other"], 1.0)
        self.assertEqual(actual["target_minus_emitted"], 1.0)

    def test_full32_ce_includes_all_other_tokens(self):
        actual = D.distribution_metrics([0.0] * 32, 4)
        self.assertAlmostEqual(actual["full_vocabulary_cross_entropy"], math.log(32), places=14)

    def test_nonfinite_or_incomplete_vectors_refuse(self):
        for values in ([0.0] * 31, [0.0] * 31 + [float("nan")], [0.0] * 31 + [float("inf")]):
            with self.assertRaises(ValueError):
                D.distribution_metrics(values, 4)

    def test_invalid_scale_refuses(self):
        for scale in (-1, float("nan"), float("inf"), True):
            with self.assertRaises(ValueError):
                D.scaled_site_logits(site(), scale)

    def test_actual_prefix_is_validated_without_replacement_by_gold(self):
        event, s, row, vocabulary, gold = event_fixture()
        self.assertEqual(D.validate_event(event, s, row, vocabulary, gold), [1, 31])
        row["consumed_prefix"][1] = 30
        with self.assertRaisesRegex(ValueError, "Actual stored prefix"):
            D.validate_event(event, s, row, vocabulary, gold)

    def test_gold_labels_cannot_be_fabricated_from_argmax(self):
        event, s, row, vocabulary, gold = event_fixture()
        gold["modality"] = "F"
        with self.assertRaisesRegex(ValueError, "Reference label"):
            D.validate_event(event, s, row, vocabulary, gold)

    def test_duplicate_sites_refuse_instead_of_shrinking_denominator(self):
        with self.assertRaisesRegex(ValueError, "Duplicate"):
            D.index_unique([{"id": 1}, {"id": 1}], lambda x: x["id"])

    def test_literal_style_requires_one_known_source_cue(self):
        self.assertEqual(D.literal_style("The trustee is obligated to preserve the archive."), "is obligated to")
        for text in ("Unclassified wording.", "is obligated to and is authorized to"):
            with self.assertRaises(ValueError):
                D.literal_style(text)

    def test_margins_keep_empty_groups_explicit(self):
        self.assertEqual(D.margin_summary([]), {"count": 0, "min": None, "median": None, "mean": None, "max": None})

    def test_complete_source_formula_truth_matrix_keeps_denominators(self):
        rows = [{"source_correct": s, "formula_correct": f, "source": {"target_minus_best_other": 1.0 if s else -1.0}}
                for s, f in ((True, True), (True, False), (False, True), (False, False))]
        counts = D.grouped_counts(rows, lambda row: "all")[0]
        self.assertEqual(counts["reference_sites"], 4)
        self.assertEqual(counts["source_correct"], 2)
        self.assertEqual(counts["generated_correct"], 2)
        self.assertEqual(counts["source_correct_generated_wrong"], 1)
        self.assertEqual(counts["source_wrong_generated_correct"], 1)
        self.assertEqual(counts["source_wrong_generated_wrong"], 1)
        self.assertEqual(counts["source_margin_all"]["mean"], 0.0)

    def test_selection_and_authority_flags_refuse_recursively(self):
        D.assert_false_masks({"nested": [{"checkpoint_promoted": False}]})
        with self.assertRaises(ValueError):
            D.assert_false_masks({"nested": [{"checkpoint_promoted": True}]})


if __name__ == "__main__":
    unittest.main()
