"""Independent saved-output audit. Standard library only; no model imports."""
import argparse
import ast
from collections import Counter
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import statistics
import time


def audit(completion_signaled):
    if not completion_signaled:
        raise ValueError("Root completion signal required")
    start = time.monotonic()
    root = Path(__file__).resolve().parent
    workspace = root.parents[2]
    run = workspace / "external/ipfs_datasets/workspace/test-logs/decoder-train-readout-observation-20261006"
    out = run / "train-observation-r1/results"
    pure_path = root.parent / "diagnosis/diagnose_retention.py"
    spec = importlib.util.spec_from_file_location("pure_saved_logit_arithmetic", pure_path)
    pure = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(pure)
    reader = pure.ArtifactReader()
    raw, digest = pure.raw, pure.digest
    checks = []

    def check(name, passed, detail=None):
        if not passed:
            raise ValueError(name)
        item = {"id": name, "passed": True}
        if detail is not None:
            item["details"] = detail
        checks.append(item)

    manifest = reader.json(run / "evaluation-manifest.json")
    plan = reader.json(run / "evaluation-plan.json")
    summary = reader.json(out / "summary.json")
    barrier = reader.json(out / "predictions-complete.json")
    preflight = reader.json(root / "independent-runner-readiness.json")
    guardian = reader.json(run / "train-observation-r1-guardian-exit.json")
    child = reader.json(run / "train-observation-r1/child-exit.json")
    final = reader.json(run / "train-observation-r1/resources-final.json")
    check("completed-run-and-prior-clean-contract", preflight["passed"] is True and preflight["findings"] == [] and summary["complete"] is True and guardian["returncode"] == child["returncode"] == 0 and child["leader_reaped"] is True and final["status"] == "released" and final["cleanup_error"] is None)
    check("same-fixed-recipe-and-explicit-inherited-metadata", manifest["plan_sha256"] == hashlib.sha256((run / "evaluation-plan.json").read_bytes()).hexdigest() and plan["input_sha256"] == manifest["inputs"] and plan["samples_per_panel"] == 96 and plan["rules_per_panel"] == 360 and plan["scalar_sites_per_panel"] == 1440 and plan["context_tokens"] == plan["output_tokens"] == 512 and plan["temperature"] == 0 and plan["vocabulary_size"] == 32 and summary["inherited_train_validation_metadata_loaded_before_collection"] is True and summary["archived_original_generation_parity_verified"] is True)
    expected = {(d, arm) for d in (384, 768) for arm in ("normative-wording-zero", "normative-wording-ce")}
    check("four-selected-panels-and-durable-posthoc-barrier", len(summary["panels"]) == len(barrier["records"]) == 4 and {(x["dimension"], x["arm"]) for x in summary["panels"]} == expected and barrier["posthoc_train_reference_json_loaded"] is False and barrier["inherited_train_validation_metadata_loaded_before_collection"] is True and barrier["all_predictions_fsynced"] is True and summary["all_predictions_fsynced_before_reference_load"] is True and summary["all_predictions_persisted_before_reference_load"] is True)
    cached = {}
    for width in (384, 768):
        original = reader.json(manifest["original_training_rows"][str(width)])["train"]
        original_contexts = reader.json(Path(manifest["original_training_rows"][str(width)]).with_name("source-contexts.json"))["train"]
        normative = reader.json(manifest["source_inputs"][str(width)])
        rows = [{k: row[k] for k in ("id", "source_text", "input")} for row in original] + normative["rows"]
        contexts = dict(original_contexts, **normative["source_contexts"])
        check("complete-source-cache-" + str(width), len(rows) == len({r["id"] for r in rows}) == len(contexts) == 96 and all(set(r) == {"id", "source_text", "input"} for r in rows) and normative["targets_attached"] is False and normative["inputs_sha256"] == digest({k: v for k, v in normative.items() if k != "inputs_sha256"}) and sum(len(v["segments"]) for v in contexts.values()) == 360)
        cached[width] = (original, rows, original_contexts, contexts)
    barrier_index = pure.index_unique(barrier["records"], lambda x: (x["dimension"], x["arm"]))
    saved, parity = {}, []
    trace_sites_checked = 0
    for record in summary["panels"]:
        key = (record["dimension"], record["arm"])
        state = reader.reference(record["state_ref"])
        pred = reader.reference(record["predictions_ref"])
        trace = reader.reference(record["source_head_trace_ref"])
        original, rows, original_ctx, contexts = cached[key[0]]
        check("durable-state-trace-prediction-" + str(key), record["role"] == "selected" and record["state_ref"] == manifest["selected_states"][f"{key[0]}-{key[1]}"] and all(record[k] == barrier_index[key][k] for k in ("state_ref", "predictions_ref", "source_head_trace_ref")) and record["prediction_fsynced"] is True and record["source_head_trace_fsynced"] is True and state["weights_sha256"] == digest(state["model_state"]) and state["tensor_sha256"] == pred["model_tensor_sha256"] == trace["model_tensor_sha256"] == record["state_ref"]["tensor_sha256"] and trace["source_rows_sha256"] == pred["source_rows_sha256"] == digest(rows) and trace["source_contexts_sha256"] == pred["source_contexts_sha256"] == digest(contexts) and trace["codec_sha256"] == digest(state["codec"]) and trace["input_transform_sha256"] == digest(state["input_transform"]))
        check("same-pass-contract-" + str(key), trace["sample_count"] == 96 and trace["vocabulary_size"] == 32 and trace["trace_sha256"] == digest({k: v for k, v in trace.items() if k != "trace_sha256"}) and pred["same_pass_scalar_trace_sha256"] == trace["trace_sha256"] and pred["predictions"] == trace["predictions"] and all(trace[k] is False for k in ("reference_count_access", "reference_prefix_access", "reference_documents_passed_to_model", "inventory_access", "source_context_target_access", "syntax_mask", "forced_closure", "model_copied")) and all(trace[k] is True for k in ("full_vocabulary_retained", "decomposition_exact", "source_only", "caller_state_preserved", "hooks_removed")) and trace["extra_model_passes"] == trace["source_head_extra_evaluations"] == trace["optimizer_steps"] == 0 and trace["greedy_batch_steps"] == trace["recurrent_readout_calls"])
        sites = {}
        batch_steps = {}
        for row, prediction in zip(trace["rows"], pred["predictions"]):
            if row["id"] != prediction["id"] or row["consumed_prefix"] != [1] + prediction["token_ids"][:len(row["consumed_prefix"]) - 1]:
                raise ValueError("Actual generated prefix mismatch")
            batch_steps[row["batch_offset"]] = max(batch_steps.get(row["batch_offset"], 0), len(row["consumed_prefix"]))
            for site in row["scalar_sites"]:
                identity = (row["id"], site["slot"], site["field"])
                if identity in sites:
                    raise ValueError("Duplicate actual scalar site")
                vectors = [pure.vector32(site[name]) for name in ("raw_recurrent_logits", "applied_source_logits", "combined_logits")]
                if [pure.f32(a + b) for a, b in zip(*vectors[:2])] != vectors[2]:
                    raise ValueError("Exact float32 decomposition mismatch")
                available = site["slot"] < len(contexts[row["id"]]["segments"])
                if site["source_slot_available"] is not available or (not available and any(v != 0 for v in vectors[1])):
                    raise ValueError("Unavailable source-slot guidance mismatch")
                position = site["position"]
                if pure.argmax(vectors[2]) != site["actual_next_token_id"] or position >= len(prediction["token_ids"]) or prediction["token_ids"][position] != site["actual_next_token_id"]:
                    raise ValueError("Full32 argmax is not the actual emitted scalar token")
                sites[identity] = (site, row)
                trace_sites_checked += 1
        check("complete-trace-sites-and-batch-readouts-" + str(key), len(sites) == trace["scalar_site_count"] == 1440 and sum(batch_steps.values()) == trace["greedy_batch_steps"])
        archive = reader.reference(manifest["archived_original_predictions"][f"{key[0]}-{key[1]}"])
        keys = ("id", "token_ids", "generation_status", "eos_reached")
        check("actual-archived-original48-parity-" + str(key), [{k: row[k] for k in keys} for row in pred["predictions"][:48]] == [{k: row[k] for k in keys} for row in archive["predictions"]] and archive["report"]["model_weights_sha256"] == state["tensor_sha256"] and archive["report"]["source_contexts_sha256"] == digest(original_ctx) and [x["id"] for x in archive["predictions"]] == [x["id"] for x in original])
        parity.append({"dimension": key[0], "arm": key[1], "original_rows": 48, "token_status_EOS_exact": True, "archive_ref": manifest["archived_original_predictions"][f"{key[0]}-{key[1]}"]})
        saved[key] = (record, state, pred, trace, sites)
    # Reference bodies are parsed only after the explicit completion signal and
    # after all four durable trace/prediction bindings have been checked here.
    normative = reader.json(manifest["normative_references"])
    receipt = reader.json(manifest["normative_receipt"])
    original_rows = cached[384][0]
    codec = next(iter(saved.values()))[1]["codec"]
    vocabulary = codec["target_vocabulary"]
    refs = []
    for row in original_rows:
        ids = row["target_ids"]
        target = json.loads("".join(vocabulary[t] for t in ids[1:-1]))
        refs.append(dict(id=row["id"], source_text=row["source_text"], source_sha256=hashlib.sha256(row["source_text"].encode()).hexdigest(), target_ids=ids, target=target, target_sha256=digest(target), target_ids_sha256=digest(ids), codec_sha256=digest(codec), clause_count=len(target["rules"]), template="original_train", cohort="original_train", split="training"))
    refs.extend(dict(ref, cohort="normative_train") for ref in normative)
    namespace = {}
    runner_path = run / "experiment-source/scripts/ops/autoencoder/observe_normative_training_readouts.py"
    for node in ast.parse(runner_path.read_text()).body:
        if isinstance(node, ast.Assign) and all(isinstance(t, ast.Name) and t.id == "FALSE" for t in node.targets):
            exec(compile(ast.Module(body=[node], type_ignores=[]), str(runner_path), "exec"), namespace)
    receipt_envelope = dict(schema="train-observation-reference-receipts/v1", normative=receipt, original_training_rows_sha256={str(w): hashlib.sha256(Path(manifest["original_training_rows"][str(w)]).read_bytes()).hexdigest() for w in (384, 768)}, posthoc_reference_load_after_all_four_durable_panels=True, inherited_train_validation_metadata_previously_loaded=True, **namespace["FALSE"])
    check("complete-posthoc-TRAIN-reference-identities", len(normative) == 48 and len(refs) == 96 and sum(len(r["target"]["rules"]) for r in refs) == 360 and digest(refs) == summary["references_sha256"] and receipt["references_sha256"] == digest(normative) and receipt["receipt_sha256"] == digest({k: v for k, v in receipt.items() if k != "receipt_sha256"}) and digest(receipt_envelope) == summary["training_reference_receipts_sha256"] and all(rule[f] == [] for ref in refs for rule in ref["target"]["rules"] for f in ("conditions", "exceptions", "temporal")))
    panels = []
    distribution_count = 0
    for key, (record, state, pred, trace, sites) in saved.items():
        score = reader.reference(record["score_ref"])
        scalar = reader.reference(record["source_head_score_ref"])
        joined = reader.reference(record["source_head_formula_join_ref"])
        fidelity = score["fidelity"]
        teacher = score["teacher_forced"]
        check("scalar-score-and-complete-reference-join-" + str(key), scalar["trace_sha256"] == trace["trace_sha256"] and scalar["references_sha256"] == digest(refs) and scalar["score_sha256"] == digest({k: v for k, v in scalar.items() if k != "score_sha256"}) and len(fidelity["rows"]) == len(teacher["rows"]) == 96 and len(joined["rows"]) == 360 and len(scalar["events"]) == 1440 and not scalar["unvisited_reference_sites"] and not scalar["unscored_sites"] and not joined["extra_generated_unavailable_sites"])
        events = pure.index_unique(scalar["events"], lambda e: (e["id"], e["slot"], e["field"]))
        expected_sites = {(r["id"], slot, field) for r in refs for slot in range(len(r["target"]["rules"])) for field in pure.FIELDS}
        check("all1440-targets-prefixes-and-source-clauses-" + str(key), set(events) == set(sites) == expected_sites)
        source_contexts = cached[key[0]][3]
        reference_map = {r["id"]: r for r in refs}
        for identity, event in events.items():
            site, row = sites[identity]
            reference = reference_map[identity[0]]
            pure.validate_event(event, site, row, vocabulary, reference["target"]["rules"][identity[1]])
            if event["source_clause_sha256"] != site["source_clause_sha256"] or event["source_clause_sha256"] != source_contexts[identity[0]]["segments"][identity[1]]["source_sha256"]:
                raise ValueError("Actual source-clause identity mismatch")
            distribution_count += 3
        exact, facets, missing, extra = 0, {f: 0 for f in pure.FACETS}, 0, 0
        for reference, prediction, row in zip(refs, pred["predictions"], fidelity["rows"]):
            generated = json.loads("".join(vocabulary[t] for t in prediction["token_ids"]))
            if reference["id"] != prediction["id"] or prediction["id"] != row["id"] or reference["target"] != row["expected_ir"] or generated != row["generated_ir"]:
                raise ValueError("Actual generated JSON/fidelity/gold ordering mismatch")
            correct = prediction["eos_reached"] and generated == reference["target"]
            exact += correct
            if int(correct) != row["counts"]["ordered_exact"]:
                raise ValueError("Independent paragraph exactness mismatch")
            for field in pure.FACETS:
                count = sum(slot < len(generated["rules"]) and generated["rules"][slot][field] == gold[field] for slot, gold in enumerate(reference["target"]["rules"]))
                if count != row["by_facet"][field]["correct"] or row["by_facet"][field]["total"] != len(reference["target"]["rules"]):
                    raise ValueError("Full seven-facet denominator mismatch")
                facets[field] += count
            gold = Counter(raw(r) for r in reference["target"]["rules"])
            actual = Counter(raw(r) for r in generated["rules"])
            matched = sum((gold & actual).values())
            missing += sum(gold.values()) - matched
            extra += sum(actual.values()) - matched
        check("complete-formula-and-multiset-counts-" + str(key), exact == record["ordered_exact"] == fidelity["metrics"]["ordered_exact"] and fidelity["metrics"]["expected_rules"] == fidelity["metrics"]["generated_rules"] == 360 and fidelity["metrics"]["eos_count"] == fidelity["metrics"]["syntax_valid"] == 96 and fidelity["metrics"]["whole_rules_missing"] == missing and fidelity["metrics"]["whole_rules_extra"] == extra and all(fidelity["by_facet"][f] == {"correct": facets[f], "total": 360, "unordered_correct": fidelity["by_facet"][f]["unordered_correct"]} for f in pure.FACETS))
        joined_expected = [(r["id"], slot, rule) for r in refs for slot, rule in enumerate(r["target"]["rules"])]
        for actual, (identity, slot, gold) in zip(joined["rows"], joined_expected):
            if actual["id"] != identity or actual["slot"] != slot or actual["expected_rule"] != gold:
                raise ValueError("Ordered360 rule slot mismatch")
            for field in pure.FIELDS:
                value = actual["fields"][field]
                event = events[(identity, slot, field)]
                if value["status"] != "visited" or value["source_correct"] is not (event["source"]["argmax_token_id"] == event["target_token_id"]) or value["formula_field_correct"] is not (actual["generated_rule"][field] == gold[field]):
                    raise ValueError("Joined source/combined/formula truth mismatch")
                for head in ("source", "recurrent", "combined"):
                    if value[head] != event[head]:
                        raise ValueError("Join does not retain actual full32 scalar metrics")
        ce_sum, token_count = 0, 0
        for reference, row in zip(refs, teacher["rows"]):
            losses = row["token_cross_entropies"]
            n = len(reference["target_ids"]) - 1
            if row["id"] != reference["id"] or row["target_token_ids"] != reference["target_ids"][1:] or row["token_count"] != n or len(losses) != n or not math.isclose(row["cross_entropy"], sum(losses) / n, abs_tol=1e-12, rel_tol=1e-12):
                raise ValueError("Full teacher-forced target/EOS/loss accounting mismatch")
            ce_sum += sum(losses)
            token_count += n
        check("separate-full32-teacher-forced-CE-" + str(key), token_count == teacher["valid_target_tokens"] and math.isclose(ce_sum / token_count, record["token_cross_entropy"], abs_tol=1e-12, rel_tol=1e-12) and teacher["full_vocabulary_size"] == 32 and teacher["reference_prefixes_used"] is True and teacher["greedy_repeated"] is False and teacher["used_for_selection"] is False)
        cohort_summaries = {}
        for cohort in ("original_train", "normative_train"):
            ids = {r["id"] for r in refs if r["cohort"] == cohort}
            full = [row for row in fidelity["rows"] if row["id"] in ids]
            slots = [row for row in joined["rows"] if row["id"] in ids]
            losses = [row for row in teacher["rows"] if row["id"] in ids]
            reported = record["by_cohort"][cohort]
            metrics = {k: sum(row["counts"][k] for row in full) for k in full[0]["counts"]}
            seven = {f: {"correct": sum(row["by_facet"][f]["correct"] for row in full), "total": sum(row["by_facet"][f]["total"] for row in full)} for f in pure.FACETS}
            n = sum(row["token_count"] for row in losses)
            ce = sum(sum(row["token_cross_entropies"]) for row in losses) / n
            check("independent-cohort-complete-counts-" + str(key) + "-" + cohort, len(ids) == len(full) == len(losses) == 48 and len(slots) == 180 and reported["paragraphs"] == 48 and reported["rules"] == 180 and reported["scalar_sites"] == 720 and reported["formula_metrics"] == metrics and reported["seven_facets"] == seven and reported["target_tokens"] == n and reported["ordered_exact"] == metrics["ordered_exact"] and math.isclose(reported["token_cross_entropy"], ce, abs_tol=1e-12, rel_tol=1e-12))
            for field in pure.FIELDS:
                values = [row["fields"][field] for row in slots]
                expected_field_counts = dict(reference_sites=180, visited=180, unvisited=0, unavailable=0, source_correct=sum(v["source_correct"] for v in values), source_correct_formula_wrong=sum(v["source_correct"] and not v["formula_field_correct"] for v in values))
                if reported["fields"][field] != expected_field_counts:
                    raise ValueError("Independent complete cohort source/formula field counts mismatch")
                for head in ("source", "recurrent", "combined"):
                    distributions = [value[head] for value in values]
                    margins = [d["target_minus_best_other"] for d in distributions]
                    stored = reported["full_vocabulary_scalar_distributions"][field][head]
                    independent = dict(reference_sites=180, visited_scored_sites=180, unvisited_or_unavailable_sites=0, argmax_correct=sum(value[head]["argmax_token_id"] == value["target_token_id"] for value in values), full_vocabulary_size=32, mean_cross_entropy=sum(d["full_vocabulary_cross_entropy"] for d in distributions) / 180, minimum_target_margin=min(margins), maximum_target_margin=max(margins), mean_target_margin=sum(margins) / 180, nonpositive_target_margins=sum(m <= 0 for m in margins), unvisited_or_unavailable_counted_correct=False, scope="actual visited scalar prefix distributions; unvisited/unavailable remain separate")
                    if stored != independent:
                        raise ValueError("Independent full32 cohort CE/margin aggregate mismatch")
            cohort_summaries[cohort] = reported
        for artifact in (trace, pred, scalar, joined, score, record):
            pure.assert_false_masks(artifact)
        panels.append(dict(dimension=key[0], arm=key[1], state_ref=record["state_ref"], paragraphs=96, rules=360, reference_scalar_sites=1440, visited_scalar_sites=1440, unvisited_sites=0, unavailable_sites=0, extra_sites=0, original48_exact_archived_parity=True, ordered_exact=exact, seven_facets={f: {"correct": facets[f], "total": 360} for f in pure.FACETS}, token_cross_entropy=ce_sum / token_count, teacher_forced_target_tokens=token_count, by_cohort=cohort_summaries, generation_seconds=record["generation_seconds"], teacher_forced_and_formula_scoring_seconds=record["scoring_seconds"], scalar_scoring_seconds=record["source_head_scoring_seconds"]))
    pure.assert_false_masks(summary)
    input_hashes = {}
    for path, wanted in manifest["inputs"].items():
        h = hashlib.sha256()
        with Path(path).open("rb") as stream:
            for chunk in iter(lambda: stream.read(1048576), b""):
                h.update(chunk)
        if h.hexdigest() != wanted:
            raise ValueError("Frozen input changed: " + path)
        input_hashes[path] = {"sha256": h.hexdigest(), "bytes": Path(path).stat().st_size}
    check("all1162-postrun-inputs-unchanged", len(input_hashes) == 1162, {"input_bytes": sum(v["bytes"] for v in input_hashes.values()), "binding_tree_sha256": digest(input_hashes)})
    for path, wanted in summary["source_dependencies"].items():
        if hashlib.sha256(Path(path).read_bytes()).hexdigest() != wanted:
            raise ValueError("Resident numerical owner body changed")
    check("full-trace-distribution-count", trace_sites_checked == 5760 and distribution_count == 17280)
    reader.read_bytes(pure_path)
    reader.read_bytes(__file__)
    result = dict(schema="actual-TRAIN-observation-independent-review/v1", passed=True, findings=[], checks=checks, artifacts=reader.bindings, root_completion_signal_received=True, run_root=str(run), attempt="train-observation-r1", panels=panels, all_four_original48_generation_parity=parity, full32_scalar_sites_checked=trace_sites_checked, source_recurrent_combined_distributions_checked=distribution_count, postrun_input_count=len(input_hashes), postrun_input_binding_tree_sha256=digest(input_hashes), all_semantic_proof_admission_promotion_masks_false=True, timing=dict(driver_elapsed_seconds=summary["elapsed_seconds"], guardian_outer_seconds=guardian["elapsed_seconds"], launch_return_through_reap_wall_seconds=child["launch_return_through_reap_wall_seconds"], isolated_child_execution_seconds=child["isolated_child_execution_seconds"]), measurement_limits=["These are exposed original/normative TRAIN cohorts, not heldout semantic generalization.", "Inherited setup loaded TRAIN/validation metadata; separate posthoc scoring reads followed the four-panel durability barrier.", "Full32 source/recurrent decomposition is arithmetic, not causal isolation; no scale or checkpoint is selected.", "Empty qualifiers do not establish nonempty qualifier support. Representation preflight and metadata registration remain separate nonauthority activities.", "Frozen historical numerical owners and warm caches are measured; no encoder/current compiler/native-family/Lean admission is measured."], audit_execution=dict(model_imported=False, numerical_owner_imported=False, model_executed=False, encoder_executed=False, native_or_Lake_executed=False, source_or_tensor_modified=False, posthoc_reference_bodies_parsed_after_completion_signal_and_four_panel_binding_checks=True, elapsed_seconds=time.monotonic() - start))
    target = root / "actual-result-independent-review.json"
    target.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(dict(passed=True, report=str(target), checks=len(checks), full32_sites=trace_sites_checked, distributions=distribution_count, panels=[dict(dimension=p["dimension"], arm=p["arm"], ordered_exact=p["ordered_exact"], original=p["by_cohort"]["original_train"]["ordered_exact"], normative=p["by_cohort"]["normative_train"]["ordered_exact"]) for p in panels])))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root-completion-signaled", action="store_true")
    audit(parser.parse_args().root_completion_signaled)
