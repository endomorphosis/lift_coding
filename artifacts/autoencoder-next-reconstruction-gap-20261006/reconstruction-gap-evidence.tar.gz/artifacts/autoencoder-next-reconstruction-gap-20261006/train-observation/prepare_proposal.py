#!/usr/bin/env python3
"""Seal a TRAIN observation proposal; no numerical owner is imported or run."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

R = Path(__file__).resolve().parent
P = Path('/home/barberb/lift_coding/external/ipfs_datasets')
E = P/'workspace/test-logs/decoder-normative-wording-r2-20261006'
BASE = P/'workspace/test-logs/decoder-normative-wording-retention-20261006/experiment-source/scripts/ops/autoencoder/evaluate_normative_wording_retention.py'
PRIVATE = 'scripts/ops/autoencoder/observe_normative_training_readouts.py'
BASE_SHA = 'ea7c61a94cd40c09c81cc952134751546b5cd9171a324a187a7010039ac954d4'

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1048576),b''): h.update(block)
    return h.hexdigest()

def read(path): return json.loads(Path(path).read_bytes())
def save(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x') as f: json.dump(value,f,sort_keys=True,indent=2); f.write('\n')

def replace_once(source,old,new):
    if source.count(old)!=1: raise ValueError('unique adaptation anchor required: '+old[:90])
    return source.replace(old,new,1)

def function(source,name,replacement):
    node=next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name==name)
    lines=source.splitlines(True)
    return ''.join(lines[:node.lineno-1])+replacement+'\n\n'+''.join(lines[node.end_lineno:])

ORIGINAL_ARCHIVES = '''def verify_original_archives(manifest, records, lanes, digest):
    """Four existing original-TRAIN outputs, checked only after durable rollout."""
    require(len(records)==4, 'all four endpoint observations required')
    keys=('id','token_ids','generation_status','eos_reached')
    for record in records:
        key=f'{record["dimension"]}-{record["arm"]}'
        oldref=manifest['archived_original_predictions'][key]
        old=bound(manifest,oldref['path'])
        lane=lanes[record['dimension']]
        require(sha(oldref['path'])==oldref['sha256'] and
            Path(oldref['path']).stat().st_size==oldref['bytes'] and
            old['report']['complete'] is True and old['report']['sample_count']==48 and
            old['report']['model_weights_sha256']==record['state_ref']['tensor_sha256'] and
            old['report']['source_contexts_sha256']==digest(lane['original_contexts']) and
            old['report']['generation_target_access'] is False and
            old['report']['generation_temperature']==0 and old['report']['max_target_tokens']==512,
            'archived original TRAIN endpoint/provenance differs')
        ref=record['predictions_ref']
        require(sha(ref['path'])==ref['sha256'],'new prediction changed')
        new=json.loads(Path(ref['path']).read_bytes())
        original_ids=[r['id'] for r in lane['original_rows']]
        require([r['id'] for r in old['predictions']]==original_ids and
            [r['id'] for r in new['predictions'][:48]]==original_ids and
            [{k:r[k] for k in keys} for r in new['predictions'][:48]]==
            [{k:r[k] for k in keys} for r in old['predictions']],
            'actual original TRAIN tokens/status/EOS differ from archived endpoint')
'''

LOAD_REFERENCES = '''def load_references(manifest, records, runs, lanes, codec, digest):
    verify_predictions(records,runs,lanes,digest)
    verify_original_archives(manifest,records,lanes,digest)
    # These independent posthoc artifact reads occur after all four rollouts.
    # Inherited load_context/prepare_lane already reads historic TRAIN/validation
    # metadata, explicitly declared in FIXED. No withheld-TRAIN-label claim.
    original_by_width={}
    for width in (384,768):
        saved=bound(manifest,manifest['original_training_rows'][str(width)])
        rows=saved['train']
        require(len(rows)==48 and [{k:r[k] for k in ('id','source_text','input')} for r in rows]
            ==lanes[width]['original_rows'],'posthoc original TRAIN rows changed')
        original_by_width[width]=rows
    require([{k:r[k] for k in ('id','source_text','target_ids')} for r in original_by_width[384]]==
        [{k:r[k] for k in ('id','source_text','target_ids')} for r in original_by_width[768]],
        'original TRAIN target/source identities differ by width')
    normative=bound(manifest,manifest['normative_references'])
    receipt=bound(manifest,manifest['normative_receipt'])
    require(type(normative) is list and len(normative)==48 and receipt['complete'] is True and
        receipt['schema']=='normative-wording-training-sources/v1' and
        receipt['references_sha256']==digest(normative) and
        receipt['receipt_sha256']==digest({k:v for k,v in receipt.items() if k!='receipt_sha256'}) and
        receipt['codec_sha256']==digest(codec) and receipt['original_train_sources']==180 and
        receipt['unique_original_train_rules']==90 and receipt['unique_clauses']==180,
        'complete unchanged normative TRAIN reference receipt required')
    original=[]
    vocabulary=codec['target_vocabulary']
    require(len(vocabulary)==32,'unchanged32V TRAIN codec required')
    for row in original_by_width[384]:
        ids=row['target_ids']
        require(type(ids) is list and 3<=len(ids)<=512 and ids[0]==1 and ids[-1]==2 and
            all(type(t) is int and 3<=t<32 for t in ids[1:-1]),'complete original TRAIN tokens required')
        target=json.loads(''.join(vocabulary[t] for t in ids[1:-1]))
        original.append(dict(id=row['id'],source_text=row['source_text'],
            source_sha256=hashlib.sha256(row['source_text'].encode()).hexdigest(),
            target_ids=ids,target=target,target_sha256=digest(target),target_ids_sha256=digest(ids),
            codec_sha256=digest(codec),clause_count=len(target['rules']),
            template='original_train',cohort='original_train',split='training'))
    refs=original+[dict(ref,cohort='normative_train') for ref in normative]
    source=[{k:r[k] for k in ('id','source_text')} for r in lanes[384]['fresh_rows']]
    require(source==[{k:r[k] for k in ('id','source_text')} for r in lanes[768]['fresh_rows']] and
        len(refs)==96 and len({r['id'] for r in refs})==96,
        'same96 source/reference ordering required by width')
    for ref,row in zip(refs,source):
        ids=ref['target_ids']; target=ref['target']
        require(ref['id']==row['id'] and ref['source_text']==row['source_text'] and
            ref['source_sha256']==hashlib.sha256(row['source_text'].encode()).hexdigest() and
            ref['target_sha256']==digest(target) and ref['target_ids_sha256']==digest(ids) and
            type(ids) is list and 3<=len(ids)<=512 and ids[0]==1 and ids[-1]==2 and
            all(type(t) is int and 3<=t<32 for t in ids[1:-1]) and
            json.loads(''.join(vocabulary[t] for t in ids[1:-1]))==target and
            set(target)=={'rules'} and 1<=len(target['rules'])<=8 and
            all(set(rule)=={'actor','action','modality','object','conditions','exceptions','temporal'} and
                all(rule[k]==[] for k in ('conditions','exceptions','temporal')) for rule in target['rules']),
            'complete fixed original/normative TRAIN source/target/qualifier binding required')
    require(sum(len(r['target']['rules']) for r in original)==180 and
        sum(len(r['target']['rules']) for r in normative)==180,
        'retain180 rules per cohort and360 total')
    return refs,dict(schema='train-observation-reference-receipts/v1',normative=receipt,
        original_training_rows_sha256={str(w):sha(manifest['original_training_rows'][str(w)]) for w in (384,768)},
        posthoc_reference_load_after_all_four_durable_panels=True,
        inherited_train_validation_metadata_previously_loaded=True,**FALSE)
'''

SCORING_REFERENCES = '''def scoring_references(references,receipt):
    """All meanings are derived from original TRAIN; grouping added posthoc."""
    return [dict(deepcopy(ref),template_family=ref['cohort']+':'+ref['template'],
        components=[dict(slot=slot,training_pair_seen=True) for slot in range(len(ref['target']['rules']))])
        for ref in references]
'''

COHORT_SUMMARY = '''def summarize_cohorts(score,joined,references):
    result={}
    def observed_distribution(fields,field,head):
        available=[r['fields'][field] for r in fields if r['fields'][field]['status']=='visited']
        distributions=[r[head] for r in available]
        margins=[r['target_minus_best_other'] for r in distributions]
        losses=[r['full_vocabulary_cross_entropy'] for r in distributions]
        return dict(reference_sites=180,visited_scored_sites=len(available),
            unvisited_or_unavailable_sites=180-len(available),
            argmax_correct=sum(r[head]['argmax_token_id']==r['target_token_id'] for r in available),
            full_vocabulary_size=32,mean_cross_entropy=sum(losses)/len(losses) if losses else None,
            minimum_target_margin=min(margins) if margins else None,
            maximum_target_margin=max(margins) if margins else None,
            mean_target_margin=sum(margins)/len(margins) if margins else None,
            nonpositive_target_margins=sum(v<=0 for v in margins),
            unvisited_or_unavailable_counted_correct=False,
            scope='actual visited scalar prefix distributions; unvisited/unavailable remain separate')
    for cohort in ('original_train','normative_train'):
        selected=[r for r in references if r['cohort']==cohort]
        ids={r['id'] for r in selected}
        fidelity=[r for r in score['fidelity']['rows'] if r['id'] in ids]
        fields=[r for r in joined['rows'] if r['id'] in ids]
        losses=[r for r in score['teacher_forced']['rows'] if r['id'] in ids]
        require(len(selected)==len(fidelity)==len(losses)==48 and len(fields)==180,
            'complete48/180 cohort denominator required')
        token_count=sum(r['token_count'] for r in losses)
        result[cohort]=dict(paragraphs=48,rules=180,scalar_sites=720,
            ordered_exact=sum(r['counts']['ordered_exact'] for r in fidelity),
            formula_metrics={key:sum(r['counts'][key] for r in fidelity) for key in fidelity[0]['counts']},
            seven_facets={field:dict(correct=sum(r['by_facet'][field]['correct'] for r in fidelity),
                total=sum(r['by_facet'][field]['total'] for r in fidelity)) for field in
                ('actor','action','modality','object','conditions','exceptions','temporal')},
            full_vocabulary_scalar_distributions={field:{head:observed_distribution(fields,field,head)
                for head in ('source','recurrent','combined')} for field in ('actor','action','modality','object')},
            token_cross_entropy=sum(sum(r['token_cross_entropies']) for r in losses)/token_count,
            target_tokens=token_count,
            fields={field:dict(reference_sites=180,
                visited=sum(r['fields'][field]['status']=='visited' for r in fields),
                unvisited=sum(r['fields'][field]['status']=='unvisited' for r in fields),
                unavailable=sum(r['fields'][field]['status']=='unavailable' for r in fields),
                source_correct=sum(r['fields'][field]['source_correct'] is True for r in fields),
                source_correct_formula_wrong=sum(r['fields'][field]['source_correct'] is True and
                    not r['fields'][field]['formula_field_correct'] for r in fields))
                for field in ('actor','action','modality','object')},**FALSE)
    return result
'''

LANE_INPUTS = '''        lane['continuation_manifest']=manifest
        # Original rows are the exact frozen native lane, with labels stripped
        # at this boundary. Their metadata is already loaded by inheritance.
        original_rows=[{k:r[k] for k in ('id','source_text','input')} for r in lane['rows']['train']]
        original_contexts=lane['source_contexts']['train']
        pins=manifest['original_source_pins'][str(dimension)]
        require(len(original_rows)==48 and digest(original_rows)==pins['rows_sha256'] and
            digest(original_contexts)==pins['contexts_sha256'],
            'original cached TRAIN source/contexts differ from archived fit')
        data=bound(manifest,manifest['source_inputs'][str(dimension)])
        require(data['schema']=='training-paraphrase-source-inputs/v1' and data['complete'] is True and
            data['dimension']==dimension and data['targets_attached'] is False and
            data['preprocessing_fitted'] is False and data['inputs_sha256']==
            digest({k:v for k,v in data.items() if k!='inputs_sha256'}),
            'authenticated target-free normative TRAIN cache required')
        normative_rows=data['rows']
        require(len(normative_rows)==48 and all(set(r)=={'id','source_text','input'} for r in normative_rows)
            and all(set(r)=={'id','source_text','input'} for r in data['clause_cache']),
            'closed48 normative source rows/clause cache required')
        context_owner=ctx['owners']['clause_source_context']
        normative_contexts=context_owner.build_source_contexts(
            [{k:r[k] for k in ('id','source_text')} for r in normative_rows],data['clause_cache'])
        require(normative_contexts==data['source_contexts'] and
            context_owner.validate_contexts(normative_rows,normative_contexts)['dimension']==dimension,
            'normative native source contexts changed')
        require(not(set(original_contexts)&set(normative_contexts)), 'cohort context IDs overlap')
        rows=original_rows+normative_rows
        contexts=dict(original_contexts,**normative_contexts)
        require(len(rows)==len({r['id'] for r in rows})==len(contexts)==96 and
            all(set(r)=={'id','source_text','input'} for r in rows), 'closed unique96 source-only rows required')
        for row in rows: ctx['core']._vector(row['input'],dimension)
        require(context_owner.validate_contexts(rows,contexts)['dimension']==dimension,
            'combined original/normative source contexts invalid')
        lane.update(fresh_rows=rows,fresh_contexts=contexts,original_rows=original_rows,
            original_contexts=original_contexts,source_cohorts_by_id={r['id']:
                ('original_train' if i<48 else 'normative_train') for i,r in enumerate(rows)})
'''

def main():
    # The parent runner's exact checksum is independently sealed in the completed
    # retention manifest, rather than inferred from an editable canonical file.
    old_manifest=read(BASE.parents[4]/'evaluation-manifest.json')
    expected=old_manifest['extensions']['scripts/ops/autoencoder/evaluate_normative_wording_retention.py']
    if sha(BASE)!=expected or expected!=BASE_SHA: raise ValueError('completed retention runner changed')
    source=BASE.read_text()
    source=source.replace('normative-wording-retention','normative-wording-train-observation')
    source=source.replace('samples_per_panel=48','samples_per_panel=96')
    source=source.replace('max_seconds_per_panel=30','max_seconds_per_panel=60')
    source=source.replace('max_trace_memory_bytes=134217728','max_trace_memory_bytes=268435456')
    source=source.replace('previously_exposed_authored_modality_holdout_v3','original_and_normative_TRAIN_observation')
    source=replace_once(source,"    comparison_seal='4e09fd75f40e410d1a53f7f13d01c034c1b0bcae5254a5f7f195754d7db16eac',",
        "    cohort_count=2, samples_per_cohort=48, rules_per_cohort=180, rules_per_panel=360,\n"
        "    scalar_sites_per_cohort=720, scalar_sites_per_panel=1440,\n"
        "    inherited_train_validation_metadata_loaded_before_collection=True,\n"
        "    posthoc_train_references_loaded_after_four_panel_barrier=True,\n"
        "    cached_native_profiles_preserved_without_reencoding=True,")
    source=source.replace('no_training_or_selection_from_development=True','no_training_or_checkpoint_selection=True')
    source=source.replace("trace.get('sample_count') == 48","trace.get('sample_count') == 96")
    source=source.replace("len(panel.get('predictions',[])) == 48","len(panel.get('predictions',[])) == 96")
    source=function(source,'verify_zero_archives',ORIGINAL_ARCHIVES)
    source=function(source,'load_references',LOAD_REFERENCES)
    source=function(source,'scoring_references',SCORING_REFERENCES+'\n'+COHORT_SUMMARY)
    node=next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef)and n.name=='join_source_heads_and_formula')
    lines=source.splitlines(True);old=''.join(lines[node.lineno-1:node.end_lineno])
    new=old.replace('==48','==96').replace('== 48','== 96').replace('==720','==1440').replace('== 720','== 1440').replace('==180','==360').replace('== 180','== 360').replace('reference_sites=180','reference_sites=360').replace('len(rows)==180','len(rows)==360')
    new=new.replace('all180','all360').replace('complete48','complete96').replace('exact180-rule720-scalar','exact360-rule1440-scalar').replace('per-field180','per-field360')
    source=source[:0]+''.join(lines[:node.lineno-1])+new+'\n'+''.join(lines[node.end_lineno:])
    start=source.index("        lane['continuation_manifest'] = manifest\n",source.index('def execute'))
    end=source.index('        lanes[dimension] = lane',start)
    source=source[:start]+LANE_INPUTS+source[end:]
    source=replace_once(source,"deadline=min(deadline,time.monotonic()+30.),max_memory_bytes=FIXED['max_trace_memory_bytes'])",
        "deadline=min(deadline,time.monotonic()+60.),max_memory_bytes=FIXED['max_trace_memory_bytes'])")
    source=source.replace("development_reference_json_loaded=False","posthoc_train_reference_json_loaded=False,\n        inherited_train_validation_metadata_loaded_before_collection=True")
    source=source.replace("time.monotonic()+30.-record['generation_seconds']","time.monotonic()+60.-record['generation_seconds']")
    source=source.replace("split='exposed_development'","split='training'")
    source=source.replace('original_v3_grouping_metadata_preserved=True','training_grouping_metadata_added_after_reference_barrier=True')
    source=source.replace("source_head_formula_join_ref=joined_ref,source_head_by_field=joined['per_field'],",
        "source_head_formula_join_ref=joined_ref,source_head_by_field=joined['per_field'],\n            by_cohort=summarize_cohorts(score,joined,refs),")
    source=source.replace('exposed_v3_receipt_sha256=digest(receipt), archived_zero_generation_parity_verified=True',
        'training_reference_receipts_sha256=digest(receipt), archived_original_generation_parity_verified=True,\n        inherited_train_validation_metadata_loaded_before_collection=True')
    source=source.replace('development observer','TRAIN observer').replace('development references','posthoc TRAIN references')
    first=source.index('"""');last=source.index('"""',first+3)+3
    source=source[:first]+'"""Four selected endpoints, original TRAIN48 plus normative TRAIN48.\n'+\
        'Frozen numerical owners; source-only same-pass traces before posthoc scoring.\n'+\
        'Inherited setup reads historical TRAIN/validation metadata, declared explicitly.\n'+\
        'No fitting, encoder, downloads, default activation or qualification.\n"""'+source[last:]
    ast.parse(source)
    target=R/'experiment-source'/PRIVATE;target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('x')as f:f.write(source)
    (R/'runner-adaptation.diff').write_text(''.join(difflib.unified_diff(BASE.read_text().splitlines(True),source.splitlines(True),fromfile=str(BASE),tofile=str(target))))
    namespace={}
    for node in ast.parse(source).body:
        if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name)and t.id in {'OBSERVER_SHA256','ARMS','ROLES','FALSE','FIXED'}for t in node.targets):
            exec(compile(ast.Module(body=[node],type_ignores=[]),str(target),'exec'),namespace)
    inherited=read(E/'evaluation-manifest.json');training=read(E/'training-manifest.json')
    inputs=dict(training['inputs'])
    def retain(path,wanted=None):
        path=Path(path).resolve();actual=sha(path)
        if wanted is not None and actual!=wanted:raise ValueError('changed sealed input: '+str(path))
        if str(path)in inputs and inputs[str(path)]!=actual:raise ValueError('conflicting input pin')
        inputs[str(path)]=actual
    retain(E/'training-manifest.json');retain(E/'training-plan.json');retain(E/'evaluation-manifest.json');retain(BASE,expected);retain(Path(__file__))
    for rel,wanted in training['extensions'].items():retain(E/'experiment-source'/rel,wanted)
    selected={};archives={};original_paths={};original_pins={}
    for width,summarypath in inherited['training_summaries'].items():
        retain(summarypath,inherited['inputs'][str(Path(summarypath).resolve())]);summary=read(summarypath)
        saved=E/f'training-{width}-r1/results/training-rows.json';contexts=E/f'training-{width}-r1/results/source-contexts.json'
        retain(saved);retain(contexts);original_paths[width]=str(saved.resolve())
        rows=read(saved)['train'];source_rows=[{k:r[k]for k in ('id','source_text','input')}for r in rows]
        packet=read(contexts)['train']
        digest=lambda v:hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()
        original_pins[width]=dict(rows_sha256=digest(source_rows),contexts_sha256=digest(packet),metadata_read_by_sealer=True)
        for item in summary['runs']:
            retain(item['summary_path'],item['summary_sha256']);run=read(item['summary_path']);ref=run['states']['selected'];key=f'{width}-{run["arm"]}'
            retain(ref['path'],ref['sha256']);selected[key]=ref
            old=run['postfit']['selected']['training'];archives[key]={k:old[k]for k in ('path','sha256')};archives[key]['bytes']=Path(old['path']).stat().st_size
            retain(old['path'],old['sha256'])
    if len(selected)!=4 or len({r['tensor_sha256']for r in selected.values()})!=4:raise ValueError('four distinct selected tensors required')
    source_inputs={str(w):str((E/f'preparation-r1/results/dimension-inputs-{w}.json').resolve())for w in (384,768)}
    references=str((E/'preparation-r1/results/training-references.json').resolve());receipt=str((E/'preparation-r1/results/training-corpus-receipt.json').resolve())
    for path in [*source_inputs.values(),references,receipt]:retain(path)
    for term in inherited['training_terminals'].values():
        for path in term.values():retain(path)
    manifest={k:inherited[k]for k in ['training_extension_root','training_manifest','training_plan','training_summaries','training_terminals']}
    manifest.update(schema='normative-wording-train-observation-manifest/v1',inputs=inputs,extensions={PRIVATE:sha(target)},
        selected_states=selected,archived_original_predictions=archives,original_training_rows=original_paths,
        original_source_pins=original_pins,source_inputs=source_inputs,normative_references=references,normative_receipt=receipt,
        frozen_parent_runner=dict(path=str(BASE),sha256=expected),source_tree_switch_performed=False,
        model_execution=False,inherited_train_validation_metadata_loaded_before_collection=True,
        posthoc_reference_json_parsed_by_sealer=False,original_training_metadata_parsed_by_sealer=True)
    original_report=P.parents[1]/'artifacts/legal-decoder-native-conditioning-20261002/native768/embeddings-complete/producer-report.json'
    retain(original_report)
    profile=read(original_report)
    production={str(w):read(E/f'preparation-r1/results/production-{w}.json')['representation'] for w in (384,768)}
    original_profiles={}
    for w in (384,768):
        path=E/f'training-{w}-r1/results/preprocessing.json'
        retain(path)
        original_profiles[str(w)]=dict(representation=read(path)['representation'],
            provenance_path=str(path),sha256=sha(path))
    manifest['cached_native_profile_boundaries']=dict(
        original768=dict(profile_id=profile['profile_id'],execution_profile=profile['execution_profile'],
            provenance_path=str(original_report),relabelled_to512=False),
        original=original_profiles,normative=production,
        configured_observation_context_tokens=512,decoder_output_tokens=512,
        encoder_executed=False,cache_reencoded=False,context_increased=False,
        original_and_normative_profile_limits_pooled=False)
    plan=dict(namespace['FIXED'],input_sha256=inputs)
    save(R/'observation-plan.json',plan);manifest['plan_sha256']=sha(R/'observation-plan.json');save(R/'observation-manifest.json',manifest)
    save(R/'proposal-receipt.json',dict(schema='train-observation-private-proposal/v1',passed=True,findings=[],
        runner=dict(path=str(target),sha256=sha(target),bytes=target.stat().st_size),
        plan=dict(path=str(R/'observation-plan.json'),sha256=sha(R/'observation-plan.json')),
        manifest=dict(path=str(R/'observation-manifest.json'),sha256=sha(R/'observation-manifest.json')),
        endpoint_count=4,source_paragraphs_per_endpoint=96,rules_per_endpoint=360,scalar_sites_per_endpoint=1440,
        original_archived_generation_controls=4,model_imported=False,model_executed=False,training_executed=False,
        source_tree_switch_performed=False,canonical_edits=False,posthoc_reference_json_parsed=False,
        original_training_metadata_parsed=True))
    print(json.dumps(dict(proposal=str(R),runner=str(target),four_endpoints=True,model_executed=False)))

if __name__=='__main__':main()
