#!/usr/bin/env python3
"""Pure boundary tests. No numerical owner, model, cache or corpus is loaded."""
import ast
from copy import deepcopy
import hashlib
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

R=Path(__file__).resolve().parent
RUNNER=R/'experiment-source/scripts/ops/autoencoder/observe_normative_training_readouts.py'

def digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()

def load_pure():
    allowed={'require','sha','bound','validate_plan','check_deadline','durable_save',
        'prediction_from_trace','verify_predictions','verify_original_archives',
        'load_references','scoring_references','join_source_heads_and_formula','summarize_cohorts'}
    tree=ast.parse(RUNNER.read_text());nodes=[]
    for node in tree.body:
        if isinstance(node,ast.Import) and all(x.name in {'hashlib','json','os','time'}for x in node.names):nodes.append(node)
        elif isinstance(node,ast.ImportFrom) and node.module in {'copy','pathlib'}:nodes.append(node)
        elif isinstance(node,ast.Assign) and all(isinstance(t,ast.Name)and t.id in
            {'TRACE_FALSE_FLAGS','OBSERVER_SHA256','ARMS','ROLES','FALSE','FIXED'}for t in node.targets):nodes.append(node)
        elif isinstance(node,ast.FunctionDef)and node.name in allowed:nodes.append(node)
    namespace={};exec(compile(ast.Module(body=nodes,type_ignores=[]),str(RUNNER),'exec'),namespace)
    return namespace

class Contracts(unittest.TestCase):
    def setUp(self):
        self.m=load_pure();self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        self.lanes={};self.runs={};self.records=[];self.manifest={'inputs':{},'archived_original_predictions':{}}
        for width in (384,768):
            rows=[dict(id=f'row:{i}',source_text=f'source {i}',input=[0.]*width)for i in range(96)]
            ctx={r['id']:{'fixture':r['id']}for r in rows};original=rows[:48];originalctx={r['id']:ctx[r['id']]for r in original}
            self.lanes[width]=dict(fresh_rows=rows,fresh_contexts=ctx,original_rows=original,
                original_contexts=originalctx,donor=dict(codec={'target_vocabulary':list(range(32))},input_transform={'fixture':width}))
            for ordinal,arm in enumerate(self.m['ARMS']):
                tensor=hashlib.sha256(f'{width}:{arm}'.encode()).hexdigest();state=dict(path='declared-state',sha256='declared-bytes',tensor_sha256=tensor)
                self.runs[width,arm]={'states':{'selected':state}}
                predictions=[dict(id=r['id'],token_ids=[3,2],generation_status='eos',eos_reached=True)for r in rows]
                trace=dict(schema='generated-contextual-scalar-trace/v1',complete=True,sample_count=96,
                    dimension=width,model_tensor_sha256=tensor,source_rows_sha256=digest(rows),
                    source_contexts_sha256=digest(ctx),codec_sha256=digest(self.lanes[width]['donor']['codec']),
                    input_transform_sha256=digest(self.lanes[width]['donor']['input_transform']),vocabulary_size=32,
                    generation_temperature=0,max_target_tokens=512,batch_size=8,predictions=predictions,
                    extra_model_passes=0,source_head_extra_evaluations=0,optimizer_steps=0,elapsed_seconds=0.)
                for key in ('source_only','full_vocabulary_retained','decomposition_exact','caller_state_preserved','hooks_removed','complete_rollout_before_reference_scoring'):trace[key]=True
                for key in ('reference_count_access','reference_prefix_access','reference_documents_passed_to_model','inventory_access','source_context_target_access','syntax_mask','forced_closure','model_copied',*self.m['TRACE_FALSE_FLAGS']):trace[key]=False
                trace['trace_sha256']=digest(trace)
                panel=self.m['prediction_from_trace'](trace)
                folder=self.root/f'{width}-{ordinal}';folder.mkdir()
                tref=self.write(folder/'trace.json',trace);pref=self.write(folder/'predictions.json',panel)
                self.records.append(dict(dimension=width,arm=arm,role='selected',state_ref=state,
                    source_head_trace_ref=tref,source_head_trace_fsynced=True,predictions_ref=pref,prediction_fsynced=True))
                old=dict(report=dict(complete=True,sample_count=48,model_weights_sha256=tensor,
                    source_contexts_sha256=digest(originalctx),generation_target_access=False,
                    generation_temperature=0,max_target_tokens=512),predictions=predictions[:48])
                oref=self.write(folder/'archive.json',old);self.manifest['inputs'][oref['path']]=oref['sha256']
                self.manifest['archived_original_predictions'][f'{width}-{arm}']=oref

    def tearDown(self):self.tmp.cleanup()

    def write(self,p,v):
        p.write_text(json.dumps(v,sort_keys=True)+'\n');b=p.read_bytes()
        return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))

    def rewrite_trace(self,index,mutate):
        r=self.records[index];p=Path(r['source_head_trace_ref']['path']);t=json.loads(p.read_text());mutate(t)
        t['trace_sha256']=digest({k:v for k,v in t.items()if k!='trace_sha256'})
        r['source_head_trace_ref']=self.write(p,t)
        q=Path(r['predictions_ref']['path']);panel=json.loads(q.read_text());panel['same_pass_scalar_trace_sha256']=t['trace_sha256']
        r['predictions_ref']=self.write(q,panel)

    def verify(self):self.m['verify_predictions'](self.records,self.runs,self.lanes,digest)

    def test_exact_four_and_archived_original48_accept(self):
        self.verify();self.m['verify_original_archives'](self.manifest,self.records,self.lanes,digest)

    def test_fixed_recipe_limits_and_truthful_metadata(self):
        p=deepcopy(self.m['FIXED']);self.m['validate_plan'](p)
        self.assertEqual((p['samples_per_panel'],p['rules_per_panel'],p['scalar_sites_per_panel']),(96,360,1440))
        self.assertTrue(p['inherited_train_validation_metadata_loaded_before_collection'])
        for key,value in [('context_tokens',513),('output_tokens',513),('temperature',1),('vocabulary_size',3),('workers',2),('training_executed',True),('fresh_holdout',True),('inherited_train_validation_metadata_loaded_before_collection',False)]:
            q=deepcopy(p);q[key]=value
            with self.subTest(key=key),self.assertRaises(ValueError):self.m['validate_plan'](q)

    def test_boolean_integer_alias_refused(self):
        p=deepcopy(self.m['FIXED']);p['workers']=True
        with self.assertRaises(ValueError):self.m['validate_plan'](p)

    def test_missing_endpoint_refuses_before_any_posthoc_reference_read(self):
        self.records.pop();calls=[]
        with patch.dict(self.m,bound=lambda *a:calls.append(a)):
            with self.assertRaises(ValueError):self.m['load_references'](self.manifest,self.records,self.runs,self.lanes,{},digest)
        self.assertEqual(calls,[])

    def test_duplicate_endpoint_refused(self):
        self.records[3]=deepcopy(self.records[0])
        with self.assertRaises(ValueError):self.verify()

    def test_last_role_not_extra_replication(self):
        self.records[0]['role']='last-attempt'
        with self.assertRaises(ValueError):self.verify()

    def test_prediction_not_durable_refused(self):
        self.records[0]['prediction_fsynced']=False
        with self.assertRaises(ValueError):self.verify()

    def test_trace_not_durable_refused(self):
        self.records[0]['source_head_trace_fsynced']=False
        with self.assertRaises(ValueError):self.verify()

    def test_actual_prediction_bytes_must_remain_bound(self):
        Path(self.records[0]['predictions_ref']['path']).write_text('{}')
        with self.assertRaises(ValueError):self.verify()

    def test_reference_masks_and_extra_passes_refused(self):
        for key in ['reference_prefix_access','reference_count_access','reference_documents_passed_to_model','inventory_access','source_context_target_access','syntax_mask','forced_closure','model_copied']:
            with self.subTest(key=key):
                old=deepcopy(self.records);self.rewrite_trace(0,lambda t:t.update({key:True}))
                with self.assertRaises(ValueError):self.verify()
                self.records=old
                # Each next case uses another independently constructed fixture.
                self.tearDown();self.setUp()
        for key in ['extra_model_passes','source_head_extra_evaluations','optimizer_steps']:
            with self.subTest(key=key):
                self.rewrite_trace(0,lambda t:t.update({key:1}))
                with self.assertRaises(ValueError):self.verify()
                self.tearDown();self.setUp()

    def test_full_vocabulary_and_source_count_required(self):
        self.rewrite_trace(0,lambda t:t.update(vocabulary_size=3))
        with self.assertRaises(ValueError):self.verify()
        self.tearDown();self.setUp();self.rewrite_trace(0,lambda t:t.update(sample_count=48))
        with self.assertRaises(ValueError):self.verify()

    def test_state_identity_required(self):
        self.rewrite_trace(0,lambda t:t.update(model_tensor_sha256='other-state'))
        with self.assertRaises(ValueError):self.verify()

    def test_cohort_order_is_fixed(self):
        self.rewrite_trace(0,lambda t:t['predictions'].reverse())
        with self.assertRaises(ValueError):self.verify()

    def test_archived_original_tokens_and_eos_are_exact(self):
        r=self.records[0];key=f'{r["dimension"]}-{r["arm"]}';p=Path(self.manifest['archived_original_predictions'][key]['path'])
        old=json.loads(p.read_text());old['predictions'][0]['eos_reached']=False
        ref=self.write(p,old);self.manifest['archived_original_predictions'][key]=ref;self.manifest['inputs'][str(p)]=ref['sha256']
        with self.assertRaises(ValueError):self.m['verify_original_archives'](self.manifest,self.records,self.lanes,digest)

    def test_archive_wrong_state_rejected(self):
        r=self.records[0];key=f'{r["dimension"]}-{r["arm"]}';p=Path(self.manifest['archived_original_predictions'][key]['path'])
        old=json.loads(p.read_text());old['report']['model_weights_sha256']='other-state'
        ref=self.write(p,old);self.manifest['archived_original_predictions'][key]=ref;self.manifest['inputs'][str(p)]=ref['sha256']
        with self.assertRaises(ValueError):self.m['verify_original_archives'](self.manifest,self.records,self.lanes,digest)

    def reference_fixture(self):
        rule=dict(actor='trustee',action='preserve',modality='O',object='archive',conditions=[],exceptions=[],temporal=[])
        vocabulary=['']*32;vocabulary[3]='{"rules":[';vocabulary[4]=json.dumps(rule,sort_keys=True,separators=(',',':'));vocabulary[5]=',';vocabulary[6]=']}'
        codec={'target_vocabulary':vocabulary};counts=[count for count in (1,2,4,8)for _ in range(12)]
        original_paths={};normative=[]
        for width,lane in self.lanes.items():
            lane['donor']['codec']=codec
            original=[]
            for i,row in enumerate(lane['original_rows']):
                ids=[1,3]+[token for slot in range(counts[i])for token in ([4]if slot==0 else [5,4])]+[6,2]
                original.append(dict(row,target_ids=ids))
            p=self.root/f'original-{width}.json';ref=self.write(p,{'train':original,'validation':[]});self.manifest['inputs'][str(p)]=ref['sha256'];original_paths[str(width)]=str(p)
        for i,row in enumerate(self.lanes[384]['fresh_rows'][48:]):
            ids=[1,3]+[token for slot in range(counts[i])for token in ([4]if slot==0 else [5,4])]+[6,2]
            target={'rules':[deepcopy(rule)for _ in range(counts[i])]}
            normative.append(dict(id=row['id'],source_text=row['source_text'],source_sha256=hashlib.sha256(row['source_text'].encode()).hexdigest(),target=target,target_ids=ids,
                target_sha256=digest(target),target_ids_sha256=digest(ids),template='fixture_template'))
        receipt=dict(schema='normative-wording-training-sources/v1',complete=True,references_sha256=digest(normative),codec_sha256=digest(codec),original_train_sources=180,unique_original_train_rules=90,unique_clauses=180)
        receipt['receipt_sha256']=digest(receipt)
        np=self.root/'normative-refs.json';rp=self.root/'normative-receipt.json'
        for p,v in [(np,normative),(rp,receipt)]:
            ref=self.write(p,v);self.manifest['inputs'][str(p)]=ref['sha256']
        self.manifest.update(original_training_rows=original_paths,normative_references=str(np),normative_receipt=str(rp))
        for i in range(4):self.rewrite_trace(i,lambda t:t.update(codec_sha256=digest(codec)))
        return codec

    def test_complete_reference_assembly_has_two_full180_rule_cohorts(self):
        codec=self.reference_fixture()
        refs,receipt=self.m['load_references'](self.manifest,self.records,self.runs,self.lanes,codec,digest)
        self.assertEqual(len(refs),96);self.assertEqual(sum(len(r['target']['rules'])for r in refs),360)
        self.assertEqual([r['cohort']for r in refs[:48]],['original_train']*48)
        self.assertTrue(receipt['posthoc_reference_load_after_all_four_durable_panels'])
        normalized=self.m['scoring_references'](refs,receipt)
        self.assertEqual(sum(len(r['components'])for r in normalized),360)
        self.assertTrue(all(c['training_pair_seen']for r in normalized for c in r['components']))

    def test_changed_normative_reference_tokens_refused(self):
        codec=self.reference_fixture();p=Path(self.manifest['normative_references']);refs=json.loads(p.read_text());refs[0]['target_ids']=[1,2]
        ref=self.write(p,refs);self.manifest['inputs'][str(p)]=ref['sha256']
        with self.assertRaises(ValueError):self.m['load_references'](self.manifest,self.records,self.runs,self.lanes,codec,digest)

    def test_cohort_summary_preserves_empty_qualifiers_and_null_margins(self):
        codec=self.reference_fixture();refs,_=self.m['load_references'](self.manifest,self.records,self.runs,self.lanes,codec,digest)
        rows=[];losses=[];unvisited=[]
        for r in refs:
            n=len(r['target']['rules']);counts=dict(ordered_exact=1,eos_count=1,expected_rules=n,generated_rules=n,rows=1,syntax_valid=1,whole_rules_missing=0,whole_rules_extra=0)
            rows.append(dict(id=r['id'],counts=counts,generated_ir=deepcopy(r['target']),by_facet={f:dict(correct=n,total=n)for f in ('actor','action','modality','object','conditions','exceptions','temporal')}))
            losses.append(dict(id=r['id'],token_count=1,token_cross_entropies=[0.5]))
            unvisited.extend(dict(id=r['id'],slot=i,field=f)for i in range(n)for f in ('actor','action','modality','object'))
        scalar=dict(complete=True,events=[],unvisited_reference_sites=unvisited,unscored_sites=[])
        joined=self.m['join_source_heads_and_formula'](scalar,{'rows':rows},refs)
        score=dict(fidelity={'rows':rows},teacher_forced={'rows':losses})
        result=self.m['summarize_cohorts'](score,joined,refs)
        for cohort in result.values():
            self.assertEqual((cohort['paragraphs'],cohort['rules'],cohort['scalar_sites'],cohort['ordered_exact']),(48,180,720,48))
            self.assertEqual(cohort['seven_facets']['conditions'],{'correct':180,'total':180})
            for field in cohort['full_vocabulary_scalar_distributions'].values():
                for head in field.values():
                    self.assertEqual(head['unvisited_or_unavailable_sites'],180)
                    self.assertIsNone(head['minimum_target_margin']);self.assertIsNone(head['mean_cross_entropy'])
                    self.assertEqual(head['argmax_correct'],0)

    def test_full_reference_denominator_keeps_unvisited_null(self):
        refs=[];fidelity=[]
        for cohort in range(2):
            for count in (1,2,4,8):
                for i in range(12):
                    identity=f'{cohort}:{count}:{i}';rule=dict(actor='trustee',action='preserve',modality='O',object='archive',conditions=[],exceptions=[],temporal=[])
                    refs.append(dict(id=identity,source_sha256=identity,target={'rules':[deepcopy(rule)for _ in range(count)]}))
                    fidelity.append(dict(id=identity,generated_ir={'rules':[deepcopy(rule)for _ in range(count)]}))
        unvisited=[dict(id=r['id'],slot=i,field=f)for r in refs for i in range(len(r['target']['rules']))for f in ('actor','action','modality','object')]
        score=dict(complete=True,events=[],unvisited_reference_sites=unvisited,unscored_sites=[])
        joined=self.m['join_source_heads_and_formula'](score,{'rows':fidelity},refs)
        self.assertEqual(len(joined['rows']),360)
        for value in joined['per_field'].values():
            self.assertEqual((value['reference_sites'],value['unvisited'],value['source_correct']),(360,360,0))
        self.assertIsNone(joined['rows'][0]['fields']['modality']['source_correct'])
        self.assertFalse(joined['unvisited_counted_correct'])
        score['unvisited_reference_sites'].pop()
        with self.assertRaises(ValueError):self.m['join_source_heads_and_formula'](score,{'rows':fidelity},refs)

    def test_durable_save_fsync_and_exact_hash(self):
        def saver(p,v):p.parent.mkdir(parents=True,exist_ok=True);return self.write(p,v)
        p=self.root/'durable/result.json'
        with patch.object(os,'fsync',wraps=os.fsync) as sync:
            ref=self.m['durable_save'](saver,p,{'complete':True})
        self.assertEqual(sync.call_count,2);self.assertEqual(ref['sha256'],self.m['sha'](p))

if __name__=='__main__':unittest.main(verbosity=2)
