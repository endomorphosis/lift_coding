"""Seal a read-only cached diagnostic; importing this file starts no work."""
from pathlib import Path
import hashlib
import importlib.util
import json
import shutil

R = Path(__file__).resolve().parent
P = R.parents[2]
OLD = R.parent / 'decoder-paraphrase-modality-styles-20261004'
SCRIPT = 'scripts/ops/autoencoder/diagnose_paraphrase_modality_margins.py'
TEST = 'tests/unit/logic/formalization/autoencoder/test_paraphrase_modality_margins.py'


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1048576), b''):
            h.update(chunk)
    return h.hexdigest()


def read(path):
    return json.loads(Path(path).read_bytes())


def save(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write('\n')


def main():
    if (R / 'diagnostic-manifest.json').exists():
        raise ValueError('completed diagnostic seal is immutable')
    parent = read(OLD / 'evaluation-manifest.json')
    inputs = dict(parent['inputs'])

    def retain(path, wanted=None):
        path = Path(path).resolve()
        actual = sha(path)
        if wanted is not None and wanted != actual:
            raise ValueError('input digest differs: ' + str(path))
        if str(path) in inputs and inputs[str(path)] != actual:
            raise ValueError('inherited input changed: ' + str(path))
        inputs[str(path)] = actual

    for path, wanted in list(inputs.items()):
        retain(path, wanted)
    extensions = dict(parent['extensions'])
    for rel, wanted in list(extensions.items()):
        if sha(R / 'experiment-source' / rel) != wanted:
            raise ValueError('inherited extension differs: ' + rel)
    for rel in (SCRIPT, TEST):
        src = P / rel
        dst = R / 'experiment-source' / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        if dst.exists():
            raise ValueError('fresh new extension required: ' + rel)
        shutil.copyfile(src, dst)
        extensions[rel] = sha(dst)
        retain(src, extensions[rel])
    spec = importlib.util.spec_from_file_location('_sealed_margin_recipe', R / 'experiment-source' / SCRIPT)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    style_summary = OLD / 'evaluation-r1/results/summary.json'
    summary = read(style_summary)
    if summary['complete'] is not True or len(summary['panels']) != 8:
        raise ValueError('complete archived exposed-style evaluation required')
    for name in ('evaluation-manifest.json', 'evaluation-plan.json', 'evaluation-r1-guardian-exit.json',
                 'evaluation-r1/child-exit.json', 'evaluation-r1/resources-final.json'):
        retain(OLD / name)
    retain(style_summary)
    if read(OLD / 'evaluation-r1-guardian-exit.json')['returncode'] != 0:
        raise ValueError('prior observer did not succeed')
    if read(OLD / 'evaluation-r1/resources-final.json')['status'] != 'released':
        raise ValueError('prior observer resources are not released')
    archived = {}
    aliases = []
    for d in module.FIXED['dimensions']:
        for arm in module.ARMS:
            pair = {row['role']: row for row in summary['panels'] if row['dimension'] == d and row['arm'] == arm}
            if set(pair) != {'selected', 'last-attempt'}:
                raise ValueError('exact archived endpoint pair required')
            if pair['selected']['state_ref']['tensor_sha256'] != pair['last-attempt']['state_ref']['tensor_sha256']:
                raise ValueError('last-attempt is not the expected selected tensor alias')
            key = f'{d}-{arm}-selected'
            archived[key] = pair['selected']['predictions_ref']
            for row in pair.values():
                for kind in ('state_ref', 'predictions_ref', 'score_ref'):
                    retain(row[kind]['path'], row[kind]['sha256'])
            aliases.append(dict(dimension=d, arm=arm, tensor_sha256=pair['selected']['state_ref']['tensor_sha256'],
                                observed_role='selected', skipped_duplicate_role='last-attempt'))
    for name in ('run_reserved.py', 'run_guardian.py', 'adopt_shared_scheduler.py', 'lazy_scheduler_adoption.py',
                 'owned_lease_watchdog.py', 'guardian-adaptation.json', 'guardian-static-review.json', 'seal_diagnostic.py'):
        retain(R / name)
    plan = dict(module.FIXED, input_sha256=inputs)
    save(R / 'diagnostic-plan.json', plan)
    manifest = dict(parent, schema='paraphrase-modality-margin-diagnostic-manifest/v1',
                    inputs=inputs, extensions=extensions, plan_sha256=sha(R / 'diagnostic-plan.json'),
                    style_manifest=str(OLD / 'evaluation-manifest.json'),
                    style_plan=str(OLD / 'evaluation-plan.json'), style_summary=str(style_summary),
                    archived_predictions=archived, duplicate_endpoints_skipped=aliases)
    save(R / 'diagnostic-manifest.json', manifest)
    print(json.dumps(dict(inputs=len(inputs), panels=4, manifest_sha256=sha(R / 'diagnostic-manifest.json'),
                          model_work_executed=False)))


if __name__ == '__main__':
    main()
