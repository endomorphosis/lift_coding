"""Execute only an independently reviewed frozen diagnostic and retain its exit."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time

R = Path(__file__).resolve().parent
REVIEW = Path('/home/barberb/lift_coding/artifacts/autoencoder-next-gap-20261006/diagnosis/independent-readiness.json')


def main():
    if (R / 'guardian-exit.json').exists():
        raise ValueError('completed guardian evidence is immutable')
    ready = json.loads(REVIEW.read_bytes())
    if ready.get('passed') is not True or ready.get('findings'):
        raise ValueError('clean independent readiness required')
    for name, expected in ready['artifacts'].items():
        path = Path(name)
        raw = path.read_bytes()
        wanted = expected if type(expected) is str else expected['sha256']
        if hashlib.sha256(raw).hexdigest() != wanted:
            raise ValueError('reviewed artifact changed: ' + name)
        if type(expected) is dict and 'bytes' in expected and len(raw) != expected['bytes']:
            raise ValueError('reviewed artifact size changed: ' + name)
    start = time.monotonic()
    with (R / 'guardian.log').open('x') as stream:
        result = subprocess.run([sys.executable, str(R / 'run_reserved.py'),
            '--phase', 'diagnostic', '--attempt', 'diagnostic-r1'], stdout=stream, stderr=subprocess.STDOUT)
    receipt = dict(returncode=result.returncode, wrapper_elapsed_seconds=time.monotonic() - start)
    with (R / 'guardian-exit.json').open('x') as stream:
        json.dump(receipt, stream, indent=2)
        stream.write('\n')
    print(json.dumps(receipt), flush=True)
    raise SystemExit(result.returncode)


if __name__ == '__main__':
    main()
