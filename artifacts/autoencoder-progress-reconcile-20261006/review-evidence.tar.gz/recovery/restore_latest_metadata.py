"""Restore only exact published a3f metadata corrections; preserve preimages."""
from pathlib import Path
import hashlib,json,os,subprocess
R=Path(__file__).resolve().parents[1];W=R.parents[1];P=W/'external/ipfs_datasets'
base='795d960170214d03e2eaf4c0a13ad4eb922c5c08';target='a3f16f2870a80a7e985b35bed3334512c47d9dc3'
def git(*a):return subprocess.check_output(['git','-C',str(P),*a],stderr=subprocess.PIPE)
def sha(b):return hashlib.sha256(b).hexdigest()
def state():
 i=Path(git('rev-parse','--git-path','index').decode().strip());i=i if i.is_absolute() else P/i
 return {'head':git('rev-parse','HEAD').decode().strip(),'index_sha256':sha(i.read_bytes())}
paths=git('diff','--name-only',base,target).decode().splitlines();assert len(paths)==13
staged=[]
for rel in paths:
 p=P/rel;assert not p.is_symlink()
 for parent in p.parents:
  if parent==P:break
  assert not parent.is_symlink()
 tree=git('--literal-pathspecs','ls-tree','-z',base,'--',rel)
 old=git('show',base+':'+rel) if tree else None
 new=git('show',target+':'+rel)
 assert (p.read_bytes() if p.exists() else None)==old,'exact published preimage required: '+rel
 staged.append((rel,old,new))
before=state();rows=[]
for rel,old,new in staged:
 p=P/rel
 if old is not None:
  pre=R/'recovery/latest-metadata-preimages'/rel;pre.parent.mkdir(parents=True,exist_ok=True)
  with pre.open('xb') as f:f.write(old)
  assert p.read_bytes()==old
  # Existing authenticated main files only; atomic same-directory replacement.
  tmp=p.with_name(p.name+'.reconcile-a3f.tmp')
  with tmp.open('xb') as f:f.write(new);f.flush();os.fsync(f.fileno())
  os.chmod(tmp,p.stat().st_mode&0o777);assert p.read_bytes()==old
  os.replace(tmp,p)
 else:
  p.parent.mkdir(parents=True,exist_ok=True)
  with p.open('xb') as f:f.write(new);f.flush();os.fsync(f.fileno())
 assert p.read_bytes()==new
 rows.append({'path':rel,'previous_sha256':None if old is None else sha(old),'sha256':sha(new),'bytes':len(new),'action':'updated_exact_published_preimage' if old is not None else 'created_absent'})
assert state()==before
report={'schema':'published-contextual-metadata-restoration/v1','source_revision':base,'target_revision':target,'existing_updated':4,'created_absent':9,'paths':rows,'normal_before':before,'normal_after':state(),'normal_state_preserved':True,'numerical_or_authority_behavior_changed':False,'model_executed':False,'qualification_granted':False,'training_executed':False}
with (R/'recovery/latest-metadata-restoration.json').open('x') as f:json.dump(report,f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps({'updated':4,'created':9,'state_preserved':True}))
