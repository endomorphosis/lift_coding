#!/usr/bin/env python3
"""Build a private observation proposal from immutable existing driver bytes.

This script hashes inputs and parses completed metadata only. It imports no
model, training, Torch, encoder, database or resource owner and launches no run.
"""
import ast
import difflib
import hashlib
import json
from pathlib import Path

R = Path(__file__).resolve().parent
P = Path('/home/barberb/lift_coding/external/ipfs_datasets')
E = P/'workspace/test-logs/decoder-normative-wording-r2-20261006'
B = P/'workspace/test-logs/decoder-paraphrase-modality-styles-20261004'
D = P/'workspace/test-logs/decoder-paraphrase-modality-margins-r2-20261006'
DRIVER = 'scripts/ops/autoencoder/evaluate_normative_wording_development.py'
PRIVATE = 'scripts/ops/autoencoder/evaluate_normative_wording_retention.py'


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda:f.read(1048576),b''):h.update(chunk)
    return h.hexdigest()


def read(path):return json.loads(Path(path).read_bytes())


def save(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x') as f:json.dump(value,f,sort_keys=True,indent=2);f.write('\n')


def replace_once(source,old,new):
    if source.count(old)!=1:raise ValueError('adaptation anchor must occur once: '+old[:90])
    return source.replace(old,new,1)


def replace_function(source,name,replacement):
    node=next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name==name)
    lines=source.splitlines(keepends=True)
    return ''.join(lines[:node.lineno-1])+replacement+'\n\n'+''.join(lines[node.end_lineno:])


LOAD_REFERENCES='''def load_references(manifest, records, runs, lanes, codec, digest):
    verify_predictions(records, runs, lanes, digest)
    verify_zero_archives(manifest, records, lanes, digest)
    refs = bound(manifest, manifest['references'])
    receipt = bound(manifest, manifest['holdout_receipt'])
    source = [{k:r[k] for k in ('id','source_text')} for r in lanes[384]['fresh_rows']]
    require(source == [{k:r[k] for k in ('id','source_text')} for r in lanes[768]['fresh_rows']],
        'exposed-v3 source ordering differs by width')
    require(type(refs) is list and len(refs) == 48 and len(codec['target_vocabulary']) == 32
        and receipt.get('complete') is True and receipt.get('schema') == 'authored-modality-holdout/v3'
        and receipt.get('receipt_sha256') == digest({k:v for k,v in receipt.items() if k != 'receipt_sha256'})
        and receipt.get('references_sha256') == digest(refs) and receipt.get('source_rows_sha256') == digest(source)
        and receipt.get('codec_sha256') == digest(codec)
        and receipt.get('sealed_comparison_sha256') == FIXED['comparison_seal'],
        'authenticated unchanged exposed-v3 references required')
    for ref,row in zip(refs,source):
        ids=ref['target_ids']
        require(ref['id']==row['id'] and ref['source_text']==row['source_text']
            and ref['source_sha256']==hashlib.sha256(row['source_text'].encode()).hexdigest()
            and ref['target_sha256']==digest(ref['target']) and ref['codec_sha256']==digest(codec)
            and type(ids) is list and 3<=len(ids)<=512 and ids[0]==1 and ids[-1]==2
            and all(type(t) is int and 3<=t<32 for t in ids[1:-1])
            and json.loads(''.join(codec['target_vocabulary'][t] for t in ids[1:-1]))==ref['target'],
            'complete unchanged exposed-v3 source/target binding required')
    require(sum(len(ref['target']['rules']) for ref in refs)==180,
        'unchanged180-rule exposed-v3 denominator required')
    return refs,receipt
'''

ZERO_ARCHIVES='''def verify_zero_archives(manifest,records,lanes,digest):
    """Only the two numerically identical M2 zero controls have old outputs."""
    keys=('id','token_ids','generation_status','eos_reached')
    zero=[r for r in records if r['arm']=='normative-wording-zero']
    require(len(zero)==2 and {r['dimension'] for r in zero}=={384,768},
        'two distinct zero controls required')
    for record in zero:
        d=record['dimension']; lane=lanes[d]
        oldref=manifest['archived_zero_predictions'][str(d)]
        old=bound(manifest,oldref['path'])
        require(sha(oldref['path'])==oldref['sha256'] and
            Path(oldref['path']).stat().st_size==oldref['bytes'] and
            old.get('complete') is True and
            old.get('model_tensor_sha256')==record['state_ref']['tensor_sha256'] and
            old.get('source_rows_sha256')==digest(lane['fresh_rows']) and
            old.get('source_contexts_sha256')==digest(lane['fresh_contexts']) and
            old.get('generation_reference_access') is False and
            old.get('generation_temperature')==0 and old.get('max_target_tokens')==512,
            'old zero archived source/tensor/generation bindings differ')
        ref=record['predictions_ref']; require(sha(ref['path'])==ref['sha256'],'new zero prediction changed')
        new=json.loads(Path(ref['path']).read_bytes())
        require([{k:r[k] for k in keys} for r in new['predictions']]==
            [{k:r[k] for k in keys} for r in old['predictions']],
            'new zero differs from exact archived M2 output')
'''

JOIN='''def join_source_heads_and_formula(scalar_score,fidelity,references):
    """Keep all180 authored rule slots and unvisited sites in denominators."""
    fields=('actor','action','modality','object')
    require(scalar_score.get('complete') is True and len(references)==48
        and len(fidelity['rows'])==48,'complete48-row paired evidence required')
    require([r['id'] for r in references]==[r['id'] for r in fidelity['rows']],
        'head/formula reference ordering differs')
    wanted={(ref['id'],slot,field) for ref in references
        for slot in range(len(ref['target']['rules'])) for field in fields}
    require(len(wanted)==720 and len({r['id'] for r in references})==48,
        'exact180-rule720-scalar denominator required')
    events={}
    for event in scalar_score['events']:
        key=(event['id'],event['slot'],event['field'])
        require(key in wanted and key not in events,'duplicate or foreign scalar event')
        events[key]=event
    unvisited={(r['id'],r['slot'],r['field']) for r in scalar_score['unvisited_reference_sites']}
    unavailable={(r['id'],r['slot'],r['field']) for r in scalar_score['unscored_sites']
        if (r['id'],r['slot'],r['field']) in wanted}
    extra_unavailable=[r for r in scalar_score['unscored_sites']
        if (r['id'],r['slot'],r['field']) not in wanted]
    # The observer also labels unavailable reference slots unvisited because
    # only scored events enter its visited set. Keep one denominator category.
    require(len(unvisited)==len(scalar_score['unvisited_reference_sites']) and unavailable<=unvisited,
        'original unvisited reference accounting differs')
    unvisited-=unavailable
    require(
        len(unavailable)+len(extra_unavailable)==len(scalar_score['unscored_sites']) and
        not(set(events)&unvisited) and not(set(events)&unavailable) and
        not(unvisited&unavailable) and set(events)|unvisited|unavailable==wanted,
        'every scalar site must be scored, unavailable or unvisited exactly once')
    counts={field:dict(reference_sites=180,visited=0,unvisited=0,unavailable=0,
        source_correct=0,source_incorrect=0,source_correct_formula_wrong=0,
        source_wrong_formula_correct=0) for field in fields}
    rows=[]
    for reference,formula in zip(references,fidelity['rows']):
        generated=formula.get('generated_ir')
        generated_rules=generated.get('rules',[]) if isinstance(generated,dict) else []
        for slot,target in enumerate(reference['target']['rules']):
            produced=generated_rules[slot] if slot<len(generated_rules) else None
            joined={}
            for field in fields:
                key=(reference['id'],slot,field);event=events.get(key);bucket=counts[field]
                formula_correct=isinstance(produced,dict) and produced.get(field)==target[field]
                if event is None:
                    status='unvisited' if key in unvisited else 'unavailable'
                    bucket[status]+=1
                    joined[field]=dict(status=status,source_correct=None,formula_field_correct=formula_correct)
                else:
                    correct=event['source']['argmax_token_id']==event['target_token_id']
                    bucket['visited']+=1;bucket['source_correct' if correct else 'source_incorrect']+=1
                    bucket['source_correct_formula_wrong']+=int(correct and not formula_correct)
                    bucket['source_wrong_formula_correct']+=int(not correct and formula_correct)
                    joined[field]=dict(status='visited',source_correct=correct,
                        formula_field_correct=formula_correct,target_token_id=event['target_token_id'],
                        actual_next_token_id=event['actual_next_token_id'],position=event['position'],
                        source=event['source'],recurrent=event['recurrent'],combined=event['combined'])
            rows.append(dict(id=reference['id'],slot=slot,source_sha256=reference['source_sha256'],
                expected_rule=target,generated_rule=produced,fields=joined))
    require(len(rows)==180 and all(b['visited']+b['unvisited']+b['unavailable']==180
        and b['source_correct']+b['source_incorrect']==b['visited'] for b in counts.values()),
        'fixed per-field180-site denominators differ')
    return dict(schema='normative-wording-retention-source-head-formula-join/v1',complete=True,
        rows=rows,per_field=counts,source_head_scored_only_at_visited_available_sites=True,
        unvisited_counted_correct=False,unavailable_counted_correct=False,
        extra_generated_unavailable_sites=extra_unavailable,
        reference_labels_applied_after_durable_barrier=True,**FALSE)
'''


def main():
    original=E/'experiment-source'/DRIVER
    inherited=read(E/'evaluation-manifest.json')
    if sha(original)!=inherited['extensions'][DRIVER]:raise ValueError('frozen observer driver changed')
    source=original.read_text()
    source=replace_once(source,"ROLES = ('selected', 'last-attempt')","ROLES = ('selected',)")
    source=source.replace('normative-wording-development-plan/v1','normative-wording-retention-plan/v1')
    source=source.replace('panel_count=8, samples_per_panel=60','panel_count=4, samples_per_panel=48')
    source=source.replace('prospective_authored_wordings_of_previously_exposed_validation_rules',
        'previously_exposed_authored_modality_holdout_v3')
    source=replace_once(source,"original_meanings_previously_exposed=True, postfit_observation_only=True,",
        "original_meanings_previously_exposed=True, postfit_observation_only=True, previously_exposed=True,\n    comparison_seal='4e09fd75f40e410d1a53f7f13d01c034c1b0bcae5254a5f7f195754d7db16eac',")
    source=source.replace("len(records) == 8", "len(records) == 4")
    source=source.replace("all eight durable endpoint", "all four durable selected endpoint")
    source=source.replace("trace.get('sample_count') == 60", "trace.get('sample_count') == 48")
    source=source.replace("len(panel.get('predictions',[])) == 60", "len(panel.get('predictions',[])) == 48")
    source=replace_function(source,'load_references',LOAD_REFERENCES+'\n'+ZERO_ARCHIVES)
    source=replace_function(source,'scoring_references',"def scoring_references(references,receipt):\n    return deepcopy(references)\n")
    source=replace_function(source,'join_source_heads_and_formula',JOIN)
    source=source.replace("for k in ('references','development_receipt')", "for k in ('references','holdout_receipt')")
    source=source.replace("data['schema'] == 'prospective-wording-source-inputs/v1'",
        "data['schema'] == 'fresh-scalar-source-inputs-single/v1'")
    old="""require(len(rows) == 60 and all(set(r) == {'id','source_text','input'} for r in rows)
            and all(len(r['source_text'].split('\\n\\n')) == 1 for r in rows)
            and len(data['clause_cache']) == 60 and all(set(r) == {'id','source_text','input'}
                for r in data['clause_cache']), 'closed60 single-clause development rows required')"""
    new="""require(len(rows) == 48 and all(set(r) == {'id','source_text','input'} for r in rows)
            and len({r['id'] for r in rows}) == 48
            and all(set(r) == {'id','source_text','input'} for r in data['clause_cache']),
            'closed48-source exposed-v3 rows and clause cache required')"""
    source=replace_once(source,old,new)
    source=replace_once(source,"runs[dimension,run['arm']] = run", """require(run['states']['selected'] == manifest['selected_states'][f'{dimension}-{run["arm"]}'],
                'exact newly sealed selected state required')
            runs[dimension,run['arm']] = run""")
    source=source.replace('normative-wording-development-results/v1','normative-wording-retention-results/v1')
    source=source.replace('development_receipt_sha256=digest(receipt)',
        'exposed_v3_receipt_sha256=digest(receipt), archived_zero_generation_parity_verified=True')
    source=source.replace("grouping_metadata_added_after_reference_barrier=True", "original_v3_grouping_metadata_preserved=True")
    source=source.replace("normative-wording-source-predictions/v1", "normative-wording-retention-source-predictions/v1")
    source=replace_once(source,source[source.index('"""'):source.index('"""',source.index('"""')+3)+3],
        '"""Private postfit retention observation of four NEW normative selected states on exposed-v3 cached48sources.\nAdapted from the exact frozen normative observer; numerical owners unchanged.\nNo training, encoder, downloads, solver, Lake, promotion or fresh holdout.\nAll four traces/predictions are durable before v3 reference parsing.\n"""')
    ast.parse(source)
    target=R/'experiment-source'/PRIVATE;target.parent.mkdir(parents=True,exist_ok=True)
    target.write_text(source)
    (R/'runner-adaptation.diff').write_text(''.join(difflib.unified_diff(original.read_text().splitlines(True),
        source.splitlines(True),fromfile=str(original),tofile=str(target))))
    # Obtain literal FIXED without importing any producer or Torch.
    tree=ast.parse(source);namespace={}
    for node in tree.body:
        if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id in
            {'OBSERVER_SHA256','ARMS','ROLES','FALSE','FIXED'} for t in node.targets):
            exec(compile(ast.Module(body=[node],type_ignores=[]),str(target),'exec'),namespace)
    fixed=namespace['FIXED']
    inputs=dict(inherited['inputs'])
    def retain(path,wanted=None):
        path=Path(path).resolve();actual=sha(path)
        if wanted is not None and actual!=wanted:raise ValueError('changed source/input: '+str(path))
        if str(path) in inputs and inputs[str(path)]!=actual:raise ValueError('conflicting inherited input')
        inputs[str(path)]=actual
    # Revalidate only existing immutable closures; never replace their files.
    for path,wanted in list(inputs.items()):retain(path,wanted)
    for rel,wanted in inherited['extensions'].items():retain(E/'experiment-source'/rel,wanted)
    for path in [E/'training-manifest.json',E/'training-plan.json',E/'evaluation-manifest.json',
        B/'evaluation-manifest.json',B/'evaluation-plan.json',B/'evaluation-r1/results/summary.json',
        D/'experiment-source/scripts/ops/autoencoder/diagnose_paraphrase_modality_margins.py',original,
        Path(__file__)]:retain(path)
    old=read(B/'evaluation-manifest.json');oldsummary=read(B/'evaluation-r1/results/summary.json')
    for path in list(old['source_inputs'].values())+[old['references'],old['holdout_receipt']]:
        retain(path,old['inputs'][str(Path(path).resolve())])
    archived={};selected={};aliases=[]
    for width,summarypath in inherited['training_summaries'].items():
        summary=read(summarypath)
        for item in summary['runs']:
            run=read(item['summary_path']);ref=run['states']['selected'];retain(ref['path'],ref['sha256'])
            selected[f'{width}-{run["arm"]}']=ref
            if ref['tensor_sha256']!=run['states']['last-attempt']['tensor_sha256']:
                raise ValueError('expected selected/last endpoint alias absent')
            aliases.append({'dimension':int(width),'arm':run['arm'],'selected_tensor_sha256':ref['tensor_sha256'],
                'last_attempt_not_run':True})
            if run['arm']=='normative-wording-zero':
                panel=next(p for p in oldsummary['panels'] if p['dimension']==int(width)
                    and p['arm']=='paraphrase-modality-zero' and p['role']=='selected')
                if panel['state_ref']['tensor_sha256']!=ref['tensor_sha256']:
                    raise ValueError('new zero is not exact M2 tensor')
                archived[width]=panel['predictions_ref']
                retain(archived[width]['path'],archived[width]['sha256'])
                retain(panel['state_ref']['path'],panel['state_ref']['sha256'])
    if len(selected)!=4 or len({r['tensor_sha256'] for r in selected.values()})!=4:
        raise ValueError('four distinct selected states required')
    manifest={k:inherited[k] for k in ['training_extension_root','training_manifest','training_plan',
        'training_summaries','training_terminals']}
    manifest.update(schema='normative-wording-retention-manifest/v1',inputs=inputs,
        extensions={PRIVATE:sha(target)},source_inputs=old['source_inputs'],references=old['references'],
        holdout_receipt=old['holdout_receipt'],selected_states=selected,archived_zero_predictions=archived,
        endpoint_aliases=aliases,original_observer_pin={'path':str(original),'sha256':sha(original)},
        source_tree_switch_performed=False,model_execution=False,reference_json_parsed_by_sealer=False)
    plan=dict(fixed,input_sha256=inputs)
    save(R/'retention-plan.json',plan)
    manifest['plan_sha256']=sha(R/'retention-plan.json')
    save(R/'retention-manifest.json',manifest)
    save(R/'proposal-preflight.json',dict(schema='normative-wording-retention-proposal-preflight/v1',passed=True,
        input_count=len(inputs),models_loaded=False,model_execution=False,encoders_executed=False,
        training_executed=False,reference_json_parsed=False,numerical_owner_sources_modified=False,
        four_distinct_selected_tensors=True,two_exact_archived_M2_zero_tensor_joins=True,
        artifacts={str(p):sha(p) for p in [target,R/'retention-plan.json',R/'retention-manifest.json',
            R/'runner-adaptation.diff',Path(__file__)]},execution_readiness_granted=False,
        independent_runner_and_guardian_review_required=True))
    print(json.dumps({'inputs':len(inputs),'panels':4,'proposal_only':True,'models_executed':False}))


if __name__=='__main__':main()
