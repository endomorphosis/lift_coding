# Exposed-v3 retention proposal for the new normative decoder endpoints

This private proposal observes the four **new** selected endpoints from
`decoder-normative-wording-r2-20261006` on the existing exposed-v3 source panel.
It measures retention before further fitting. No numerical run, encoder,
optimizer, download, native validator, prover, Lake build or promotion has
executed while preparing this proposal.

`retention-manifest.json` binds 1,297 existing inputs, the four exact selected
state files, the old native source caches and archived M2 zero predictions.
`proposal-preflight.json` records successful hashing and metadata joins. It
grants no execution readiness. `pure-contracts.xml` records 36 passing pure
tests. An independent review of the runner, closure, resource wrapper and these
receipts is required before numerical execution.

## Fixed source and numerical owners

The source owner is the existing
`decoder-paraphrase-modality-styles-20261004/evaluation-manifest.json`: native
384D/768D source-only caches from
`decoder-fresh-normative-style-r2-20261004/preparation-r1/results/`, with 48
paragraphs and 180 authored rules per panel. The v3 comparison seal remains
`4e09fd75f40e410d1a53f7f13d01c034c1b0bcae5254a5f7f195754d7db16eac`.
Reference JSON and the original receipt are separate files; preparing this
proposal hashes their bytes without parsing their bodies. This cohort has
already been repeatedly inspected and is **exposed development**, with no
fresh-holdout claim.

The numerical context, donor, codec, TRAIN transforms, restoration and fidelity
scorer come from the authenticated frozen normative E training closure. The
private runner calls its unchanged `load_context` and `restore_endpoint`.
`generated_scalar_observation.py` remains pinned to
`1f1d35f7fd90df0396f3222676f2ffd11f17e2b1b2c79c0a79f1600488eb08d8`.
Resident boundary/field/core identities must agree; source inventory is checked
before and after observation. No package path, numerical source, canonical
tree, model asset or frozen predecessor file is rewritten. Inherited setup
reads older metadata, so the reference barrier applies specifically to these
persisted v3 observations.

| Width | New normative arm | Selected tensor SHA256 |
| --- | --- | --- |
| 384 | zero | `e918a196684aa2f7d4021c210908eaba2517542e14523d98c4f72419c23ae3b3` |
| 384 | 0.05 auxiliary | `0b3c7c3b1a5581cd393d9bb8db1d24b87fe2cb9dff0be268aa2b5ed1f88b6594` |
| 768 | zero | `991f9a1abdf01b72ac5f827adde5ef7be5af28fc0dc3a3db8e4e6e2d8816f379` |
| 768 | 0.05 auxiliary | `3fe21b42657bf33f5d0d129d538b72dbb5808f9cc491a3822abd902b13a74b6d` |

Selected/last-attempt tensors are aliases within each arm; only selected runs.
The new zero tensor hashes equal the original M2 zero hashes, while their
serialized checkpoint hashes differ because of run metadata. Their full token,
termination and EOS outputs must exactly match the archived M2 zero v3 reports
(historical exact counts 20/48 and 46/48). New positive tensors have no old v3
predictions; imposing old-positive parity would test the wrong checkpoints.

## Observation, barrier and measurements

The runner executes one unchanged greedy generation for each of four distinct
tensors. A same-pass hook retains all 32 source, recurrent and combined logits
at actually visited scalar sites, with no second greedy pass, model copy,
reference prefix, grammar mask or forced closure. Each trace and prediction
file is fsynced, and all four source/checkpoint/codec/context identities plus
the two archived zero outputs are checked before the v3 references are parsed.

Posthoc scoring then uses the original v3 references and grouping metadata,
the unchanged full-vocabulary teacher-forced CE owner, full ordered formula
fidelity, syntax/EOS and all seven facets, including complete qualifier fields.
The scalar score reports source/recurrent/combined distributions separately.
Its new explicit head/formula join preserves all 180 rule slots and 720 scalar
reference sites per panel, with 180 sites per scalar field. Unvisited and
unavailable sites retain null source correctness; extra generated sites remain
recorded. Teacher-forced posthoc scoring performs its own required forwards
after the barrier; these are distinct from the single same-pass greedy trace.
The output reports all counts, CE, changes, failures and timing scopes without
selecting or promoting a model.

Temperature is 0, encoder context and decoder output ceiling are 512, vocabulary
size is 32, batch is 8, CPU workers are 1, CUDA is disabled, bridge names are
empty, provers and metric disk cache are disabled. Trace memory ceiling is
128 MiB, each combined generation/scoring panel has a 30-second cooperative
budget, and the numerical driver has a 600-second cooperative deadline.
Resource accounting and an owned lease watchdog remain required outside it.

## Cost and execution handoff

The earlier four-panel R2 diagnostic took 25.252 seconds for its driver and
67.006 seconds including its guardian; its retained output was 9.69 MB. New
full formula/teacher-forced scoring adds work. Estimate 25–40 seconds for this
driver and 60–120 seconds including hash checks/admission, with host sharing
uncontrolled. These estimates are planning bounds, not measured speedups.
Start from the existing 100,000,000-byte, 1,536-MiB, one-CPU/one-child reservation
and 900-second outer deadline. Adjust only from independently reviewed actual
memory evidence; the 128-MiB trace estimate excludes model/Python/import RSS.

The parent can adapt the reviewed R2 `run_reserved.py` and watchdog/adoption
owners inside this private directory. The wrapper must use a fresh attempt,
`retention-plan.json`/`retention-manifest.json`, this private runner, phase
`evaluation`, the original frozen dependency root, and its own independently
passed readiness receipt. Include only this owned directory in the existing
resource owner's authorized roots for new output. Preserve all foreign
leases, scheduler configuration and completed attempts. A direct unguarded
runner launch is not the proposed execution path.

`runner-adaptation.diff` is the reviewable difference from the frozen normative
observer. It changes the observed cohort, selected endpoint count, v3 reference
contract, archived-zero check and multirule head/formula join. It rewrites no
training owner or objective. If any bound input changed, retain the failed
preflight and investigate the change; do not silently reseal to another tree.

No observed result will supply fresh semantic holdout, teacher, native-profile,
production runtime, family qualification or proof authority. Source-tree pins,
family-specific semantic checks and the applicable actual `lake build <Lib>`
policy remain binding. The Constitution remains unformalized.
