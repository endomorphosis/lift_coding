"""Pure proposed runner contracts; no Torch, numerical owner or model import."""
from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

import pytest

R=Path(__file__).resolve().parent
SCRIPT=R/'experiment-source/scripts/ops/autoencoder/evaluate_normative_wording_retention.py'
spec=importlib.util.spec_from_file_location('_pure_retention_contracts',SCRIPT)
owner=importlib.util.module_from_spec(spec);spec.loader.exec_module(owner)


def digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),
        ensure_ascii=False,allow_nan=False).encode()).hexdigest()


def save(path,value):
    path.write_text(json.dumps(value))
    return dict(path=str(path),sha256=owner.sha(path),bytes=path.stat().st_size)


def fixture(tmp_path):
    rows=[dict(id=f'source:{i}',source_text=f'Source {i}.',input=[float(i)]) for i in range(48)]
    codec=dict(target_vocabulary=['pad','bos','eos']+[f'token:{i}' for i in range(29)])
    lanes={d:dict(fresh_rows=deepcopy(rows),fresh_contexts={},
        donor=dict(codec=codec,input_transform={'width':d})) for d in (384,768)}
    runs={};records=[];manifest=dict(inputs={},archived_zero_predictions={})
    for d in (384,768):
        for arm in owner.ARMS:
            state=dict(tensor_sha256=digest([d,arm]));runs[d,arm]=dict(states={'selected':state})
            trace=dict(schema='generated-contextual-scalar-trace/v1',complete=True,
                predictions=[dict(id=r['id'],token_ids=[3,4],generation_status='eos',eos_reached=True) for r in rows],
                model_tensor_sha256=state['tensor_sha256'],dimension=d,source_rows_sha256=digest(rows),
                source_contexts_sha256=digest({}),codec_sha256=digest(codec),
                input_transform_sha256=digest(lanes[d]['donor']['input_transform']),sample_count=48,
                batch_size=8,vocabulary_size=32,max_target_tokens=512,generation_temperature=0,
                elapsed_seconds=.01,source_only=True,full_vocabulary_retained=True,decomposition_exact=True,
                caller_state_preserved=True,hooks_removed=True,complete_rollout_before_reference_scoring=True,
                reference_count_access=False,reference_prefix_access=False,reference_documents_passed_to_model=False,
                inventory_access=False,source_context_target_access=False,syntax_mask=False,forced_closure=False,
                model_copied=False,extra_model_passes=0,source_head_extra_evaluations=0,optimizer_steps=0,
                **{flag:False for flag in owner.TRACE_FALSE_FLAGS})
            trace['trace_sha256']=digest(trace)
            tr=save(tmp_path/f'{d}-{arm}-trace.json',trace)
            prediction=owner.prediction_from_trace(trace)
            pr=save(tmp_path/f'{d}-{arm}-prediction.json',prediction)
            records.append(dict(dimension=d,arm=arm,role='selected',state_ref=state,
                predictions_ref=pr,prediction_fsynced=True,source_head_trace_ref=tr,source_head_trace_fsynced=True))
            if arm=='normative-wording-zero':
                old=save(tmp_path/f'{d}-old-zero.json',prediction)
                manifest['inputs'][old['path']]=old['sha256'];manifest['archived_zero_predictions'][str(d)]=old
    return manifest,records,runs,lanes,codec


def joined_fixture():
    references=[];fidelity=[];events=[]
    for i in range(48):
        count=(1,2,4,8)[i//12];rules=[]
        for slot in range(count):
            rule=dict(actor=f'actor:{i}',action='act',modality='O',object='object',conditions=[],exceptions=[],temporal=[])
            rules.append(rule)
            for field in ('actor','action','modality','object'):
                events.append(dict(id=f'source:{i}',slot=slot,field=field,target_token_id=3,actual_next_token_id=3,
                    position=0,source=dict(argmax_token_id=3),recurrent={},combined={}))
        target=dict(rules=rules)
        references.append(dict(id=f'source:{i}',source_sha256=digest(i),target=target))
        fidelity.append(dict(id=f'source:{i}',generated_ir=deepcopy(target)))
    score=dict(complete=True,events=events,unscored_sites=[],unvisited_reference_sites=[])
    return score,dict(rows=fidelity),references


def test_cold_import_blocks_all_numerical_packages():
    code="""import builtins,importlib.util,sys
previous=builtins.__import__
def guarded(name,*a,**k):
 if name=='torch' or name.startswith('ipfs_datasets_py'):raise RuntimeError(name)
 return previous(name,*a,**k)
builtins.__import__=guarded
spec=importlib.util.spec_from_file_location('_cold',sys.argv[1]);m=importlib.util.module_from_spec(spec)
spec.loader.exec_module(m);m.validate_plan(m.FIXED)
assert m.FIXED['panel_count']==4 and m.FIXED['samples_per_panel']==48
"""
    r=subprocess.run([sys.executable,'-B','-c',code,str(SCRIPT)],capture_output=True,text=True)
    assert r.returncode==0,r.stderr


@pytest.mark.parametrize('key,value',[('workers',2),('temperature',False),('temperature',1),
    ('context_tokens',8192),('output_tokens',1024),('panel_count',8),('samples_per_panel',60),
    ('roles',['last-attempt']),('fresh_holdout',True),('admitted',True),('lake_executed',True),
    ('training_executed',True),('encoder_executed',True),('bridge_names',['legal']),
    ('legal_ir_evaluate_provers',True),('metric_disk_cache_used',True)])
def test_fixed_recipe_limits(key,value):
    plan=deepcopy(owner.FIXED);plan[key]=value
    with pytest.raises(ValueError):owner.validate_plan(plan)


def test_complete_four_panel_barrier_and_two_zero_parity(tmp_path):
    manifest,records,runs,lanes,codec=fixture(tmp_path)
    owner.verify_predictions(records,runs,lanes,digest)
    owner.verify_zero_archives(manifest,records,lanes,digest)


@pytest.mark.parametrize('change',['missing','duplicate','alias_role','wrong_state','changed_trace','changed_prediction','not_fsynced'])
def test_reference_barrier_rejects_before_labels(tmp_path,monkeypatch,change):
    manifest,records,runs,lanes,codec=fixture(tmp_path)
    if change=='missing':records.pop()
    if change=='duplicate':records[-1]=records[0]
    if change=='alias_role':records[-1]['role']='last-attempt'
    if change=='wrong_state':records[0]['state_ref']={'tensor_sha256':'wrong'}
    if change=='changed_trace':Path(records[0]['source_head_trace_ref']['path']).write_text('{}')
    if change=='changed_prediction':Path(records[0]['predictions_ref']['path']).write_text('{}')
    if change=='not_fsynced':records[0]['prediction_fsynced']=False
    parsed=[]
    monkeypatch.setattr(owner,'bound',lambda *a:parsed.append(a))
    with pytest.raises(ValueError):owner.load_references(manifest,records,runs,lanes,codec,digest)
    assert parsed==[]


@pytest.mark.parametrize('key,value',[('model_tensor_sha256','wrong'),('generation_reference_access',True),
    ('generation_temperature',1),('max_target_tokens',1024)])
def test_archived_zero_identity_refuses_substitution(tmp_path,key,value):
    manifest,records,runs,lanes,codec=fixture(tmp_path)
    ref=manifest['archived_zero_predictions']['384'];old=json.loads(Path(ref['path']).read_text());old[key]=value
    ref=save(Path(ref['path']),old);manifest['archived_zero_predictions']['384']=ref
    manifest['inputs'][ref['path']]=ref['sha256']
    with pytest.raises(ValueError):owner.verify_zero_archives(manifest,records,lanes,digest)


def test_archived_zero_tokens_must_match(tmp_path):
    manifest,records,runs,lanes,codec=fixture(tmp_path)
    ref=manifest['archived_zero_predictions']['384'];old=json.loads(Path(ref['path']).read_text())
    old['predictions'][0]['token_ids']=[4,3];ref=save(Path(ref['path']),old)
    manifest['archived_zero_predictions']['384']=ref;manifest['inputs'][ref['path']]=ref['sha256']
    with pytest.raises(ValueError,match='exact archived M2'):owner.verify_zero_archives(manifest,records,lanes,digest)


def test_all180_rule_slots_and720_sites_retained():
    score,fidelity,refs=joined_fixture();joined=owner.join_source_heads_and_formula(score,fidelity,refs)
    assert len(joined['rows'])==180
    assert all(v['reference_sites']==180 and v['source_correct']==180 for v in joined['per_field'].values())


@pytest.mark.parametrize('kind',['unvisited','unavailable','extra_generated'])
def test_missing_and_extra_sites_keep_denominators(kind):
    score,fidelity,refs=joined_fixture()
    if kind=='extra_generated':score['unscored_sites']=[dict(id='source:0',slot=8,field='actor',reason='source_slot_unavailable')]
    else:
        event=score['events'].pop(0);row={k:event[k] for k in ('id','slot','field')}
        score['unvisited_reference_sites']=[row]
        if kind=='unavailable':score['unscored_sites']=[row]
    joined=owner.join_source_heads_and_formula(score,fidelity,refs)
    actor=joined['per_field']['actor']
    assert actor['reference_sites']==180
    if kind=='extra_generated':assert actor['source_correct']==180 and len(joined['extra_generated_unavailable_sites'])==1
    else:assert actor['source_correct']==179 and actor[kind]==1


def test_duplicate_or_foreign_scalar_events_refused():
    score,fidelity,refs=joined_fixture();score['events'].append(deepcopy(score['events'][0]))
    with pytest.raises(ValueError):owner.join_source_heads_and_formula(score,fidelity,refs)


def test_wrong_formula_field_is_joined_without_hiding_head_correctness():
    score,fidelity,refs=joined_fixture();fidelity['rows'][0]['generated_ir']['rules'][0]['modality']='P'
    joined=owner.join_source_heads_and_formula(score,fidelity,refs)
    assert joined['per_field']['modality']['source_correct']==180
    assert joined['per_field']['modality']['source_correct_formula_wrong']==1
