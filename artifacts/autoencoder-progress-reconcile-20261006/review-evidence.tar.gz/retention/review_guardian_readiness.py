"""Review the retention guardian and frozen file hashes without numerical imports."""
from __future__ import annotations
import ast
from datetime import datetime, timezone
import difflib
import hashlib
import json
import os
from pathlib import Path
import stat
import time
import xml.etree.ElementTree as ET

WORKSPACE=Path('/home/barberb/lift_coding')
REPO=WORKSPACE/'external/ipfs_datasets'
ARTIFACTS=WORKSPACE/'artifacts/autoencoder-progress-reconcile-20261006/retention'
RUN=REPO/'workspace/test-logs/decoder-normative-wording-retention-20261006'
PREVIOUS=REPO/'workspace/test-logs/decoder-normative-wording-r2-20261006'
SOURCE=REPO/'workspace/test-logs/ui-modal-coverage-20261002/validation-source-r2'
OWNER=REPO/'workspace/test-logs/native4096-four-width-20261004/resource-cap/autoencoder_daemon_resources.py'
OWNER_SHA='b00d2752ba852fe73760bba4fbd51b0e845742c3527642606a2a77ed9f8f5e2c'
SCHEDULER=SOURCE/'ipfs_datasets_py/optimizers/logic_theorem_optimizer/resource_scheduler.py'
SCHEDULER_SHA='a418e84f70ed8509ba0518feea69e7a8c27865139f83b6c81349eefdfd5893a4'

def identity(info):
    return (info.st_dev,info.st_ino,info.st_mode,info.st_nlink,info.st_size,
            info.st_mtime_ns,info.st_ctime_ns)

def hashed(path):
    path=Path(path)
    before=os.stat(path,follow_symlinks=False)
    if not stat.S_ISREG(before.st_mode):raise ValueError('expected regular reviewed file: '+str(path))
    descriptor=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC|os.O_NONBLOCK)
    try:
        expected=identity(before);digest=hashlib.sha256();count=0
        if identity(os.fstat(descriptor))!=expected:raise ValueError('reviewed file changed before open')
        while True:
            block=os.read(descriptor,min(1048576,before.st_size-count+1))
            if not block:break
            count+=len(block)
            if count>before.st_size:raise ValueError('reviewed file grew')
            digest.update(block)
        if (count!=before.st_size or identity(os.fstat(descriptor))!=expected
                or identity(os.stat(path,follow_symlinks=False))!=expected):
            raise ValueError('reviewed file metadata changed')
        return dict(path=str(path),bytes=count,sha256=digest.hexdigest())
    finally:os.close(descriptor)

def raw(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()

def main():
    started=time.monotonic();findings=[];checks=[];artifacts={}
    def check(name,condition,detail):
        checks.append(dict(id=name,passed=bool(condition),detail=detail))
        if not condition:findings.append(dict(id=name,detail=detail))
    def artifact(path):
        pin=hashed(path);artifacts[pin['path']]={k:pin[k] for k in ('bytes','sha256')};return pin
    freeze=json.loads((ARTIFACTS/'guardian-freeze.json').read_bytes())
    manifest=json.loads((ARTIFACTS/'retention-manifest.json').read_bytes())
    plan=json.loads((ARTIFACTS/'retention-plan.json').read_bytes())
    ready=json.loads((ARTIFACTS/'independent-runner-readiness.json').read_bytes())
    independent=json.loads((ARTIFACTS/'independent-input-hash-review.json').read_bytes())
    for name in ('guardian-freeze.json','retention-manifest.json','retention-plan.json',
                 'independent-runner-readiness.json','independent-input-hash-review.json',
                 'independent-runner-review.json','proposal-preflight.json','proposal-readiness-summary.json',
                 'pure-contracts.xml','independent-pure-contracts.xml','runner-adaptation.diff',
                 'test_retention_contracts.py','prepare_retention_proposal.py','README.md'):
        artifact(ARTIFACTS/name)
    check('exact-private-guardian-root',freeze['run_root']==str(RUN) and freeze['source_guardian']==str(PREVIOUS),
          'Exact owned retention directory and unchanged original E directory are explicit.')
    check('copied-plan-manifest',
          (RUN/'evaluation-plan.json').read_bytes()==(ARTIFACTS/'retention-plan.json').read_bytes()
          and (RUN/'evaluation-manifest.json').read_bytes()==(ARTIFACTS/'retention-manifest.json').read_bytes()
          and hashed(RUN/'evaluation-manifest.json')['sha256']==freeze['manifest_sha256']
          and hashed(RUN/'evaluation-plan.json')['sha256']==manifest['plan_sha256'],
          'evaluation names contain byte-identical reviewed plan/manifest copies with their original seals.')
    for filename in ('run_guardian.py','owned_lease_watchdog.py','adopt_shared_scheduler.py','lazy_scheduler_adoption.py'):
        artifact(RUN/filename);artifact(PREVIOUS/filename)
        check('unchanged-'+filename,(RUN/filename).read_bytes()==(PREVIOUS/filename).read_bytes(),
              'Original helper/wrapper source is unchanged; foreign state reset, child custody, watchdog and safe failure contracts are retained.')
    old=(PREVIOUS/'run_reserved.py').read_text();current=(RUN/'run_reserved.py').read_text()
    expected=old.replace("choices=('preparation','preflight','training','evaluation')", "choices=('evaluation',)",1)
    expected=expected.replace("return hashlib.sha256(path.read_bytes()).hexdigest()",
        "digest = hashlib.sha256()\n        with Path(path).open('rb') as stream:\n            for data in iter(lambda: stream.read(1048576), b''):\n                digest.update(data)\n        return digest.hexdigest()",1)
    expected=expected.replace("'evaluation': ('evaluate_normative_wording_development.py',100_000_000,1536,900)",
                              "'evaluation': ('evaluate_normative_wording_retention.py',100_000_000,1536,900)",1)
    check('only-declared-guardian-adaptation',expected==current,
          'Exact diff consists of evaluation-only phase, retention runner name and bounded1MiB streaming hash; resource/cleanup bodies are unchanged.')
    adaptation=''.join(difflib.unified_diff(old.splitlines(True),current.splitlines(True),
                                           fromfile=str(PREVIOUS/'run_reserved.py'),tofile=str(RUN/'run_reserved.py')))
    (ARTIFACTS/'guardian-adaptation.diff').write_text(adaptation);artifact(ARTIFACTS/'guardian-adaptation.diff')
    artifact(RUN/'run_reserved.py');artifact(PREVIOUS/'run_reserved.py')
    for name in ('run_reserved.py','run_guardian.py','owned_lease_watchdog.py','adopt_shared_scheduler.py','lazy_scheduler_adoption.py'):
        compile((RUN/name).read_bytes(),str(RUN/name),'exec')
    check('archived-resource-owner-and-scheduler',
          artifact(OWNER)['sha256']==OWNER_SHA and artifact(SCHEDULER)['sha256']==SCHEDULER_SHA,
          'Archived145GB owner b00d2752 and frozen scheduler a418e84f match; current dirty scheduler is not selected.')
    owner_ast=ast.parse(OWNER.read_bytes())
    maximum=next(ast.literal_eval(n.value) for n in owner_ast.body if isinstance(n,ast.Assign)
                 and any(isinstance(t,ast.Name) and t.id=='MAX_STORAGE_BYTES' for t in n.targets))
    check('resource-budgets',maximum==145000000000 and freeze['storage_bytes']==100000000
          and freeze['memory_mib']==1536 and freeze['cpu_slots']==1 and freeze['cap_bytes']==maximum,
          'Evaluation reserves100MB storage,1536MiB, one CPU/child,600s admission,900s outer deadline. Cap stays145GB; enforcement is owned/cooperative.')
    extensions=manifest['extensions']
    check('one-exact-retention-extension',set(extensions)=={'scripts/ops/autoencoder/evaluate_normative_wording_retention.py'},
          'Only the reviewed private retention runner is cloned; no package runtime or numerical owner is replaced.')
    for relative,wanted in extensions.items():
        source=ARTIFACTS/'experiment-source'/relative;clone=RUN/'experiment-source'/relative
        check('cloned-'+relative,artifact(source)['sha256']==wanted and artifact(clone)['sha256']==wanted,
              'Cloned runner bytes equal the reviewed extension seal.')
    check('normalized-independent-runner-review',ready.get('passed') is True and ready.get('findings')==[]
          and len(ready['checks'])==13 and all(row.get('passed') is True for row in ready['checks'])
          and ready.get('numerical_execution_readiness_granted') is False,
          'All13 normalized runner checks pass, findings are empty and numerical readiness is not granted.')
    for path,record in ready['artifacts'].items():
        actual=artifact(path);wanted=record if type(record) is str else record['sha256']
        check('runner-artifact-'+Path(path).name,actual['sha256']==wanted,
              'Normalized runner review artifact SHA remains exact: '+path)
    inputs=manifest['inputs'];rows={row['path']:row for row in independent['files']}
    check('exact-1297-source-closure',len(inputs)==1297 and len(rows)==1297
          and set(rows)==set(inputs) and plan['input_sha256']==inputs
          and all(rows[path]['expected_sha256']==wanted and rows[path]['observed_sha256']==wanted
                  and rows[path]['passed'] is True for path,wanted in inputs.items()),
          'Reviewed plan and complete independent hash receipt bind exactly the same1297 inputs.')
    closure=[];total=0
    for path,wanted in sorted(inputs.items()):
        pin=hashed(path);total+=pin['bytes'];passed=pin['sha256']==wanted and pin['bytes']==rows[path]['bytes']
        closure.append(dict(**pin,expected_sha256=wanted,passed=passed))
        if not passed:findings.append(dict(id='input-pin-drift',path=path))
    check('refreshed-complete-input-hashes',all(row['passed'] for row in closure)
          and total==independent['total_bytes'],
          'All1297 inputs independently streamed in1MiB chunks with before/after file metadata fences; reference bodies and tensor values were not parsed.')
    input_receipt=dict(schema='guardian-retention-input-hash-review/v1',input_count=len(closure),
                       total_bytes=total,files=closure,passed=all(row['passed'] for row in closure),
                       model_executed=False,model_imported=False,reference_json_parsed=False)
    (ARTIFACTS/'guardian-input-hash-review.json').write_text(json.dumps(input_receipt,indent=2)+'\n')
    artifact(ARTIFACTS/'guardian-input-hash-review.json')
    manifest_tree=hashlib.sha256(raw(inputs)).hexdigest()
    check('normalized-input-tree-binding',manifest_tree==ready['source_closure']['inputs_tree_sha256'],
          'Normalized runner review input-tree SHA matches the live copied manifest.')
    for owner in ready['source_closure']['frozen_numerical_owner_bindings']:
        check('frozen-owner-'+Path(owner['path']).name,inputs.get(owner['path'])==owner['sha256']
              and hashed(owner['path'])['sha256']==owner['sha256'],
              'Original numerical dependency is still in the exact training/input closure.')
    test_rows=[]
    for name in ('pure-contracts.xml','independent-pure-contracts.xml'):
        suites=ET.parse(ARTIFACTS/name).getroot();counts={key:sum(int(s.get(key,0)) for s in suites.iter('testsuite'))
            for key in ('tests','failures','errors','skipped')};test_rows.append(dict(path=str(ARTIFACTS/name),**counts))
        check('reused-pure-tests-'+name,counts['tests']==36 and counts['failures']==counts['errors']==0,
              'Existing36 synthetic pure controls are retained and not rerun; no numerical owner/model was imported.')
    for name in ('evaluation-plan.json','evaluation-manifest.json'):artifact(RUN/name)
    check('evaluation-only-without-dimension',"choices=('evaluation',)" in current
          and "(args.phase in ('preflight','training')) != (args.dimension is not None)" in current,
          'This guardian accepts evaluation only and rejects a supplied dimension before admission; both widths run within one reviewed evaluation.')
    result=dict(schema='independent-retention-guardian-readiness/v1',created_at=datetime.now(timezone.utc).isoformat(),
                passed=not findings,findings=findings,checks=checks,artifacts=artifacts,
                phase='evaluation',dimension=None,run_root=str(RUN),dependency_root=str(SOURCE),
                execution_readiness_granted=False,numerical_execution_readiness_granted=False,
                integration_publication_required=True,integration_publication_receipt=None,
                publication_prerequisite='Root must bind this clean guardian review with the scoped source integration publication receipt before producing final execution readiness.',
                source_closure=dict(input_count=len(inputs),total_bytes=total,inputs_tree_sha256=manifest_tree,
                                    refreshed_hash_review=str(ARTIFACTS/'guardian-input-hash-review.json')),
                resource_policy=dict(storage_bytes=100000000,memory_mib=1536,cpu_slots=1,child_process_slots=1,
                                     cap_bytes=145000000000,admission_timeout_seconds=600,outer_deadline_seconds=900,
                                     driver_deadline_seconds=600,panel_deadline_seconds=30,
                                     process_birth_cleanup_unchanged=True,foreign_lease_reset_permitted=False,
                                     watchdog_unchanged=True,continuous_lease_coverage_claimed=False),
                pure_test_receipts_reused=test_rows,
                scope='Guardian source/diff/static budget/input custody and normalized runner review only. Fresh live admission/capacity is checked by the unchanged owned guardian at launch.',
                execution_launched=False,model_executed=False,model_imported=False,encoder_executed=False,
                training_executed=False,prover_or_Lake_executed=False,source_or_tensor_modified=False,
                scheduler_or_lease_state_mutated=False,Git_mutated=False,
                teacher_qualified=False,source_semantics_verified=False,proof_authority=False,
                elapsed_seconds=time.monotonic()-started)
    (ARTIFACTS/'guardian-readiness.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(dict(passed=result['passed'],findings=findings,checks=len(checks),input_count=len(inputs),
                         total_bytes=total,run_root=str(RUN),execution_readiness_granted=False)))

if __name__=='__main__':main()
