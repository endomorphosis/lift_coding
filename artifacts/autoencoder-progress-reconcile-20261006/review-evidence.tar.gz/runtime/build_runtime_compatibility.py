"""Read pinned Git source and live bytes; never import numerical/model owners."""
from __future__ import annotations

import ast
from datetime import datetime, timezone
import difflib
import hashlib
import json
from pathlib import Path
import subprocess

WORKSPACE = Path('/home/barberb/lift_coding')
REPOSITORY = WORKSPACE / 'external/ipfs_datasets'
OUTPUT = WORKSPACE / 'artifacts/autoencoder-progress-reconcile-20261006/runtime'
COMMIT = '795d960170214d03e2eaf4c0a13ad4eb922c5c08'
PREFIX = 'ipfs_datasets_py/logic/formalization/autoencoder/'


def source(relative):
    return subprocess.check_output(['git', 'show', COMMIT + ':' + relative], cwd=REPOSITORY)


def receipt(relative):
    main = source(relative)
    live = REPOSITORY / relative
    present = live.exists()
    actual = live.read_bytes() if present else None
    return dict(path=relative, main_commit=COMMIT, main_bytes=len(main),
                main_sha256=hashlib.sha256(main).hexdigest(),
                live_exists=present, live_bytes=len(actual) if present else None,
                live_sha256=hashlib.sha256(actual).hexdigest() if present else None,
                live_equals_main=actual == main if present else None)


def main():
    OUTPUT.mkdir(parents=True, exist_ok=True)
    tree = ast.parse(source(PREFIX + 'contextual_legal_ir_runtime.py'))
    owners = next(ast.literal_eval(node.value) for node in tree.body
                  if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name)
                  and target.id == 'SOURCE_OWNER_NAMES' for target in node.targets))
    dependencies = [PREFIX + name + '.py' for name in owners]
    dependencies += [PREFIX + 'contextual_legal_ir_output.py', PREFIX + 'decoder_source_fidelity.py',
                     PREFIX + '__init__.py', 'ipfs_datasets_py/logic/legal_ir/canonical_contracts.py',
                     'ipfs_datasets_py/logic/legal_ir/canonical_decompiler.py',
                     'ipfs_datasets_py/logic/legal_ir/__init__.py']
    additions = [PREFIX + name + '.py' for name in
                 ('contextual_legal_ir_runtime', 'contextual_legal_ir_numeric', 'contextual_legal_ir_output')]
    additions += ['tests/unit/logic/formalization/autoencoder/test_' + name + '.py' for name in
                  ('contextual_legal_ir_runtime', 'contextual_legal_ir_runtime_adversarial',
                   'contextual_legal_ir_numeric', 'contextual_legal_ir_output')]
    additions += ['docs/autoencoders/contextual_legal_reconstruction_runtime.md']
    patch_path = PREFIX + 'source_value_decoder_experiment.py'
    original = (REPOSITORY / patch_path).read_text()
    published = source(patch_path).decode()
    delta = ''.join(difflib.unified_diff(original.splitlines(True), published.splitlines(True),
                                        fromfile='live/' + patch_path, tofile=COMMIT + '/' + patch_path))
    (OUTPUT / 'source_value_lazy_import.diff').write_text(delta)
    expected = original.replace('from .long_span_decoder_training import reference_weights\n', '', 1)
    needle = '    _require(type(max_rules) is int and 1 <= max_rules <= MAX_RULES, "bounded source slot count required")'
    insert = ('    # Training reference preparation stays lazy; cached inference needs only\n'
              '    # the numerical source-value protocol from this module.\n'
              '    from .long_span_decoder_training import reference_weights\n\n')
    expected = expected.replace(needle, insert + needle, 1)
    exact_patch = expected == published
    old_tree, new_tree = ast.parse(original), ast.parse(published)
    def numerical_ast(tree):
        tree.body = [node for node in tree.body if not isinstance(node, ast.ImportFrom)
                     or node.module != 'long_span_decoder_training']
        for node in tree.body:
            if isinstance(node, ast.FunctionDef) and node.name == 'reference_source_values':
                node.body = [inner for inner in node.body if not isinstance(inner, ast.ImportFrom)
                             or inner.module != 'long_span_decoder_training']
        return ast.dump(tree, include_attributes=False)
    unchanged_calculations = numerical_ast(old_tree) == numerical_ast(new_tree)
    historical = WORKSPACE / 'artifacts/autoencoder-integration-review-20261006/branches/test-receipts.json'
    old = json.loads(historical.read_text())
    previous = [item for item in old['receipts'] if item['attempt'] in
                ('profile-canonical-tests-r1', 'ir-wrapper-canonical-tests-r1', 'checkpoint-hub-existing-tests-r1')]
    records = [receipt(path) for path in dict.fromkeys(dependencies + additions)]
    pin_paths = [PREFIX + 'ir_model_manager_import.py', PREFIX + 'ir_decoder_profile_inventory.py',
                 PREFIX + 'ir_cell_runtime.py', PREFIX + 'ir_decoder_format_runtime.py',
                 PREFIX + 'native4096_formula_sidecar_experiment.py',
                 'ipfs_datasets_py/optimizers/logic_theorem_optimizer/autoencoder_runtime_registry.py',
                 'ipfs_datasets_py/optimizers/logic_theorem_optimizer/autoencoder_lineages/legacy_v1/linguistic_teacher.py',
                 'ipfs_datasets_py/optimizers/logic_theorem_optimizer/autoencoder_family_training_validated_v5.py',
                 'docs/autoencoders/formula_fleet.md', 'docs/autoencoders/control_plane_and_sync.md',
                 'docs/autoencoders/logic_output_requirements.md', 'docs/autoencoders/normative_wording_training.md']
    report = {
        'schema': 'autoencoder-runtime-compatibility-audit/v1',
        'created_at': datetime.now(timezone.utc).isoformat(),
        'repository': str(REPOSITORY), 'source_commit': COMMIT,
        'working_head_at_review': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPOSITORY, text=True).strip(),
        'inspection_scope': 'Pinned published Git source and bounded live source bytes; no source or Git edits, numerical imports, model loads, weight reads, databases, networks or suite reruns.',
        'owner_dependency_and_addition_survey': records,
        'reference_source_pins': [receipt(path) for path in pin_paths],
        'patch': {'path': patch_path, 'exact_import_relocation_only': exact_patch,
                  'calculation_ast_unchanged_after_import_relocation': unchanged_calculations,
                  'diff_path': str(OUTPUT / 'source_value_lazy_import.diff'),
                  'contract': 'reference_weights is imported only inside reference_source_values. Cached numerical inference does not need the historical training/reference owner; explicitly calling training reference preparation retains its original import and call.'},
        'contextual_contract': {
            'family': 'legal_ir', 'dimensions': [384, 768], 'dimension_role': 'input_embedding',
            'task_id': 'semantic_IR_reconstruction',
            'prepare': 'prepare_contextual_legal_ir_runtime(request, checkpoint_pin, preprocessing_pin, donor_checkpoint_pin, source_inputs_pin, source_contexts_pin, source_owner_pins, row_ids)',
            'open': 'open_contextual_legal_ir_autoencoder: explicit lazy CPU numerical restoration; describe and infer_cached only',
            'inputs': 'Original cached normalized paragraph vectors and original ordered raw clause vectors with literal source spans; source binding, saved TRAIN transform, full selected 32 tensors and raw384 13-tensor donor are authenticated.',
            'budgets': {'rows': 64, 'source_clauses': 8, 'decoder_output_tokens_including_BOS_EOS': 512,
                        'cpu_threads_caller_owned': 1, 'dtype': 'float32', 'device': 'cpu'},
            'outputs': 'Raw token/status/EOS candidates. Separate output owner validates actual CanonicalRoundTripIR and scores ordered IR, canonical IR and original text independently.',
            'reference_access': 'Generation accepts no gold prefix, reference IR, labels or rule count. Evaluation is separate.',
            'authority': 'Native format/profile identities remain null; complete_runtime_io_contract, teacher, production runtime, fresh holdout, learned prose and proof authority remain false.',
            'unsupported': ['fresh source or embeddings', '8D', '4096D', 'other families', 'training/resume',
                            'automatic ModelManager serving dispatch', '8-family promotion', 'Lake admission', '8192-token span qualification']},
        'integration_map': [
            {'owner': 'ir_model_manager_import.py', 'relationship': 'Metadata-only injected genuine ModelManager registration with independently reopened persisted readback; asset/component identity is separate from serving selection. Dimension8/384/768 concrete bindings and null-dimension source-token components;4096 cannot become an allowed lane merely by renaming metadata. runtime_ready/teacher/proof remain false.'},
            {'owner': 'autoencoder_runtime_registry.py', 'relationship': 'Common domain/version API knows legacy8D, current384D, published384 source packages, separate legal source-text formula lineage and compiler-structural native formula lineages. Contextual cached384/768 is not a version of any listed profile and has no exact-resume adapter.'},
            {'owner': 'LegacyLinguisticTeacher', 'relationship': 'Explicit original8D linguistic model plus bounded canonical compiler observations; parser features and target caches remain supervised/guided observations. No contextual384/768 automatic teacher promotion or tensor migration.'},
            {'owner': 'ir_decoder_profile_inventory / ir_decoder_format_runtime', 'relationship': 'Stable supported profiles currently only exact original Intent/Security384 fragment bindings. Contextual Legal384/768 explicitly has unknown native schema/profile/format; do not force its state serialization schema into a native profile.'},
            {'owner': 'native4096_formula_sidecar_experiment.py', 'relationship': 'Separate4096 pilot requires a live full native-owner result, reuses donor token embedding/GRU/readout only, and creates new source heads. Its project returns identity explicitly; zero reconstruction MSE is not learned reconstruction or autoformalization progress.'},
            {'owner': 'autoencoder_family_training_validated_v5.py', 'relationship': 'Validated native-v7 feature training requires live complete projections and source-disjoint batches, with no source-text decoder objective. These states and targets cannot be fed directly into contextual sequence checkpoints.'},
            {'owner': 'shared Arrow / DuckDB / Quack', 'relationship': 'Shared prepared targets, mapped Arrow features and sparse modal updates support owned feature campaigns with exact checkpoint/source identities. Formula fleet is separate exact-resume full checkpoint exchange, one DuckDB owner/scoped Quack leases and actual decoded-output Lake replay. Contextual runtime opens none of these stores; publication is not transactional training synchronization.'}],
        'prior_closure': {'receipt': str(historical), 'receipt_sha256': hashlib.sha256(historical.read_bytes()).hexdigest(),
                          'canonical_unique_tests_passed': old['canonical_unique_tests_passed'],
                          'receipts_reused_not_rerun': previous,
                          'scope': '129 profile closure +774 original wrapper closure +25 existing checkpoint-Hub controls. No models or Lean admission. This is older5171a632-era closure, not validation of the newly added contextual runtime.'},
        'bounded_integration': {
            'action': 'Materialize only absent published contextual modules, dedicated tests and guide into canonical workspace; apply exact guarded lazy reference import delta only if preimage still matches.',
            'additions': additions, 'existing_patch': patch_path,
            'source_compatibility': 'Ten existing numerical owners and three direct output dependencies are byte-identical published main; only source-value import placement differs.',
            'source_mutation_owner': 'root agent; this audit wrote only its runtime artifact directory',
            'verification_required': [
                'Hash every materialized file against pinned795d960 and retain before/after source-value SHA; refuse existing-path clobber.',
                'Run dedicated pure metadata/adversarial/output test files in canonical workspace with minimal imports, no auto-install, offline flags and plugin autoload disabled. Assert complete metadata fixture imports no ML/database/network owner.',
                'Run fresh-process numerical._owners() import probe with historical training/reference, manager/database, encoder and network imports blocked. Calling _owners imports no models; it verifies lazy training import closure.',
                'Keep numeric original-asset regression receipts as prior evidence. No model reload, training or archived weight read is needed for this materialization.',
                'No retest of old774/129/25 green closures absent new dependency changes.']},
        'new_verification': {'static_import_relocation_check_passed': exact_patch,
                             'static_calculation_AST_check_passed': unchanged_calculations,
                             'pure_pytest_executed_by_this_audit': False,
                             'model_or_encoder_forwards': 0, 'training_runs': 0, 'Lake_calls': 0,
                             'qualification_granted': False},
        'remaining_disconnected_interfaces': [
            'Canonical workspace lacked contextual entry points despite published GitHubmain containing them; bounded materialization fixes this source availability gap.',
            'Common registry, ModelManager metadata and decoder-profile inventories do not supply contextual training/resume/serving qualification. New adapter would require exact task and state contracts; no silent routing now.',
            'Legal semantic IR erases original prose choices. Deterministic source-withheld renderer is a separate canonical baseline;48/48 semantic exactness coexists with0/48 original text byte equality.',
            'Original contextual48-row regression, separate modality paraphrase panels and normative TRAIN/DEVELOPMENT controls have distinct checkpoint/source populations; merging scores cannot establish broader semantic coverage.',
            'Actual source-bound family and Lake gates remain required before formalization/proof admission.']}
    (OUTPUT / 'runtime-compatibility.json').write_text(json.dumps(report, indent=2) + '\n')
    assert exact_patch and unchanged_calculations
    print(json.dumps({'report': str(OUTPUT / 'runtime-compatibility.json'),
                      'owner_files': len(owners), 'materialization_files': len(additions),
                      'exact_guarded_import_relocation': exact_patch,
                      'calculation_AST_unchanged': unchanged_calculations}))


if __name__ == '__main__':
    main()
