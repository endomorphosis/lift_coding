"""Plan or explicitly restore reviewed, absent published source files only.

No checkout, reset, index update, runtime import, model, encoder, database or
network call is used. Existing files must already match the pinned bytes/mode;
they are never overwritten. Partial outcomes survive ordinary execution errors.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import subprocess

PIN = '795d960170214d03e2eaf4c0a13ad4eb922c5c08'
WORKSPACE = Path('/home/barberb/lift_coding')
ARTIFACTS = WORKSPACE / 'artifacts/autoencoder-progress-reconcile-20261006/runtime'
DEFAULT_REPOSITORY = WORKSPACE / 'external/ipfs_datasets'
MAX_FILE = 32 * 1024 * 1024
MAX_TOTAL = 64 * 1024 * 1024
DIRECTORY_FLAGS = os.O_RDONLY | os.O_CLOEXEC | os.O_DIRECTORY | os.O_NOFOLLOW


def git(repository, *arguments):
    return subprocess.check_output(['git', '--literal-pathspecs', '-C', str(repository), *arguments],
                                   stderr=subprocess.PIPE)


def identity(info):
    return (info.st_dev, info.st_ino, info.st_mode, info.st_nlink, info.st_size,
            info.st_mtime_ns, info.st_ctime_ns)


def normalized(path):
    parsed = PurePosixPath(path)
    if (type(path) is not str or not path or parsed.is_absolute() or str(parsed) != path
            or any(part in ('..', '.git') for part in parsed.parts)):
        raise ValueError('closed normalized repository-relative source path required')
    return parsed.parts


class Directories:
    """Hold no-follow descriptors and fence their physical path identities."""
    def __init__(self, path):
        path = Path(path).absolute()
        if path != path.resolve(strict=True):
            raise ValueError('canonical existing directory root required')
        self.opened, self.witnesses, self.children = [], [], {}
        try:
            self.root = os.open('/', DIRECTORY_FLAGS)
            self.opened.append(self.root)
            for part in path.parts[1:]:
                self.root = self.child(self.root, part, create=False)
        except BaseException:
            self.close()
            raise

    def child(self, parent, name, *, create):
        if (parent, name) in self.children:
            child, expected = self.children[parent, name]
            if (identity(os.stat(name, dir_fd=parent, follow_symlinks=False))[:3] != expected
                    or identity(os.fstat(child))[:3] != expected):
                raise ValueError('cached restore directory path changed')
            return child
        try:
            before = os.stat(name, dir_fd=parent, follow_symlinks=False)
        except FileNotFoundError:
            if not create:
                raise
            try:
                os.mkdir(name, 0o755, dir_fd=parent)
            except FileExistsError:
                pass
            before = os.stat(name, dir_fd=parent, follow_symlinks=False)
        if not stat.S_ISDIR(before.st_mode):
            raise ValueError('restore ancestors must be actual directories')
        child = os.open(name, DIRECTORY_FLAGS, dir_fd=parent)
        self.opened.append(child)
        if identity(os.fstat(child))[:3] != identity(before)[:3]:
            raise ValueError('restore directory changed before open')
        self.witnesses.append((parent, name, identity(before)[:3], child))
        self.children[parent, name] = child, identity(before)[:3]
        return child

    def parent(self, relative, *, create):
        parts, parent = normalized(relative), self.root
        for name in parts[:-1]:
            parent = self.child(parent, name, create=create)
        return parent, parts[-1]

    def fence(self):
        for parent, name, expected, child in self.witnesses:
            if (identity(os.stat(name, dir_fd=parent, follow_symlinks=False))[:3] != expected
                    or identity(os.fstat(child))[:3] != expected):
                raise ValueError('restore ancestor path identity changed')

    def close(self):
        for descriptor in reversed(self.opened):
            os.close(descriptor)
        self.opened.clear()


def existing(directories, relative):
    try:
        parent, name = directories.parent(relative, create=False)
        before = os.stat(name, dir_fd=parent, follow_symlinks=False)
    except FileNotFoundError:
        directories.fence()
        return None
    if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1:
        raise ValueError('existing restore path must be a single-link regular file: ' + relative)
    if before.st_size > MAX_FILE:
        raise ValueError('existing source exceeds32MiB bound: ' + relative)
    descriptor = os.open(name, os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW | os.O_NONBLOCK,
                         dir_fd=parent)
    try:
        witness, count, digest = identity(before), 0, hashlib.sha256()
        if identity(os.fstat(descriptor)) != witness:
            raise ValueError('existing restore file changed before read')
        while True:
            block = os.read(descriptor, min(65536, before.st_size-count+1))
            if not block:
                break
            count += len(block)
            if count > before.st_size:
                raise ValueError('existing restore file grew')
            digest.update(block)
        if (count != before.st_size or identity(os.fstat(descriptor)) != witness
                or identity(os.stat(name, dir_fd=parent, follow_symlinks=False)) != witness):
            raise ValueError('existing restore file changed while reading')
        directories.fence()
        return dict(bytes=count, sha256=digest.hexdigest(),
                    mode='100755' if before.st_mode & stat.S_IXUSR else '100644')
    finally:
        os.close(descriptor)


def manifest():
    reviews = [('additive-closure-review.json', ('source_additions', 'dedicated_missing_tests', 'test_support')),
               ('additive-guide-pins.json', ('guides',))]
    rows, receipts = {}, []
    for filename, keys in reviews:
        path = ARTIFACTS / filename
        raw = path.read_bytes()
        document = json.loads(raw)
        if document['source_commit'] != PIN:
            raise ValueError('review source commit changed')
        receipts.append(dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()))
        for key in keys:
            for row in document[key]:
                relative = row['path']
                normalized(relative)
                selected = dict(path=relative, bytes=row['bytes'], sha256=row['sha256'], group=key)
                if relative in rows and rows[relative] != selected:
                    raise ValueError('conflicting duplicate reviewed path')
                rows[relative] = selected
    if len(rows) != 175:
        raise ValueError('exact reviewed175-path additive selection required')
    if sum(row['bytes'] for row in rows.values()) > MAX_TOTAL:
        raise ValueError('reviewed aggregate source exceeds64MiB')
    return [rows[path] for path in sorted(rows)], receipts


def published(repository, row):
    if type(row['bytes']) is not int or not 0 <= row['bytes'] <= MAX_FILE:
        raise ValueError('bounded exact source byte count required')
    value = git(repository, 'ls-tree', '-z', PIN, '--', row['path'])
    records = value.rstrip(b'\0').split(b'\0')
    if len(records) != 1 or not value:
        raise ValueError('exact pinned published source required')
    header, name = records[0].split(b'\t', 1)
    mode, kind, blob = header.decode().split()
    if name.decode() != row['path'] or kind != 'blob' or mode not in ('100644', '100755'):
        raise ValueError('published source must be a regular Git file')
    size = int(git(repository, 'cat-file', '-s', blob))
    if size != row['bytes'] or size > MAX_FILE:
        raise ValueError('published source byte pin differs')
    content = git(repository, 'cat-file', 'blob', blob)
    if len(content) != size or hashlib.sha256(content).hexdigest() != row['sha256']:
        raise ValueError('published source SHA256 differs')
    return content, dict(mode=mode, blob=blob, bytes=size, sha256=row['sha256'])


def git_state(repository):
    head = git(repository, 'rev-parse', '--verify', 'HEAD').decode().strip()
    index = Path(git(repository, 'rev-parse', '--git-path', 'index').decode().strip())
    if not index.is_absolute():
        index = repository / index
    directories = Directories(index.parent)
    try:
        receipt = existing(directories, index.name)
    finally:
        directories.close()
    return dict(head=head, index=receipt)


def create(directories, relative, content, expected):
    parent, name = directories.parent(relative, create=True)
    directories.fence()
    descriptor = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC,
                         0o755 if expected['mode'] == '100755' else 0o644, dir_fd=parent)
    try:
        os.fchmod(descriptor, 0o755 if expected['mode'] == '100755' else 0o644)
        view = memoryview(content)
        while view:
            written = os.write(descriptor, view)
            if written <= 0:
                raise OSError('source write did not advance')
            view = view[written:]
        os.fsync(descriptor)
    finally:
        os.close(descriptor)
    observed = existing(directories, relative)
    if observed != {key: expected[key] for key in ('bytes', 'sha256', 'mode')}:
        raise ValueError('created source differs from published pin')
    return observed


def restore(repository, *, execute=False):
    repository = Path(repository).absolute()
    directories = Directories(repository)
    result = dict(schema='published-autoencoder-additive-restore/v1', source_commit=PIN,
                  repository=str(repository), execute=execute, paths=[], completed=False,
                  model_executed=False, training_executed=False, encoder_executed=False,
                  database_opened=False, network_executed=False, qualification_granted=False,
                  source_value_patch_applied=False, security_span_patch_applied=False,
                  resource_profile_reconciled=False,
                  pending_routes=['bounded_header_checker', 'codebase_header_context', 'codebase_source_units_384'])
    before = None
    try:
        before = git_state(repository)
        rows, receipts = manifest()
        result['review_receipts'] = receipts
        prepared = []
        # Authenticate every Git blob and inspect every collision before mutation.
        for row in rows:
            content, expected = published(repository, row)
            actual = existing(directories, row['path'])
            if actual is not None and actual != {key: expected[key] for key in ('bytes', 'sha256', 'mode')}:
                raise ValueError('existing path differs; never overwrite: ' + row['path'])
            entry = dict(path=row['path'], group=row['group'], published=expected,
                         before=actual, status='already_present' if actual is not None else 'missing')
            result['paths'].append(entry)
            prepared.append((row, content, expected, entry))
        directories.fence()
        if execute:
            for row, content, expected, entry in prepared:
                actual = existing(directories, row['path'])
                if actual is not None:
                    if actual != {key: expected[key] for key in ('bytes', 'sha256', 'mode')}:
                        raise ValueError('late existing path differs; never overwrite: ' + row['path'])
                    entry.update(status='already_present', after=actual)
                    continue
                entry['create_started'] = True
                try:
                    actual = create(directories, row['path'], content, expected)
                except FileExistsError:
                    actual = existing(directories, row['path'])
                    if actual != {key: expected[key] for key in ('bytes', 'sha256', 'mode')}:
                        raise ValueError('concurrent insertion differs; never overwrite: ' + row['path'])
                    entry.update(status='already_present', after=actual, create_returned=False)
                else:
                    entry.update(status='created_verified', after=actual, create_returned=True)
        after = git_state(repository)
        result.update(git_state_before=before, git_state_after=after, git_head_index_unchanged=before==after)
        if before != after:
            raise ValueError('HEAD/index endpoint observations changed; inspect concurrent Git activity')
        directories.fence()
        result['completed'] = True
    except Exception as error:
        result['error'] = str(error)
        if before is not None:
            result['git_state_before'] = before
            try:
                after = git_state(repository)
                result.update(git_state_after=after, git_head_index_unchanged=before==after)
            except Exception as observation_error:
                result['git_state_after_error'] = str(observation_error)
    finally:
        directories.close()
    result['counts'] = {status: sum(row['status'] == status for row in result['paths'])
                        for status in ('missing', 'already_present', 'created_verified')}
    return result


def write_receipt(path, value):
    path = Path(path).absolute()
    directories = Directories(path.parent)
    try:
        content = (json.dumps(value, indent=2, sort_keys=True)+'\n').encode()
        create(directories, path.name, content, dict(mode='100644', bytes=len(content),
               sha256=hashlib.sha256(content).hexdigest()))
    finally:
        directories.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repository', type=Path, default=DEFAULT_REPOSITORY)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()
    output = args.output.absolute()
    if output.exists() or output.is_symlink():
        parser.error('fresh output receipt path required')
    # Check output parents before the first restore mutation.
    parent = Directories(output.parent)
    parent.close()
    result = restore(args.repository, execute=args.execute)
    write_receipt(output, result)
    print(json.dumps(dict(completed=result['completed'], execute=args.execute,
                         counts=result['counts'], receipt=str(output), error=result.get('error'))))
    if not result['completed']:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
