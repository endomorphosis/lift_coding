"""Static published-source closure for additive workspace recovery."""
from __future__ import annotations
import ast
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

ROOT=Path('/home/barberb/lift_coding')
REPO=ROOT/'external/ipfs_datasets'
OUT=ROOT/'artifacts/autoencoder-progress-reconcile-20261006/runtime'
PIN='795d960170214d03e2eaf4c0a13ad4eb922c5c08'
MANIFEST=ROOT/'artifacts/autoencoder-progress-reconcile-20261006/branches/published-source-missing-from-canonical.json'
TREE=set(subprocess.check_output(['git','ls-tree','-r','--name-only',PIN],cwd=REPO,text=True).splitlines())
CACHE={}
def raw(path):
    if path not in CACHE:
        CACHE[path]=subprocess.check_output(['git','show',PIN+':'+path],cwd=REPO)
    return CACHE[path]
def pin(path):
    content=raw(path); p=REPO/path; actual=p.read_bytes() if p.is_file() else None
    return dict(path=path,bytes=len(content),sha256=hashlib.sha256(content).hexdigest(),
                exists_live=p.exists(),live_equals_main=actual==content if actual is not None else None,
                live_sha256=hashlib.sha256(actual).hexdigest() if actual is not None else None)
def module_path(name):
    for path in (name.replace('.','/')+'.py',name.replace('.','/')+'/__init__.py'):
        if path in TREE:return path
    return None
def imports(path):
    package=path.replace('/','.').removesuffix('.py').split('.')[:-1]
    if path.endswith('/__init__.py'):package=package[:-1]
    # __init__ package is its directory, not parent; reset explicitly.
    if path.endswith('/__init__.py'):package=path.split('/')[:-1]
    result=[]
    for node in ast.walk(ast.parse(raw(path))):
        if isinstance(node,ast.Import):
            for a in node.names:
                owner=module_path(a.name)
                if owner:result.append(dict(path=owner,symbol=None,line=node.lineno,statement=ast.unparse(node)))
        if isinstance(node,ast.ImportFrom):
            parts=package[:len(package)-node.level+1] if node.level else []
            parts+=node.module.split('.') if node.module else []
            base='.'.join(parts)
            for a in node.names:
                child=module_path(base+'.'+a.name)
                owner=child or module_path(base)
                if owner:result.append(dict(path=owner,symbol=None if child else a.name,line=node.lineno,statement=ast.unparse(node)))
    return result
def definitions(content):
    tree=ast.parse(content); names=set()
    for node in tree.body:
        if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)):names.add(node.name)
        elif isinstance(node,ast.Import):names.update(a.asname or a.name.split('.')[0] for a in node.names)
        elif isinstance(node,ast.ImportFrom):names.update(a.asname or a.name for a in node.names)
        elif isinstance(node,(ast.Assign,ast.AnnAssign)):
            targets=node.targets if isinstance(node,ast.Assign) else [node.target]
            names.update(n.id for t in targets for n in ast.walk(t) if isinstance(n,ast.Name))
    return names
def classify(path):
    if '/distributed_384/' in path:return 'distributed_source384_owner_worker_and_native_gates'
    if '/contextual_legal_ir_' in path:return 'contextual_legal384_768_cached_replay'
    if '/duckdb_control/' in path:return 'single_owner_codebase_history_catalog_retention'
    if '/software_contracts/' in path:return 'codebase_source384_runtime_training_custody_and_semantic_state'
    if '/security/' in path or '/security_ir/' in path:return 'security_source_semantics_and_header_checks'
    if 'intent' in Path(path).name or '/intent_ir/' in path:return 'intent_action_source_effects_and_native_checks'
    if 'native_' in Path(path).name:return 'native_family_Lean_emitters_and_interpretations'
    if 'source_' in Path(path).name:return 'source_checkpoint_continuation_program_state_and_portable_pins'
    if 'ir_model_' in path:return 'metadata_publication_and_ModelManager_registration'
    return 'legal_text_and_source_custody'
def main():
    manifest=json.loads(MANIFEST.read_text()); assert manifest['target']==PIN
    initial={row['path'] for row in manifest['paths']}
    missing=set(initial); scanned=set(); edges=[]; changed={}; absent=[]; symbols=[]
    queue=list(initial)
    while queue:
        path=queue.pop()
        if path in scanned or not path.endswith('.py'):continue
        scanned.add(path)
        for edge in imports(path):
            target=edge['path']; p=REPO/target; edges.append(dict(importer=path,**edge))
            if not p.exists():
                if target not in missing:missing.add(target);queue.append(target)
            elif p.is_file() and p.read_bytes()!=raw(target):
                changed.setdefault(target,pin(target))
                symbol=edge['symbol']
                if symbol and symbol!='*':
                    pub=definitions(raw(target)); live=definitions(p.read_bytes())
                    if symbol in pub and symbol not in live:
                        symbols.append(dict(importer=path,dependency=target,symbol=symbol,line=edge['line']))
            if edge['symbol'] and edge['symbol']!='*' and p.is_file():
                # Dynamic/lazy __getattr__ exports may require review; only record declared main names.
                if edge['symbol'] not in definitions(p.read_bytes()) and edge['symbol'] in definitions(raw(target)):
                    pass
    # Include source files referred to by literal package paths in restored owners.
    literal_support=set()
    for path in list(missing):
        if path.endswith('.py'):
            for n in ast.walk(ast.parse(raw(path))):
                if isinstance(n,ast.Constant) and isinstance(n.value,str):
                    value=n.value
                    candidates=(value,'ipfs_datasets_py/'+value)
                    for c in candidates:
                        if c in TREE and not (REPO/c).exists():literal_support.add(c)
    missing.update(literal_support)
    source_stems={Path(p).stem for p in missing if p.endswith('.py') and not p.startswith('scripts/') and Path(p).name!='__init__.py'}
    # Dedicated tests matching recovered module names. Importers also capture wrappers named by behavior.
    tests=set()
    test_roots=('tests/unit/logic/formalization/autoencoder/','tests/unit/logic/software_contracts/',
                'tests/unit/logic/security_ir/','tests/unit/logic/intent_ir/',
                'tests/unit/duckdb_control/','tests/integration/logic/software_contracts/')
    for path in TREE:
        if not path.endswith('.py') or (REPO/path).exists() or not path.startswith(test_roots):continue
        matching=Path(path).stem.removeprefix('test_') in source_stems
        if matching or any(e['path'] in missing for e in imports(path)):tests.add(path)
    support=set()
    for path in tests:
        # Preserve existing package markers; restore only original absent tracked markers.
        parent=Path(path).parent
        while parent!=Path('.'):
            marker=str(parent/'__init__.py')
            if marker in TREE and not (REPO/marker).exists():support.add(marker)
            parent=parent.parent
        for edge in imports(path):
            target=edge['path']
            if not (REPO/target).exists() and target not in missing and target not in tests:
                support.add(target)
    groups=Counter(classify(p) for p in initial)
    report=dict(schema='additive-autoencoder-source-closure-review/v1',created_at=datetime.now(timezone.utc).isoformat(),
                source_commit=PIN,input_manifest=str(MANIFEST),input_manifest_sha256=hashlib.sha256(MANIFEST.read_bytes()).hexdigest(),
                original_published_missing_counts=dict(total=len(initial),python=sum(p.endswith('.py') for p in initial),other=sum(not p.endswith('.py') for p in initial)),
                original_groups=dict(groups),source_additions=[pin(p) for p in sorted(missing)],
                source_dependencies_outside_initial_scope=[pin(p) for p in sorted(missing-initial)],
                dedicated_missing_tests=[pin(p) for p in sorted(tests)],test_support=[pin(p) for p in sorted(support)],
                changed_existing_direct_dependencies=list(changed.values()),missing_declared_symbols_in_existing_dependencies=symbols,
                direct_dependency_edges=edges,
                effect_scope='Source availability only. Copying absent immutable published files starts no runtime/training/store/prover/network process and grants no readiness/admission.',
                safe_action='Restore exact absent source/test/schema/support paths under exclusive create and pinned hashes. Preserve every existing file; do not bulk checkout/reset/rebase shared tree. Guard source_value import move separately.',
                activation_blockers='Missing declared symbols below identify API conflicts in existing dirty owners. Restore files first; gate affected route activation until narrowly reconciled and tested. Static AST covers explicit imports, not dynamic import or runtime filesystem dependencies.',
                verification='Compile recovered Python without import execution; run only pure tests selected by inspecting calls and monkeypatch controls. Do not execute numerical/training/encoder/native-Lake tests as a bulk group.',
                numerical_imports=0,model_forwards=0,source_mutations=0,qualification_granted=False)
    (OUT/'additive-closure-review.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:report[k] for k in ('original_published_missing_counts','original_groups','missing_declared_symbols_in_existing_dependencies')}))
    print(json.dumps(dict(source_additions=len(missing),new_source_dependencies=len(missing-initial),dedicated_missing_tests=len(tests),test_support=len(support),changed_existing_dependencies=len(changed))))
if __name__=='__main__':main()
