"""Read-only path-based Git/worktree inventory; writes only this artifact directory."""
from __future__ import annotations
import concurrent.futures
import hashlib
import json
from pathlib import Path
import subprocess
import time

ROOT = Path('/home/barberb/lift_coding')
OUT = Path(__file__).parent
BASE = ROOT / 'artifacts/autoencoder-integration-review-20261006'

def git(repo, *args, allowed=(0,)):
    proc = subprocess.run(['git', '--no-optional-locks', '-C', str(repo), *args], capture_output=True)
    if proc.returncode not in allowed:
        raise RuntimeError(f'{args[:3]}: {proc.stderr.decode(errors="replace")[:500]}')
    return proc

def scoped(path, kind):
    p = path.lower()
    if any(t in p for t in ['hacc', 'hallucinate_app']):
        return False
    if kind == 'workspace':
        return ((p.startswith(('scripts/', 'tests/', 'implementation_plan/', 'docs/', 'papers/', 'jevops/'))
                 and any(t in p for t in ['autoencoder', 'decoder', 'reconstruct', 'source-v2', 'formalization']))
                or p == 'external/ipfs_datasets')
    roots = ('ipfs_datasets_py/', 'tests/', 'scripts/', 'configs/', 'docs/')
    if not p.startswith(roots):
        return False
    return (any(t in p for t in ['autoencod', 'decoder', 'reconstruction', 'contextual', 'alignment',
                                 '/duckdb_control/', '/logic/intent_ir/', '/logic/ui_ux_ir/',
                                 '/logic/legal_ir/', '/logic/security_ir/', '/logic/software_contracts/',
                                 '/logic/autoformal/', '/logic/formalization/'])
            or p.startswith('docs/implementation/reports/evidence/autoencoder'))

def worktrees(repo):
    result=[]
    for record in git(repo, 'worktree', 'list', '--porcelain').stdout.decode().strip().split('\n\n'):
        row={}
        for line in record.splitlines():
            k, _, v=line.partition(' ')
            row[k]=v or True
        if row: result.append(row)
    return result

def refs(repo):
    rows=[]
    for line in git(repo, 'for-each-ref', '--format=%(refname)\t%(objectname)\t%(committerdate:iso8601)\t%(subject)').stdout.decode().splitlines():
        name, oid, date, subject=line.split('\t', 3)
        resolved=git(repo, 'rev-parse', '--verify', name+'^{commit}', allowed=(0,128))
        rows.append({'name':name,'object':oid,'commit':resolved.stdout.decode().strip() if not resolved.returncode else None,
                     'date':date,'subject':subject})
    return rows

def tree(repo, commit):
    rows={}
    for line in git(repo,'ls-tree','-rz',commit).stdout.split(b'\0'):
        if not line: continue
        meta,path=line.split(b'\t',1)
        mode,kind,blob=meta.decode().split()
        rows[path.decode(errors='surrogateescape')]={'mode':mode,'kind':kind,'blob':blob}
    return rows

def scan_repo(kind):
    repo=ROOT if kind=='workspace' else ROOT/'external/ipfs_datasets'
    initial=json.loads((OUT.parent/'initial-state.json').read_text())
    target=initial[kind]['origin_main']
    observed_origin=git(repo,'rev-parse','origin/main').stdout.decode().strip()
    advertised=git(repo,'ls-remote','--heads','origin').stdout.decode().splitlines()
    baseline=json.loads((BASE/f'{kind}-fetched-refs.json').read_text())
    before={r['name']:r['commit'] for r in baseline['refs']}
    old_target=baseline['main']
    current_refs=refs(repo)
    current_worktrees=worktrees(repo)
    commits={r['commit'] for r in current_refs if r['commit']}
    commits.update(w['HEAD'] for w in current_worktrees)
    main_tree=tree(repo,target)
    old_tree=tree(repo,old_target)
    def analyze(sha):
        ancestor=git(repo,'merge-base','--is-ancestor',sha,target,allowed=(0,1)).returncode==0
        old_ancestor=git(repo,'merge-base','--is-ancestor',sha,old_target,allowed=(0,1)).returncode==0
        row={'commit':sha,'ancestor_of_main':ancestor,'ancestor_of_previous_main':old_ancestor}
        if ancestor and old_ancestor:
            row['classification']='already_history_merged_before_prior_audit'
            return row
        mb=git(repo,'merge-base',target,sha,allowed=(0,1)).stdout.decode().strip()
        row['merge_base']=mb or None
        if not mb:
            row['classification']='unrelated_history_requires_owner_review'
            return row
        changed=git(repo,'diff','--name-only','-z',mb,sha).stdout.decode(errors='surrogateescape').split('\0')
        scope=[p for p in changed if p and scoped(p,kind)]
        # Newly merged history gets its introduced paths from the previous audit target.
        if ancestor:
            changed=git(repo,'diff','--name-only','-z',old_target,sha).stdout.decode(errors='surrogateescape').split('\0')
            scope=[p for p in changed if p and scoped(p,kind)]
        row['scoped_changed_paths_count']=len(scope)
        if not scope:
            row['classification']='already_merged' if ancestor else 'no_scoped_progress_since_divergence'
            return row
        source=tree(repo,sha)
        entries=[]
        for p in scope:
            s=source.get(p);m=main_tree.get(p);o=old_tree.get(p)
            status='identical_on_main' if s==m else 'source_removed_path' if s is None else 'absent_from_main' if m is None else 'different_on_main'
            entries.append({'path':p,'status':status,'source':s,'main':m,
                            'previous_main':o,'difference_existed_at_previous_review':s!=o})
        row['paths']=entries
        row['classification']=('newly_history_merged_effective_tree_checked' if ancestor else
                               'scoped_branch_progress_requires_effective_comparison')
        return row
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
        analysis=list(pool.map(analyze,sorted(commits)))
    by_sha={r['commit']:r for r in analysis}
    for r in current_refs:
        r['new_or_updated_since_prior_inventory']=before.get(r['name'])!=r['commit']
        r['classification']=by_sha.get(r['commit'],{}).get('classification','non_commit_ref')
    source_scope=sorted(p for p in main_tree if scoped(p,kind))
    canonical_missing=[]
    for p in source_scope:
        # Gitlinks are inventoried, but canonical file recovery concerns regular source/evidence only.
        if main_tree[p]['kind']!='blob':continue
        file=repo/p
        if not file.exists():
            data=git(repo,'cat-file','blob',main_tree[p]['blob']).stdout
            canonical_missing.append({'path':p,'main':main_tree[p],'bytes':len(data),
                                      'sha256':hashlib.sha256(data).hexdigest(),
                                      'classification':'published_on_main_but_missing_from_shared_canonical_source'})
    worktree_rows=[]
    for w in current_worktrees:
        # The package's primary registered path is its common Git directory; its working source is external/ipfs_datasets.
        actual=repo if Path(w['worktree'])==ROOT/'.git/modules/external/ipfs_datasets' else Path(w['worktree'])
        row={**w,'actual_source_worktree':str(actual),'exists':actual.exists(),
             'head_classification':by_sha.get(w['HEAD'],{}).get('classification')}
        if not actual.exists():
            worktree_rows.append(row);continue
        # Nested submodule worktrees may have intentionally retained broken metadata.
        # Their own source belongs to separate repositories; this inventory covers this repository.
        status=git(actual,'status','--porcelain=v1','-z','--untracked-files=all','--ignore-submodules=all').stdout.split(b'\0')
        entries=[];total=0;i=0
        while i<len(status):
            raw=status[i];i+=1
            if not raw:continue
            total+=1
            state=raw[:2].decode();path=raw[3:].decode(errors='surrogateescape')
            if 'R' in state or 'C' in state:
                old=status[i].decode(errors='surrogateescape');i+=1
            else:old=None
            if not scoped(path,kind):continue
            file=actual/path
            item={'status':state,'path':path,'from_path':old}
            if file.is_file() and not file.is_symlink():
                # Bind source/evidence bytes; avoid reading checkpoint/cache files into memory.
                h=hashlib.sha256()
                with file.open('rb') as stream:
                    for block in iter(lambda:stream.read(1024*1024),b''):h.update(block)
                item.update(bytes=file.stat().st_size,sha256=h.hexdigest())
                if file.stat().st_size<=4*1024*1024 and main_tree.get(path,{}).get('kind')=='blob':
                    expected=git(repo,'cat-file','blob',main_tree[path]['blob']).stdout
                    item['same_bytes_as_main']=hashlib.sha256(expected).hexdigest()==item['sha256']
                else:item['same_bytes_as_main']=False
            else:item['exists_as_regular_file']=False
            entries.append(item)
        row.update(total_status_paths=total,scoped_dirty_paths=entries,
                   classification='uncommitted_work_requires_exact_scoped_review' if entries else 'no_scoped_dirty_paths')
        worktree_rows.append(row)
    result={'schema':'autoencoder-read-only-ref-worktree-audit/v2','repo':str(repo),'target':target,'previous_target':old_target,
            'observed_origin_main':observed_origin,'advertised_origin_heads':advertised,
            'inventory_time_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
            'refs':current_refs,'commit_analysis':analysis,'worktrees':worktree_rows,'main_scoped_path_count':len(source_scope),
            'published_main_paths_missing_from_shared_canonical_source':canonical_missing,
            'coverage':{'all_refs_including_archives_recovery_tags':len(current_refs),'unique_commit_heads_including_detached':len(commits),
                        'registered_worktrees':len(current_worktrees),'ancestry_checked_for_every_commit_head':True,
                        'path_scoped_introduced_changes_checked_for_every_nonancestor':True,
                        'dirty_status_checked_for_every_existing_registered_worktree':True,
                        'unchanged_previously_merged_ref_effective_tree_checks':'Focused source restoration/producer pins validated separately'},
            'git_or_source_mutated':False}
    (OUT/f'{kind}-ref-worktree-inventory.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'repo':kind,'target':target,'coverage':result['coverage'],
                      'new_or_updated_refs':sum(r['new_or_updated_since_prior_inventory'] for r in current_refs),
                      'dirty_worktrees':sum(bool(w.get('scoped_dirty_paths')) for w in worktree_rows)}),flush=True)
    return result

if __name__=='__main__':
    import sys
    OUT.mkdir(parents=True,exist_ok=True)
    for kind in sys.argv[1:] or ['datasets','workspace']:scan_repo(kind)
