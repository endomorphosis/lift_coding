"""Build and bind a metadata-owned package closure for exact main runtime files."""
from pathlib import Path
import hashlib
import json
import subprocess

ROOT=Path('/home/barberb/lift_coding')
OUT=Path(__file__).parent
REPO=ROOT/'external/ipfs_datasets'
TARGET='795d960170214d03e2eaf4c0a13ad4eb922c5c08'
CLOSURE=OUT/'main-coordination-closure'
DEPS=[
 'ipfs_datasets_py/logic/formalization/autoencoder/native_family_lean_emitters.py',
 'ipfs_datasets_py/logic/intent_ir/formalize/modal_projections.py',
 'ipfs_datasets_py/logic/autoformal/family_qualification.py',
 'ipfs_datasets_py/logic/autoformal/tree_pin.py',
 'ipfs_datasets_py/logic/TDFOL/tdfol_parser.py',
 'ipfs_datasets_py/logic/TDFOL/tdfol_core.py',
 'ipfs_datasets_py/logic/CEC/native/dcec_integration.py',
 'ipfs_datasets_py/logic/CEC/native/dcec_core.py',
 'ipfs_datasets_py/logic/CEC/native/dcec_cleaning.py',
 'ipfs_datasets_py/logic/CEC/native/dcec_parsing.py',
 'ipfs_datasets_py/logic/CEC/native/dcec_prototypes.py',
 'ipfs_datasets_py/logic/CEC/native/exceptions.py',
]
def git(*args):return subprocess.check_output(['git','--no-optional-locks','-C',str(REPO),*args])
def sha(data):return hashlib.sha256(data).hexdigest()
def put(path,data):
    dest=CLOSURE/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
    return {'path':path,'bytes':len(data),'sha256':sha(data)}

def build(use_canonical_tests=False):
    CLOSURE.mkdir(exist_ok=True)
    candidate=json.loads((OUT/'standalone-coordination-candidate.json').read_text())
    changes=json.loads((OUT/'coordination-test-only-proposal.json').read_text())
    expected={p['path']:p for p in candidate['paths']}
    dependency_pins=[]
    for path in DEPS:
        raw=git('ls-tree','-z',TARGET,'--',path)
        blob=raw.rstrip(b'\0').split(b'\t')[0].decode().split()[2]
        data=git('cat-file','blob',blob)
        live=(REPO/path).read_bytes()
        dependency_pins.append({**put(path,data),'main_blob':blob,'canonical_sha256':sha(live),
                                'canonical_matches_main':sha(live)==sha(data)})
    candidate_files=[]
    for path in expected:
        if path.startswith('tests/'):
            proposal=next(p for p in changes['paths'] if p['path']==path)
            data=(REPO/path).read_bytes() if use_canonical_tests else (OUT/proposal['proposed_artifact']).read_bytes()
            if sha(data)!=proposal['proposed_sha256']:raise RuntimeError('Proposed test digest mismatch: '+path)
            candidate_files.append({**put(path,data),'source':'actual_canonical_adapted_test' if use_canonical_tests else 'artifact_proposed_test'})
        else:
            data=(REPO/path).read_bytes()
            if sha(data)!=expected[path]['sha256']:raise RuntimeError('Production candidate changed: '+path)
            candidate_files.append({**put(path,data),'source':'unchanged_canonical_candidate'})
    markers=[]
    for parent in sorted({p for path in DEPS+list(expected) if path.startswith('ipfs_datasets_py/')
                          for p in Path(path).parents if str(p)!='.'},key=str):
        path=str(parent/'__init__.py')
        markers.append(put(path,b'"""Metadata-owned namespace for the isolated coordination contract review."""\n'))
    # The negative tests register only fail-on-call helper modules. This parent namespace
    # permits import resolution without loading the active canonical source parser.
    markers.append(put('ipfs_datasets_py/logic/deontic/utils/__init__.py',b'"""Metadata-owned test namespace; no source parser or compiler is measured."""\n'))
    manifest={'target':TARGET,'closure':str(CLOSURE),'runtime_dependency_pins':dependency_pins,
              'candidate_files':candidate_files,'metadata_namespace_markers':markers,
              'full_package_entrypoint_measured':False,'current_legal_compiler_measured':False,
              'negative_control_fixtures':'Only the two adapted test bodies register fail-on-call source helper modules; no external harness replacements.',
              'uses_actual_canonical_tests':use_canonical_tests,'models_or_lake_executed':False}
    (OUT/'main-coordination-closure-manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'closure':str(CLOSURE),'main_dependency_files':len(dependency_pins),
                      'all_runtime_dependencies_match_canonical_main':all(p['canonical_matches_main'] for p in dependency_pins),
                      'actual_canonical_tests':use_canonical_tests}),flush=True)

if __name__=='__main__':
    import sys
    build('--canonical-tests' in sys.argv)
