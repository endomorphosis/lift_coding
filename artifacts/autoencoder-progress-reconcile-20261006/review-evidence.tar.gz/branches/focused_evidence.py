"""Bind scoped differences and patch IDs without importing any source module."""
from pathlib import Path
import concurrent.futures
import difflib
import hashlib
import json
import subprocess

ROOT=Path('/home/barberb/lift_coding')
OUT=Path(__file__).parent
def git(repo,*args):
    return subprocess.check_output(['git','--no-optional-locks','-C',str(repo),*args],stderr=subprocess.PIPE)
def digest(data):return hashlib.sha256(data).hexdigest()
def patch_ids(data):
    out=subprocess.check_output(['git','patch-id','--stable'],input=data)
    return [line.split() for line in out.decode().splitlines()]
def patch_review(kind):
    inventory=json.loads((OUT/f'{kind}-ref-worktree-inventory.json').read_text())
    repo=Path(inventory['repo']);target=inventory['target']
    def one(row):
        paths=[p['path'] for p in row['paths'] if p['path'].endswith(('.py','.md','.json','.sh','.ts'))
               and not '/evidence/' in p['path'] and not '/papers/' in p['path']]
        result={'commit':row['commit'],'merge_base':row['merge_base'],
                'effective_status_counts':{s:sum(p['status']==s for p in row['paths'])
                for s in {p['status'] for p in row['paths']}},'patch_review_scoped_paths':paths}
        if paths:
            patch=git(repo,'diff',row['merge_base'],row['commit'],'--',*paths)
            ids=patch_ids(patch)
            result.update(introduced_scoped_patch_sha256=digest(patch),introduced_scoped_patch_id=ids[0][0] if ids else None)
            main_patches=git(repo,'log','-p','--no-merges',target,'--not',row['merge_base'],'--',*paths)
            main_ids=patch_ids(main_patches)
            result['matching_main_commit_scoped_patch_ids']=[p for p in main_ids if ids and p[0]==ids[0][0]]
            result['main_commits_patch_ids_compared']=len(main_ids)
        return result
    candidates=[r for r in inventory['commit_analysis'] if not r['ancestor_of_main'] and r.get('paths')]
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool: rows=list(pool.map(one,candidates))
    (OUT/f'{kind}-patch-equivalence.json').write_text(json.dumps({'target':target,'branches':rows,
       'interpretation':'A missing patch ID match does not establish missing behavior; effective file blob inclusion is checked separately.'},indent=2,sort_keys=True)+'\n')
    print(kind,'patch-reviewed heads',len(rows),flush=True)

def canonical_differences():
    inventory=json.loads((OUT/'datasets-ref-worktree-inventory.json').read_text());repo=Path(inventory['repo']);target=inventory['target']
    live=next(w for w in inventory['worktrees'] if w['actual_source_worktree']==str(repo))
    baseline=json.loads((ROOT/'artifacts/autoencoder-integration-review-20261006/datasets-initial-inventory.json').read_text())
    previous_paths={line[3:] for line in baseline['status']}
    tree={}
    for row in git(repo,'ls-tree','-rz',target).split(b'\0'):
        if row:
            meta,path=row.split(b'\t',1);tree[path.decode()]=meta.decode().split()[2]
    result=[]
    for row in live['scoped_dirty_paths']:
        p=row['path']
        if row.get('same_bytes_as_main') is not False or not p.endswith(('.py','.md','.json','.sh')):continue
        data=(repo/p).read_bytes()
        record={**row,'path_present_in_prior_dirty_inventory':p in previous_paths,
                'main_blob':tree.get(p),'classification':'unpublished_local_path' if p not in tree else 'live_main_divergence'}
        if p in tree:
            main=git(repo,'cat-file','blob',tree[p]);record['main_sha256']=digest(main)
            if max(len(main),len(data))<=512*1024 and '/evidence/' not in p:
                text=''.join(difflib.unified_diff(main.decode(errors='replace').splitlines(True),data.decode(errors='replace').splitlines(True),fromfile='published-main/'+p,tofile='canonical-cwd/'+p))
                fn='canonical-'+digest(p.encode())[:12]+'.diff';(OUT/fn).write_text(text);record['full_diff_artifact']=fn
                record['diff_excerpt']=''.join(text.splitlines(True)[:80])
            else:record['diff_artifact_omitted']='Large evidence is bound by SHA256; source patch excerpt only.'
        if p.startswith(('ipfs_datasets_py/','scripts/')):
            try:
                import ast
                parsed=ast.parse(data)
                record['top_level_definitions']=[n.name for n in parsed.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))]
                record['imports']=[ast.unparse(n) for n in parsed.body if isinstance(n,(ast.Import,ast.ImportFrom))]
            except SyntaxError as error: record['syntax_error']=str(error)
        result.append(record)
    (OUT/'canonical-uncommitted-scope.json').write_text(json.dumps({'target':target,'paths':result,
      'tested':False,'models_imported':False,'classification_scope':'Presence in prior inventory binds path history, not byte history; active files remain uncommitted and untouched.'},indent=2,sort_keys=True)+'\n')
    print('canonical pinned differences',len(result),flush=True)

if __name__=='__main__':
    canonical_differences()
    for kind in ['datasets','workspace']:patch_review(kind)
