#!/usr/bin/env python3
"""Read pinned Git evidence without importing numerical/model owners."""
import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path('/home/barberb/lift_coding')
OUT = ROOT / 'artifacts/autoencoder-progress-reconcile-20261006/evidence'
DATA = ROOT / 'external/ipfs_datasets'
PINS = {
    str(ROOT): 'b0ba1aaa9c8a3f1d0e42bca31aa710f1108c686e',
    str(DATA): '795d960170214d03e2eaf4c0a13ad4eb922c5c08',
}


def git(repo, *args):
    return subprocess.check_output(['git', '-C', str(repo), *args])


def source(repo, commit, path):
    commit = git(repo, 'rev-parse', commit + '^{commit}').decode().strip()
    raw = git(repo, 'show', commit + ':' + path)
    return {
        'repository': str(repo), 'commit': commit, 'path': path,
        'git_blob': git(repo, 'rev-parse', commit + ':' + path).decode().strip(),
        'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
        'reachable_from_reviewed_main': subprocess.run(
            ['git', '-C', str(repo), 'merge-base', '--is-ancestor', commit, PINS[str(repo)]],
            capture_output=True,
        ).returncode == 0,
        'effective_main_identical': git(repo, 'rev-parse', commit + ':' + path)
        == git(repo, 'rev-parse', PINS[str(repo)] + ':' + path),
    }, raw


def read(repo, commit, path):
    ref, raw = source(repo, commit, path)
    return ref, json.loads(raw)


def pick(d, *keys):
    return {k: d[k] for k in keys if k in d}


def compact_bindings(value, prefix=''):
    """Index artifact receipts and explicit identity scalars, excluding weights."""
    found = []
    if isinstance(value, dict):
        if isinstance(value.get('path'), str) and isinstance(value.get('sha256'), str):
            found.append({'json_pointer': prefix, **pick(value, 'path', 'sha256', 'bytes', 'tensor_sha256')})
            return found
        for k, v in value.items():
            pointer = prefix + '/' + k.replace('~', '~0').replace('/', '~1')
            if isinstance(v, (dict, list)) and k not in {'tensors', 'weights', 'optimizer_state', 'state_dict'}:
                found.extend(compact_bindings(v, pointer))
            elif isinstance(v, (str, int, float, bool)) and (
                k.endswith(('checkpoint_sha256', 'tensor_sha256', 'codec_sha256', 'corpus_sha256',
                            'source_rows_sha256', 'source_contexts_sha256', 'model_revision',
                            'code_revision', 'profile_id', 'format_id', 'lineage_id'))
                or k in {'repository_id', 'source_generation', 'input_profile'}
            ):
                found.append({'json_pointer': pointer, 'value': v})
    elif isinstance(value, list):
        for i, v in enumerate(value):
            if isinstance(v, (dict, list)):
                found.extend(compact_bindings(v, prefix + '/' + str(i)))
    return found


prior_ref, prior = read(ROOT, PINS[str(ROOT)],
    'artifacts/autoencoder-integration-review-20261006/findings/evidence-matrix.json')
entries = []
for old in prior['entries']:
    ref, raw = source(Path(old['source']['repository']), old['source']['commit'], old['source']['path'])
    assert old['source']['sha256'] == ref['sha256']
    assert old['source']['bytes'] == ref['bytes']
    e = dict(old)
    e['source'] = ref
    e['catalog_origin'] = 'preserved_previous_16_study_review'
    e['exact_published_identity_bindings'] = compact_bindings(json.loads(raw)) if ref['path'].endswith('.json') else []
    e['identity_scope'] = ('All extracted exact artifact receipts and explicit profile/checkpoint/codec identity scalars in the cited JSON; '
                           'absence does not mean no asset exists. Markdown-only entries require their cited primary subordinate manifests.')
    entries.append(e)

diag_path = 'docs/implementation/reports/evidence/decoder-paraphrase-modality-margins-20261006/results.json'
diag_ref, diag = read(DATA, '7a16fc065', diag_path)
entries.append({
    'id': 'paraphrase-modality-source-recurrent-diagnostic-20261006',
    'source': diag_ref, 'catalog_origin': 'new_since_prior_review',
    'kind': 'frozen_decoder_diagnostic', 'domain': 'legal_ir', 'widths': [384, 768],
    'actual_work': pick(diag, 'complete', 'decoder_states_executed', 'training_executed', 'encoder_executed',
                       'all_archived_predictions_exact', 'new_decoder_loss_or_predictions_improved', 'fresh_holdout',
                       'lake_executed', 'compiler_output_executed', 'checkpoint_promoted', 'protected_teacher_modified'),
    'panels': diag['panels'], 'recipe': diag['recipe'],
    'exact_published_identity_bindings': compact_bindings(diag),
    'independent_review': pick(diag, 'independent_check_count', 'independent_float32_coordinates_checked',
                               'maximum_component_metric_absolute_difference', 'resources_released'),
    'findings': ['Four unique selected tensors; selected/last endpoints are aliases.',
                 'Exposed-v3 paragraph exact counts are384D20/48→19/48 and768D46/48→46/48; no prediction improved.',
                 'Most modality failures already originate in the source head; positive384D adds one source-correct recurrent override.'],
    'limitations': ['Same familiar authored sources repeated across arms; no new independent holdout or semantic qualification.',
                    'Source/recurrent additive logits describe actual-prefix decisions, not separate complete decoders or causal feature interventions.'],
})

context_base = 'docs/autoencoders/evidence/contextual-legal-runtime-20261006/'
context_ref, context = read(DATA, '39f25777d', context_base + 'separate-evaluation.json')
generation_ref, generation = read(DATA, '39f25777d', context_base + 'generation-qualification.json')
context_lanes = []
for width in (384, 768):
    ref, plan = read(DATA, '39f25777d', context_base + str(width) + '-metadata-plan.json')
    lane = next(x for x in context['lanes'] if x['dimension'] == width)
    context_lanes.append({
        'metadata_source': ref,
        'request': plan['request'], 'artifact_receipts': plan['artifact_receipts'],
        'model_tensor_sha256': plan['model_tensor_sha256'], 'codec_sha256': plan['codec_sha256'],
        'input_transform_sha256': plan['input_transform_sha256'],
        'saved_preprocessing_sha256': plan['saved_preprocessing_sha256'],
        'state_serialization_schema': plan['state_serialization_schema'],
        'native_ir_schema_version': plan['native_ir_schema_version'],
        'decoder_format_id': plan['decoder_format_id'], 'decoder_profile_id': plan['decoder_profile_id'],
        'authority': plan['authority'], 'budgets': plan['budgets'], 'input_contract': plan['input_contract'],
        'ordered_source_cohort_ids': plan['row_ids'], 'row_receipts': plan['row_receipts'],
        'evaluation': lane,
    })
context_reviews = []
for path in ['review/final-facade-review.json', 'review/adversarial-final-receipt.json',
             'review/architecture-review.json', 'source-survey/docs-final-review.json']:
    ref, reviewed = read(DATA, '39f25777d', context_base + path)
    context_reviews.append({'source': ref, 'published_review': pick(reviewed, 'schema', 'approved', 'passed',
        'findings', 'independently_executed_controls', 'endpoint_source_closure_stable', 'limits')})
entries.append({
    'id': 'cached-contextual-legal-ir-original-assets-20261006',
    'source': context_ref, 'generation_source': generation_ref, 'runtime_source_commit': generation['datasets_head'],
    'catalog_origin': 'new_since_prior_review', 'kind': 'opt_in_original_asset_runtime_replay',
    'domain': 'legal_ir', 'widths': [384, 768], 'lanes': context_lanes,
    'actual_work': pick(generation, 'completed', 'source_only_generation', 'original_targets_opened_during_generation',
                      'encoder_executed', 'fitting_executed', 'optimizer_executed', 'database_or_network_executed',
                      'fresh_holdout', 'native_profile_qualified', 'proof_authority'),
    'independent_reviews': context_reviews,
    'findings': ['Each width generates48/48 original-cohort ordered semantic IR and canonical contracts, preserving180/180 rules.',
                 'Both source-withheld deterministic text baselines score0/48 verbatim and NFC/whitespace prose equality.',
                 'These selected parents also initialize newest normative-wording fits; new endpoints are not automatically contextual runtime registrations.'],
    'limitations': ['Empty reference qualifiers; exposed authored original48 panel; no fresh semantic holdout.',
                    'Native schema, decoder format and decoder profile identities remain null in the published plans.',
                    'Production runtime, teacher, native profile and proof authority flags remain false.',
                    'CanonicalRoundTripIR@1 sorting/deduplication is a distinct metric from ordered seven-field semantic IR.'],
})

word_path = 'docs/implementation/reports/evidence/decoder-normative-wording-20261006/results.json'
word_ref, word = read(DATA, PINS[str(DATA)], word_path)
word_manifest_ref, word_manifest = read(DATA, PINS[str(DATA)], word_path.replace('results.json', 'manifest.json'))
dev_base = 'artifacts/autoencoder-wording-fit-20261006/development/'
dev_receipt_ref, dev_receipt = read(ROOT, PINS[str(ROOT)], dev_base + 'development-corpus-receipt.json')
dev_sources_ref, dev_sources = read(ROOT, PINS[str(ROOT)], dev_base + 'source-rows.json')
dev_codec_ref, dev_codec = read(ROOT, PINS[str(ROOT)], dev_base + 'codec.json')
fit_arms = []
for width, arms in word['training'].items():
    for arm in arms:
        fit_arms.append(pick(arm, 'dimension', 'arm', 'seed', 'parent_state', 'states', 'bank', 'cache',
            'source_inventory', 'schedule', 'recipe', 'initial_parity', 'training_ref',
            'budget_completed', 'zero_arm_archived_replay_verified', 'fresh_optimizer', 'exact_optimizer_resume',
            'training_call_elapsed_seconds', 'full180_parent_readout', 'full180_postfit_readouts'))
entries.append({
    'id': 'normative-wording-paired-head-fit-20261006', 'source': word_ref,
    'catalog_origin': 'new_since_prior_review', 'kind': 'actual_restricted_formula_head_training',
    'domain': 'legal_ir', 'widths': [384, 768],
    'actual_work': pick(word, 'complete', 'training_executed', 'local_native_encoders_executed',
        'native_encoder_weights_updated', 'weights_downloaded', 'model_4096d_trained',
        'historical_8d_teacher_modified', 'fresh_holdout', 'original_development_meanings_previously_exposed',
        'input_reconstruction_mse_measured', 'current_compiler_executed', 'logic_family_projections_executed',
        'lake_executed', 'checkpoint_promoted', 'qualified', 'admitted', 'formalized', 'roundtrip_ok'),
    'arms': fit_arms, 'panels': word['panels'], 'development_recipe': word['recipe'],
    'source_cohort': {
        'source': dev_receipt_ref, 'source_rows': dev_sources_ref,
        'ordered_source_ids': [row['id'] for row in dev_sources],
        'published_corpus_receipt': dev_receipt,
        'codec': {'source': dev_codec_ref, 'published_codec': dev_codec},
    },
    'native_preparation': pick(word['native_preparation_audit'], 'dimensions', 'scope', 'passed', 'checks', 'limitations'),
    'independent_fit_review': pick(word['fit_audit'], 'schema', 'passed', 'checks', 'findings', 'limitations',
        'total_optimizer_updates', 'total_original_row_presentations', 'total_auxiliary_observed_clause_presentations',
        'total_auxiliary_positively_supervised_clause_presentations'),
    'independent_development_review': pick(word['development_audit'], 'schema', 'passed', 'checks', 'findings',
        'limitations', 'selected_pair_deltas', 'fidelity_limits', 'formula_ordered_exact_independent_target_equality_checked'),
    'archive': {'source': word_manifest_ref, 'manifest': {k:v for k,v in word_manifest.items() if k!='members'}},
    'findings': ['Four170-update fits complete680 optimizer updates; no encoder-weight training.',
                 'Selected384D wording exact55/60→60/60; five bears-a-duty obligations corrected; tokenCE0.0083256300→0.0025041777.',
                 'Selected768D exact60/60→60/60; tokenCE0.0015389897→0.0015766217,2.45% worse.',
                 'OriginalDEV remains48/48 every arm with slightly worse CE; selected and last-attempt tensors are identical aliases.',
                 'Real offline native preparation produces276 source vectors per width (216TRAIN+60development).'],
    'limitations': ['Prospective wording of previously exposed meanings, not an untouched semantic holdout or independent human review.',
                    'Thirty originalDEV rule identities rendered twice are60sources, not60independent original semantic groups.',
                    'Nonempty qualifiers are refused;32-token vocabulary does not imply32-token output limit (512).',
                    'Exposed-v3 retention on these new endpoint tensors and new richer sealed source groups remain unmeasured.',
                    'Evidence archive excludes actual model assets/private tensors/predecessor source trees; local authenticated dependencies remain necessary.'],
})

observer_ref, observer = read(ROOT, PINS[str(ROOT)],
    'artifacts/autoencoder-wording-fit-20261006/review/postfit_observer_integration_review.json')
entries.append({
    'id': 'prospective-observer-loss-definition-review-20261006', 'source': observer_ref,
    'catalog_origin': 'new_since_prior_review', 'kind': 'pure_metric_contract_review',
    'published_review': observer,
    'findings': ['Old identity-input MSE is not learned reconstruction; formula scoring does not consume embedding MSE.',
                 'Composition64 prior native-vector comparison remains incomplete; sources were excluded from wordingTRAIN.'],
    'limitations': ['No model executed in the review; trace prediction embedding reconstruction MSE remains unmeasured.'],
})

lineage_ref, lineages = read(DATA, PINS[str(DATA)], 'configs/autoencoders/legal_autoencoder_lineages.json')
assets_ref, assets = read(DATA, PINS[str(DATA)], 'configs/autoencoders/gte_multilingual_local_assets_v1.json')
inventory = []
for family in ['legal_ir', 'intent_ir', 'security_ir', 'codebase_ir']:
    for width in [8, 384, 768]:
        ref, cell = read(DATA, PINS[str(DATA)], f'docs/autoencoders/inventories/{family}/{width}d.json')
        inventory.append({'source': ref, **pick(cell, 'status', 'cell_id', 'dimension_profile',
            'existing_checkpoint_evidence', 'existing_cached_vector_rows', 'checkpoint_discovery_complete',
            'source_only_raw_text_decoder_admission', 'runtime_databases_created', 'remote_repository_created',
            'model_or_embeddings_modified'),
            'physical_store_status': cell['storage']['status'],
            'hub_status': cell['huggingface']['status'],
            'existing_read_only_descriptors': cell['huggingface']['existing_read_only_descriptors']})

policy_paths = ['docs/autoencoders/logic_output_requirements.md', 'docs/autoencoders/progress_integration.md',
    'docs/autoencoders/native_formal_decoders.md', 'docs/autoencoders/complete_features_and_ui_fidelity.md',
    'docs/autoencoders/ir_progress_recovery.md']
policy_refs = [source(DATA, PINS[str(DATA)], path)[0] for path in policy_paths]

supporting_native_reviews = []
for path in ['docs/implementation/reports/evidence/multidomain-training-20261001/summary.json',
             'docs/implementation/reports/evidence/modal-joint-20261001/summary.json',
             'docs/implementation/reports/evidence/legal-lineages-20260930/logic-output-requirements-validation.json']:
    ref, report = read(DATA, PINS[str(DATA)], path)
    supporting_native_reviews.append({'source': ref, 'published_report': report,
        'scope': 'Older separately scoped executed native/compiler-feature or synthetic joint-head evidence; not a new normative fit or independently reviewed legal-text holdout.'})
runtime_ref, _ = source(DATA, PINS[str(DATA)],
    'ipfs_datasets_py/optimizers/logic_theorem_optimizer/autoencoder_runtime_registry.py')
native_formula_ref, _ = source(DATA, PINS[str(DATA)], 'docs/autoencoders/native_formula_training.md')

review = {
    'schema': 'autoencoder-progress-reconciliation-evidence/v1', 'date': '2026-10-06',
    'reviewed_immutable_main_pins': PINS, 'prior_catalog_source': prior_ref,
    'review_execution': {'model_execution': False, 'training': False, 'encoder_execution': False,
        'git_mutation': False, 'canonical_edits': False, 'lake_execution': False, 'downloads': False},
    'entry_count': len(entries), 'entries': entries,
    'teacher_lineage': {'source': lineage_ref, 'published_catalog': lineages},
    'native768_assets': {'source': assets_ref, 'published_assets': assets},
    'family_width_inventory': inventory,
    'supporting_native_training_reviews': supporting_native_reviews,
    'native_runtime_capability_sources': [runtime_ref, native_formula_ref],
    'dimension_role_warning': 'Historical legal8 and source384/768/4096 embedding widths differ from native Intent/Security/UI structural feature widths and bottleneck latent widths. Native formula_v1 latent widths up to64 do not establish a native768 raw-text decoder. Codebase family/width plans are supplementary and do not replace UI native evidence.',
    'metric_definitions': {
        'identity_mse': 'Comparison of input with itself or preserved input representation; cannot establish learned decoder reconstruction.',
        'vector_reconstruction_mse': 'AE-produced reconstructed source vector versus source embedding, with frozen producer/profile and TRAIN-fitted preprocessing; no semantic fidelity by itself.',
        'formula_token_ce': 'Teacher-forced token cross-entropy under specific target codec; distinct from greedy exact formula output.',
        'scalar_head_ce': 'Full-vocabulary source/recurrent/combined logits at actually visited scalar sites; masks and unvisited sites must remain explicit.',
        'ordered_ir_exact': 'Complete ordered seven-field generated rule document equality; includes qualifiers and rule multiplicity.',
        'canonical_contract_exact': 'CanonicalRoundTripIR@1 payload equality after contract sorting/deduplication; different from ordered IR.',
        'original_text_exact': 'Separate UTF8 byte and NFC/whitespace equality; semantic-only IR does not retain arbitrary lexical choices.',
        'native_feature_loss': 'Reconstruction of compiler-prepared native-domain feature targets; atom support denominators can drive large gains.',
        'lake_validation': 'Actual source-bound lake build <Lib> execution with exact scope; successful structure typecheck alone does not establish source meaning.',
    },
    'qualification_policy_sources': policy_refs,
    'qualification_invariants': [
        'Constitution remains unformalized and cannot become roundtrip_ok from this review.',
        'Typed parser/compiler/decompiler/source-tree pins remain binding; authenticated historical numerical closure is not a current compiler benchmark.',
        'Eight distinct Legal family requirements remain; CEC and DCEC do not collapse; applicable code/state/TLA routes remain separately checked.',
        'Only actual successful applicable source-bound lake build <Lib> can grant Lean admission; raw Lean diagnostics, catalog registration, identity hashes, enum labels and MSE cannot.',
        'Source custody, family scope, native format, checkpoint quality, teacher qualification and proof authority are separate evidence claims.',
        'Existing family-width inventory files are declarative plans; planned stores/Hub repos and null profile IDs are not executable qualified runtimes.',
    ],
    'recommended_next_gap': {
        'immediate': 'Observe the newest384D/768D endpoint tensors on the already exposed-v3 retention cohort under original codec/cache/policies; do not treat it as a fresh holdout or promote endpoints from wording60 alone.',
        'next_training_prerequisite': 'Admit independently reviewed source/formalTRAIN pairs with complete nonempty qualifiers, scope/negation/context and multi-rule composition; establish lossless decoder/profile compatibility first.',
        'evaluation': 'Seal fresh source groups disjoint by semantic/source identity before fitting; preserve source-bound references and applicable per-family native/Lake checks.',
        'comparison': 'Use matched raw/PCA/AE conditioners and separately trained compatible decoders with equal architecture, updates, initialization, selection and output budgets; report whole-rule/facet fidelity separately from MSE/CE/cost.',
        'reuse': 'Preserve immutable8D teacher, cached contextual parents, native384/768 producers, actual scoped Intent/UI/Security findings and exact source/version/cache owners.',
        'not_yet_ready': 'The64-source authored corpus has reusable source embeddings but formal reviews/masks remain pending; its richer targets do not fit current32-token Legal grammar.',
    },
}

OUT.mkdir(parents=True, exist_ok=True)
(OUT/'evidence-review.json').write_text(json.dumps(review, indent=2, ensure_ascii=False)+'\n')
md = '''# Autoencoder evidence reconciled on 2026-10-06

The review preserves the previous sixteen studies and adds four newly published evidence lanes. It reads immutable local Git objects; no training, model, encoder, proof, download, source or Git mutation occurred. Dataset main is `{datasets}`; workspace main is `{workspace}`. [The catalog](evidence-review.json) records exact Git blobs, byte counts, SHA256 identities, teacher/source producer lineage, checkpoints, codec/cache/cohort joins and published independent reviews. Historical report bodies remain pinned to their own commits rather than being relabelled as current source benchmarks.

| Evidence lane | Actual result | Limits and consequence |
| --- | --- | --- |
| Preserved 8D linguistic teacher | Immutable June full teacher hash7236de26… with1,205,336rows; historical runtime separately pinned | Source embedding provenance unknown; deterministic linguistic codec; target-aware reconstruction and text provenance do not prove semantics |
| Initial 8D learned formula sidecar | OriginalDEV1/48; exposed wording0/48 | Different decoder from protected teacher |
| Original contextual384/768 replay | Both48/48 ordered semantic IR and canonical contracts;180rules retained; original prose0/48 | Exposed48-source empty-qualifier cohort; source-withheld text baseline has no trained prose decoder; native schema/profile IDs remain null |
| New normative384 paired fit | Prospective wording55/60→60/60; CE0.0083256300→0.0025041777 | Five duty-wording obligations repaired; selected/last are tensor aliases;30previously exposed meanings rendered twice |
| New normative768 paired fit |60/60→60/60; CE0.0015389897→0.0015766217 | Control already exact; no uniform width gain or promotion |
| Parallel exposed-v3 diagnosis |384exact20/48→19/48;76846/48→46/48; all archived generations replayed | Distinct endpoint/cohort from original48 and newest prospective60; source heads already wrong in most modality errors |
| Native4096 head training | Two-clauseTRAIN2/2; broader exposedDEV0/12 in both scaling arms | Real readiness/fitting, unestablished broader source generalization |
| Source-only8/384/768 MLPs | Nine expanded models lower authoredDEV vector MSE; all trail TRAIN-onlyPCA |1,827updates include27private controls; no admitted semantic/formal/proof masks; distinct from formula sidecars |
| Intent/UI fixed schema | Ridge24/24 per domain on sealed known-vocabulary compositions;14actual native builds | Fixed target shape; some incorrect UI candidates pass Lake; source fidelity remains distinct |
| Complete native feature support |26,986Intent/7,329UIatoms;20actual Lake builds; lower common-support losses | Coverage restoration/compiler-feature target reconstruction; family regressions remain |
| UI authored modal floor |23fixtures;9UIUXIRbuilds; seven-entry floor satisfied | Authored projections, no neural fit; richer575–759token targets exceed unchanged64token codec |
| Security production decoder | Bounded learned production choices generate AST candidates independently reparsed | Parser-scaffolded coverage; separate44-feature advisory checkpoint has no formula head; arbitrary software/specification fidelity absent |
| Frozen conditioner/span controls | Raw/PCA/AE agreed on outputs in frozen decoder study; joint policy increases proposals10→183/192 | Raw-trained decoder weights unchanged; structural proposals require independent meaning/family review |

The newest wording study executes680head updates and real offline native preparation of276vectors per width. It executes no encoder-weight fitting, current compiler, logic projection or Lake build. Every originalDEV arm remains48/48 with slightly worse CE. Its archive records local dependency requirements and excludes actual model assets/private checkpoint tensors. Endpoint availability does not establish production registration or qualification.

Checkpoint joins are explicit: contextual original384 parent SHA256`0ac5c21656187d1d8040a02bcc0b4716a8093db17f05adc9a22e99d5b6b2cc00`, tensor`6a527b568c1ec834fc6704a9d12a17532840076432a93dc1390c59c92d483ec3`;768 parent`8892a3261c0750a6247ba5400069ed18cad3354426e2095ed1d295287e3559b4`, tensor`8900d69fb00c17a54b7d3cbe6fbd2c24651b614839ad57c588d0f04dc308fada`. These initialize the new fits, but their new endpoint hashes are distinct. Both contextual lanes use codec hash`cba3e5384e2bee12e709ccc8e9ee430e51cf09a8fc2e8abdd57143fdaa38dba2`; the separately serialized prospective codec has its own artifact digest. Exact ordered row IDs and per-row source/context/vector receipts remain in the JSON.

Source profiles also stay distinct.8D formula diagnostics use nonsemantic feature hashes, while historical teacher embedding provenance is unknown.384D uses native GTE-small and768D native multilingual GTE with separate model/code revisions and CLS/L2 production. Existing768declarations allow8192tokens, but current experiments use512;4096is another native lineage. They cannot support a pure dimension-only ablation. Family/width inventory plans describe prospective physical stores and repositories; planned cells and cached bytes are not evidence that those runtimes or training lanes executed.

Identity-input MSE is not learned reconstruction. Actual source-AE vector MSE, teacher-forced tokenCE, full-vocabulary scalarCE, greedy ordered IR exactness, canonical contract exactness, original-prose equality, compiler-native feature loss and native proof checks must remain separately named and scoped. No score should pool the original48, exposed-v348, twice-rendered prospective60, TRAIN32/DEV32 source-only corpus or authored native-family fixtures as a common benchmark. Selected/last tensor aliases and duplicate conditioning publications are retained as aliases, not independent replications.

The immediate next check is exposed-v3 retention for the four new endpoint tensors. The next training gap is independently reviewed richer source/formal pairs with complete nonempty qualifiers, scope, negation/context and multi-rule composition under a compatible lossless decoder contract. Seal fresh source groups before fitting and compare matched raw/PCA/AE conditioners with separately trained compatible decoders. Existing64source native caches are reusable source evidence; pending formal reviews and zero semantic masks cannot supply admitted targets, and richer targets cannot be simplified into the current32token Legal grammar.

Maintain source-tree pin invariants, the eight distinct Legal families and applicable code/state/TLA routes. Only actual successful source-bound`lake build <Lib>` supplies Lean admission. Structural checks, raw Lean diagnostics, feature reconstruction, metadata registration and deterministic teacher agreement confer no source-meaning or proof authority. The Constitution remains unformalized.
'''.format(datasets=PINS[str(DATA)], workspace=PINS[str(ROOT)])
(OUT/'evidence-review.md').write_text(md)
print(json.dumps({'entries':len(entries),'json_bytes':(OUT/'evidence-review.json').stat().st_size,
                  'markdown_bytes':(OUT/'evidence-review.md').stat().st_size}))
