"""Read-only Git/report review; writes only this review's evidence artifacts."""
import hashlib,json, pathlib, subprocess
W=pathlib.Path('/home/barberb/lift_coding'); P=W/'external/ipfs_datasets'; OUT=W/'artifacts/autoencoder-integration-review-20261006/findings'
def git(repo,*args): return subprocess.check_output(['git','-C',str(repo),*args])
def source(repo,revision,path):
 commit=git(repo,'rev-parse',revision).decode().strip(); body=git(repo,'show',f'{commit}:{path}')
 return {'repository':str(repo),'commit':commit,'path':path,'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest(),'reachable_from_reviewed_origin_main':subprocess.run(['git','-C',str(repo),'merge-base','--is-ancestor',commit,'origin/main'],capture_output=True).returncode==0},body
entries=[]
def add(id,repo,rev,path,kind,scope,findings,limitations,next_gap):
 binding,body=source(repo,rev,path)
 entries.append(dict(id=id,source=binding,kind=kind,scope=scope,findings=findings,limitations=limitations,next_gap=next_gap))
base='docs/implementation/reports/evidence/'
add('preserved-8d-linguistic-teacher',P,'0ced2e533','docs/autoencoders/legacy_linguistic_validation_20261001.md','historical-runtime-preservation','8D sparse residual runtime around deterministic linguistic codec',
 ['Original training/resume and retained-teacher compatibility are preserved independently of learned formula sidecars.','Target-aware vector reconstruction and provenance text decompilation can be exact without semantic fidelity.','Historical linguistic prohibition emits O while canonical compiler emits F; numeric duration structure remains incomplete.'],
 ['Deterministic linguistic formulas are not learned latent-to-formula generation.','Bridge-off timings have zero legal-IR targets.','No qualified legal teacher is established by this operational replay.'],'Distill explicitly reviewed shared semantic targets; keep teacher/source/runtime identities immutable.')
add('four-width-initial-head-comparison',P,'dce8ab819',base+'decoder-four-width-20261004/results.json','restricted-authored-formula-training','8D/384D/768D source-conditioned formula sidecars; encoders frozen',
 ['Six fits completed340updates each. Final dev exact8D1→1,384D47→48,768D46→44 outof48; exposedR6exact0→0,30→28,47→48.','All width comparisons change source producers; not an isolated width ablation.'],
 ['Selected vs final-attempt checkpoints differ.','8Dsidecar score is not historical linguistic teacher fidelity.','Original4096readiness gap was later partially superseded.'],'Use later selected384/768parents and preserve oldcontrols; separately repair8Dsourceobject/cue fidelity.')
add('native4096-and-field-rates',P,'d466db01a',base+'decoder-conditioning-20261004/results.json','restricted-authored-formula-training','Native4096 source decoder matched conditioning +8D head-rate experiment',
 ['940headupdates: three4096fits200each; two8Dfits170each.','Scaled4096 final2/2TRAINexact, CE0.015291 versus0.018791unscaled; initial priorfreezing worsens.','8Dlowerrate reduces CE0.16349→0.14803 but devexact remains1/48 and object fidelity97→88/180.'],
 ['4096twoTRAINpermissionclauses differ only inobject; noholdout or broad-familyclaim.','8Dcandidate rejected; unchanged parent retained.','Noencodertraining orLake.'],'Improvebroadsourcefidelity before capacity or optimizer claims.')
add('broader4096-and-8d-geometry',P,'fd89d2a48',base+'decoder-generalization-20261004/results.json','restricted-authored-formula-training','Corrected8Ddiagnostic and broader4096authoredpanel; TRAINparaphrasepreparation',
 ['740headupdates completed.8Dcovariancecandidate worsensdevCE0.163492→0.168503 andobjects97→93/180.','Broader4096TRAIN12/dev12: originalTRAIN7/12,scaledTRAIN1/12; bothdev0/12exact.','Prepared216uniqueverifiednative384/768inputs each; production8.679s/26.969s.'],
 ['TRAIN-inputscaling notadopted.','Previous8Dgeometryomission affecteddiagnostics only.','Authoredexposedevaluation; noLake orpromotion.'],'4096requiresgeneralizingsemantic readout,notmoretwo-rowfitting.')
add('train-paraphrase-mixture',P,'aa586a9b9',base+'decoder-training-mixture-20261004/results.json','restricted-authored-formula-training','Original-only vs halfTRAINparaphrases384/768;170updates each',
 ['680updates;originaldev48/48allfits.','Exposedv3exact38420→18/48,76846→46/48.','Fitcalls38438.389/38.103s;76850.626/50.639s.'],
 ['Exposedv3isregressiondata,nofreshholdout.','Noencoderforwards;warmcachedvectors.','Changingmixturesdidnotimproveexactreconstruction.'],'Preserve originalbatchstreamwhiletestingnew semantic supervision.')
add('train-paraphrase-modality',P,'60f5c2951',base+'decoder-paraphrase-modality-20261004/results.json','restricted-authored-formula-training','IndependentbalancedR4modalityauxweight0vs0.05;384/768',
 ['680updates;232tests;zeroarmpreservesarchivedordinarytrainingresult.','Originaldev48/48. Exposedv3exact38420→19/48;76846→46/48.','ExposedCE3840.030589255→0.028552217;7680.003361466→0.003004750.','Fitseconds38440.964→42.164;76850.002→50.582;full180TRAINmodalityalready180/180beforefit.'],
 ['Noexactreconstructiongain;no promotion.','Additionalpositivesupervisedworkisexplicit;not equalFLOPs.','NoLake/bridgeevaluate/convergenceclaim.'],'Investigaterecurrent contribution and wording-specificmodalityerrors before increasing saturatedauxweight.')
add('source-margin-two-seed-study',P,'1b6461e65',base+'decoder-source-margin-20261004/README.md','restricted-authored-formula-training','18fits;340updates each;twoseeds;authoredR6cohort',
 ['Finalattempt768exact96/96andCE12.6%lowerthanzerocontrol;384exact61/96matching original butCE2.6%worse;8D0/96exact.','Both768positive finalstatesrejectedbyunchangedextra-ruleregressiongate;selected768exact0/96.'],
 ['Same48sources×2seeds arenot96independentexamples.','R6subsequentlyexposed;finalattemptisnotselectedqualifiedhead.'],'Targetmodality/whole-rulefidelityandstrictselection,notscore-onlypromotion.')
add('intent-ui-composition-ridge',P,'6589f7887',base+'intent-ui-coverage-20261002/results.json','source-to-typed-candidate-training','384Dfixedschema known-vocabularyIntent/UI24compositiontestrows/domain',
 ['Deterministicridge24/24exacteachdomain;GRUIntent3/24and8/24;UI3/24and2/24.','Ridgepublicfit~0.140s;warmreadout0.226ms/Intentspan,0.326ms/UIspan undercommonlocalnativecheckscope.','Nativefollowup14realbuildspass:5IntentIR,9UIUXIR;4wrongIntentpredictionsblockedbeforeLake.'],
 ['AlltestvocabularyseeninTRAIN;fixedshape/scalarclasses.','BuiltIntent10/40routes,UI2/40;everyreceiptpartial.','SixwrongUIbaselinepredictionsalsoLakebuildsuccess,showingLake alonecannotmeasuremeaning.'],'Addsource-boundfull-documentfidelity and richer targets; keep fixedschemaheadseparatefromGRU.')
add('complete-intent-ui-feature-loss',P,'df732e8aa','docs/autoencoders/complete_features_and_ui_fidelity.md','compiler-target-feature-reconstruction','Nativefamilyfeatureautoencoders;12fits;completevs4096atomcap',
 ['20actualLakebuildsIntentIR/UIUXIRand390projectionchecks.','Common-supportheldoutlossIntent0.026985→0.001958fixed;UI0.008037→0.002575fixed.','CoverageknownatomsIntent15.108→99.651%,UI56.543→97.876%;26,986Intent/7,329UIatomsretained.','Numericalrefinement7.55/315.04stotalfit;nativevalidation/preparationdominate.'],
 ['Gainslargelysupportrestoration;individualfamilylossregressionsremain.','Adaptivepathnobroadwin;fixedremainsdefault.','Structuralcompiler-targetlossisnotindependent source-to-formula fidelity.'],'Reusecompletecoverageaccountingandguardednativechecks;addressfamilyregressions anddecodergrammar.')
add('ui-temporal-dcec-floor',P,'ea275ae32',base+'ui-modal-coverage-20261002/results.json','authored-native-projection-validation','23declaredfixtures;noAEinferenceoroptimizer',
 ['9/9actual lakebuildUIUXIR;12/12newmodaloccurrencesparser/lowering/Lakepass.','UIseven-entryminimumfloor satisfied;7/40familiesvalidatedsomewhereinthefixtureunion.','Allstricttraininggatesremainclosed;compoundtargets575–759tokens exceedunchanged64tokencodec andgrammar.'],
 ['Declaredbelief/norm/traceinterpretationisnottruth orobservedruntimebehavior.','Authoredpreparedtargetsarenotlearneddecoderoutputs.'],'Create losslesssupportedtargetencoding and source-specific40familyreviewswithouttruncation/contextincrease.')
add('security-production-head',P,'2d93857e7','docs/security_formula_decoder.md','bounded-source-production-decoder','Parser-providedtopology+names+constants;learnedgrammarproductions;separatehead',
 ['ActuallearnedproductionchoicesfeedcandidateAST;independentreparsecomparisonrejectsincorrectoutputs.','Complete-functionbyte-map/sourceadaptersandmodel-offcontrolsretainunsupportedfunctions.','SupervisorModelManager/DuckLakeconsumescandidateobservations+nativeproof-workplans.'],
 ['Notarbitrarysoftwareformalizationorlearnedsecurityspecification.','AdvisorySecurity-CVE44ASTfeaturecheckpointremainsunchangedwithnoformulahead.','AuthoredcontractsandSMTdiagnosticsgrantnolaw/sourcequalification.'],'Keepadvisoryclassificationandformulaheadidentitiesseparate;extendadmittedgrammar/scopeandindependentfunctioncoverage.')
wb='artifacts/autoformalization-publication-20261004/'
add('source-ae-frozen-control',W,'e44254d4',wb+'evaluation/frozen-development-summary-01.json','source-vector-reconstruction-and-retrieval','9source-only8/384/768AEseeds;TRAIN16;authoredDEV',
 ['AllneuralmodelsbeatTRAINmeanvectorMSEbutalltrailTRAINPCA.','384latentfacetnDCGmean0.96408versusraw0.96190;768latent0.95623versusraw0.98384.','Noformal-target/proof supervision;authoredrelevanceonly.'],
 ['DensecenteredTRAINrank15below32/64bottlenecks.','Retrievalgeometry/organizerreferenceisnotsemanticaccuracy.','TheseMLPAEsarenotPsparseresidualruntimeorformulasidecars.'],'Retainraw/mean/PCA controls and defineformal-targetalignmentseparately.')
add('source-ae-authored32-expansion',W,'67bd5f1a',wb+'expansion/expanded-summary-01.json','source-vector-reconstruction-training','64authoredsources;TRAIN32DEV32;9newMLPAEfits8→16→4,384→128→32,768→128→64',
 ['1827actualupdatesincludingprivateresumechecks;1800selectedupdates;200permodel.','DEVmeanMSEimprovementvsoldsame-seedmodels82.36%,80.94%,77.03%;everynewmodelstillworsethanTRAINPCA.','ImmutableHFreleasePublicus/legal-ir-autoencoder@d624057cf58e0090a0db9a3ad25857aaa91357de.'],
 ['All5semantic/decoder/contrastive/proof/fidelitymaskszero.','ChangedTRAINcohortmeasuresadaptation,notisolatedcohort-sizebenefit.','DEVrank31limits32/64capacityinterpretation.'],'Admitricherpairedsource/formaltargetsandcomparematcheddecoders,nothighercapacitybyvectorMSE.')
add('frozen-law-conditioner-interventions',W,'b48ec0fb',wb+'downstream/summary-01.json','frozen-native768-source-span-decoder-inference','64sources×3seeds×6conditions=1152rowforwards',
 ['Raw/PCA-reconstructed/AE-reconstructed/rotatedrawgenerateidenticalIR/status/reasonall64sourcesperseed.','Rawproposals1/64,1/64,8/64;182/192otheroccurrencesoverlapabstain.','Zero/disabledchange3pairedsource-seedoutcomeseach;internalconditioningscoresareactive.'],
 ['Full768inverse-reconstructionsperturbraw-traineddecoder;notmatchedconditionertrainingorcompression.','Alloutputsproposals;nofidelitylabels orproof.'],'Repairsource-spanassignment/symbolbindingandoptionalpresence before capacityselection.')
add('bounded-joint-span-policy',W,'ec4302ac',wb+'joint_span/results-02/summary-01.json','frozen-native768-policy-diagnostic','192sharednativeforwards;384greedy/jointoutcomes',
 ['Proposals10→183/192;all10previouspreserved;173overlapabstentionsyieldnewunacceptedproposals.','Top16candidate spans/beam64;9retained-searchabstentions.','Workerwall8.462s,parent10.271s;724032KiBmaxworkerRSS;excludesencoding/fit.'],
 ['Singlecopieddeonticrule;actor/modality/qualifiererrorsremain.','Everysearchpruned;nofullspacesolution/globaloptimumclaim.','Structuralcoverageisnotsemanticgain.'],'Keepasdiagnosticproposalpolicy;reviewhead/attachment/presencefidelitybeforetrainingtargets.')
add('joint-span-six-condition-control',W,'3b39519d',wb+'joint_conditioning/results-01/summary-01.json','frozen-native768-policy-diagnostic','1152forwards;2304pairedpolicyoutcomes;3seeds×6conditions',
 ['Raw/PCA/AEjointIR/status/reasonidenticalall192pairedsource-seedoccurrences;each183proposals.','Rotationchanges1jointmodalityrecord;zero26/disabled31jointIR/status/reasonrecords.','Acrossallcontrols1099jointversus61greedyproposals;all61preserved.','Workerwall20.665s,parent22.443s;774896KiBmaxworkerRSS.'],
 ['Broadfamily/independentreviewmaskszero;noadmittedcandidate.','Shares64sources/checkpointswithpreviousrounds;donotaddasindependentconfirmation.','ZeroFiLMbiasanddisabledgatearemechanisticallydifferent.'],'Reviewsource-role/modality/negation/attachment/presencepairs,thenmatchedraw/PCA/AE/source-onlytraining.')
heads={str(repo):git(repo,'rev-parse','origin/main').decode().strip() for repo in (W,P)}
report={'schema':'autoencoder-findings-integration-review/v1','date':'2026-10-06','reviewed_remote_heads':heads,'model_execution':False,'encoder_execution':False,'weights_downloaded':False,'canonical_files_changed':False,'entries':entries,
'non_aggregation_rules':['No poolingexposed48rows×seeds asindependentholdouts.','No poolingvectorsourceMSE,formulaCE,andLakecount intoonesuccessmetric.','No tensor/update mergeacrossruntime/decoder/embeddingprofiles.','No claimingWnewMLPlegacy8asprotected8Dhistoricalteacher.','No promotionfromlastattemptthatunchangedgaterejected.'],
'next_priorities':['Unifyevidenceregistrybylineage,encoderprofile,decodergrammar,sourcegenerationandformal/proofscope.','Integratenewownersintomainwithoutchangingoldercheckpoint/sourcepins orfrozenreplayowners.','Admitindependentlyreviewedsource/formalpairscoveringmodality,negation,anchors,scope,qualifierpresence andmultiple rules.','Runmatchedraw/PCA/AEandsource-onlydecodercomparisononlyaftercompatibletargetgrammarandadmittedTRAINpairs.','Reusefullatom/familycoverageandrealLakegatesseparatelyfromsourcefidelity;do nottruncateunsupportedtargets.','Keep8Dlinguisticteacherimmutable;repairitssemanticdefectsinseparatelyversionedprofile orreviewedteacherlabels.','4096broaddev0/12needsdecodinggeneralizationbeforelargercampaign.']}
(OUT/'evidence-matrix.json').write_text(json.dumps(report,indent=2)+'\n')
# Preserve concise authentic scalars from the published W summaries.
scalars={}
for key,p in [('frozen',wb+'evaluation/frozen-development-summary-01.json'),('expanded',wb+'expansion/expanded-summary-01.json')]:
 binding,body=source(W,heads[str(W)],p); d=json.loads(body)
 scalar={'source':binding,'lanes':{}}
 for name,x in d['lanes'].items():
  scalar['lanes'][name]={k:v for k,v in x.items() if k in ['all_neural_seeds_better_than_train_mean_mse','all_neural_seeds_worse_than_train_pca_mse','all_new_seeds_better_than_old_same_seed_mse','all_new_seeds_worse_than_train_pca_mse','new_mean_mse_reduction_fraction_against_old_models','pca_effective_rank','pca_retained_axes']}
  for field in ['development_raw_coordinate_mse','development_mse','authored_positive_mean_graded_facet_ndcg_at_5']:
   if field in x:scalar['lanes'][name][field]={k:v['mean'] for k,v in x[field].items() if isinstance(v,dict) and 'mean' in v}
 scalars[key]=scalar
(OUT/'published-scalars.json').write_text(json.dumps(scalars,indent=2)+'\n')
print(json.dumps({'entries':len(entries),'all_entries_reachable_from_origin_main':all(x['source']['reachable_from_reviewed_origin_main'] for x in entries),'heads':heads,'matrix_sha256':hashlib.sha256((OUT/'evidence-matrix.json').read_bytes()).hexdigest()}))
prose=json.loads((OUT/'prose.json').read_text())
for entry in report['entries']:
 entry.update(prose[entry['id']])
report['non_aggregation_rules']=[
 'Repeated observations of 48 sources under different seeds are not independent holdouts.',
 'Source-vector MSE, formula token CE and Lake counts measure different objectives.',
 'Do not merge tensors or sparse updates across runtime, decoder grammar or embedding profiles.',
 'The new source-only 8→16→4 MLP is distinct from the protected historical 8D linguistic teacher.',
 'A final attempt rejected by an unchanged gate cannot be promoted from its diagnostic score.'
]
report['next_priorities']=[
 'Unify evidence by lineage, encoder profile, decoder grammar, source generation and formal/proof scope.',
 'Integrate reviewed owners into main while preserving frozen replay sources and existing checkpoint pins.',
 'Admit independently reviewed source/formal pairs for modality, negation, source anchors, qualifier scope/presence and multiple rules.',
 'Compare matched raw/PCA/AE and source-only decoders after target grammar compatibility and TRAIN-pair admission.',
 'Reuse full atom/family accounting and actual Lake builds while testing source fidelity separately; do not truncate unsupported targets.',
 'Preserve the historical 8D teacher; repair semantic defects in separately versioned profiles or independently reviewed teacher targets.',
 'Broader 4096D development remains 0/12 exact and needs decoder generalization before a larger campaign.'
]
(OUT/'evidence-matrix.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'final_matrix_sha256':hashlib.sha256((OUT/'evidence-matrix.json').read_bytes()).hexdigest()}))
