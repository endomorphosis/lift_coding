"""Validate local links, artifact joins and previously reviewed factual claims."""
import hashlib,json,pathlib,re
W=pathlib.Path('/home/barberb/lift_coding');P=W/'external/ipfs_datasets';B=W/'artifacts/autoencoder-integration-review-20261006';O=B/'findings'
def bound(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def read(p):return json.loads(p.read_text())
files=[P/'docs/autoencoders/progress_integration.md',P/'docs/autoencoders/four_width_training.md',P/'docs/autoencoders/README.md',W/'implementation_plan/docs/58-autoencoder-progress-integration-2026-10-06.md']
links=[]
for p in files:
 for link in re.findall(r'\]\(([^)]+)\)',p.read_text()):
  if link.startswith(('http:','https:')):continue
  target=(p.parent/link.split('#')[0]).resolve();links.append({'source':str(p),'destination':link,'exists':target.exists()})
checks=[]
def check(name,condition):
 assert condition,name;checks.append({'check':name,'passed':True})
check('all relative source/evidence links exist',all(x['exists'] for x in links))
ptext=files[0].read_text();wtext=files[3].read_text();gtext=files[1].read_text()
check('linguistic IR is explicitly deterministic under a neutral output header','Output or representation' in ptext and 'Feature reconstruction and deterministic linguistic IR' in ptext)
check('joint policy uses shared native scores rather than claiming an offline-only execution','same native forward scores for both policies' in ptext)
check('four-width opening preserves retrospective first-comparison scope','4096D was' in gtext[:1200] and 'unavailable in that comparison' in gtext[:1200] and '0/12 exposed development' in gtext[:1200])
check('default tree audit is explicitly an inventory','Default mode is an' in wtext and '--fail-on-missing' in wtext)
check('no source qualification or Constitution formalization is claimed','review grants no model promotion, semantic qualification or law formalization' in wtext and 'Constitution remains unformalized' in wtext and 'US Constitution remains unformalized' in ptext)
inputs=[]
for repo,expected_worktrees,expected_refs,expected_origin in [('workspace',35,298,35),('datasets',16,410,9)]:
 initial=B/(repo+'-initial-inventory.json');fetched=B/(repo+'-fetched-refs.json');di=read(initial);df=read(fetched);inputs.extend([bound(initial),bound(fetched)])
 check(repo+' inventory counts match docs',len(di['worktrees'])==expected_worktrees and len(di['refs'])==expected_refs)
 check(repo+' origin tracking count matches docs',sum(x['name'].startswith('refs/remotes/origin/') for x in df['refs'])==expected_origin)
 check(repo+' reviewed snapshots agree',di['origin_main']==df['main'] and di['origin_main'] in wtext and df['main'] in ptext)
r=B/'pipeline/recovery-candidates.json';dr=read(r);inputs.append(bound(r))
check('bounded historical recovery count and bytes match docs',len(dr['historical_recovery'])==23 and dr['historical_total_bytes']==699974)
check('publication recovery comprises twelve retained paths',len(dr['uncommitted_publication_recovery'])==12)
check('recovery report grants no execution or authority',dr['new_model_calls']==0 and dr['new_training_runs']==0 and dr['Hub_calls']==0 and dr['qualification_granted'] is False)
r=B/'pipeline/integration-review.json';dr=read(r);inputs.append(bound(r))
check('published canonical-source sample is 209 exact present files',dr['published_local_alignment_sources']['exact_same_main']==209 and dr['published_local_alignment_sources']['changed_shared']==0)
check('ancestor historical-source loss counts match docs',dr['effective_tree_regression']['branch_files']==1569 and dr['effective_tree_regression']['missing']==1082)
m=read(O/'evidence-matrix.json');inputs.append(bound(O/'evidence-matrix.json'))
check('matrix has sixteen ancestor-bound studies',len(m['entries'])==16 and all(x['source']['reachable_from_reviewed_origin_main'] for x in m['entries']))
d=read(O/'duplicate-publications.json');inputs.append(bound(O/'duplicate-publications.json'))
check('joint-conditioning duplicate is one identical evidence tree',d[0]['identical_scope'] is True and d[0]['changed_paths']==[])
report={'schema':'autoencoder-progress-doc-fact-review/v1','revision':'r3','sources':[bound(p) for p in files],'artifact_inputs':inputs,'checks':checks,'relative_links':links,'missing_relative_link_count':0,'findings':[],'prior_clarity_findings_resolved':True,
'manually_verified_numerical_claims':['The latest auxiliary study has four fits and 680 updates; development48/48, exposed exact20→19 and46→46, with CE reductions6.7% and10.6%.','Expanded MLPs use TRAIN32/DEV32 and nine selected models; they improve over older models but all trail TRAIN-only PCA.','Raw/PCA/AE frozen decoder parity holds for192paired source/seed occurrences; this is full768D inverse reconstruction into a raw-trained decoder.','The joint policy yields183/192 raw proposals from10, preserves all10, and retains unmeasured source-fidelity flags.','The later4096head evidence has two TRAIN pilot clauses and separate12-clause exposed development0/12; this is not a fresh test cohort.','Actual domain Lake builds are separate from the restricted decoder-head comparisons, which run no Lake.'],
'scope_limits':['Branch repairs and incoming wrapper changes are reviewed separately; this documentation audit does not attest their runtime behavior.','Remote Markdown links are to paths selected for publication; this review checks local relative paths and authentic local Git report contents, not network availability.','Saved branch inventory counts are exact joins to their retained reports, not a claim that every unrelated branch is reviewed.'],
'canonical_source_edited':False,'model_executed':False,'native_proof_executed':False,'qualified':False,'admitted':False}
(O/'progress-doc-fact-review-r3.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'checks':len(checks),'relative_links':len(links),'findings':0,'sha256':bound(O/'progress-doc-fact-review-r3.json')['sha256']}))
