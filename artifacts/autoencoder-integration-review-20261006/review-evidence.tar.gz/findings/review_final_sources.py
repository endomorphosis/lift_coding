"""Independent static review of additive interfaces and raw-compile accounting."""
import ast,hashlib,json,pathlib,subprocess,xml.etree.ElementTree as ET
W=pathlib.Path('/home/barberb/lift_coding');P=W/'external/ipfs_datasets';B=W/'artifacts/autoencoder-integration-review-20261006';O=B/'findings'
def bound(p):
 body=p.read_bytes();return {'path':str(p),'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()}
def git(repo,*args):return subprocess.check_output(['git','-C',str(repo),*args])
checks=[]
def check(name,condition):
 assert condition,name;checks.append({'check':name,'passed':True})
scope_path=B/'branches/ir-wrapper-restoration-final-source-scope.json';scope=json.loads(scope_path.read_text());sources=[]
for row in scope['paths']:
 p=P/row['path'];actual=bound(p);sources.append(actual)
 check('sealed wrapper path matches current bytes: '+row['path'],actual['bytes']==row['bytes'] and actual['sha256']==row['sha256'])
 if row['path'].endswith('checkpoint_hub.py'):
  old=git(P,'show',scope['origin_main']+':'+row['path']);current=p.read_bytes()
  check('checkpoint_hub exact original source prefix preserved',current.startswith(old))
  ta=ast.parse(old);tb=ast.parse(current);olddefs={x.name:ast.dump(x,include_attributes=False) for x in ta.body if isinstance(x,(ast.FunctionDef,ast.ClassDef))};newdefs={x.name:ast.dump(x,include_attributes=False) for x in tb.body if isinstance(x,(ast.FunctionDef,ast.ClassDef))}
  check('all original checkpoint_hub definitions unchanged',all(newdefs.get(k)==v for k,v in olddefs.items()))
  check('exactly four opt-in checkpoint_hub APIs added',set(newdefs)-set(olddefs)==set(row['addition_functions']))
 else:
  original=git(P,'show',row['producer_commit']+':'+row['path'])
  check('restored path is byte-identical to retained producer: '+row['path'],original==p.read_bytes())
check('thirteen scoped wrapper paths present',len(scope['paths'])==13)
# Resolve false authority dictionaries using AST data only; never import numerical owners.
authorities={}
for module,aliases in [('ir_cell_runtime',{}),('ir_cell_target_compatibility',{'runtime':'ir_cell_runtime'}),('ir_original_corpus_runtime',{'cached':'ir_cell_runtime'}),('ir_decoder_format_runtime',{'original':'ir_original_corpus_runtime'}),('ir_decoder_profile_inventory',{'formats':'ir_decoder_format_runtime'})]:
 tree=ast.parse((P/f'ipfs_datasets_py/logic/formalization/autoencoder/{module}.py').read_text());expr=next(n.value for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='_AUTHORITY' for t in n.targets))
 if isinstance(expr,ast.Call):
  check(module+' authority initializer is closed dict',isinstance(expr.func,ast.Name) and expr.func.id=='dict' and not expr.args)
  vals={k.arg:ast.literal_eval(k.value) for k in expr.keywords}
 else:
  vals={}
  for key,value in zip(expr.keys,expr.values):
   if key is None:
    assert isinstance(value,ast.Attribute) and value.attr=='_AUTHORITY';vals.update(authorities[aliases[value.value.id]])
   else:vals[ast.literal_eval(key)]=ast.literal_eval(value)
 authorities[module]=vals;check(module+' qualification/authority flags explicitly remain false',all(v is False for v in vals.values()))
# Verify raw-Lean patch changes only the recorded current probe/test preimages.
raw=B/'pipeline/raw-lean-probe-tests-r2.json';dr=json.loads(raw.read_text());sources.extend(bound(W/r['path']) for r in dr['owned_changes'])
for row in dr['owned_changes']:
 check('raw compile source matches tested bytes: '+row['path'],bound(W/row['path'])['sha256']==row['source_sha256_after'])
owner=W/'scripts/autoformalization_recovery_probe.py';before=B/'pipeline/autoformalization_recovery_probe.py.preimage';old=ast.parse(before.read_text());current=ast.parse(owner.read_text())
def defs(tree):return {n.name:ast.dump(n,include_attributes=False) for n in tree.body if isinstance(n,ast.FunctionDef)}
da,db=defs(old),defs(current)
check('raw Lean proof grammar/request controls unchanged',all(da[n]==db[n] for n in ['proof_policy','parse_body','command']))
check('raw Lean changed definitions are narrowly scoped',{n for n in da if da[n]!=db[n]}=={'check_lean','model_call','main'} and set(db)-set(da)=={'summarize_probe'})
# Every ordinary receipt dict in changed compile paths that includes accepted uses False.
for name in ['check_lean','model_call','summarize_probe','main']:
 fn=next(n for n in current.body if isinstance(n,ast.FunctionDef) and n.name==name)
 found=0
 for node in ast.walk(fn):
  if not isinstance(node,ast.Dict):continue
  literals={k.value:v for k,v in zip(node.keys,node.values) if isinstance(k,ast.Constant) and isinstance(k.value,str)}
  for field in ['accepted','admitted','lake_executed']:
   if field in literals:check(name+' receipt '+field+' is false',isinstance(literals[field],ast.Constant) and literals[field].value is False);found+=1
 check(name+' has explicit false admission receipt fields',found>0)
summary=next(n for n in current.body if isinstance(n,ast.FunctionDef) and n.name=='summarize_probe')
for node in ast.walk(summary):
 if isinstance(node,ast.Dict):
  items={k.value:v for k,v in zip(node.keys,node.values) if isinstance(k,ast.Constant) and isinstance(k.value,str)}
  for key in ['model_native_accepted_proofs','native_positive_controls_accepted']:
   if key in items:check('summary '+key+' cannot count compile success',isinstance(items[key],ast.Constant) and items[key].value==0)
check('author raw Lean suite passed13 with native/model/Hub calls zero',dr['test_count']==13 and dr['exit_code']==0 and dr['native_checker_calls']==0 and dr['model_calls']==0 and dr['Hub_calls']==0 and dr['native_commands_mocked'] is True)
log=(O/'raw-lean-probe-independent-mocked-tests.log').read_text();check('independent mocked raw Lean suite passed13', 'Ran 13 tests' in log and '\nOK\n' in log)
report={'schema':'autoencoder-progress-additive-source-independent-review/v1','date':'2026-10-06','source_scope':bound(scope_path),'sources':sources,'checks':checks,'qualification_authority_dicts':authorities,'findings':[],
'raw_compile_mocked_test_receipt':bound(O/'raw-lean-probe-independent-mocked-tests.log'),
'scope_limits':['The restored APIs are explicit cached replay/metadata interfaces, not newly trained or qualified models.','The first cached wrapper permits Legal/Security/Intent384; original corpus and format wrappers bind only Intent/Security384 fragments. Other cells remain declarative.','The existing optimized Legal loader source is unchanged; its numerical performance is not rerun here.','Raw output-format structural checking does not execute native grammar validators or Lake.','Per-file byte fences and repeated endpoint checks do not establish an atomic snapshot or continuous currentness.','The retained774 mocked interface tests establish contracts; this static audit does not independently execute the real numerical owners.','Direct lean compilation is recorded separately as compile_passed, while all admission/proof acceptance flags and counts remain false or zero.','The raw probe retains an explicit optional runtime/model execution command; this review executes only mocked tests and makes no native claim.'],
'canonical_sources_changed':False,'model_executed':False,'native_proof_executed':False,'qualified':False,'admitted':False}
(O/'additive-wrapper-and-raw-compile-source-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'checks':len(checks),'findings':0,'sha256':bound(O/'additive-wrapper-and-raw-compile-source-audit.json')['sha256']}))
