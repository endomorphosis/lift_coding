"""Independent pure-Git CLI/control review; imports no model or native proof owner."""
import hashlib, importlib.util, json, os, pathlib, subprocess, sys, tempfile
W=pathlib.Path('/home/barberb/lift_coding'); O=pathlib.Path(__file__).resolve().parent
OWNER=W/'scripts/review_autoencoder_progress.py'; TEST=W/'tests/test_review_autoencoder_progress.py'
def bound(p):
 b=p.read_bytes(); return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
pre=[bound(p) for p in (OWNER,TEST)]
spec=importlib.util.spec_from_file_location('review_owner',OWNER);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
checks=[]
def checked(name,condition):
 assert condition,name;checks.append({'check':name,'passed':True})
def git(repo,*args):return subprocess.check_output(['git','-C',str(repo),*args],stderr=subprocess.PIPE).decode().strip()
with tempfile.TemporaryDirectory(prefix='effective-tree-fixture-',dir=O) as directory:
 repo=pathlib.Path(directory);git(repo,'init','--quiet');git(repo,'config','user.name','Independent Fixture');git(repo,'config','user.email','fixture@example.invalid')
 (repo/'old_decoder.py').write_text('version = 1\n');(repo/'later.py').write_text('version = 1\n');git(repo,'add','.');git(repo,'commit','--quiet','-m','Earlier owner');old=git(repo,'rev-parse','HEAD')
 (repo/'old_decoder.py').unlink();(repo/'later.py').write_text('version = 2\n');git(repo,'add','-u');git(repo,'commit','--quiet','-m','Later owner omits decoder');new=git(repo,'rev-parse','HEAD')
 head_before=git(repo,'rev-parse','HEAD');index_before=(repo/'.git/index').read_bytes();(repo/'later.py').write_text('uncommitted version = 3\n')
 result=module.review(repo,old,new,['later.py','old_decoder.py'])
 checked('ancestry remains true while exact source path is missing',result['source_history_reachable_from_target'] is True and result['counts']=={'identical':0,'modified':1,'missing':1})
 checked('working-tree edits do not replace committed target bytes',result['paths'][0]['target']['sha256']==hashlib.sha256(b'version = 2\n').hexdigest())
 checked('modified files are retained for review without restoration',result['paths'][0]['status']=='modified' and (repo/'later.py').read_text()=='uncommitted version = 3\n')
 checked('both authority flags remain false despite ancestral history',result['semantic_qualification_granted'] is False and result['lean_admission_granted'] is False)
 common=[sys.executable,str(OWNER),'--repository',str(repo),'--source',old,'--target',new,'--path','old_decoder.py']
 output=repo/'review.json';cli=subprocess.run(common+['--output',str(output)],capture_output=True,text=True)
 checked('default CLI records missing source without claiming strict success',cli.returncode==0 and json.loads(output.read_text())['counts']['missing']==1)
 fail=subprocess.run(common+['--fail-on-missing'],capture_output=True,text=True)
 checked('explicit missing-path guard exits one',fail.returncode==1 and json.loads(fail.stdout)['counts']['missing']==1)
 saved=output.read_bytes();repeat=subprocess.run(common+['--output',str(output)],capture_output=True,text=True)
 checked('receipt cannot overwrite an existing output',repeat.returncode!=0 and output.read_bytes()==saved)
 modified=subprocess.run([sys.executable,str(OWNER),'--repository',str(repo),'--source',old,'--target',new,'--path','later.py','--fail-on-missing'],capture_output=True,text=True)
 checked('modified-only review does not fail the missing-only guard',modified.returncode==0 and json.loads(modified.stdout)['counts']['modified']==1)
 module.MAX_BLOB_BYTES=1
 try:module.path_entry(repo,old,'later.py')
 except ValueError as error:checked('oversized blob bound refuses selected source', '32 MiB' in str(error))
 else:raise AssertionError('oversized blob read allowed')
 checked('HEAD and normal index remain unchanged',git(repo,'rev-parse','HEAD')==head_before and (repo/'.git/index').read_bytes()==index_before)
checked('reviewed source files unchanged through independent controls',pre==[bound(p) for p in (OWNER,TEST)])
report={'schema':'autoencoder-progress-owner-independent-audit/v1','date':'2026-10-06','sources':pre,'existing_pytest_receipts':[bound(O/'effective-tree-review-tests.log'),bound(O/'effective-tree-review-tests.xml')],'focused_tests_passed':9,'independent_control_checks':len(checks),'checks':checks,'findings':[],
'interpretation':['Ancestry is reported independently of exact path retention.','Counts include identical, modified and missing regular committed files; renamed source paths count as missing.','Modified content or mode needs manual integration review, and is deliberately not a missing-only failure.','The CLI only exits nonzero for missing paths when --fail-on-missing is supplied; default output is an inventory, not an admission guard.','Source and target revisions are resolved to immutable commit IDs; working-tree/index contents are neither evidence inputs nor mutated.','Literal Git pathspecs, normalized repository-relative paths, regular-file modes and a bounded blob size constrain the selected files.','False model, semantic-qualification and Lean-admission flags are appropriate for this pure Git observation.'],
'remaining_test_limits':['The existing nine focused tests do not exercise the CLI; the independent controls above cover its exit and exclusive-output behavior.','This tool verifies explicit selected paths only; it does not discover all lineage files, attest implementation compatibility, inspect training fidelity or merge changes.','The 32 MiB bound is per blob, not a cumulative I/O or elapsed-time bound.'],
'model_executed':False,'native_proof_executed':False,'canonical_source_changed':False,'git_state_mutated':False,'qualified':False,'admitted':False}
(O/'effective-tree-owner-source-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'focused_tests':9,'independent_checks':len(checks),'findings':len(report['findings']),'audit_sha256':bound(O/'effective-tree-owner-source-audit.json')['sha256']}))
