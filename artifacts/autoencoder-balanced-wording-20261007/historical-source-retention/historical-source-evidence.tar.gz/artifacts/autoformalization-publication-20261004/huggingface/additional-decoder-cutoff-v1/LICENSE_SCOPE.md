Authorial source/checkpoint assets originate in an AGPL-3.0 repository.
No upstream backbone weights are included or relicensed. No new content rights
or semantic review authority are asserted by this experimental release.
