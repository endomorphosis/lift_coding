"""Deontic logic parsing and formula generation utilities.

This module is intentionally conservative.  It is a deterministic scaffold for
indexing, triage, and LLM prompting, not a substitute for an LLM/legal review
formalization pass.
"""

import re
import hashlib
import json
from pathlib import Path
from typing import Any, Dict, List, Optional


PARSER_SCHEMA_VERSION = "deterministic_deontic_v12"
PARSER_REQUIRED_FIELDS = [
    "schema_version",
    "source_id",
    "canonical_citation",
    "text",
    "support_text",
    "support_span",
    "field_spans",
    "norm_type",
    "deontic_operator",
    "modal",
    "subject",
    "actor_type",
    "entity_type",
    "action",
    "action_verb",
    "action_object",
    "action_recipient",
    "conditions",
    "condition_details",
    "temporal_constraints",
    "temporal_constraint_details",
    "exceptions",
    "exception_details",
    "override_clauses",
    "override_clause_details",
    "cross_references",
    "cross_reference_details",
    "resolved_cross_references",
    "enforcement_links",
    "conflict_links",
    "enumerated_items",
    "defined_term_refs",
    "definition_scope",
    "ontology_terms",
    "formal_terms",
    "llm_repair",
    "export_readiness",
    "logic_frame",
    "legal_frame",
    "kg_relationship_hints",
    "monetary_amounts",
    "monetary_amount_details",
    "penalty",
    "procedure",
    "section_context",
    "hierarchy_path",
    "hierarchy_details",
    "document_type",
    "extraction_method",
    "confidence_floor",
    "slot_coverage",
    "scaffold_quality",
    "quality_label",
    "parser_warnings",
    "promotable_to_theorem",
]
LEGACY_SCHEMA_DEFAULTS: Dict[str, Any] = {
    "source_id": "",
    "canonical_citation": "",
    "field_spans": {},
    "condition_details": [],
    "temporal_constraint_details": [],
    "exception_details": [],
    "override_clause_details": [],
    "cross_reference_details": [],
    "resolved_cross_references": [],
    "enforcement_links": [],
    "conflict_links": [],
    "defined_term_refs": [],
    "definition_scope": {},
    "ontology_terms": [],
    "formal_terms": {},
    "llm_repair": {},
    "export_readiness": {},
    "logic_frame": {},
    "legal_frame": {},
    "kg_relationship_hints": [],
    "monetary_amounts": [],
    "monetary_amount_details": [],
    "penalty": {},
    "procedure": {},
    "section_context": {},
    "hierarchy_path": [],
    "hierarchy_details": [],
}
EXPORT_TABLE_SPECS: Dict[str, Dict[str, Any]] = {
    "canonical": {"primary_key": "source_id", "requires_source_id": True},
    "formal_logic": {"primary_key": "formula_id", "requires_source_id": True},
    "proof_obligations": {"primary_key": "proof_obligation_id", "requires_source_id": True},
    "knowledge_graph_triples": {"primary_key": "triple_id", "requires_source_id": True},
    "clause_records": {"primary_key": "clause_id", "requires_source_id": True},
    "reference_records": {"primary_key": "reference_id", "requires_source_id": True},
    "procedure_event_records": {"primary_key": "event_id", "requires_source_id": True},
    "sanction_records": {"primary_key": "sanction_id", "requires_source_id": True},
    "ontology_entities": {"primary_key": "entity_id", "requires_source_id": True},
    "repair_queue": {"primary_key": "repair_id", "requires_source_id": True},
}
_SENTENCE_SPLIT_RE = re.compile(r"(?<=[.!?])\s+(?=[A-Z0-9(])")
_SECTION_HEADER_RE = re.compile(
    r"^\s*(?:(?:sec(?:tion)?\.?|§)\s*)?([0-9]+(?:\.[0-9]+)*(?:[A-Za-z])?)\.?\s*(.*)$",
    re.IGNORECASE,
)
_USC_CITATION_CONTEXT_RE = re.compile(
    r"\b(?P<title>\d+)\s+U\.?\s*S\.?\s*C\.?\s+"
    r"(?P<section>[0-9][0-9A-Za-z.\-]*)\b"
    r"(?:\s*[:\-]\s*|\s+)?(?P<heading>[^.;:]{0,120})",
    re.IGNORECASE,
)
_SEC_CITATION_CONTEXT_RE = re.compile(
    r"\bSec(?:tion)?\.?\s+(?P<section>[0-9][0-9A-Za-z.\-]*)"
    r"\s*(?:[-:]\s*)?(?P<heading>[^.;:]{0,120})",
    re.IGNORECASE,
)
_HIERARCHY_HEADER_RE = re.compile(
    r"^\s*(title|chapter|article|part|division)\s+([0-9A-Za-z][0-9A-Za-z.\-]*)\.?\s*(.*)$",
    re.IGNORECASE,
)
_ENUM_LABEL_RE = re.compile(r"\(([A-Za-z0-9]+)\)")
# Spelled durations are source text, not invented numerals. A digit duration
# still has to be followed by its unit. Bare "within this Union" is not a duration.
_SPELLED_SMALL = (
    r"twenty[\s-](?:one|two|three|four|five|six|seven|eight|nine)"
    r"|thirty[\s-](?:one|two|three|four|five|six|seven|eight|nine)"
    r"|forty[\s-](?:one|two|three|four|five|six|seven|eight|nine)"
    r"|fifty[\s-](?:one|two|three|four|five|six|seven|eight|nine)"
    r"|sixty[\s-](?:one|two|three|four|five|six|seven|eight|nine)"
    r"|seventy[\s-](?:one|two|three|four|five|six|seven|eight|nine)"
    r"|eighty[\s-](?:one|two|three|four|five|six|seven|eight|nine)"
    r"|ninety[\s-](?:one|two|three|four|five|six|seven|eight|nine)"
    r"|eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen"
    r"|ten|one|two|three|four|five|six|seven|eight|nine"
    r"|twenty|thirty|forty|fifty|sixty|seventy|eighty|ninety"
)
_DURATION_UNIT = r"(?:(?:business|calendar)\s+)?(?:days?|weeks?|months?|years?|hours?)"
_SPELLED_DURATION = rf"(?:{_SPELLED_SMALL})\s+{_DURATION_UNIT}"
_DIGIT_DURATION = rf"\d+\s+{_DURATION_UNIT}"
_CALENDAR_MONTH = (
    r"january|february|march|april|may|june|july|august|september|october|november|december"
)
_PARENTHETICAL_LABEL = r"(?:\s*\([A-Za-z0-9]+\))*"
_ACTION_TEMPORAL_CUT = (
    rf"before\s+(?:{_CALENDAR_MONTH}|\d)"
    rf"|after\s+(?:{_CALENDAR_MONTH}|\d|notice|consultation)"
    rf"|on\s+(?:{_CALENDAR_MONTH})\s+\d{{1,2}}"
    rf"|within\s+(?:{_DIGIT_DURATION}|every\s+subsequent\s+term\s+of\s+{_SPELLED_DURATION}|{_SPELLED_DURATION})"
)
_MODAL_RE = re.compile(
    r"""
    (?P<subject>
        (?:the\s+)?
        [A-Za-z][A-Za-z0-9'’\-]*
        """
    + _PARENTHETICAL_LABEL
    + r"""
        (?:\s+(?!shall\b|must\b|may\b|cannot\b|can\b|is\b|are\b|will\b|should\b)
            [A-Za-z][A-Za-z0-9'’\-]*
            """
    + _PARENTHETICAL_LABEL
    + r"""){0,10}
    )
    \s+
    (?P<modal>
        shall\s+not|must\s+not|may\s+not|cannot|can\s+not|
        is\s+prohibited\s+from|are\s+prohibited\s+from|
        is\s+forbidden\s+to|are\s+forbidden\s+to|
        shall|must|required\s+to|is\s+required\s+to|are\s+required\s+to|
        is\s+required\s+by\s+law\s+to|are\s+required\s+by\s+law\s+to|
        is\s+legally\s+required\s+to|are\s+legally\s+required\s+to|
        is\s+legally\s+obligated\s+to|are\s+legally\s+obligated\s+to|
        is\s+(?:legally\s+)?compelled\s+(?:by\s+law\s+)?to|are\s+(?:legally\s+)?compelled\s+(?:by\s+law\s+)?to|
        has\s+a\s+duty\s+to|have\s+a\s+duty\s+to|
        has\s+(?:a\s+|the\s+)?responsibility\s+to|
        have\s+(?:a\s+|the\s+)?responsibility\s+to|
        owes\s+(?:a\s+|the\s+)?duty\s+to|
        owe\s+(?:a\s+|the\s+)?duty\s+to|
        is\s+charged\s+with\s+the\s+duty\s+to|are\s+charged\s+with\s+the\s+duty\s+to|
        is\s+responsible\s+for|are\s+responsible\s+for|
        is\s+accountable\s+for|are\s+accountable\s+for|
        is\s+answerable\s+for|are\s+answerable\s+for|
        is\s+tasked\s+with|are\s+tasked\s+with|
        is\s+entrusted\s+with|are\s+entrusted\s+with|
        is\s+obligated\s+to|are\s+obligated\s+to|
        is\s+under\s+a\s+duty\s+to|are\s+under\s+a\s+duty\s+to|
        is\s+subject\s+to\s+(?:a\s+|the\s+)?duty\s+to|
        are\s+subject\s+to\s+(?:a\s+|the\s+)?duty\s+to|
        bears\s+(?:a\s+|the\s+)?responsibility\s+for|bear\s+(?:a\s+|the\s+)?responsibility\s+for|
        bears\s+(?:an?\s+|the\s+)?obligation\s+to|bear\s+(?:an?\s+|the\s+)?obligation\s+to|
        is\s+assigned\s+(?:a\s+|the\s+)?responsibility\s+for|
        are\s+assigned\s+(?:a\s+|the\s+)?responsibility\s+for|
        is\s+obligated\s+by\s+law\s+to|are\s+obligated\s+by\s+law\s+to|
        is\s+assigned\s+(?:an?\s+|the\s+)?duty\s+to|
        are\s+assigned\s+(?:an?\s+|the\s+)?duty\s+to|
        is\s+under\s+a\s+legal\s+duty\s+to|are\s+under\s+a\s+legal\s+duty\s+to|
        is\s+bound\s+by\s+law\s+to|are\s+bound\s+by\s+law\s+to|
        is\s+duty-bound\s+to|are\s+duty-bound\s+to|
        is\s+duty\s+bound\s+to|are\s+duty\s+bound\s+to|
        is\s+liable\s+to|are\s+liable\s+to|
        is\s+bound\s+to|are\s+bound\s+to|
        has\s+(?:the\s+)?(?:authority|power)\s+to|have\s+(?:the\s+)?(?:authority|power)\s+to|
        is\s+(?:delegated|granted)\s+(?:the\s+)?(?:authority|power)\s+to|
        are\s+(?:delegated|granted)\s+(?:the\s+)?(?:authority|power)\s+to|
        is\s+(?:vested\s+with|conferred)\s+(?:the\s+)?(?:authority|power)\s+to|
        are\s+(?:vested\s+with|conferred)\s+(?:the\s+)?(?:authority|power)\s+to|
        is\s+authorized\s+and\s+directed\s+to|are\s+authorized\s+and\s+directed\s+to|
        is\s+directed\s+to|are\s+directed\s+to|
        is\s+instructed\s+to|are\s+instructed\s+to|
        is\s+ordered\s+to|are\s+ordered\s+to|
        is\s+mandated\s+to|are\s+mandated\s+to|
        is\s+commanded\s+to|are\s+commanded\s+to|
        is\s+designated\s+to|are\s+designated\s+to|
        is\s+appointed\s+to|are\s+appointed\s+to|
        is\s+empowered\s+to|are\s+empowered\s+to|
        may(?!\s+\d{1,2}(?:st|nd|rd|th)?(?:,\s*|\s+)\d{4}\b)|is\s+authorized\s+to|are\s+authorized\s+to|
        is\s+permitted\s+to|are\s+permitted\s+to|
        is\s+entitled\s+to|are\s+entitled\s+to
    )
    \s*,?\s+
    (?P<action>.+?)
    (?=(?:\s+(?:and|or)\s+(?!which\b|who\b|that\b)(?:shall|must|may|cannot|can\s+not|is\s+required|are\s+required|is\s+authorized|are\s+authorized|is\s+permitted|are\s+permitted)\b)|(?:\s+(?:if|when(?!\s+compared\b)|where|provided\s+that|unless|except|except\s+that|without|absent\s+(?:a|an|the|any|such|this)|"""
    + _ACTION_TEMPORAL_CUT
    + r"""|not\s+later\s+than|no\s+later\s+than|not\s+more\s+than|no\s+more\s+than)\b)|(?:,\s+(?:the\s+)?(?!which\b|who\b|that\b|or\b|and\b|nor\b|but\b)[A-Za-z][A-Za-z'’\-]*(?:\s+(?!which\b|who\b|that\b)[A-Za-z'’\-]+){0,6}\s+shall\b)|[.]|(?:\:(?!\s*[\"“—]))|$)
    """,
    re.IGNORECASE | re.VERBOSE,
)
_HEREBY_PROHIBITED_RE = re.compile(
    r"(?P<subject>.+?)\s+is\s+hereby\s+prohibited\b",
    re.IGNORECASE,
)
_TAKE_EFFECT_RE = re.compile(
    r"(?P<subject>.+?)\s+(?P<modal>shall)\s+(?P<action>take effect\b.*)$",
    re.IGNORECASE,
)
_COMMA_SUBJECT_MODAL_RE = re.compile(
    r"(?P<subject>[A-Z][^.;]{0,300}?),\s+"
    r"(?P<modal>shall\s+not|must\s+not|may\s+not|shall|must|may)\s+"
    r"(?P<action>.+?)"
    r"(?=(?:;(?!\s*or\b))|[.:]|$)",
    re.IGNORECASE,
)
_IMPLICIT_MODAL_RE = re.compile(
    r"""
    \b(?:and|or)\s+
    (?P<modal>
        shall\s+not|must\s+not|may\s+not|cannot|can\s+not|
        shall|must|required\s+to|may|
        is\s+authorized\s+to|are\s+authorized\s+to|
        is\s+permitted\s+to|are\s+permitted\s+to
    )
    \s+
    (?P<action>.+?)
    (?=(?:\s+(?:and|or)\s+(?!which\b|who\b|that\b)(?:shall|must|may|cannot|can\s+not)\b)|(?:\s+(?:if|when(?!\s+compared\b)|where|provided\s+that|unless|except|except\s+that|without|absent\s+(?:a|an|the|any|such|this)|"""
    + _ACTION_TEMPORAL_CUT
    + r"""|not\s+later\s+than|no\s+later\s+than|not\s+more\s+than|no\s+more\s+than)\b)|(?:,\s+(?:the\s+)?(?!which\b|who\b|that\b|or\b|and\b|nor\b|but\b)[A-Za-z][A-Za-z'’\-]*(?:\s+(?!which\b|who\b|that\b)[A-Za-z'’\-]+){0,6}\s+shall\b)|[.]|(?:\:(?!\s*[\"“—]))|$)
    """,
    re.IGNORECASE | re.VERBOSE,
)
_IMPERSONAL_NORM_RE = re.compile(
    r"""
    (?:
        (?P<unlawful>it\s+is\s+(?:unlawful|illegal|prohibited)\s+(?:for\s+(?P<unlawful_subject>.+?)\s+)?to\s+(?P<unlawful_action>.+?))
        |
        (?P<license>(?:a|an|the)\s+(?P<license_subject>license|permit|certificate|registration|approval)\s+is\s+required\s+to\s+(?P<license_action>.+?))
        |
        (?P<duty>(?:a|an|the)\s+duty\s+is\s+imposed\s+on\s+(?P<duty_subject>.+?)\s+to\s+(?P<duty_action>.+?))
    )
    (?=(?:\s+(?:if|when(?!\s+compared\b)|where|provided\s+that|unless|except|without|absent|before|after|within|not\s+later\s+than|no\s+later\s+than|not\s+more\s+than|no\s+more\s+than)\b)|[.;:]|$)
    """,
    re.IGNORECASE | re.VERBOSE,
)
_VIOLATION_RE = re.compile(
    r"\bfailure\s+to\s+(.+?)\s+is\s+(?:a\s+)?(?:violation|offense|infraction)\b",
    re.IGNORECASE,
)
_PENALTY_RE = re.compile(
    r"\b(?:a\s+)?(?:violation|offense|infraction)(?:\s+of\s+(?:this\s+section|section\s+[0-9][0-9A-Za-z.\-]*(?:\([a-z0-9]+\))*))?\s+(?:is|shall\s+be)\s+"
    r"(?:punishable\s+by|subject\s+to)\s+(.+?)(?:[.;:]|$)",
    re.IGNORECASE,
)
_APPLICABILITY_RE = re.compile(
    r"\b(?P<scope>this|the)\s+(?P<scope_type>section|chapter|title|article|part)\s+"
    r"(?:applies|shall\s+apply|is\s+applicable)\s+to\s+(?P<target>.+?)(?:[.;:]|$)",
    re.IGNORECASE,
)
_NON_APPLICABILITY_RE = re.compile(
    r"\b(?P<scope>this|the)\s+(?P<scope_type>section|chapter|title|article|part)\s+"
    r"(?:does\s+not\s+apply|shall\s+not\s+apply|is\s+not\s+applicable)\s+to\s+(?P<target>.+?)(?:[.;:]|$)",
    re.IGNORECASE,
)
_SAVINGS_PRESERVATION_RE = re.compile(
    r"\bnothing\s+in\s+(?P<scope>this\s+(?:act|section|chapter|title|article|part|subchapter|subtitle|division))\s+"
    r"(?P<modal>affects|shall\s+affect|may\s+be\s+construed\s+as\s+affecting|shall\s+be\s+construed\s+to\s+affect|shall\s+be\s+construed\s+as\s+affecting)\s+"
    r"(?P<target>.+?)(?:[.;:]|$)",
    re.IGNORECASE,
)
_EXEMPTION_RE = re.compile(
    r"\b(?P<target>.+?)\s+(?:is|are)\s+exempt\s+from\s+(?P<requirement>.+?)(?:[.;:]|$)",
    re.IGNORECASE,
)
_NOT_REQUIRED_EXEMPTION_RE = re.compile(
    r"\b(?:no\s+|(?:a|an|the|any)\s+)?"
    r"(?P<instrument>permit|license|certificate|registration|approval)\s+"
    r"(?:(?:is|are|shall\s+be)\s+not\s+required|(?:is|are)\s+unnecessary)\s+"
    r"(?P<preposition>for|to)\s+(?P<target>.+?)(?:[.;:]|$)",
    re.IGNORECASE,
)
_INSTRUMENT_VALIDITY_RE = re.compile(
    r"\b(?P<instrument>(?:the|a|an)\s+)?(?P<instrument_type>permit|license|certificate|registration|approval|variance)\s+"
    r"(?:is|shall\s+be)\s+valid\s+for\s+(?P<duration>.+?)(?:[.;:]|$)",
    re.IGNORECASE,
)
_INSTRUMENT_EXPIRATION_RE = re.compile(
    r"\b(?P<instrument>(?:the|a|an)\s+)?(?P<instrument_type>permit|license|certificate|registration|approval|variance)\s+"
    r"(?:expires|shall\s+expire|terminates|shall\s+terminate)\s+(?P<anchor>.+?)(?:[.;:]|$)",
    re.IGNORECASE,
)
_DECLARATIVE_COPULA_RE = re.compile(
    r"(?P<subject>.+?)\s+(?:is|are)\s+(?P<action>(?:reserved to|citizens of)\b.*)$",
    re.IGNORECASE,
)
# A constitutional repeal names the article. It is not a U.S. Code "§ N. Repealed." note.
_HEREBY_REPEALED_RE = re.compile(
    r"\b(?P<subject>the\s+[A-Za-z0-9][A-Za-z0-9\-]*"
    r"(?:\s+[A-Za-z0-9][A-Za-z0-9\-]*){0,8}\s+article\s+of\s+amendment\b"
    r"(?:\s+to\s+the\s+Constitution\s+of\s+the\s+United\s+States)?)"
    r"\s+is\s+hereby\s+repealed\b",
    re.IGNORECASE,
)
_SECTION_STATUS_RE = re.compile(
    r"(?:(?P<section_marker>(?:secs?\.?|sections?|§{1,2})\s*[0-9][0-9A-Za-z.\-]*(?:\s*,\s*[0-9][0-9A-Za-z.\-]*)*)\s*[\.:]?\s*)?"
    r"\b(?P<status>repealed|omitted|reserved|transferred|renumbered|redesignated)\b"
    r"(?P<detail>[^.;:]*)",
    re.IGNORECASE,
)
_SECTION_STATUS_DETAIL_STOP_RE = re.compile(
    r"\b(?:editorial\s+notes?|codification|pub\.?\s*l\.?|section|sections?|see|prior\s+provisions?)\b",
    re.IGNORECASE,
)
_PURPOSE_RE = re.compile(
    r"""
    \b(?:the\s+)?
    (?P<purpose_kind>general\s+purposes?|purposes?|mission|function|functions)
    \s+of\s+(?P<subject>.+?)
    \s+(?:is|are)\s+
    (?P<action>.+?)
    (?=[.;:]|$)
    """,
    re.IGNORECASE | re.VERBOSE,
)
_CRITICAL_THAT_RE = re.compile(
    r"\b[Ii]t\s+is\s+(?P<modal>critical|essential|necessary)\s+that\s+"
    r"(?P<subject>[A-Z][A-Z0-9&]*(?:\s+[A-Z][A-Z0-9&]*){0,5})\s+"
    r"(?P<action>.+?)(?=[.;:]|$)",
)
_HEREBY_AUTHORIZED_RE = re.compile(
    r"\b(?P<subject>(?:[Tt]he\s+)?[A-Z][A-Za-z0-9'’\-]*(?:\s+(?!is\b)[A-Za-z][A-Za-z0-9'’\-]*){0,10})\s*"
    r"(?:,\s*[^,;]{1,260},\s*)?"
    r"(?P<modal>[Ii]s\s+hereby\s+authorized(?:\s+and\s+directed)?|"
    r"[Aa]re\s+hereby\s+authorized(?:\s+and\s+directed)?)"
    r"(?:\s+to|\s*[-—:]\s*)\s*(?P<action>.+?)(?=[.;]|$)",
)
_DASH_MODAL_RE = re.compile(
    r"\b(?P<subject>(?:[Tt]he\s+)?[A-Za-z][A-Za-z0-9'’\-]*(?:\s+(?!may\b|shall\b|must\b)[A-Za-z][A-Za-z0-9'’\-]*){0,10})\s+"
    r"(?P<modal>may|shall|must)\s*[-—:]\s*(?P<action>.+?)(?=[.;]|$)",
    re.IGNORECASE,
)
_MONEY_RE = re.compile(
    r"(?:\$\s?\d[\d,]*(?:\.\d{2})?|\b\d[\d,]*\s+dollars?\b)",
    re.IGNORECASE,
)
_CLAUSE_END_RE = r"(?:,|;|[.]\s|[.]$|$)"
_IF_COMMA_RE = re.compile(
    r"\bif\s*,\s*(?P<body>.+),\s+(?:the\s+)?[A-Z][^,;]{0,80}?\s+shall\b",
    re.IGNORECASE,
)
_CONDITION_PATTERNS = [
    # "If, <preamble>, the Vice President elect shall ..." keeps the preamble.
    ("if", r"\bif\s*,\s*(.+),\s+(?:the\s+)?(?-i:[A-Z])[^,;]{0,80}?\s+shall\b"),
    # "If the Congress, <timing>, determines by two-thirds vote, the Vice President shall"
    ("if", r"\bif\s+(.+?),\s+(?:the\s+)?(?-i:[A-Z])[^,;]{0,80}?\s+shall\b"),
    # "if the House shall not choose ..., before the fourth day of March ..., then"
    ("if", r"\bif\s+(.+?,\s+before\s+the\s+.+?),\s+then\b"),
    # "if Vacancies happen by Resignation, or otherwise, during the Recess ..., the Executive may"
    ("if", r"\bif\s+(.+?,\s+or\s+otherwise,\s+during\s+the\s+.+?),\s+the\s+"),
    # "if there be more than one ..., and have an equal Number of Votes, then"
    ("if", r"\bif\s+(.+?,\s+and\s+have\s+an\s+equal\s+.+?),\s+then\b"),
    ("if", rf"\bif\s+(.+?)(?:,|;|\s+then|[.]$|$)"),
    # A comma before the verb is still inside the whenever/when that governs the later shall.
    ("whenever", r"\b(whenever\s+.+?),\s+(?:the\s+)?(?-i:[A-Z])[^,;]{0,80}?\s+shall\b"),
    ("whenever", rf"\b(whenever\s+.+?){_CLAUSE_END_RE}"),
    ("until", rf"\b(until\s+.+?){_CLAUSE_END_RE}"),
    ("when", r"\bwhen\s+(?!compared\b)(.+?),\s+(?:the\s+)?(?-i:[A-Z])[^,;]{0,80}?\s+shall\b"),
    # "when the right to vote ... is denied, the basis ... shall be reduced"
    ("when", r"\bwhen\s+(?!compared\b)(.+?),\s+the\s+[^,;]{0,80}?\s+shall\b"),
    ("when", rf"\bwhen\s+(?!compared\b)(.+?){_CLAUSE_END_RE}"),
    ("where", rf"\bwhere\s+(.+?){_CLAUSE_END_RE}"),
    # "Provided that no Amendment shall affect" is a prohibition, not a proviso condition.
    ("provided_that", rf"\bprovided that\s+(?!no\b)(.+?){_CLAUSE_END_RE}"),
    # "territory subject to the jurisdiction" is not the proviso "subject to".
    ("subject_to", rf"\bsubject to\s+(?!(?:the|their|its|his|her)\s+jurisdiction\b)(.+?){_CLAUSE_END_RE}"),
    # Keep the words "in case", including ", or of his Death, ... Inability to discharge".
    ("in_case", r"\b(in case\s+.+?),\s+(?:the\s+)?(?-i:[A-Z])[^,;]{0,80}?\s+shall\b"),
    ("in_case", rf"\b(in case\s+.+?){_CLAUSE_END_RE}"),
]
_EXCEPTION_PATTERNS = [
    # "unless on the testimony of two witnesses, or on confession" is one exception.
    ("unless", r"\bunless\s+(.+?,\s+or\s+.+?)(?:[.;]|$)"),
    # "unless ... prevent its Return, in which Case it shall not be a Law."
    ("unless", r"\bunless\s+(.+?,\s+in\s+which\s+case\s+.+?)(?:[.;]|$)"),
    # "unless ... as provided in the Constitution, within seven years"
    ("unless", r"\bunless\s+(.+?,\s+as\s+provided\s+in\s+[^,;]+)"),
    # "unless the Vice President ..., transmit within four days ..."
    ("unless", r"\bunless\s+(.+?,\s+transmit\s+.+?)(?:[.;]|$)"),
    ("unless", rf"\bunless\s+(.+?){_CLAUSE_END_RE}"),
    # "No Person except a natural born Citizen, or a Citizen ..., shall"
    # The class runs through the comma before shall. It is one exception.
    ("except", r"\bexcept\s+(.+),\s+(?:shall|must|may)\b"),
    (
        "except",
        r"\bexcept\s+(.+?)\s*,\s*(?=be\b|accept\b|have\b|make\b|take\b)",
    ),
    ("except", rf"\bexcept\s+(?:for\s+)?(.+?){_CLAUSE_END_RE}"),
    ("without", rf"\bwithout\s+(.+?){_CLAUSE_END_RE}"),
    # "absent a warrant" is an exception. "absent Members" is not.
    ("absent", rf"\babsent\s+(?=(?:a|an|the|any|such|this)\b)(.+?){_CLAUSE_END_RE}"),
    ("with_exception_of", rf"\bwith the exception of\s+(.+?){_CLAUSE_END_RE}"),
    ("other_than", rf"\bother than\s+(.+?){_CLAUSE_END_RE}"),
    ("excluding", rf"\bexcluding\s+(.+?){_CLAUSE_END_RE}"),
]
_OVERRIDE_PATTERNS = [
    ("notwithstanding", rf"\bnotwithstanding\s+(.+?)(?:,|[.]$|$)"),
    ("without_regard_to", rf"\bwithout regard to\s+(.+?)(?:,|[.]$|$)"),
]
_TEMPORAL_PATTERNS = [
    (
        "deadline",
        "by_date",
        r"\bby\s+((?:january|february|march|april|may|june|july|august|september|october|november|december)\s+\d{1,2}(?:st|nd|rd|th)?(?:,?\s+\d{4})?)",
    ),
    (
        "deadline",
        "on_date",
        rf"\bon\s+((?:{_CALENDAR_MONTH})\s+\d{{1,2}}(?:st|nd|rd|th)?(?:,?\s+\d{{4}})?)",
    ),
    ("deadline", "by_numeric_date", r"\bby\s+(\d{1,2}/\d{1,2}/\d{2,4})"),
    ("deadline", "by_numeric_date", r"\bby\s+(\d{1,2}-\d{1,2}-\d{2,4})"),
    (
        "deadline",
        "whichever_is_earlier",
        r"\bwithin\s+(\d+\s+(?:(?:business|calendar)\s+)?(?:days?|weeks?|months?|years?)\s+after\s+[^,.;]+?\s+or\s+\d+\s+(?:(?:business|calendar)\s+)?(?:days?|weeks?|months?|years?)\s+after\s+[^,.;]+?,?\s+whichever\s+is\s+earlier)(?=\s+(?:unless|except|without|absent|if|when|where|provided that|subject to)\b|[.;]|$)",
    ),
    (
        "deadline",
        "whichever_is_later",
        r"\bwithin\s+(\d+\s+(?:(?:business|calendar)\s+)?(?:days?|weeks?|months?|years?)\s+after\s+[^,.;]+?\s+or\s+\d+\s+(?:(?:business|calendar)\s+)?(?:days?|weeks?|months?|years?)\s+after\s+[^,.;]+?,?\s+whichever\s+is\s+later)(?=\s+(?:unless|except|without|absent|if|when|where|provided that|subject to)\b|[.;]|$)",
    ),
    (
        "deadline",
        "within_duration",
        r"\bwithin\s+(\d+\s+(?:(?:business|calendar)\s+)?(?:days?|weeks?|months?|years?)(?:\s+after\s+.+?)?)(?=\s+(?:unless|except|without|absent|if|when|where|provided that|subject to)\b|[,.;]|$)",
    ),
    (
        "deadline",
        "not_later_than",
        r"\bnot\s+later\s+than\s+(\d+\s+(?:(?:business|calendar)\s+)?(?:days?|weeks?|months?|years?)(?:\s+after\s+.+?)?)(?=\s+(?:unless|except|without|absent|if|when|where|provided that|subject to)\b|[,.;]|$)",
    ),
    (
        "deadline",
        "no_later_than",
        r"\bno\s+later\s+than\s+(\d+\s+(?:(?:business|calendar)\s+)?(?:days?|weeks?|months?|years?)(?:\s+after\s+.+?)?)(?=\s+(?:unless|except|without|absent|if|when|where|provided that|subject to)\b|[,.;]|$)",
    ),
    (
        "deadline",
        "not_more_than",
        r"\bnot\s+more\s+than\s+(\d+\s+(?:(?:business|calendar)\s+)?(?:days?|weeks?|months?|years?)(?:\s+after\s+.+?)?)(?=\s+(?:unless|except|without|absent|if|when|where|provided that|subject to)\b|[,.;]|$)",
    ),
    (
        "deadline",
        "no_more_than",
        r"\bno\s+more\s+than\s+(\d+\s+(?:(?:business|calendar)\s+)?(?:days?|weeks?|months?|years?)(?:\s+after\s+.+?)?)(?=\s+(?:unless|except|without|absent|if|when|where|provided that|subject to)\b|[,.;]|$)",
    ),
    (
        "deadline",
        "minimum_duration",
        r"\b(?:at\s+least|(?:a\s+)?minimum\s+of)\s+(\d+\s+(?:(?:business|calendar)\s+)?(?:days?|weeks?|months?|years?))(?=\s+(?:unless|except|without|absent|if|when|where|provided that|subject to)\b|[,.;]|$)",
    ),
    (
        "deadline",
        "before_date",
        r"\bbefore\s+((?:january|february|march|april|may|june|july|august|september|october|november|december)\s+\d{1,2})",
    ),
    (
        "deadline",
        "after_date",
        r"\bafter\s+((?:january|february|march|april|may|june|july|august|september|october|november|december)\s+\d{1,2})",
    ),
    (
        "procedure",
        "after_notice_and_hearing",
        r"\b(after\s+(?:public\s+)?notice\s+and\s+hearing)\b",
    ),
    (
        "procedure",
        "after_consultation",
        r"\b(after\s+consultation\s+with\s+(?:the\s+)?[A-Za-z][A-Za-z0-9'’\-]*(?:\s+[A-Za-z][A-Za-z0-9'’\-]*){0,6})\b",
    ),
    ("period", "annually", r"\b(annually)\b"),
    ("period", "monthly", r"\b(monthly)\b"),
    ("period", "weekly", r"\b(weekly)\b"),
    ("period", "daily", r"\b(daily)\b"),
    (
        "duration",
        "for_duration",
        r"\bfor\s+(\d+\s+(?:(?:business|calendar)\s+)?(?:days?|weeks?|months?|years?))",
    ),
    (
        "deadline",
        "within_duration",
        r"\bwithin\s+(\d+\s+hours?)(?=\s+(?:unless|except|without|absent|if|when|where|provided that|subject to)\b|[,.;(]|$)",
    ),
    (
        "deadline",
        "within_duration",
        rf"\bwithin\s+((?:every\s+subsequent\s+term\s+of\s+)?{_SPELLED_DURATION}(?:\s*\([^)]*\))?(?:\s+(?:after|for|from|to)\s+.+?)?)(?=\s+(?:unless|except|without|absent|if|when|where|provided that|subject to)\b|[,.;(]|$)",
    ),
]
_DEFINITION_RE = re.compile(
    r"\b(?:means|includes?|defined\s+as|has\s+the\s+meaning\s+given|refers\s+to)\b",
    re.IGNORECASE,
)
_DEFINED_TERM_RE = re.compile(
    r"\b(?:the\s+)?(?:term|terms|word|words)\s+['\"“”]?([A-Za-z][A-Za-z0-9'’\-\s]{0,80}?)[\"'“”]?\s+"
    r"(?:means|includes?|defined\s+as|has\s+the\s+meaning\s+given|refers\s+to)\b",
    re.IGNORECASE,
)
_UNQUOTED_DEFINED_TERM_RE = re.compile(
    r"^\s*(?:(?:(?:in|as\s+used\s+in)\s+this\s+(?:section|chapter|title)|for\s+purposes\s+of\s+this\s+(?:section|chapter|title)),?\s+)?"
    r"(?:the\s+)?([A-Za-z][A-Za-z0-9'’\-]*(?:\s+[A-Za-z][A-Za-z0-9'’\-]*){0,8}?)\s+"
    r"(?:means|includes?|defined\s+as|has\s+the\s+meaning\s+given|refers\s+to)\b",
    re.IGNORECASE,
)
_LEADING_DETERMINERS_RE = re.compile(r"^(?:the|a|an|any|each|every|such|no)\s+", re.IGNORECASE)
_TRAILING_NOISE_RE = re.compile(
    r"\s+(?:in accordance with|pursuant to|as provided in|except as provided in)\s+.+$"
    r"|\s+under\s+(?:section|title|chapter|paragraph|subsection|part)\b.+$",
    re.IGNORECASE,
)
_PASSIVE_BY_RE = re.compile(r"^be\s+([A-Za-z][A-Za-z0-9'’\-]*)\s+by\s+(.+)$", re.IGNORECASE)
_PASSIVE_BENEFIT_RECIPIENT_RE = re.compile(
    r"^be\s+(?:given|granted|provided|awarded|allocated|distributed|paid|issued|made)\s+"
    r"(?:to|for)\s+(.+?)(?=(?:\s+(?:if|when|where|provided\s+that|unless|except|within|before|after)\b)|[.;:]|$)",
    re.IGNORECASE,
)
_PAST_PARTICIPLE_BASE = {
    "adopted": "adopt",
    "awarded": "award",
    "carried": "carry",
    "completed": "complete",
    "filed": "file",
    "fulfilled": "fulfill",
    "implemented": "implement",
    "issued": "issue",
    "maintained": "maintain",
    "prepared": "prepare",
    "provided": "provide",
    "submitted": "submit",
}
_COPULA_STATUS_COMPLEMENTS = frozenset(
    {
        "able",
        "applicable",
        "available",
        "binding",
        "effective",
        "eligible",
        "entitled",
        "essential",
        "final",
        "inoperative",
        "insufficient",
        "invalid",
        "lawful",
        "liable",
        "necessary",
        "null",
        "operative",
        "responsible",
        "subject",
        "sufficient",
        "unlawful",
        "valid",
        "void",
    }
)
_IRREGULAR_PARTICIPLES = frozenset(
    {
        "begun",
        "bound",
        "brought",
        "built",
        "bought",
        "caught",
        "chosen",
        "cut",
        "done",
        "drawn",
        "driven",
        "eaten",
        "fallen",
        "flown",
        "forgotten",
        "found",
        "frozen",
        "given",
        "grown",
        "held",
        "hidden",
        "hit",
        "hurt",
        "kept",
        "known",
        "led",
        "left",
        "lost",
        "made",
        "met",
        "paid",
        "put",
        "read",
        "ridden",
        "risen",
        "seen",
        "sent",
        "set",
        "shown",
        "sold",
        "sought",
        "spoken",
        "spent",
        "spread",
        "stolen",
        "sworn",
        "taken",
        "taught",
        "thought",
        "thrown",
        "told",
        "torn",
        "won",
        "worn",
        "written",
    }
)
_COPULA_PASSIVE_RE = re.compile(
    r"^(?:be|been|being)\s+"
    r"(?P<head>[A-Za-z][A-Za-z0-9'’\-]*)"
    r"(?:\s+(?P<particle>out|off|up|down|through|into|away|over|along|forth))?"
    r"\b",
    re.IGNORECASE,
)
_MENTAL_STATE_TERMS = {
    "intentionally",
    "knowingly",
    "negligently",
    "purposely",
    "recklessly",
    "maliciously",
    "willfully",
    "wilfully",
    "fraudulently",
    "deliberately",
    "corruptly",
}
_MENTAL_STATE_TERM_PATTERN = "|".join(sorted(_MENTAL_STATE_TERMS, key=len, reverse=True))
_LEADING_COMPLEX_MENTAL_STATE_RE = re.compile(
    r"^\s*(?P<state>with\s+(?:the\s+)?(?:"
    r"intent\s+to\s+[^,;:]+|"
    r"knowledge\s+that\s+[^,;:]+|"
    r"reckless\s+disregard\s+for\s+[^,;:]+"
    r"))\s*,\s*(?P<action>.+)$",
    re.IGNORECASE,
)
_LEADING_COMPOUND_MENTAL_STATE_RE = re.compile(
    r"^\s*(?P<state>(?:"
    + _MENTAL_STATE_TERM_PATTERN
    + r")(?:\s*(?:,|and|or)\s*(?:"
    + _MENTAL_STATE_TERM_PATTERN
    + r")){1,4})\s+(?P<action>.+)$",
    re.IGNORECASE,
)
_RECIPIENT_RE = re.compile(
    r"\b(?:to|for)\s+((?:the\s+)?[A-Za-z][A-Za-z0-9'’\-]*(?:\s+[A-Za-z][A-Za-z0-9'’\-]*){0,6})$",
    re.IGNORECASE,
)
# "send the notice to the clerk" is a recipient. "eligible to the Office" and
# "power to enforce" are not: no giving verb governs that to/for.
_RECIPIENT_TRANSFER_RE = re.compile(
    r"\b(?:give|gives|given|send|sends|sent|present|presents|presented|"
    r"deliver|delivers|delivered|transmit|transmits|transmitted|"
    r"pay|pays|paid|submit|submits|submitted|provide|provides|provided|"
    r"direct|directs|directed|issue|issues|issued|return|returns|returned|"
    r"render|renders|rendered|furnish|furnishes|furnished|serve|serves|served|"
    r"remit|remits|remitted|award|awards|awarded|offer|offers|offered|"
    r"tender|tenders|tendered)\b"
    r"(?:\s+\S+){0,8}\s*$",
    re.IGNORECASE,
)
_NOT_RECIPIENT_HEAD = frozenset({
    "be", "do", "fill", "pay", "lay", "make", "provide", "regulate", "support",
    "raise", "collect", "borrow", "coin", "fix", "grant", "issue", "hold",
    "take", "give", "send", "appoint", "choose", "chuse", "elect", "vest",
    "consist", "secure", "promote", "establish", "define", "punish", "try",
    "which", "whom",
})
_DEFINITION_BODY_RE = re.compile(
    r"\b(?:means|includes?|defined\s+as|has\s+the\s+meaning\s+given|refers\s+to)\b\s+(.+)$",
    re.IGNORECASE,
)
_GOVERNMENT_ACTORS = {
    "administrator",
    "agency",
    "bureau",
    "city",
    "commission",
    "commissioner",
    "council",
    "department",
    "director",
    "engineer",
    "examiner",
    "hearings",
    "mayor",
    "officer",
    "secretary",
    "state",
    "auditor",
}
_LEGAL_PERSON_ACTORS = {
    "applicant",
    "borrower",
    "contractor",
    "defendant",
    "employee",
    "employer",
    "individual",
    "landlord",
    "lessee",
    "licensee",
    "owner",
    "party",
    "permittee",
    "person",
    "plaintiff",
    "resident",
    "tenant",
    "worker",
}
_ORGANIZATION_ACTORS = {
    "business",
    "company",
    "corporation",
    "entity",
    "institution",
    "organization",
    "provider",
}
_LEGAL_INSTRUMENT_ENTITIES = {
    "approval",
    "certificate",
    "clause",
    "compact",
    "constitution",
    "easement",
    "franchise",
    "instrument",
    "license",
    "ordinance",
    "paragraph",
    "permit",
    "proclamation",
    "registration",
    "regulation",
    "resolution",
    "statute",
    "subparagraph",
    "subsection",
    "treaty",
    "variance",
}
_LEGAL_EVENT_ENTITIES = {
    "appeal",
    "citation",
    "complaint",
    "fee",
    "hearing",
    "inspection",
    "notice",
    "offense",
    "order",
    "penalty",
    "review",
    "violation",
}
_PROPERTY_ENTITIES = {
    "building",
    "facility",
    "park",
    "premises",
    "property",
    "right-of-way",
    "sewer",
    "sidewalk",
    "street",
    "tree",
    "vehicle",
}
_PROCEDURE_EVENT_ORDER = [
    "application",
    "receipt",
    "inspection",
    "review",
    "notice",
    "hearing",
    "decision",
    "issuance",
    "renewal",
    "suspension",
    "revocation",
    "appeal",
]
_PROCEDURE_EVENT_PATTERNS = {
    "application": r"\b(?:apply|applies|application|applicant)\b",
    "receipt": r"\b(?:receipt|receive|received)\b",
    "inspection": r"\b(?:inspect|inspection)\b",
    "review": r"\b(?:review|investigate|investigation)\b",
    "notice": r"\b(?:notice|notify|notification)\b",
    "hearing": r"\b(?:hearing)\b",
    "decision": r"\b(?:decision|decide|determination|order)\b",
    "issuance": r"\b(?:issue|issued|issuance|grant|approve|approval)\b",
    "renewal": r"\b(?:renew|renewal)\b",
    "suspension": r"\b(?:suspend|suspension)\b",
    "revocation": r"\b(?:revoke|revocation)\b",
    "appeal": r"\b(?:appeal\w*)\b",
}


def extract_normative_elements(
    text: str,
    document_type: str = "statute",
    *,
    expand_enumerations: bool = False,
) -> List[Dict[str, Any]]:
    status_elements = _extract_section_status_lifecycle_elements(str(text or ""), document_type)
    if status_elements and _section_status_should_short_circuit(str(text or ""), status_elements):
        elements: List[Dict[str, Any]] = status_elements
        _apply_definition_context(elements)
        _apply_cross_reference_context(elements)
        _apply_same_document_reference_repair_clearance(elements)
        _apply_local_applicability_repair_clearance(elements)
        _apply_local_scope_condition_repair_clearance(elements)
        _apply_local_scope_exception_repair_clearance(elements)
        _apply_formula_resolved_repair_clearance(elements)
        _apply_active_repair_status(elements)
        _apply_document_penalty_context(elements, str(text or ""))
        _apply_enforcement_context(elements)
        _apply_conflict_context(elements)
        return elements
    elements = []
    segments = segment_legal_text(text)
    for segment in segments:
        segment_text = segment["text"].strip()
        if not segment_text:
            continue
        for element in analyze_normative_sentence(segment_text, document_type):
            element["source_span"] = segment["span"]
            element["section_context"] = segment["section_context"]
            element["hierarchy_path"] = segment["hierarchy_path"]
            element["hierarchy_details"] = segment.get("hierarchy_details", [])
            _finalize_element(element)
            if element.get("deontic_operator") and not element.get("modality"):
                element["modality"] = element["deontic_operator"]
            elements.append(element)
    if expand_enumerations:
        elements = expand_enumerated_norms(elements)
    _apply_definition_context(elements)
    _apply_cross_reference_context(elements)
    _apply_same_document_reference_repair_clearance(elements)
    _apply_local_applicability_repair_clearance(elements)
    _apply_local_scope_condition_repair_clearance(elements)
    _apply_local_scope_exception_repair_clearance(elements)
    _apply_formula_resolved_repair_clearance(elements)
    _apply_active_repair_status(elements)
    _apply_document_penalty_context(elements, str(text or ""))
    _apply_enforcement_context(elements)
    _apply_conflict_context(elements)
    for element in elements:
        _keep_without_phrase(element)
    return elements


def _apply_same_document_reference_repair_clearance(elements: List[Dict[str, Any]]) -> None:
    """Clear active repair when a reference exception resolves in-document.

    A clause such as ``except as provided in section 552`` is not proof-ready
    when parsed by itself. When the parser has same-document evidence that the
    cited section exists, however, the reference is deterministic provenance,
    not an LLM repair task. Parser warnings and theorem promotion remain
    conservative audit signals; this only updates active repair status.
    """

    for element in elements or []:
        if not _has_resolved_same_document_reference_exception(element):
            continue
        _mark_same_document_reference_resolutions(element)

        resolution = {
            "type": "resolved_same_document_reference_exception",
            "references": _same_document_reference_values(element),
            "reason": "numbered exception reference is backed by same-document section context",
        }

        element["active_repair_warnings"] = []
        element["repair_required_warnings"] = []

        readiness = dict(element.get("export_readiness") or {})
        readiness["metric_requires_validation"] = False
        readiness["metric_repair_required"] = False
        readiness["deterministic_resolution"] = resolution
        element["export_readiness"] = readiness

        repair = dict(element.get("llm_repair") or {})
        repair["required"] = False
        repair["allow_llm_repair"] = False
        repair["reasons"] = []
        repair["prompt_context"] = {}
        repair["prompt_hash"] = ""
        repair["suggested_router"] = ""
        repair["deterministically_resolved"] = True
        repair["deterministic_resolution"] = resolution
        element["llm_repair"] = repair


def _has_resolved_same_document_reference_exception(element: Dict[str, Any]) -> bool:
    if not element.get("exceptions") and not element.get("exception_details"):
        return False
    if not element.get("cross_references") and not element.get("cross_reference_details"):
        return False
    return any(
        isinstance(ref, dict)
        and ref.get("target_exists") is True
        and str(ref.get("resolution_status") or "").lower() == "resolved"
        for ref in element.get("resolved_cross_references") or []
    )


def _mark_same_document_reference_resolutions(element: Dict[str, Any]) -> None:
    """Expose same-document resolution in parser-native reference records."""

    resolved_references: List[Dict[str, Any]] = []
    for ref in element.get("resolved_cross_references") or []:
        if not isinstance(ref, dict):
            continue
        if (
            ref.get("target_exists") is True
            and str(ref.get("resolution_status") or "").lower() == "resolved"
        ):
            enriched = dict(ref)
            enriched["resolved"] = True
            enriched["same_document"] = True
            enriched.setdefault("resolution_scope", "same_document")
            resolved_references.append(enriched)
        else:
            resolved_references.append(dict(ref))

    element["resolved_cross_references"] = resolved_references


def _same_document_reference_values(element: Dict[str, Any]) -> List[str]:
    values: List[str] = []
    for ref in element.get("resolved_cross_references") or []:
        if not isinstance(ref, dict) or ref.get("target_exists") is not True:
            continue
        value = _same_document_reference_display_text(ref)
        if value and value not in values:
            values.append(value)
    return values


def _same_document_reference_display_text(ref: Dict[str, Any]) -> str:
    """Return canonical display text for same-document reference provenance."""

    for key in ("canonical_citation", "citation", "normalized_text", "raw_text", "text"):
        value = str(ref.get(key) or "").strip()
        if value:
            return value

    reference_type = str(ref.get("reference_type") or ref.get("type") or "").strip().lower()
    target = str(ref.get("target") or ref.get("section") or ref.get("value") or "").strip()
    if (
        reference_type == "section"
        and target
        and target.lower() not in {"this", "current"}
        and not target.lower().startswith("section ")
        and not re.search(r"\s", target)
    ):
        return f"section {target}"
    if reference_type and target and not target.lower().startswith(reference_type + " "):
        return f"{reference_type} {target}"
    return target


def _apply_local_applicability_repair_clearance(elements: List[Dict[str, Any]]) -> None:
    """Mark local self-scope applicability as resolved repair provenance.

    ``This section applies to ...`` carries a syntactic cross-reference because
    the subject is the local section. That reference is useful provenance, but
    it is not active repair work: the formula/export layer can deterministically
    treat it as local self-scope without an LLM or external citation lookup.

    Keep ``parser_warnings`` intact for audit and warning-distribution metrics;
    expose the active repair channel separately so repair counters do not treat
    the local self-reference as unresolved work.
    """

    for element in elements or []:
        if not _is_local_applicability_element(element):
            continue

        local_records = _local_applicability_reference_records(element)
        if not local_records:
            continue

        element["resolved_cross_references"] = local_records
        element["active_repair_warnings"] = []
        element["repair_required_warnings"] = []

        readiness = dict(element.get("export_readiness") or {})
        readiness["metric_requires_validation"] = False
        readiness["metric_repair_required"] = False
        readiness["local_applicability_resolved"] = True
        readiness["deterministic_resolution"] = {
            "type": "local_scope_applicability",
            "scopes": sorted(
                {record.get("value", "") for record in local_records if record.get("value")}
            ),
            "reason": "local applicability subject is a self-scope reference exported as provenance",
        }
        element["export_readiness"] = readiness

        repair = dict(element.get("llm_repair") or {})
        repair["required"] = False
        repair["allow_llm_repair"] = False
        repair["reasons"] = []
        repair["prompt_context"] = {}
        repair["prompt_hash"] = ""
        repair["suggested_router"] = ""
        repair["deterministically_resolved"] = True
        repair["deterministic_resolution"] = readiness["deterministic_resolution"]
        element["llm_repair"] = repair


def _is_local_applicability_element(element: Dict[str, Any]) -> bool:
    if element.get("norm_type") != "applicability":
        return False
    operator = str(element.get("deontic_operator") or element.get("modality") or "").strip()
    if operator and operator != "APP":
        return False
    action = _first_text(element.get("action")).strip().lower()
    if not action.startswith(("apply to ", "applies to ", "shall apply to ", "is applicable to ")):
        return False
    subject = _first_text(element.get("subject")).strip().lower()
    if subject not in {
        "this section",
        "this subsection",
        "this chapter",
        "this title",
        "this article",
        "this part",
        "the section",
        "the chapter",
        "the title",
        "the article",
        "the part",
    }:
        return False
    if element.get("exceptions") or element.get("exception_details"):
        return False
    if element.get("override_clauses") or element.get("override_clause_details"):
        return False
    return True


def _local_applicability_reference_records(element: Dict[str, Any]) -> List[Dict[str, Any]]:
    refs = list(element.get("cross_reference_details") or element.get("cross_references") or [])
    if not refs:
        refs = [
            {
                "type": "section",
                "value": _first_text(element.get("subject")),
                "raw_text": _first_text(element.get("subject")),
                "span": (element.get("field_spans") or {}).get("subject", []),
            }
        ]

    records: List[Dict[str, Any]] = []
    for ref in refs:
        if not isinstance(ref, dict):
            return []
        reference_type = (
            str(ref.get("reference_type") or ref.get("type") or "section").strip().lower()
        )
        if reference_type not in {"section", "subsection", "chapter", "title", "article", "part"}:
            return []

        text = (
            str(
                ref.get("value")
                or ref.get("normalized_text")
                or ref.get("raw_text")
                or ref.get("text")
                or ""
            )
            .strip()
            .lower()
        )
        target = (
            str(ref.get("target") or ref.get("section") or ref.get("subsection") or "")
            .strip()
            .lower()
        )
        scope = ""
        if target in {"this", f"this {reference_type}"}:
            scope = f"this {reference_type}"
        elif text in {
            f"this {reference_type}",
            f"the {reference_type}",
            f"section this {reference_type}",
        }:
            scope = f"this {reference_type}"
        if not scope:
            return []

        record = {
            "reference_type": reference_type,
            "target": "this",
            "value": scope,
            "raw_text": str(ref.get("raw_text") or ref.get("text") or scope),
            "span": list(ref.get("span") or []),
            "resolution_scope": "local_self",
            "resolved": True,
            "resolution_status": "resolved",
            "same_document": True,
            "target_exists": True,
        }
        records.append(record)
    return records


def _apply_local_scope_condition_repair_clearance(elements: List[Dict[str, Any]]) -> None:
    """Clear active repair for exact local self-scope condition references.

    ``Subject to this section`` is a local provenance constraint, not an
    unresolved external citation. Keep parser warnings and theorem promotion
    conservative, but avoid queuing an LLM repair prompt when the condition is
    only that local self-reference.
    """

    for element in elements or []:
        if not _is_local_scope_condition_element(element):
            continue

        scopes = _local_scope_condition_scopes(element)
        if not scopes:
            continue

        resolution = {
            "type": "local_scope_reference_condition",
            "scopes": scopes,
            "reason": "local self-reference condition is exported as provenance outside the operative formula",
        }

        element["active_repair_warnings"] = []
        element["repair_required_warnings"] = []

        readiness = dict(element.get("export_readiness") or {})
        readiness["metric_requires_validation"] = False
        readiness["metric_repair_required"] = False
        readiness["deterministic_resolution"] = resolution
        element["export_readiness"] = readiness

        repair = dict(element.get("llm_repair") or {})
        repair["required"] = False
        repair["allow_llm_repair"] = False
        repair["reasons"] = []
        repair["prompt_context"] = {}
        repair["prompt_hash"] = ""
        repair["suggested_router"] = ""
        repair["deterministically_resolved"] = True
        repair["deterministic_resolution"] = resolution
        element["llm_repair"] = repair


def _is_local_scope_condition_element(element: Dict[str, Any]) -> bool:
    if element.get("norm_type") not in {"obligation", "permission", "prohibition"}:
        return False
    if not element.get("conditions") and not element.get("condition_details"):
        return False
    if element.get("exceptions") or element.get("exception_details"):
        return False
    if element.get("override_clauses") or element.get("override_clause_details"):
        return False

    warnings = set(element.get("parser_warnings") or [])
    allowed_warnings = {"cross_reference_requires_resolution", "llm_repair_required"}
    if not warnings or not warnings.issubset(allowed_warnings):
        return False
    return "cross_reference_requires_resolution" in warnings


def _local_scope_condition_scopes(element: Dict[str, Any]) -> List[str]:
    scopes: List[str] = []
    condition_records = element.get("condition_details") or []
    if not condition_records:
        condition_records = [
            {"normalized_text": text}
            for text in element.get("conditions") or []
            if isinstance(text, str)
        ]

    if not condition_records:
        return []

    pattern = re.compile(
        r"^(?:this|current)\s+(section|subsection|chapter|title|article|part)$", re.IGNORECASE
    )
    for record in condition_records:
        if not isinstance(record, dict):
            return []
        text = str(
            record.get("normalized_text") or record.get("raw_text") or record.get("value") or ""
        ).strip()
        match = pattern.match(text)
        if not match:
            return []
        scope = f"this {match.group(1).lower()}"
        if scope not in scopes:
            scopes.append(scope)
    return scopes


def _apply_local_scope_exception_repair_clearance(elements: List[Dict[str, Any]]) -> None:
    """Clear active repair for exact local self-scope exception references.

    ``except as provided in this section`` is an auditable reference to the
    current local legal scope, not an unresolved external citation. Keep parser
    warnings and theorem promotion conservative, but do not enqueue an LLM
    repair prompt when the exception is only that local self-reference.
    """

    for element in elements or []:
        if not _is_local_scope_exception_element(element):
            continue

        scopes = _local_scope_exception_scopes(element)
        if not scopes:
            continue

        resolution = {
            "type": "local_scope_reference_exception",
            "scopes": scopes,
            "reason": "local self-reference exception is exported as provenance outside the operative formula",
        }

        element["active_repair_warnings"] = []
        element["repair_required_warnings"] = []

        readiness = dict(element.get("export_readiness") or {})
        readiness["metric_requires_validation"] = False
        readiness["metric_repair_required"] = False
        readiness["deterministic_resolution"] = resolution
        element["export_readiness"] = readiness

        repair = dict(element.get("llm_repair") or {})
        repair["required"] = False
        repair["allow_llm_repair"] = False
        repair["reasons"] = []
        repair["prompt_context"] = {}
        repair["prompt_hash"] = ""
        repair["suggested_router"] = ""
        repair["deterministically_resolved"] = True
        repair["deterministic_resolution"] = resolution
        element["llm_repair"] = repair


def _is_local_scope_exception_element(element: Dict[str, Any]) -> bool:
    if element.get("norm_type") not in {"obligation", "permission", "prohibition"}:
        return False
    if not element.get("exceptions") and not element.get("exception_details"):
        return False
    if element.get("override_clauses") or element.get("override_clause_details"):
        return False

    warnings = set(element.get("parser_warnings") or [])
    allowed_warnings = {"exception_requires_scope_review", "llm_repair_required"}
    if not warnings or not warnings.issubset(allowed_warnings):
        return False
    return "exception_requires_scope_review" in warnings


def _local_scope_exception_scopes(element: Dict[str, Any]) -> List[str]:
    scopes: List[str] = []
    exception_records = element.get("exception_details") or []
    if not exception_records:
        exception_records = [
            {"normalized_text": text}
            for text in element.get("exceptions") or []
            if isinstance(text, str)
        ]

    if not exception_records:
        return []

    pattern = re.compile(
        r"^(?:as\s+(?:otherwise\s+)?provided\s+in|(?:otherwise\s+)?provided\s+in|under|pursuant\s+to)\s+this\s+"
        r"(section|subsection|chapter|title|article|part)$",
        re.IGNORECASE,
    )
    for record in exception_records:
        if not isinstance(record, dict):
            return []
        text = str(
            record.get("normalized_text") or record.get("raw_text") or record.get("value") or ""
        ).strip()
        match = pattern.match(text)
        if not match:
            return []
        scope = f"this {match.group(1).lower()}"
        if scope not in scopes:
            scopes.append(scope)
    return scopes


def _apply_formula_resolved_repair_clearance(elements: List[Dict[str, Any]]) -> None:
    """Clear raw repair payloads when typed formula readiness resolved them.

    Parser warnings remain audit facts and parser theorem promotion remains
    conservative. This only clears active repair accounting for clauses where
    the IR/formula layer has already produced an explicit source-grounded
    deterministic resolution: a single substantive exception represented as a
    negated antecedent, or an override used solely as precedence provenance.
    Numbered reference exceptions without same-document resolution remain
    blocked by the formula record and are not changed here.
    """

    try:
        from ipfs_datasets_py.logic.deontic.formula_builder import parser_element_to_formula_record
    except ImportError:  # pragma: no cover - defensive import guard
        return

    clearable_resolution_types = {
        "standard_substantive_exception",
        "pure_precedence_override",
    }

    for element in elements or []:
        if _is_local_applicability_element(element):
            continue

        try:
            formula_record = parser_element_to_formula_record(element)
        except Exception:  # pragma: no cover - repair clearance must never break parsing
            continue

        deterministic_resolution = formula_record.get("deterministic_resolution") or {}
        resolution_type = deterministic_resolution.get("type")
        if resolution_type not in clearable_resolution_types:
            continue
        if formula_record.get("proof_ready") is not True:
            continue
        if formula_record.get("requires_validation") or formula_record.get("repair_required"):
            continue

        if resolution_type == "pure_precedence_override":
            precedence_records = _precedence_override_reference_records(element)
            if not precedence_records:
                continue
            element["resolved_cross_references"] = precedence_records

        element["active_repair_warnings"] = []
        element["repair_required_warnings"] = []

        readiness = dict(element.get("export_readiness") or {})
        readiness["metric_requires_validation"] = False
        readiness["metric_repair_required"] = False
        readiness["deterministic_resolution"] = deterministic_resolution
        element["export_readiness"] = readiness

        repair = dict(element.get("llm_repair") or {})
        repair["required"] = False
        repair["allow_llm_repair"] = False
        repair["reasons"] = []
        repair["prompt_context"] = {}
        repair["prompt_hash"] = ""
        repair["suggested_router"] = ""
        repair["deterministically_resolved"] = True
        repair["deterministic_resolution"] = deterministic_resolution
        element["llm_repair"] = repair


def _apply_active_repair_status(elements: List[Dict[str, Any]]) -> None:
    """Expose active repair status separately from audit warnings.

    Parser warnings are intentionally retained after deterministic formula
    resolution so warning-distribution and parser-gate metrics stay stable.
    Repair metrics, however, need a direct parser-level predicate for whether a
    row still requires repair work. This projection mirrors the current
    ``llm_repair.required`` payload after local/formula repair clearance and
    keeps unresolved numbered or external references active.
    """

    for element in elements or []:
        repair = dict(element.get("llm_repair") or {})
        active_required = bool(repair.get("required"))
        if active_required:
            active_warnings = list(repair.get("reasons") or element.get("parser_warnings") or [])
        else:
            active_warnings = []

        element["active_repair_required"] = active_required
        element["repair_required"] = active_required
        element["active_repair_warnings"] = active_warnings
        element["repair_required_warnings"] = active_warnings


def _precedence_override_reference_records(element: Dict[str, Any]) -> List[Dict[str, Any]]:
    records: List[Dict[str, Any]] = []
    seen: set[str] = set()
    refs = element.get("cross_reference_details") or element.get("cross_references") or []
    for ref in refs:
        if not isinstance(ref, dict):
            continue
        reference_type = (
            str(ref.get("reference_type") or ref.get("type") or "section").strip().lower()
        )
        value = str(
            ref.get("value")
            or ref.get("canonical_citation")
            or ref.get("normalized_text")
            or ref.get("raw_text")
            or ""
        ).strip()
        if not value:
            target = str(ref.get("target") or ref.get("section") or "").strip()
            value = f"{reference_type} {target}".strip() if target else ""
        if not value:
            continue
        canonical = (
            value if value.lower().startswith(reference_type + " ") else f"{reference_type} {value}"
        )
        key = canonical.lower()
        if key in seen:
            continue
        raw_text = str(ref.get("raw_text") or ref.get("text") or canonical)
        records.append(
            {
                "type": reference_type,
                "value": value,
                "raw_text": raw_text,
                "normalized_text": canonical,
                "span": list(ref.get("span") or []),
                "resolution_scope": "precedence_provenance",
                "resolved": True,
                "resolution_status": "resolved",
                "precedence_only": True,
                "same_document": False,
                "target_exists": False,
            }
        )
        seen.add(key)
    return records


def expand_enumerated_norms(elements: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Expand modal-governed enumerated lists into item-level norm elements.

    The default parser keeps enumerated clauses as one parent scaffold for
    backward compatibility. Formal logic exporters often need one formula per
    list item, so this helper creates deterministic child elements that inherit
    the parent actor, modality, conditions, references, and hierarchy context.
    """

    expanded: List[Dict[str, Any]] = []
    for element in elements or []:
        items = element.get("enumerated_items") or []
        if not items:
            expanded.append(element)
            continue
        parent_source_id = element.get("source_id") or build_source_id(element)
        child_elements = [
            _build_enumerated_child_element(element, item, parent_source_id)
            for item in items
            if isinstance(item, dict) and item.get("text")
        ]
        if child_elements:
            expanded.extend(child_elements)
        else:
            expanded.append(element)
    return expanded


def _build_enumerated_child_element(
    parent: Dict[str, Any],
    item: Dict[str, Any],
    parent_source_id: str,
) -> Dict[str, Any]:
    action_text = _clean_action(str(item.get("text") or ""))
    sentence = str(parent.get("text") or "")
    action_span = _find_span(sentence, action_text)
    support_span = action_span or list(parent.get("support_span") or [])
    child = dict(parent)
    child.update(
        {
            "parent_source_id": parent_source_id,
            "enumeration_label": str(item.get("label") or ""),
            "support_text": action_text,
            "support_span": support_span,
            "action": [action_text],
            "action_verb": _first_verb(action_text),
            "action_object": _action_object(action_text),
            "action_recipient": extract_action_recipient(action_text),
            "enumerated_items": [],
            "extraction_method": "deterministic_enumerated_item_v1",
        }
    )
    field_spans = dict(parent.get("field_spans") or {})
    field_spans["action"] = action_span
    action_start = action_span[0] if len(action_span) == 2 else 0
    field_spans["action_verb"] = _find_span(sentence, child["action_verb"], start=action_start)
    field_spans["action_object"] = _find_span(sentence, child["action_object"], start=action_start)
    field_spans["action_recipient"] = _find_span(
        sentence, child["action_recipient"], start=action_start
    )
    child["field_spans"] = field_spans
    return _finalize_element(child)


def _split_legal_sentences(text: str) -> List[str]:
    normalized = re.sub(r"\s+", " ", str(text or "")).strip()
    if not normalized:
        return []
    # Avoid splitting common legal abbreviations such as U.S.C. and Pub. L.
    protected = (
        normalized.replace("U.S.C.", "USC")
        .replace("U.S.", "US")
        .replace("Pub. L.", "Pub L")
        .replace("Sec.", "Sec")
    )
    return [part.strip(" .") for part in _SENTENCE_SPLIT_RE.split(protected) if part.strip(" .")]


def segment_legal_text(text: str) -> List[Dict[str, Any]]:
    """Split legal text into statute-aware segments with hierarchy metadata."""
    source = str(text or "")
    if not source.strip():
        return []

    segments: List[Dict[str, Any]] = []
    section_context: Dict[str, str] = {}
    hierarchy: List[str] = []
    hierarchy_details: List[Dict[str, Any]] = []
    cursor = 0

    for raw_line in source.splitlines() or [source]:
        line_start = cursor
        cursor += len(raw_line) + 1
        line = raw_line.strip()
        if not line:
            continue

        hierarchy_header = _HIERARCHY_HEADER_RE.match(line)
        if hierarchy_header:
            level = hierarchy_header.group(1).lower()
            value = hierarchy_header.group(2)
            heading = hierarchy_header.group(3).strip(" .")
            hierarchy = [item for item in hierarchy if not _hierarchy_path_replaced_by(level, item)]
            hierarchy.append(f"{level}:{value}")
            detail_start = line_start + raw_line.find(line)
            hierarchy_details = [
                item for item in hierarchy_details if not _hierarchy_detail_replaced_by(level, item)
            ]
            hierarchy_details.append(
                {
                    "level": level,
                    "value": value,
                    "heading": heading,
                    "span": [
                        detail_start + hierarchy_header.start(),
                        detail_start + hierarchy_header.end(),
                    ],
                }
            )
            continue

        header = _SECTION_HEADER_RE.match(line)
        if header and _looks_like_section_header(line, header):
            section_context = {
                "section": header.group(1),
                "heading": header.group(2).strip(" ."),
            }
            hierarchy = [
                item
                for item in hierarchy
                if not item.startswith(("section:", "heading:", "paragraph:", "subsection:"))
            ]
            hierarchy.append(f"section:{section_context['section']}")
            if section_context["heading"]:
                hierarchy.append(f"heading:{section_context['heading']}")
            detail_start = line_start + raw_line.find(line)
            hierarchy_details = [
                item
                for item in hierarchy_details
                if item.get("level") not in {"section", "paragraph", "subsection"}
            ]
            hierarchy_details.append(
                {
                    "level": "section",
                    "value": section_context["section"],
                    "heading": section_context["heading"],
                    "span": [detail_start + header.start(), detail_start + header.end()],
                }
            )
            continue

        for start, end, segment_text, label_path in _split_segment_fragments(line):
            absolute_start = line_start + raw_line.find(line) + start
            segment_hierarchy = [*hierarchy, *label_path]
            segment_hierarchy_details = [
                *hierarchy_details,
                *[
                    {
                        "level": "paragraph",
                        "value": label.split(":", 1)[1],
                        "heading": "",
                        "span": [absolute_start, absolute_start + len(label.split(":", 1)[1]) + 2],
                    }
                    for label in label_path
                    if label.startswith("paragraph:")
                ],
            ]
            segment_section_context = dict(section_context)
            for sentence in _split_legal_sentences(segment_text):
                sentence_offset = segment_text.find(sentence)
                if sentence_offset < 0:
                    sentence_offset = 0
                sentence_start = absolute_start + sentence_offset
                citation_context = _citation_context_from_sentence(sentence)
                if citation_context:
                    segment_section_context = {
                        **segment_section_context,
                        **citation_context,
                    }
                    if not _sentence_has_normative_cue(sentence):
                        continue
                segments.append(
                    {
                        "text": sentence,
                        "span": [sentence_start, sentence_start + len(sentence)],
                        "section_context": dict(segment_section_context),
                        "hierarchy_path": segment_hierarchy,
                        "hierarchy_details": segment_hierarchy_details,
                    }
                )

    if not segments:
        normalized = re.sub(r"\s+", " ", source).strip()
        return [
            {
                "text": normalized,
                "span": [0, len(normalized)],
                "section_context": {},
                "hierarchy_path": [],
                "hierarchy_details": [],
            }
        ]
    return segments


def _citation_context_from_sentence(sentence: str) -> Dict[str, str]:
    """Return U.S.C./section context carried by official excerpt lead-ins."""

    text = str(sentence or "").strip()
    if not text:
        return {}

    usc_match = _USC_CITATION_CONTEXT_RE.search(text)
    if usc_match:
        title = usc_match.group("title")
        section = usc_match.group("section")
        heading = _clean_citation_heading(usc_match.group("heading"))
        context = {
            "title": title,
            "section": section,
            "canonical_citation": f"{title} U.S.C. {section}",
        }
        if heading:
            context["heading"] = heading
        return context

    sec_match = _SEC_CITATION_CONTEXT_RE.search(text)
    if sec_match:
        if _sentence_has_normative_cue(text):
            return {}
        section = sec_match.group("section")
        heading = _clean_citation_heading(sec_match.group("heading"))
        context = {"section": section}
        if heading:
            context["heading"] = heading
        return context
    return {}


def _clean_citation_heading(value: str) -> str:
    heading = re.sub(r"\s+", " ", str(value or "")).strip(" .:-")
    if not heading:
        return ""
    if _sentence_has_normative_cue(heading):
        return ""
    if len(heading.split()) > 12:
        return ""
    return heading


def _sentence_has_normative_cue(sentence: str) -> bool:
    return bool(
        re.search(
            r"\b(?:shall|must|may|required|prohibited|authorized|"
            r"permitted|applies|apply|means|exempt|unlawful)\b",
            str(sentence or ""),
            re.IGNORECASE,
        )
    )


def _hierarchy_path_replaced_by(level: str, item: str) -> bool:
    order = ["title", "division", "chapter", "article", "part"]
    if ":" not in item or level not in order:
        return False
    item_level = item.split(":", 1)[0]
    return item_level in order and order.index(item_level) >= order.index(level)


def _hierarchy_detail_replaced_by(level: str, item: Dict[str, Any]) -> bool:
    order = ["title", "division", "chapter", "article", "part"]
    item_level = item.get("level")
    return bool(
        item_level in order and level in order and order.index(item_level) >= order.index(level)
    )


def _looks_like_section_header(line: str, match: re.Match[str]) -> bool:
    marker = match.group(0)
    if re.match(r"^\s*(?:sec(?:tion)?\.?|§)\b", line, re.IGNORECASE):
        return True
    heading = match.group(2).strip()
    return bool(
        heading
        and len(line) < 140
        and not re.search(r"\b(?:shall|must|may|means|includes?)\b", line, re.IGNORECASE)
    )


_CITATION_PARENTHETICAL_PREFIX_RE = re.compile(
    r"\b(?:subsections?|subsecs?\.?|paragraphs?|paras?\.?|subparagraphs?|"
    r"clauses?|sections?|secs?\.?|items?)\s*$",
    re.IGNORECASE,
)
_CITATION_LABEL_TRAILER_RE = re.compile(r"(?:\s*\([A-Za-z0-9]+\))+\s*$")
_CITATION_SERIES_TRAILER_RE = re.compile(
    r"(?:\s*,)?\s*(?:and|or|through|to)\s+$|\s*,\s*$",
    re.IGNORECASE,
)


def _is_citation_parenthetical(line: str, match: re.Match[str]) -> bool:
    """True for unit cites such as ``subsection (a)``, including series and nests."""

    prefix = line[: match.start()]
    while prefix:
        trimmed = _CITATION_LABEL_TRAILER_RE.sub("", prefix)
        if trimmed == prefix:
            trimmed = _CITATION_SERIES_TRAILER_RE.sub("", prefix)
        if trimmed == prefix:
            break
        prefix = trimmed
    return bool(_CITATION_PARENTHETICAL_PREFIX_RE.search(prefix))


def _split_segment_fragments(line: str) -> List[tuple[int, int, str, List[str]]]:
    matches = [
        match
        for match in _ENUM_LABEL_RE.finditer(line)
        if not _is_citation_parenthetical(line, match)
    ]
    if not matches:
        return [(0, len(line), line, [])]

    prefix = line[: matches[0].start()].strip()
    if prefix:
        return [(0, len(line), line, [])]
    fragments: List[tuple[int, int, str, List[str]]] = []
    for index, match in enumerate(matches):
        start = match.end()
        end = matches[index + 1].start() if index + 1 < len(matches) else len(line)
        body = line[start:end].strip(" ;,.")
        if not body:
            continue
        fragments.append((match.start(), end, body, [f"paragraph:{match.group(1)}"]))
    return fragments


def analyze_normative_sentence(sentence: str, document_type: str) -> List[Dict[str, Any]]:
    sentence = sentence.strip()
    sentence_lower = sentence.lower()
    elements: List[Dict[str, Any]] = []

    savings_match = _SAVINGS_PRESERVATION_RE.search(sentence)
    if savings_match:
        return [
            _finalize_element(
                _build_savings_preservation_element(
                    sentence=sentence,
                    document_type=document_type,
                    match=savings_match,
                )
            )
        ]

    critical_match = _CRITICAL_THAT_RE.search(sentence)
    if critical_match:
        subject_text = _clean_phrase(critical_match.group("subject"))
        action_text = _clean_action(critical_match.group("action"))
        if action_text:
            return [
                _finalize_element(
                    _build_element(
                        sentence=sentence,
                        document_type=document_type,
                        norm_type="obligation",
                        deontic_operator="O",
                        modal=f"is {critical_match.group('modal').lower()} that",
                        subject_text=subject_text,
                        action_text=action_text,
                        support_span=critical_match.span(),
                        field_spans={
                            "subject": list(critical_match.span("subject")),
                            "modal": list(critical_match.span("modal")),
                            "action": list(critical_match.span("action")),
                        },
                        extraction_method="deterministic_critical_that_clause_v1",
                    )
                )
            ]

    hereby_match = _HEREBY_AUTHORIZED_RE.search(sentence)
    if hereby_match:
        modal = re.sub(r"\s+", " ", hereby_match.group("modal").lower()).strip()
        subject_text = _clean_phrase(hereby_match.group("subject"))
        action_text = _clean_action(
            _strip_leading_authorized_action_prefix(hereby_match.group("action"))
        )
        norm_type, deontic_operator = (
            ("obligation", "O") if "directed" in modal else ("permission", "P")
        )
        if action_text:
            return [
                _finalize_element(
                    _build_element(
                        sentence=sentence,
                        document_type=document_type,
                        norm_type=norm_type,
                        deontic_operator=deontic_operator,
                        modal=modal,
                        subject_text=subject_text,
                        action_text=action_text,
                        support_span=hereby_match.span(),
                        field_spans={
                            "subject": list(hereby_match.span("subject")),
                            "modal": list(hereby_match.span("modal")),
                            "action": list(hereby_match.span("action")),
                        },
                        extraction_method="deterministic_hereby_authorized_clause_v1",
                    )
                )
            ]

    dash_modal_match = _DASH_MODAL_RE.search(sentence)
    if dash_modal_match:
        modal = re.sub(r"\s+", " ", dash_modal_match.group("modal").lower()).strip()
        norm_type, deontic_operator = classify_modal(modal)
        subject_text = _clean_phrase(dash_modal_match.group("subject"))
        action_text = _clean_action(
            _strip_leading_authorized_action_prefix(dash_modal_match.group("action"))
        )
        if action_text:
            return [
                _finalize_element(
                    _build_element(
                        sentence=sentence,
                        document_type=document_type,
                        norm_type=norm_type,
                        deontic_operator=deontic_operator,
                        modal=modal,
                        subject_text=subject_text,
                        action_text=action_text,
                        support_span=dash_modal_match.span(),
                        field_spans={
                            "subject": list(dash_modal_match.span("subject")),
                            "modal": list(dash_modal_match.span("modal")),
                            "action": list(dash_modal_match.span("action")),
                        },
                        extraction_method="deterministic_dash_modal_clause_v1",
                    )
                )
            ]

    for proviso in _PROVIDED_THAT_NO_RE.finditer(sentence):
        proviso_subject = _clean_phrase(proviso.group("subject"))
        proviso_action = _clean_action(proviso.group("action"))
        if not proviso_subject or not proviso_action:
            continue
        proviso_element = _finalize_element(
            _build_element(
                sentence=sentence,
                document_type=document_type,
                norm_type="prohibition",
                deontic_operator="F",
                modal="shall not",
                subject_text=proviso_subject,
                action_text=proviso_action,
                support_span=proviso.span(),
                field_spans={
                    "subject": list(proviso.span("subject")),
                    "action": list(proviso.span("action")),
                },
                extraction_method="deterministic_provided_that_no_v1",
            )
        )
        action_text = f"Provided that {proviso_action}"
        proviso_element["action"] = [action_text]
        if proviso_element.get("action_object"):
            proviso_element["action_object"] = f"Provided that {proviso_element['action_object']}"
        elements.append(proviso_element)

    as_then = _AS_THEN_SHALL_NOT_RE.match(sentence.strip())
    if as_then and not elements:
        subject_text = _clean_phrase(as_then.group("subject"))
        action_text = _clean_action(as_then.group("action"))
        if subject_text and action_text and not re.search(r"\bshall\b", subject_text, flags=re.IGNORECASE):
            element = _finalize_element(
                _build_element(
                    sentence=sentence,
                    document_type=document_type,
                    norm_type="prohibition",
                    deontic_operator="F",
                    modal="shall not",
                    subject_text=subject_text,
                    action_text=action_text,
                    support_span=as_then.span(),
                    field_spans={
                        "subject": list(as_then.span("subject")),
                        "action": list(as_then.span("action")),
                    },
                    extraction_method="deterministic_as_then_shall_not_v1",
                )
            )
            admitted = " ".join(as_then.group("as").split())
            if admitted:
                _with_condition(element, admitted)
            return [element]

    effect_elements = _effect_before_approval_elements(sentence, document_type)
    if effect_elements and not elements:
        return effect_elements

    relative_head = _RELATIVE_HEAD_SHALL_RE.match(sentence)
    if relative_head and not elements:
        subject_text = _clean_phrase(relative_head.group("subject"))
        action_text = _clean_action(relative_head.group("action"))
        modal = re.sub(r"\s+", " ", relative_head.group("modal").lower()).strip()
        if (
            subject_text
            and action_text
            and " to which " not in subject_text.lower()
            and not re.search(r"\b(?:shall|must|may)\b", subject_text, flags=re.IGNORECASE)
        ):
            norm_type, deontic_operator = classify_modal(modal)
            element = _finalize_element(
                _build_element(
                    sentence=sentence,
                    document_type=document_type,
                    norm_type=norm_type,
                    deontic_operator=deontic_operator,
                    modal=modal,
                    subject_text=subject_text,
                    action_text=action_text,
                    support_span=relative_head.span(),
                    field_spans={
                        "subject": list(relative_head.span("subject")),
                        "modal": list(relative_head.span("modal")),
                        "action": list(relative_head.span("action")),
                    },
                    extraction_method="deterministic_relative_head_shall_v1",
                )
            )
            which = " ".join(relative_head.group("which").split())
            if which:
                _with_condition(element, which)
            return [element]

    pending_after = ""
    matches = list(_MODAL_RE.finditer(sentence))
    for index, match in enumerate(matches):
        modal = re.sub(r"\s+", " ", match.group("modal").lower()).strip()
        norm_type, deontic_operator = classify_modal(modal)
        raw_subject = match.group("subject")
        coordinated = _coordinated_no_head(sentence, match)
        if coordinated:
            raw_subject = f"{coordinated} {raw_subject}"
        negated_subject = _has_leading_negated_subject(raw_subject)
        if deontic_operator in {"O", "P"} and negated_subject:
            norm_type, deontic_operator = "prohibition", "F"
        subject_text = (
            _clean_negated_subject_phrase(raw_subject)
            if negated_subject
            else _clean_phrase(raw_subject)
        )
        if_comma = _IF_COMMA_RE.search(sentence)
        if if_comma and if_comma.start("body") <= match.start() < if_comma.end("body"):
            continue
        subject_text = _trim_embedded_heading_subject(subject_text)
        subject_text = re.sub(
            r"^(?:if|when|whenever)\s+(?:not\s+)?",
            "",
            subject_text,
            flags=re.IGNORECASE,
        ).strip()
        if subject_text.lower().startswith("be "):
            continue
        if subject_text.lower().startswith("provided that"):
            continue
        if subject_text.lower().startswith("immediately after") and _MODAL_RE.search(sentence, match.end()):
            pending_after = " ".join(match.group(0).split()).strip(" ,.")
            continue
        if subject_text.lower().startswith("within ") and _MODAL_RE.search(sentence, match.end()):
            continue
        inverted_lead = subject_text.lower() in {"and", "or", "nor", "but", "neither"}
        if _skip_subject(subject_text) and not inverted_lead:
            continue
        if _EMBEDDED_RELATIVE_SUBJECT_RE.match(subject_text) and any(
            not _EMBEDDED_RELATIVE_SUBJECT_RE.match(_clean_phrase(later.group("subject") or ""))
            for later in matches[index + 1 :]
        ):
            continue
        subject_text = _expand_infinitive_subject(sentence, subject_text, match)
        subject_text = _restore_provided_that(sentence, subject_text, match)
        subject_text = _restore_otherwise(sentence, subject_text, match)
        action_text = _keep_inhabitant_clause(
            sentence,
            _restore_interrupted_action(
                sentence,
                _clean_action(match.group("action")),
                span=match.span(),
            ),
        )
        power = _enumerated_power_before(sentence, match)
        if power and power.lower() not in action_text.lower():
            action_text = f"{power}, {action_text}"
        follows = _as_follows_tail(sentence, match)
        if follows and follows.lower() not in action_text.lower():
            action_text = f"{action_text}, {follows}"
        action_text = _flatten_relative_shall(action_text)
        if inverted_lead:
            repaired_subject, repaired_action = _split_inverted_action(action_text)
            if not repaired_subject:
                continue
            subject_text = repaired_subject
            action_text = repaired_action
            if inverted_lead in {"nor", "neither"}:
                norm_type, deontic_operator = "prohibition", "F"
        lead = _clause_lead(sentence, match)
        if lead and lead.lower() not in action_text.lower():
            action_text = f"{action_text} {lead}"
        colon_object = _colon_object(sentence, match)
        if colon_object and colon_object.lower() not in action_text.lower():
            action_text = f"{action_text} {colon_object}"
        grant_without = _grant_without(sentence, match, deontic_operator)
        if grant_without and grant_without.lower() not in action_text.lower():
            action_text = f"{action_text} {grant_without}"
        manner = _manner_phrase(sentence, match)
        if manner and manner.lower() not in action_text.lower():
            action_text = f"{action_text} {manner}"
        if index + 1 == len(matches):
            action_text = _append_elliptical_nor(sentence, action_text, start=match.end())
        if pending_after and pending_after.lower() not in action_text.lower():
            action_text = f"{action_text} {pending_after}"
            pending_after = ""
        if re.search(r",\s+shall\b", action_text, re.I) and re.match(
            r"(?:whenever|except|whereof)\b",
            match.group("subject").strip(),
            re.I,
        ):
            continue
        subject_text, action_text = _normalize_passive_clause(subject_text, action_text)
        if not action_text:
            continue
        element = _finalize_element(
            _build_element(
                sentence=sentence,
                document_type=document_type,
                norm_type=norm_type,
                deontic_operator=deontic_operator,
                modal=modal,
                subject_text=subject_text,
                action_text=action_text,
                support_span=match.span(),
                field_spans={
                    "subject": list(match.span("subject")),
                    "modal": list(match.span("modal")),
                    "action": list(match.span("action")),
                },
                extraction_method="deterministic_modal_clause_v2",
            )
        )
        _attach_leading_case(element, sentence, match)
        _drop_grant_without_exceptions(element)
        elements.append(element)

    for match in _INTERRUPTED_SHALL_RE.finditer(sentence):
        if _modal_already_covered(_occupied(elements), match.start("action")):
            continue
        raw_subject = match.group("subject")
        negated = _has_leading_negated_subject(raw_subject)
        subject_text = (
            _clean_negated_subject_phrase(raw_subject)
            if negated
            else _clean_phrase(raw_subject)
        )
        action_text = _clean_action(match.group("action"))
        pre = " ".join((match.group("pre") or "").split())
        if pre and pre.lower() not in action_text.lower():
            action_text = f"{pre} {action_text}"
        if _skip_subject(subject_text) or not subject_text or not action_text:
            continue
        norm_type, deontic_operator, modal = (
            ("prohibition", "F", "shall not") if negated else ("obligation", "O", "shall")
        )
        delivered = ""
        if negated:
            parts = re.split(r",\s*but\s+shall\s+", action_text, maxsplit=1, flags=re.IGNORECASE)
            if len(parts) == 2:
                action_text, delivered = parts
        elements.append(
            _finalize_element(
                _build_element(
                    sentence=sentence,
                    document_type=document_type,
                    norm_type=norm_type,
                    deontic_operator=deontic_operator,
                    modal=modal,
                    subject_text=subject_text,
                    action_text=action_text,
                    support_span=match.span(),
                    field_spans={
                        "subject": list(match.span("subject")),
                        "action": list(match.span("action")),
                    },
                    extraction_method="deterministic_interrupted_shall_v1",
                )
            )
        )
        if delivered:
            elements.append(
                _finalize_element(
                    _build_element(
                        sentence=sentence,
                        document_type=document_type,
                        norm_type="obligation",
                        deontic_operator="O",
                        modal="shall",
                        subject_text=subject_text,
                        action_text=_clean_action(delivered),
                        support_span=match.span(),
                        field_spans={},
                        extraction_method="deterministic_interrupted_shall_v1",
                    )
                )
            )

    for match in _COMMA_SUBJECT_MODAL_RE.finditer(sentence):
        if _modal_already_covered(_occupied(elements), match.start("modal")):
            continue
        modal = re.sub(r"\s+", " ", match.group("modal").lower()).strip()
        norm_type, deontic_operator = classify_modal(modal)
        raw_subject = match.group("subject")
        subject_text = _outer_comma_subject(_clean_phrase(raw_subject))
        action_text = _restore_interrupted_action(
            sentence,
            _clean_action(match.group("action")),
            span=match.span(),
        )
        subject_text, action_text = _normalize_passive_clause(subject_text, action_text)
        leading_no = bool(
            re.search(r"\b(?:no|neither)\s+$", sentence[: match.start("subject")], flags=re.IGNORECASE)
        )
        if deontic_operator in {"O", "P"} and (
            _has_leading_negated_subject(raw_subject)
            or _has_leading_negated_subject(subject_text)
            or leading_no
        ):
            norm_type, deontic_operator = "prohibition", "F"
            subject_text = _clean_negated_subject_phrase(subject_text)
        subject_text = _subject_without_except(subject_text)
        if _skip_subject(subject_text) or not action_text or not subject_text:
            continue
        elements.append(
            _finalize_element(
                _build_element(
                    sentence=sentence,
                    document_type=document_type,
                    norm_type=norm_type,
                    deontic_operator=deontic_operator,
                    modal=modal,
                    subject_text=subject_text,
                    action_text=action_text,
                    support_span=match.span(),
                    field_spans={
                        "subject": list(match.span("subject")),
                        "modal": list(match.span("modal")),
                        "action": list(match.span("action")),
                    },
                    extraction_method="deterministic_comma_subject_modal_v1",
                )
            )
        )

    if not elements:
        inverted = _INVERTED_SHALL_RE.search(sentence)
        if inverted:
            rest = " ".join(inverted.group("rest").split())
            subject_match = _INVERTED_SUBJECT_RE.match(rest) or _INVERTED_COMMA_SUBJECT_RE.match(rest)
            if subject_match:
                subject_text = _clean_phrase(subject_match.group("subject"))
                action_text = _clean_action(subject_match.group("action"))
            else:
                subject_text = "person" if re.search(r"\b(?:himself|herself|themselves)\b", rest, re.I) else ""
                action_text = _clean_action(rest)
            lead = inverted.group("lead").lower()
            modal = re.sub(r"\s+", " ", inverted.group("modal").lower()).strip()
            if lead == "nor" or modal.endswith("not"):
                norm_type, deontic_operator = "prohibition", "F"
            else:
                norm_type, deontic_operator = classify_modal(modal)
            if subject_text and action_text and not _skip_subject(subject_text):
                elements.append(
                    _finalize_element(
                        _build_element(
                            sentence=sentence,
                            document_type=document_type,
                            norm_type=norm_type,
                            deontic_operator=deontic_operator,
                            modal=modal,
                            subject_text=subject_text,
                            action_text=action_text,
                            support_span=inverted.span(),
                            field_spans={},
                            extraction_method="deterministic_inverted_shall_v1",
                        )
                    )
                )
        prohibited = _HEREBY_PROHIBITED_RE.search(sentence)
        if prohibited:
            subject_text = _clean_phrase(prohibited.group("subject"))
            if subject_text:
                elements.append(
                    _finalize_element(
                        _build_element(
                            sentence=sentence,
                            document_type=document_type,
                            norm_type="prohibition",
                            deontic_operator="F",
                            modal="shall not",
                            subject_text=subject_text,
                            action_text="be done",
                            support_span=prohibited.span(),
                            field_spans={
                                "subject": list(prohibited.span("subject")),
                                "action": list(prohibited.span()),
                            },
                            extraction_method="deterministic_hereby_prohibited_v1",
                        )
                    )
                )
        for match in _TAKE_EFFECT_RE.finditer(sentence):
            if elements:
                break
            subject_text = _clean_phrase(match.group("subject"))
            action_text = _clean_action(match.group("action"))
            if not subject_text or not action_text:
                continue
            elements.append(
                _finalize_element(
                    _build_element(
                        sentence=sentence,
                        document_type=document_type,
                        norm_type="obligation",
                        deontic_operator="O",
                        modal="shall",
                        subject_text=subject_text,
                        action_text=action_text,
                        support_span=match.span(),
                        field_spans={
                            "subject": list(match.span("subject")),
                            "modal": list(match.span("modal")),
                            "action": list(match.span("action")),
                        },
                        extraction_method="deterministic_take_effect_v1",
                    )
                )
            )
        for match in _COMMA_SUBJECT_MODAL_RE.finditer(sentence):
            modal = re.sub(r"\s+", " ", match.group("modal").lower()).strip()
            norm_type, deontic_operator = classify_modal(modal)
            subject_text = _clean_phrase(match.group("subject"))
            action_text = _restore_interrupted_action(
            sentence,
            _clean_action(match.group("action")),
            span=match.span(),
        )
            subject_text, action_text = _normalize_passive_clause(subject_text, action_text)
            if not action_text or not subject_text:
                continue
            elements.append(
                _finalize_element(
                    _build_element(
                        sentence=sentence,
                        document_type=document_type,
                        norm_type=norm_type,
                        deontic_operator=deontic_operator,
                        modal=modal,
                        subject_text=subject_text,
                        action_text=action_text,
                        support_span=match.span(),
                        field_spans={
                            "subject": list(match.span("subject")),
                            "modal": list(match.span("modal")),
                            "action": list(match.span("action")),
                        },
                        extraction_method="deterministic_comma_subject_modal_v1",
                    )
                )
            )

    if elements:
        first_subject = (elements[0].get("subject") or [""])[0]
        occupied_spans = [tuple(item.get("support_span") or []) for item in elements]
        for match in _IMPLICIT_MODAL_RE.finditer(sentence):
            if any(
                len(span) == 2 and match.start() >= span[0] and match.end() <= span[1]
                for span in occupied_spans
            ):
                continue
            modal = re.sub(r"\s+", " ", match.group("modal").lower()).strip()
            norm_type, deontic_operator = classify_modal(modal)
            if deontic_operator in {"O", "P"} and _has_leading_negated_subject(first_subject):
                norm_type, deontic_operator = "prohibition", "F"
            action_text = _clean_action(match.group("action"))
            manner = _manner_phrase(sentence, match)
            if manner and manner.lower() not in action_text.lower():
                action_text = f"{action_text} {manner}"
            subject_text, action_text = _normalize_passive_clause(first_subject, action_text)
            if not action_text:
                continue
            elements.append(
                _finalize_element(
                    _build_element(
                        sentence=sentence,
                        document_type=document_type,
                        norm_type=norm_type,
                        deontic_operator=deontic_operator,
                        modal=modal,
                        subject_text=subject_text or first_subject,
                        action_text=action_text,
                        support_span=match.span(),
                        field_spans={
                            "subject": [],
                            "modal": list(match.span("modal")),
                            "action": list(match.span("action")),
                        },
                        extraction_method="deterministic_implicit_modal_clause_v2",
                    )
                )
            )
        return _drop_shalls_inside_conditions(sentence, elements)

    for match in _IMPERSONAL_NORM_RE.finditer(sentence):
        if match.group("unlawful"):
            subject_text = _clean_phrase(match.group("unlawful_subject") or "person")
            action_text = _clean_action(match.group("unlawful_action"))
            norm_type, deontic_operator = "prohibition", "F"
            modal = "unlawful"
        elif match.group("license"):
            subject_text = _clean_phrase(match.group("license_subject"))
            action_text = f"authorize {match.group('license_action')}"
            norm_type, deontic_operator = "obligation", "O"
            modal = "is required to"
        else:
            subject_text = _clean_phrase(match.group("duty_subject"))
            action_text = _clean_action(match.group("duty_action"))
            norm_type, deontic_operator = "obligation", "O"
            modal = "duty is imposed"
        if not action_text:
            continue
        elements.append(
            _finalize_element(
                _build_element(
                    sentence=sentence,
                    document_type=document_type,
                    norm_type=norm_type,
                    deontic_operator=deontic_operator,
                    modal=modal,
                    subject_text=subject_text,
                    action_text=action_text,
                    support_span=match.span(),
                    field_spans=_impersonal_field_spans(match),
                    extraction_method="deterministic_impersonal_norm_v3",
                )
            )
        )
    if elements:
        return elements

    validity_match = _INSTRUMENT_VALIDITY_RE.search(sentence)
    if validity_match:
        instrument_text = _clean_phrase(validity_match.group("instrument_type"))
        duration_text = _clean_phrase(validity_match.group("duration"))
        return [
            _finalize_element(
                _build_element(
                    sentence=sentence,
                    document_type=document_type,
                    norm_type="instrument_lifecycle",
                    deontic_operator="LIFE",
                    modal="valid for",
                    subject_text=instrument_text,
                    action_text=f"valid for {duration_text}",
                    support_span=validity_match.span(),
                    field_spans={
                        "subject": list(validity_match.span("instrument_type")),
                        "modal": [
                            validity_match.end("instrument_type"),
                            validity_match.start("duration"),
                        ],
                        "action": list(validity_match.span("duration")),
                    },
                    extraction_method="deterministic_instrument_validity_clause_v1",
                )
            )
        ]

    expiration_match = _INSTRUMENT_EXPIRATION_RE.search(sentence)
    if expiration_match:
        instrument_text = _clean_phrase(expiration_match.group("instrument_type"))
        anchor_text = _clean_phrase(expiration_match.group("anchor"))
        return [
            _finalize_element(
                _build_element(
                    sentence=sentence,
                    document_type=document_type,
                    norm_type="instrument_lifecycle",
                    deontic_operator="LIFE",
                    modal="expires",
                    subject_text=instrument_text,
                    action_text=f"expires {anchor_text}",
                    support_span=expiration_match.span(),
                    field_spans={
                        "subject": list(expiration_match.span("instrument_type")),
                        "modal": [
                            expiration_match.end("instrument_type"),
                            expiration_match.start("anchor"),
                        ],
                        "action": list(expiration_match.span("anchor")),
                    },
                    extraction_method="deterministic_instrument_expiration_clause_v1",
                )
            )
        ]

    declarative_match = _DECLARATIVE_COPULA_RE.search(sentence)
    if declarative_match:
        subject_text = _clean_phrase(declarative_match.group("subject"))
        action_text = _clean_action("be " + declarative_match.group("action"))
        if subject_text and action_text:
            return [
                _finalize_element(
                    _build_element(
                        sentence=sentence,
                        document_type=document_type,
                        norm_type="obligation",
                        deontic_operator="O",
                        modal="shall",
                        subject_text=subject_text,
                        action_text=action_text,
                        support_span=declarative_match.span(),
                        field_spans={
                            "subject": list(declarative_match.span("subject")),
                            "action": list(declarative_match.span("action")),
                        },
                        extraction_method="deterministic_declarative_copula_v1",
                    )
                )
            ]

    hereby_repealed = _HEREBY_REPEALED_RE.search(sentence)
    if hereby_repealed and not elements:
        subject_text = _clean_phrase(hereby_repealed.group("subject"))
        if subject_text:
            return [
                _finalize_element(
                    _build_element(
                        sentence=sentence,
                        document_type=document_type,
                        norm_type="instrument_lifecycle",
                        deontic_operator="LIFE",
                        modal="is hereby repealed",
                        subject_text=subject_text,
                        action_text="be repealed",
                        support_span=hereby_repealed.span(),
                        field_spans={
                            "subject": list(hereby_repealed.span("subject")),
                            "action": list(hereby_repealed.span()),
                        },
                        extraction_method="deterministic_hereby_repealed_v1",
                    )
                )
            ]

    section_status_match = _SECTION_STATUS_RE.search(sentence)
    if section_status_match and not elements:
        return [
            _finalize_element(
                _build_section_status_lifecycle_element(
                    sentence=sentence,
                    document_type=document_type,
                    match=section_status_match,
                )
            )
        ]

    not_required_match = _NOT_REQUIRED_EXEMPTION_RE.search(sentence)
    if not_required_match:
        instrument_text = _clean_phrase(not_required_match.group("instrument"))
        target_text = _clean_phrase(not_required_match.group("target"))
        preposition = not_required_match.group("preposition").lower()
        if preposition == "to":
            target_text = _clean_action(target_text)
        return [
            _finalize_element(
                _build_element(
                    sentence=sentence,
                    document_type=document_type,
                    norm_type="exemption",
                    deontic_operator="EXEMPT",
                    modal="not required",
                    subject_text=target_text,
                    action_text=f"exempt from {instrument_text}",
                    support_span=not_required_match.span(),
                    field_spans={
                        "subject": list(not_required_match.span("target")),
                        "modal": [
                            not_required_match.start("instrument"),
                            not_required_match.start("target"),
                        ],
                        "action": list(not_required_match.span("instrument")),
                    },
                    extraction_method="deterministic_not_required_exemption_clause_v1",
                )
            )
        ]

    violation_match = _VIOLATION_RE.search(sentence)
    if violation_match:
        action_text = f"fail to {violation_match.group(1).strip()}"
        return [
            _finalize_element(
                _build_element(
                    sentence=sentence,
                    document_type=document_type,
                    norm_type="violation",
                    deontic_operator="F",
                    modal="violation",
                    subject_text="person",
                    action_text=action_text,
                    support_span=violation_match.span(),
                    field_spans={
                        "subject": [],
                        "modal": list(violation_match.span()),
                        "action": list(violation_match.span(1)),
                    },
                    extraction_method="deterministic_violation_clause_v4",
                )
            )
        ]

    penalty_match = _PENALTY_RE.search(sentence)
    if penalty_match:
        penalty_text = penalty_match.group(1).strip()
        return [
            _finalize_element(
                _build_element(
                    sentence=sentence,
                    document_type=document_type,
                    norm_type="penalty",
                    deontic_operator="O",
                    modal="penalty",
                    subject_text="violation",
                    action_text=f"incur {penalty_text}",
                    support_span=penalty_match.span(),
                    field_spans={
                        "subject": list(penalty_match.span()),
                        "modal": list(penalty_match.span()),
                        "action": list(penalty_match.span(1)),
                    },
                    extraction_method="deterministic_penalty_clause_v4",
                )
            )
        ]

    purpose_matches = list(_PURPOSE_RE.finditer(sentence))
    purpose_match = purpose_matches[-1] if purpose_matches else None
    if purpose_match:
        subject_text = _clean_phrase(purpose_match.group("subject"))
        subject_span = list(purpose_match.span("subject"))
        nested_subject_markers = list(
            re.finditer(
                r"\b(?:general\s+purpose|purpose|mission|function|functions)\s+of\s+",
                subject_text,
                re.IGNORECASE,
            )
        )
        if nested_subject_markers:
            nested_start = nested_subject_markers[-1].end()
            subject_text = _clean_phrase(subject_text[nested_start:])
            subject_span = [
                subject_span[0] + nested_start,
                subject_span[1],
            ]
        action_text = _clean_action(purpose_match.group("action"))
        return [
            _finalize_element(
                _build_element(
                    sentence=sentence,
                    document_type=document_type,
                    norm_type="purpose",
                    deontic_operator="PURP",
                    modal=purpose_match.group("purpose_kind"),
                    subject_text=subject_text,
                    action_text=action_text,
                    support_span=purpose_match.span(),
                    field_spans={
                        "subject": subject_span,
                        "modal": list(purpose_match.span("purpose_kind")),
                        "action": list(purpose_match.span("action")),
                    },
                    extraction_method="deterministic_purpose_clause_v1",
                )
            )
        ]

    non_applicability_match = _NON_APPLICABILITY_RE.search(sentence)
    if non_applicability_match:
        scope_subject = f"{non_applicability_match.group('scope')} {non_applicability_match.group('scope_type')}".lower()
        target_text = _clean_phrase(non_applicability_match.group("target"))
        return [
            _finalize_element(
                _build_element(
                    sentence=sentence,
                    document_type=document_type,
                    norm_type="exemption",
                    deontic_operator="EXEMPT",
                    modal="does not apply to",
                    subject_text=scope_subject,
                    action_text=f"not apply to {target_text}",
                    support_span=non_applicability_match.span(),
                    field_spans={
                        "subject": list(non_applicability_match.span("scope_type")),
                        "modal": [
                            non_applicability_match.start(),
                            non_applicability_match.start("target"),
                        ],
                        "action": list(non_applicability_match.span("target")),
                    },
                    extraction_method="deterministic_non_applicability_clause_v1",
                )
            )
        ]

    applicability_match = _APPLICABILITY_RE.search(sentence)
    if applicability_match:
        scope_subject = f"{applicability_match.group('scope')} {applicability_match.group('scope_type')}".lower()
        target_text = _clean_phrase(applicability_match.group("target"))
        return [
            _finalize_element(
                _build_element(
                    sentence=sentence,
                    document_type=document_type,
                    norm_type="applicability",
                    deontic_operator="APP",
                    modal="applies to",
                    subject_text=scope_subject,
                    action_text=f"apply to {target_text}",
                    support_span=applicability_match.span(),
                    field_spans={
                        "subject": list(applicability_match.span("scope_type")),
                        "modal": [applicability_match.start(), applicability_match.start("target")],
                        "action": list(applicability_match.span("target")),
                    },
                    extraction_method="deterministic_applicability_clause_v1",
                )
            )
        ]

    exemption_match = _EXEMPTION_RE.search(sentence)
    if exemption_match:
        target_text = _clean_phrase(exemption_match.group("target"))
        requirement_text = _clean_action(exemption_match.group("requirement"))
        return [
            _finalize_element(
                _build_element(
                    sentence=sentence,
                    document_type=document_type,
                    norm_type="exemption",
                    deontic_operator="EXEMPT",
                    modal="exempt from",
                    subject_text=target_text,
                    action_text=f"exempt from {requirement_text}",
                    support_span=exemption_match.span(),
                    field_spans={
                        "subject": list(exemption_match.span("target")),
                        "modal": [
                            exemption_match.end("target"),
                            exemption_match.start("requirement"),
                        ],
                        "action": list(exemption_match.span("requirement")),
                    },
                    extraction_method="deterministic_exemption_clause_v1",
                )
            )
        ]

    if _DEFINITION_RE.search(sentence_lower):
        defined_term_match = _DEFINED_TERM_RE.search(sentence) or _UNQUOTED_DEFINED_TERM_RE.search(
            sentence
        )
        defined_terms = (
            [_clean_phrase(defined_term_match.group(1))]
            if defined_term_match
            else extract_legal_subject(sentence)
        )
        return [
            _finalize_element(
                {
                    "schema_version": PARSER_SCHEMA_VERSION,
                    "source_id": "",
                    "canonical_citation": "",
                    "text": sentence,
                    "support_text": sentence,
                    "support_span": [0, len(sentence)],
                    "field_spans": {
                        "defined_term": list(defined_term_match.span(1))
                        if defined_term_match
                        else [],
                        "definition_body": _definition_body_span(sentence),
                        "subject": list(defined_term_match.span(1)) if defined_term_match else [],
                        "modal": [],
                        "action": [0, len(sentence)],
                        "action_verb": [],
                        "action_object": [],
                        "action_recipient": [],
                    },
                    "norm_type": "definition",
                    "deontic_operator": "DEF",
                    "modal": "definition",
                    "subject": defined_terms,
                    "action": [sentence],
                    "defined_term": defined_terms[0] if defined_terms else "",
                    "definition_body": extract_definition_body(sentence),
                    "conditions": extract_conditions(sentence),
                    "condition_details": extract_condition_details(sentence),
                    "temporal_constraints": extract_temporal_constraints(sentence),
                    "temporal_constraint_details": extract_temporal_constraint_details(sentence),
                    "exceptions": extract_exceptions(sentence),
                    "exception_details": extract_exception_details(sentence),
                    "override_clauses": extract_override_clauses(sentence),
                    "override_clause_details": extract_override_clause_details(sentence),
                    "cross_references": extract_cross_references(sentence),
                    "cross_reference_details": extract_cross_reference_details(sentence),
                    "resolved_cross_references": [],
                    "enforcement_links": [],
                    "conflict_links": [],
                    "enumerated_items": extract_enumerated_items(sentence),
                    "defined_term_refs": [],
                    "definition_scope": infer_definition_scope(sentence),
                    "ontology_terms": extract_ontology_terms(sentence),
                    "formal_terms": {},
                    "llm_repair": {},
                    "export_readiness": {},
                    "logic_frame": {},
                    "legal_frame": {},
                    "kg_relationship_hints": [],
                    "monetary_amounts": extract_monetary_amounts(sentence),
                    "monetary_amount_details": extract_monetary_amount_details(sentence),
                    "penalty": {},
                    "procedure": {},
                    "actor_type": classify_legal_entity(defined_terms[0] if defined_terms else ""),
                    "entity_type": classify_legal_entity(defined_terms[0] if defined_terms else ""),
                    "action_verb": "",
                    "action_object": "",
                    "action_recipient": "",
                    "section_context": {},
                    "hierarchy_path": [],
                    "hierarchy_details": [],
                    "document_type": document_type,
                    "extraction_method": "deterministic_definition_v2",
                    "confidence_floor": 0.25,
                }
            )
        ]

    return []


def _extract_section_status_lifecycle_elements(
    text: str,
    document_type: str,
) -> List[Dict[str, Any]]:
    """Extract whole-document section status notes before sentence splitting."""

    normalized_text = str(text or "").strip()
    if not normalized_text:
        return []

    elements: List[Dict[str, Any]] = []
    matches = list(_SECTION_STATUS_RE.finditer(normalized_text))
    for index, match in enumerate(matches):
        if _is_superseded_editorial_status_heading(
            normalized_text,
            match,
            later_matches=matches[index + 1 :],
        ):
            continue
        status_name = match.group("status").lower()
        window = normalized_text[max(0, match.start() - 160) : match.end()]
        if status_name == "repealed" and _HEREBY_REPEALED_RE.search(window):
            continue
        if status_name == "reserved" and re.search(
            r"\b(?:is|are)\s+reserved\s+to\b",
            normalized_text,
            flags=re.IGNORECASE,
        ):
            continue
        elements.append(
            _finalize_element(
                _build_section_status_lifecycle_element(
                    sentence=normalized_text,
                    document_type=document_type,
                    match=match,
                )
            )
        )
    return elements


def _is_superseded_editorial_status_heading(
    text: str,
    match: re.Match[str],
    *,
    later_matches: List[re.Match[str]],
) -> bool:
    """Return true for bare editorial-note headings refined by later statuses."""

    if not later_matches:
        return False
    status = _clean_phrase(match.group("status")).lower()
    if status not in {"transferred", "renumbered", "redesignated"}:
        return False
    detail = str(match.group("detail") or "")
    if not _SECTION_STATUS_DETAIL_STOP_RE.search(detail):
        return False
    first_later = later_matches[0]
    bridge_text = f"{detail} {text[match.end() : first_later.start()]}"
    if not re.search(
        r"\b(?:editorial\s+notes?|codification)\b",
        bridge_text,
        re.IGNORECASE,
    ):
        return False
    return any(
        _clean_phrase(later.group("status")).lower()
        in {"transferred", "renumbered", "redesignated"}
        for later in later_matches
    )


def _section_status_should_short_circuit(
    text: str,
    elements: List[Dict[str, Any]],
) -> bool:
    """Return true when status rows describe the section itself, not notes.

    Whole U.S. Code documents often contain editorial-history phrases such as
    "Prior section ... was omitted" after the operative statute. Those status
    markers are useful when the section is actually repealed/omitted, but they
    should not suppress ordinary modal parsing for mixed documents.
    """

    if not elements:
        return False
    normalized = re.sub(r"\s+", " ", str(text or "")).strip()
    if not normalized:
        return False

    status_starts = [
        int((element.get("support_span") or [0, 0])[0])
        for element in elements
        if isinstance(element.get("support_span"), list)
        and len(element.get("support_span") or []) == 2
    ]
    if not status_starts:
        return False
    first_status_start = min(status_starts)
    prefix = normalized[:first_status_start].lower()
    if re.search(
        r"\b(?:shall|must|may|is\s+authorized|are\s+authorized|"
        r"is\s+critical\s+that|are\s+required|is\s+required)\b",
        prefix,
    ):
        return False

    first_element = min(
        elements,
        key=lambda element: int((element.get("support_span") or [0, 0])[0]),
    )
    support_text = str(first_element.get("support_text") or "")
    return bool(
        re.search(
            r"^\s*(?:\[?\s*)?(?:(?:secs?\.?|sections?|§{1,2})\s*)?"
            r"[0-9][0-9A-Za-z.\-]*\.?\s*"
            r"(?:repealed|omitted|reserved|transferred|renumbered|redesignated)\b",
            support_text,
            re.IGNORECASE,
        )
        or first_status_start < 600
    )


def _build_section_status_lifecycle_element(
    *,
    sentence: str,
    document_type: str,
    match: re.Match[str],
) -> Dict[str, Any]:
    """Build a typed lifecycle row for U.S. Code editorial status markers."""

    status = _clean_phrase(match.group("status")).lower()
    section_marker = _clean_phrase(match.group("section_marker") or "")
    detail = _section_status_detail(match.group("detail") or "")
    instrument_text = section_marker or _section_status_instrument_from_context(sentence)
    action_text = status
    if detail:
        action_text = f"{status} {detail}"

    status_span = list(match.span("status"))
    subject_span = list(match.span("section_marker")) if section_marker else []
    return {
        "schema_version": PARSER_SCHEMA_VERSION,
        "source_id": "",
        "canonical_citation": "",
        "text": sentence,
        "support_text": sentence[match.start() : match.end()].strip(),
        "support_span": list(match.span()),
        "field_spans": {
            "subject": subject_span,
            "modal": status_span,
            "action": status_span,
            "action_verb": status_span,
            "action_object": subject_span,
            "action_recipient": [],
        },
        "norm_type": "instrument_lifecycle",
        "deontic_operator": "LIFE",
        "modal": status,
        "subject": [instrument_text],
        "actor_type": "legal_instrument",
        "entity_type": "legal_instrument",
        "action": [action_text],
        "mental_state": "",
        "action_verb": status,
        "action_object": instrument_text,
        "action_recipient": "",
        "conditions": extract_conditions(sentence),
        "condition_details": extract_condition_details(sentence),
        "temporal_constraints": extract_temporal_constraints(sentence),
        "temporal_constraint_details": extract_temporal_constraint_details(sentence),
        "exceptions": extract_exceptions(sentence),
        "exception_details": extract_exception_details(sentence),
        "override_clauses": extract_override_clauses(sentence),
        "override_clause_details": extract_override_clause_details(sentence),
        "cross_references": [],
        "cross_reference_details": [],
        "resolved_cross_references": [],
        "enforcement_links": [],
        "conflict_links": [],
        "enumerated_items": extract_enumerated_items(sentence),
        "defined_term_refs": [],
        "definition_scope": {},
        "ontology_terms": extract_ontology_terms(sentence),
        "formal_terms": {},
        "llm_repair": {},
        "export_readiness": {},
        "logic_frame": {},
        "legal_frame": {},
        "kg_relationship_hints": [],
        "monetary_amounts": extract_monetary_amounts(sentence),
        "monetary_amount_details": extract_monetary_amount_details(sentence),
        "penalty": {},
        "procedure": {},
        "section_context": {},
        "hierarchy_path": [],
        "hierarchy_details": [],
        "document_type": document_type,
        "extraction_method": "deterministic_section_status_lifecycle_v1",
        "confidence_floor": 0.40,
    }


def _build_savings_preservation_element(
    *,
    sentence: str,
    document_type: str,
    match: re.Match[str],
) -> Dict[str, Any]:
    """Build a typed row for statutory savings/no-effect clauses."""

    scope_text = _clean_phrase(match.group("scope"))
    target_text = _clean_phrase(match.group("target"))
    preserved_actor = _savings_preserved_actor_text(target_text) or target_text
    preserved_object = _savings_preserved_object_text(target_text)
    action_text = f"preserve {preserved_object or target_text}"
    if scope_text:
        action_text = f"{action_text} from {scope_text}"

    return {
        "schema_version": PARSER_SCHEMA_VERSION,
        "source_id": "",
        "canonical_citation": "",
        "text": sentence,
        "support_text": sentence[match.start() : match.end()].strip(),
        "support_span": list(match.span()),
        "field_spans": {
            "subject": list(match.span("target")),
            "modal": list(match.span("modal")),
            "action": list(match.span("target")),
            "action_verb": list(match.span("modal")),
            "action_object": list(match.span("target")),
            "action_recipient": [],
        },
        "norm_type": "exemption",
        "deontic_operator": "EXEMPT",
        "modal": "savings preservation",
        "subject": [preserved_actor],
        "actor_type": classify_legal_entity(preserved_actor),
        "entity_type": classify_legal_entity(preserved_actor),
        "action": [action_text],
        "mental_state": "",
        "action_verb": "preserve",
        "action_object": preserved_object or target_text,
        "action_recipient": "",
        "conditions": extract_conditions(sentence),
        "condition_details": extract_condition_details(sentence),
        "temporal_constraints": extract_temporal_constraints(sentence),
        "temporal_constraint_details": extract_temporal_constraint_details(sentence),
        "exceptions": extract_exceptions(sentence),
        "exception_details": extract_exception_details(sentence),
        "override_clauses": extract_override_clauses(sentence),
        "override_clause_details": extract_override_clause_details(sentence),
        "cross_references": extract_cross_references(sentence),
        "cross_reference_details": extract_cross_reference_details(sentence),
        "resolved_cross_references": [],
        "enforcement_links": [],
        "conflict_links": [],
        "enumerated_items": extract_enumerated_items(sentence),
        "defined_term_refs": [],
        "definition_scope": {},
        "ontology_terms": extract_ontology_terms(sentence),
        "formal_terms": {},
        "llm_repair": {},
        "export_readiness": {},
        "logic_frame": {},
        "legal_frame": {},
        "kg_relationship_hints": [],
        "monetary_amounts": extract_monetary_amounts(sentence),
        "monetary_amount_details": extract_monetary_amount_details(sentence),
        "penalty": {},
        "procedure": {},
        "section_context": {},
        "hierarchy_path": [],
        "hierarchy_details": [],
        "document_type": document_type,
        "extraction_method": "deterministic_savings_preservation_clause_v1",
        "confidence_floor": 0.40,
    }


def _savings_preserved_actor_text(target_text: str) -> str:
    text = _clean_phrase(target_text)
    actor_match = re.search(
        r"\bof\s+(?P<actor>.+?)(?=,\s+including\b|,\s+except\b|,\s+as\b|$)",
        text,
        re.IGNORECASE,
    )
    if actor_match:
        return _clean_phrase(actor_match.group("actor"))
    return ""


def _savings_preserved_object_text(target_text: str) -> str:
    text = _clean_phrase(target_text)
    object_match = re.match(
        r"(?P<object>.+?)(?:,\s*existing\b|\s+of\b|$)",
        text,
        re.IGNORECASE,
    )
    if object_match:
        return _clean_phrase(object_match.group("object"))
    return text


def _section_status_detail(value: str) -> str:
    detail = _clean_phrase(value)
    if not detail:
        return ""
    stop_match = _SECTION_STATUS_DETAIL_STOP_RE.search(detail)
    if stop_match:
        detail = detail[: stop_match.start()].strip(" ,")
    return detail


def _section_status_instrument_from_context(sentence: str) -> str:
    section_context_match = re.search(
        r"\b(?:secs?\.?|sections?|§{1,2})\s*[0-9][0-9A-Za-z.\-]*(?:\s*,\s*[0-9][0-9A-Za-z.\-]*)*",
        sentence,
        re.IGNORECASE,
    )
    if section_context_match:
        return _clean_phrase(section_context_match.group(0))
    return "section"


def _strip_leading_enumeration_label(value: str) -> str:
    return re.sub(r"^\s*\([A-Za-z0-9]+\)\s*", "", str(value or "")).strip()


def _strip_leading_authorized_action_prefix(value: str) -> str:
    text = _strip_leading_enumeration_label(value)
    return re.sub(r"^\s*to\s+", "", text, flags=re.IGNORECASE).strip()


def _build_element(
    *,
    sentence: str,
    document_type: str,
    norm_type: str,
    deontic_operator: str,
    modal: str,
    subject_text: str,
    action_text: str,
    support_span: tuple[int, int],
    extraction_method: str,
    field_spans: Optional[Dict[str, List[int]]] = None,
) -> Dict[str, Any]:
    enumerated_items = extract_enumerated_items(sentence)
    if enumerated_items and re.match(r"^\([A-Za-z0-9]+\)\s+", action_text or ""):
        action_text = enumerated_items[0]["text"]
    action_text = _keep_compared_clause(sentence, action_text)
    field_spans = dict(field_spans or {})
    compared_on_action = bool(re.search(r"\bwhen\s+compared\b", action_text, flags=re.IGNORECASE))
    complex_mental_state = ""
    original_action_text = action_text
    complex_split = _split_leading_complex_mental_state(action_text)
    if complex_split[0]:
        complex_mental_state, action_text = complex_split
        action_start = 0
        raw_action_span = list(
            field_spans.get("action") or _find_span(sentence, original_action_text)
        )
        if len(raw_action_span) == 2:
            action_start = raw_action_span[0]
        mental_state_span = _find_span(sentence, complex_mental_state, start=action_start)
        operative_action_span = _find_span(
            sentence,
            action_text,
            start=mental_state_span[1] if len(mental_state_span) == 2 else action_start,
        )
        field_spans["mental_state"] = mental_state_span
        field_spans["action"] = operative_action_span
    subject = [subject_text] if subject_text else extract_legal_subject(sentence)
    action = [action_text]
    spans = _complete_field_spans(sentence, subject_text, action_text, field_spans)
    payload = {
        "schema_version": PARSER_SCHEMA_VERSION,
        "source_id": "",
        "canonical_citation": "",
        "text": sentence,
        "support_text": sentence[support_span[0] : support_span[1]].strip(),
        "support_span": list(support_span),
        "field_spans": spans,
        "norm_type": norm_type,
        "deontic_operator": deontic_operator,
        "modal": modal,
        "subject": subject,
        "actor_type": classify_legal_entity(subject[0] if subject else ""),
        "entity_type": classify_legal_entity(subject[0] if subject else ""),
        "action": action,
        "mental_state": complex_mental_state or _mental_state(action_text),
        "action_verb": _first_verb(action_text),
        "action_object": _action_object(action_text),
        "action_recipient": extract_action_recipient(action_text),
        "conditions": extract_conditions(sentence),
        "condition_details": extract_condition_details(sentence),
        "temporal_constraints": extract_temporal_constraints(sentence),
        "temporal_constraint_details": extract_temporal_constraint_details(sentence),
        "exceptions": extract_exceptions(sentence),
        "exception_details": extract_exception_details(sentence),
        "override_clauses": extract_override_clauses(sentence),
        "override_clause_details": extract_override_clause_details(sentence),
        "cross_references": extract_cross_references(sentence),
        "cross_reference_details": extract_cross_reference_details(sentence),
        "resolved_cross_references": [],
        "enforcement_links": [],
        "conflict_links": [],
        "enumerated_items": enumerated_items,
        "defined_term_refs": [],
        "definition_scope": {},
        "ontology_terms": extract_ontology_terms(sentence),
        "formal_terms": {},
        "llm_repair": {},
        "export_readiness": {},
        "logic_frame": {},
        "legal_frame": {},
        "kg_relationship_hints": [],
        "monetary_amounts": extract_monetary_amounts(sentence),
        "monetary_amount_details": extract_monetary_amount_details(sentence),
        "penalty": {},
        "procedure": {},
        "section_context": {},
        "hierarchy_path": [],
        "hierarchy_details": [],
        "document_type": document_type,
        "extraction_method": extraction_method,
        "confidence_floor": 0.35,
    }
    if compared_on_action:
        payload["slot_details_scoped"] = True
    return payload


def _complete_field_spans(
    sentence: str,
    subject_text: str,
    action_text: str,
    field_spans: Dict[str, List[int]],
) -> Dict[str, List[int]]:
    raw_subject_span = list(field_spans.get("subject") or [])
    if len(raw_subject_span) == 2:
        raw_subject = sentence[raw_subject_span[0] : raw_subject_span[1]]
        subject_span = (
            raw_subject_span
            if raw_subject.strip().lower() == subject_text.lower()
            else _find_span(sentence, subject_text, start=raw_subject_span[0])
        )
    else:
        subject_span = _find_span(sentence, subject_text)
    spans = {
        "subject": subject_span,
        "modal": list(field_spans.get("modal") or []),
        "action": list(field_spans.get("action") or _find_span(sentence, action_text)),
        "mental_state": list(field_spans.get("mental_state") or []),
        "action_verb": [],
        "action_object": [],
        "action_recipient": [],
        "defined_term": [],
        "definition_body": [],
    }
    action_start = spans["action"][0] if len(spans["action"]) == 2 else 0
    action_verb = _first_verb(action_text)
    action_object = _action_object(action_text)
    action_recipient = extract_action_recipient(action_text)
    spans["action_verb"] = _find_span(sentence, action_verb, start=action_start)
    spans["action_object"] = _find_span(sentence, action_object, start=action_start)
    spans["action_recipient"] = _find_span(sentence, action_recipient, start=action_start)
    return spans


def _find_span(text: str, value: str, start: int = 0) -> List[int]:
    if not value:
        return []
    match = re.search(re.escape(str(value)), str(text or "")[start:], flags=re.IGNORECASE)
    if not match:
        return []
    return [start + match.start(), start + match.end()]


def _definition_body_span(sentence: str) -> List[int]:
    match = _DEFINITION_BODY_RE.search(str(sentence or ""))
    if not match:
        return []
    return [match.start(1), match.end(1)]


def _impersonal_field_spans(match: re.Match[str]) -> Dict[str, List[int]]:
    if match.group("unlawful"):
        return {
            "subject": list(match.span("unlawful_subject"))
            if match.group("unlawful_subject")
            else [],
            "modal": list(match.span("unlawful")),
            "action": list(match.span("unlawful_action")),
        }
    if match.group("license"):
        return {
            "subject": list(match.span("license_subject")),
            "modal": list(match.span("license")),
            "action": list(match.span("license_action")),
        }
    return {
        "subject": list(match.span("duty_subject")),
        "modal": list(match.span("duty")),
        "action": list(match.span("duty_action")),
    }


def _finalize_element(element: Dict[str, Any]) -> Dict[str, Any]:
    element.setdefault("schema_version", PARSER_SCHEMA_VERSION)
    element.setdefault("section_context", {})
    element.setdefault("hierarchy_path", [])
    element.setdefault("hierarchy_details", [])
    element.setdefault("defined_term_refs", [])
    element.setdefault("resolved_cross_references", [])
    element.setdefault("enforcement_links", [])
    element.setdefault("conflict_links", [])
    element.setdefault("definition_scope", {})
    element.setdefault("ontology_terms", extract_ontology_terms(element.get("text", "")))
    element["canonical_citation"] = build_canonical_citation(element)
    element["source_id"] = build_source_id(element)
    element.setdefault("llm_repair", {})
    element.setdefault("export_readiness", {})
    element.setdefault("logic_frame", {})
    _enrich_legal_frame(element)
    element["formal_terms"] = build_formal_terms(element)
    quality = score_scaffold_quality(element)
    element["slot_coverage"] = quality["slot_coverage"]
    element["scaffold_quality"] = quality["score"]
    element["quality_label"] = quality["label"]
    element["parser_warnings"] = quality["warnings"]
    element["promotable_to_theorem"] = quality["promotable_to_theorem"]
    schema_validation = validate_parser_element(element)
    element["schema_valid"] = schema_validation["valid"]
    if not schema_validation["valid"]:
        element["parser_warnings"] = [
            *element["parser_warnings"],
            *[f"schema_{field}_missing" for field in schema_validation["missing_fields"]],
        ]
        element["promotable_to_theorem"] = False
    element["logic_frame"] = build_logic_frame(element)
    element["llm_repair"] = build_llm_repair_payload(element)
    element["export_readiness"] = build_export_readiness(element)
    return element


def _apply_definition_context(elements: List[Dict[str, Any]]) -> None:
    definitions = [
        element
        for element in elements
        if element.get("norm_type") == "definition" and element.get("defined_term")
    ]
    if not definitions:
        return
    for element in elements:
        if element.get("norm_type") == "definition":
            continue
        refs: List[Dict[str, Any]] = []
        text = str(element.get("text") or "")
        for definition in definitions:
            if not _definition_applies_to_element(definition, element):
                continue
            term = str(definition.get("defined_term") or "").strip()
            if not term:
                continue
            for match in re.finditer(rf"\b{re.escape(term)}s?\b", text, flags=re.IGNORECASE):
                refs.append(
                    {
                        "term": term,
                        "definition_body": definition.get("definition_body", ""),
                        "definition_text": definition.get("text", ""),
                        "definition_scope": definition.get("definition_scope", {}),
                        "span": [match.start(), match.end()],
                    }
                )
        element["defined_term_refs"] = refs
        if refs:
            existing = element.get("kg_relationship_hints", [])
            for ref in refs:
                existing.append(
                    {
                        "subject": ref["term"],
                        "predicate": "definedBy",
                        "object": ref["definition_body"] or ref["definition_text"],
                    }
                )
            element["kg_relationship_hints"] = existing
            element["ontology_terms"] = merge_ontology_terms(
                element.get("ontology_terms", []), refs
            )
            _finalize_element(element)


def build_canonical_citation(element: Dict[str, Any]) -> str:
    """Build a deterministic citation-like label from available hierarchy metadata."""
    section_context = element.get("section_context") or {}
    if isinstance(section_context, dict):
        canonical = str(section_context.get("canonical_citation") or "").strip()
        if canonical:
            return canonical

    parts: List[str] = []
    for level in ["title", "division", "chapter", "article", "part"]:
        value = _hierarchy_value(element, level)
        if value:
            parts.append(f"{level} {value}")
    section_title = ""
    if isinstance(section_context, dict):
        section_title = str(section_context.get("title") or "").strip()
    if section_title and not any(part == f"title {section_title}" for part in parts):
        parts.insert(0, f"title {section_title}")
    section = section_context.get("section") if isinstance(section_context, dict) else ""
    if section:
        parts.append(f"section {section}")
    paragraph = _hierarchy_value(element, "paragraph")
    if paragraph:
        parts.append(f"paragraph ({paragraph})")
    return " / ".join(parts)


def build_source_id(element: Dict[str, Any]) -> str:
    """Create a stable deterministic ID for joins across parquet/KG/proof exports."""
    identity = {
        "citation": element.get("canonical_citation") or build_canonical_citation(element),
        "source_span": element.get("source_span", []),
        "support_span": element.get("support_span", []),
        "norm_type": element.get("norm_type", ""),
        "operator": element.get("deontic_operator", ""),
        "text": element.get("text", ""),
    }
    digest = hashlib.sha256(
        json.dumps(identity, sort_keys=True, default=str).encode("utf-8")
    ).hexdigest()
    return f"deontic:{digest[:24]}"


def build_formal_terms(element: Dict[str, Any]) -> Dict[str, Any]:
    """Normalize parser slots into symbols shared by KG and formal exporters."""
    action_text = (element.get("action") or [""])[0]
    actor = (element.get("subject") or [""])[0]
    section = (element.get("section_context") or {}).get("section", "")
    return {
        "source_id": element.get("source_id", ""),
        "citation_id": normalize_symbol(element.get("canonical_citation", "")),
        "section_id": normalize_symbol(section),
        "actor_id": normalize_symbol(actor),
        "actor_predicate": normalize_predicate_name(actor),
        "action_predicate": normalize_predicate_name(_action_without_mental_state(action_text)),
        "object_predicate": normalize_predicate_name(element.get("action_object", "")),
        "recipient_id": normalize_symbol(element.get("action_recipient", "")),
        "norm_predicate": normalize_predicate_name(element.get("norm_type", "")),
        "category_predicate": normalize_predicate_name(
            (element.get("legal_frame") or {}).get("category", "")
        ),
        "defined_term_id": normalize_symbol(element.get("defined_term", "")),
    }


def normalize_symbol(value: str) -> str:
    normalized = re.sub(r"[^0-9A-Za-z]+", "_", str(value or "").strip().lower()).strip("_")
    return normalized or "unknown"


def _definition_applies_to_element(definition: Dict[str, Any], element: Dict[str, Any]) -> bool:
    scope = definition.get("definition_scope") or {}
    scope_type = scope.get("scope_type", "document")
    if scope_type == "section":
        definition_section = (definition.get("section_context") or {}).get("section")
        element_section = (element.get("section_context") or {}).get("section")
        return (
            bool(definition_section and definition_section == element_section)
            or not definition_section
        )
    if scope_type in {"title", "chapter"}:
        return _same_hierarchy_scope(definition, element, scope_type)
    return True


def _same_hierarchy_scope(definition: Dict[str, Any], element: Dict[str, Any], level: str) -> bool:
    definition_value = _hierarchy_value(definition, level)
    element_value = _hierarchy_value(element, level)
    return bool(definition_value and definition_value == element_value) or not definition_value


def _hierarchy_value(element: Dict[str, Any], level: str) -> str:
    for detail in element.get("hierarchy_details") or []:
        if detail.get("level") == level:
            return str(detail.get("value") or "")
    prefix = f"{level}:"
    for item in element.get("hierarchy_path") or []:
        if str(item).startswith(prefix):
            return str(item).split(":", 1)[1]
    return ""


def _apply_cross_reference_context(elements: List[Dict[str, Any]]) -> None:
    section_index = _build_section_index(elements)
    for element in elements:
        resolved_refs = resolve_cross_references(element, section_index)
        element["resolved_cross_references"] = resolved_refs
        if resolved_refs:
            _finalize_element(element)


def _build_section_index(elements: List[Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    index: Dict[str, Dict[str, Any]] = {}
    for element in elements:
        section = (element.get("section_context") or {}).get("section")
        if not section:
            continue
        index.setdefault(
            _normalize_section_ref(section),
            {
                "section": section,
                "heading": (element.get("section_context") or {}).get("heading", ""),
                "hierarchy_path": list(element.get("hierarchy_path") or []),
                "hierarchy_details": list(element.get("hierarchy_details") or []),
                "source_span": list(element.get("source_span") or []),
            },
        )
    return index


def resolve_cross_references(
    element: Dict[str, Any],
    section_index: Optional[Dict[str, Dict[str, Any]]] = None,
) -> List[Dict[str, Any]]:
    """Resolve extracted cross references against known in-document sections."""
    section_index = section_index or {}
    resolved: List[Dict[str, Any]] = []
    for ref in element.get("cross_reference_details") or []:
        detail = dict(ref)
        ref_type = str(detail.get("type") or "")
        value = str(detail.get("value") or "")
        detail["resolution_status"] = "external"
        detail["target_exists"] = False
        detail["target_section"] = ""
        detail["target_heading"] = ""
        detail["target_hierarchy_path"] = []
        if ref_type == "section_range":
            targets = _resolve_section_range(detail, section_index)
            detail["resolution_status"] = "resolved" if targets else "unresolved"
            detail["target_exists"] = bool(targets)
            detail["target_sections"] = targets
            resolved.append(detail)
            continue
        if ref_type == "section":
            target = (
                _relative_reference_target(element, "section")
                if _is_relative_reference(value)
                else section_index.get(_normalize_section_ref(value))
            )
        elif ref_type in {"subsection", "paragraph", "chapter", "title"}:
            target = _hierarchy_reference_target(element, ref_type, value)
        else:
            target = {}
        if ref_type in {"section", "subsection", "paragraph", "chapter", "title"}:
            detail["resolution_status"] = "resolved" if target else "unresolved"
            detail["target_exists"] = bool(target)
            if target:
                detail["target_section"] = target.get("section", "")
                detail["target_heading"] = target.get("heading", "")
                detail["target_hierarchy_path"] = list(target.get("hierarchy_path") or [])
        resolved.append(detail)
    return resolved


def _hierarchy_reference_target(
    element: Dict[str, Any], ref_type: str, value: str
) -> Dict[str, Any]:
    if _is_relative_reference(value):
        return _relative_reference_target(element, ref_type)
    if ref_type in {"chapter", "title"}:
        current_value = _hierarchy_value(element, ref_type)
        return (
            _relative_reference_target(element, ref_type)
            if current_value and current_value.lower() == value.lower()
            else {}
        )
    normalized_value = str(value or "").strip().lower()
    candidates = [f"{ref_type}:{normalized_value}"]
    if ref_type == "subsection":
        candidates.append(f"paragraph:{normalized_value}")
    matched_path = [
        item for item in element.get("hierarchy_path") or [] if str(item).lower() in candidates
    ]
    if not matched_path:
        return {}
    section_context = element.get("section_context") or {}
    return {
        "section": section_context.get("section", ""),
        "heading": section_context.get("heading", ""),
        "hierarchy_path": matched_path,
        "hierarchy_details": [
            item
            for item in element.get("hierarchy_details") or []
            if item.get("level") in {ref_type, "paragraph"}
            and str(item.get("value") or "").lower() == normalized_value
        ],
        "source_span": list(element.get("source_span") or []),
    }


def _resolve_section_range(
    ref: Dict[str, Any],
    section_index: Dict[str, Dict[str, Any]],
) -> List[Dict[str, Any]]:
    start = _section_sort_key(ref.get("start_section", ""))
    end = _section_sort_key(ref.get("end_section", ""))
    if not start or not end:
        return []
    if start > end:
        start, end = end, start
    targets: List[Dict[str, Any]] = []
    for target in section_index.values():
        key = _section_sort_key(target.get("section", ""))
        if key and start <= key <= end:
            targets.append(
                {
                    "section": target.get("section", ""),
                    "heading": target.get("heading", ""),
                    "hierarchy_path": list(target.get("hierarchy_path") or []),
                }
            )
    return sorted(targets, key=lambda item: _section_sort_key(item.get("section", "")))


def _section_sort_key(value: str) -> tuple[int, ...]:
    parts = re.findall(r"\d+", str(value or ""))
    return tuple(int(part) for part in parts)


def _relative_reference_target(element: Dict[str, Any], ref_type: str) -> Dict[str, Any]:
    if ref_type == "section":
        section_context = element.get("section_context") or {}
        section = section_context.get("section", "")
        if not section:
            return {}
        return {
            "section": section,
            "heading": section_context.get("heading", ""),
            "hierarchy_path": list(element.get("hierarchy_path") or []),
            "hierarchy_details": list(element.get("hierarchy_details") or []),
            "source_span": list(element.get("source_span") or []),
        }
    if ref_type in {"subsection", "paragraph"}:
        prefix = f"{ref_type}:"
        path = [
            item for item in element.get("hierarchy_path") or [] if str(item).startswith(prefix)
        ]
        if ref_type == "subsection" and not path:
            path = [
                item
                for item in element.get("hierarchy_path") or []
                if str(item).startswith("paragraph:")
            ]
        if not path:
            return {}
        section_context = element.get("section_context") or {}
        return {
            "section": section_context.get("section", ""),
            "heading": section_context.get("heading", ""),
            "hierarchy_path": path,
            "hierarchy_details": [
                item
                for item in element.get("hierarchy_details") or []
                if item.get("level") in {ref_type, "paragraph"}
            ],
            "source_span": list(element.get("source_span") or []),
        }
    value = _hierarchy_value(element, ref_type)
    if not value:
        return {}
    detail = next(
        (item for item in element.get("hierarchy_details") or [] if item.get("level") == ref_type),
        {},
    )
    prefix = f"{ref_type}:{value}"
    return {
        "section": "",
        "heading": detail.get("heading", ""),
        "hierarchy_path": [
            item for item in element.get("hierarchy_path") or [] if str(item).startswith(prefix)
        ],
        "hierarchy_details": [detail] if detail else [],
        "source_span": list(detail.get("span") or []),
    }


def _is_relative_reference(value: str) -> bool:
    return bool(
        re.match(
            r"^this\s+(?:section|subsection|paragraph|chapter|title)$",
            str(value or ""),
            flags=re.IGNORECASE,
        )
    )


def _normalize_section_ref(value: str) -> str:
    return re.sub(r"[^0-9a-z]+", ".", str(value or "").lower()).strip(".")


def _unresolved_cross_references(element: Dict[str, Any]) -> List[Dict[str, Any]]:
    internal_ref_types = {"section", "section_range", "subsection", "paragraph", "chapter", "title"}
    resolved = element.get("resolved_cross_references") or []
    if resolved:
        return [
            ref
            for ref in resolved
            if ref.get("type") in internal_ref_types
            and ref.get("resolution_status") == "unresolved"
        ]
    return [
        ref
        for ref in element.get("cross_reference_details") or []
        if ref.get("type") in internal_ref_types
    ]


def _apply_document_penalty_context(elements: List[Dict[str, Any]], source_text: str) -> None:
    recurrence = extract_penalty_recurrence(source_text)
    if not recurrence:
        return
    for element in elements:
        if (element.get("legal_frame") or {}).get("category") != "penalty":
            continue
        penalty = dict(element.get("penalty") or {})
        if not penalty.get("recurrence"):
            penalty["recurrence"] = recurrence
            element["penalty"] = penalty
            _finalize_element(element)


def _apply_enforcement_context(elements: List[Dict[str, Any]]) -> None:
    section_violation_index = _build_section_violation_index(elements)
    for element in elements:
        links = extract_enforcement_links(element, section_violation_index)
        element["enforcement_links"] = links
        if links:
            _finalize_element(element)


def _apply_conflict_context(elements: List[Dict[str, Any]]) -> None:
    conflicts = detect_normative_conflicts(elements)
    if not conflicts:
        return
    for conflict in conflicts:
        indices = conflict.get("element_indices") or []
        for index in indices:
            if not isinstance(index, int) or index >= len(elements):
                continue
            other_indices = [item for item in indices if item != index]
            link = {
                "type": conflict.get("type", ""),
                "severity": conflict.get("severity", ""),
                "description": conflict.get("description", ""),
                "element_indices": indices,
                "other_element_indices": other_indices,
                "resolution_strategies": conflict.get("resolution_strategies", []),
            }
            existing = elements[index].setdefault("conflict_links", [])
            if link not in existing:
                existing.append(link)
            _finalize_element(elements[index])


def _build_section_violation_index(elements: List[Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    index: Dict[str, Dict[str, Any]] = {}
    for element in elements:
        if (element.get("legal_frame") or {}).get("category") != "violation":
            continue
        section = (element.get("section_context") or {}).get("section")
        if not section:
            continue
        index.setdefault(
            _normalize_section_ref(section),
            {
                "section": section,
                "heading": (element.get("section_context") or {}).get("heading", ""),
                "source_span": list(element.get("source_span") or []),
                "text": element.get("text", ""),
            },
        )
    return index


def extract_enforcement_links(
    element: Dict[str, Any],
    section_violation_index: Optional[Dict[str, Dict[str, Any]]] = None,
) -> List[Dict[str, Any]]:
    """Infer enforcement targets for violation and penalty formalization."""
    category = (element.get("legal_frame") or {}).get("category", "")
    if category not in {"violation", "penalty"}:
        return []
    section_violation_index = section_violation_index or {}
    targets = _enforcement_target_sections(element)
    links: List[Dict[str, Any]] = []
    link_type = "defines_violation_of" if category == "violation" else "penalizes_violation_of"
    if not targets and category == "penalty":
        section = (element.get("section_context") or {}).get("section", "")
        if section and _normalize_section_ref(section) in section_violation_index:
            targets.append(
                {
                    "target_type": "section",
                    "target_section": section,
                    "target_heading": (element.get("section_context") or {}).get("heading", ""),
                    "target_hierarchy_path": list(element.get("hierarchy_path") or []),
                    "resolution_status": "inferred",
                    "source": "same_section_violation",
                }
            )
    for target in targets:
        link = {
            "type": link_type,
            "target_type": target.get("target_type", "section"),
            "target_section": target.get("target_section", ""),
            "target_heading": target.get("target_heading", ""),
            "target_hierarchy_path": target.get("target_hierarchy_path", []),
            "resolution_status": target.get("resolution_status", "unresolved"),
            "source": target.get("source", "cross_reference"),
        }
        violation = section_violation_index.get(_normalize_section_ref(link["target_section"]))
        if category == "penalty" and violation:
            link["target_violation_text"] = violation.get("text", "")
            link["target_violation_span"] = violation.get("source_span", [])
        links.append(link)
    return links


def _enforcement_target_sections(element: Dict[str, Any]) -> List[Dict[str, Any]]:
    targets: List[Dict[str, Any]] = []
    for ref in element.get("resolved_cross_references") or []:
        if ref.get("type") != "section":
            continue
        target_section = ref.get("target_section") or ""
        if not target_section and _is_relative_reference(ref.get("value", "")):
            target_section = (element.get("section_context") or {}).get("section", "")
        targets.append(
            {
                "target_type": "section",
                "target_section": target_section,
                "target_heading": ref.get("target_heading", ""),
                "target_hierarchy_path": list(ref.get("target_hierarchy_path") or []),
                "resolution_status": ref.get("resolution_status", "unresolved"),
                "source": "cross_reference",
            }
        )
    if targets:
        return targets
    text = str(element.get("text") or "").lower()
    if re.search(r"\b(?:this|the)\s+section\b", text):
        section_context = element.get("section_context") or {}
        section = section_context.get("section", "")
        if section:
            targets.append(
                {
                    "target_type": "section",
                    "target_section": section,
                    "target_heading": section_context.get("heading", ""),
                    "target_hierarchy_path": list(element.get("hierarchy_path") or []),
                    "resolution_status": "resolved",
                    "source": "local_section_phrase",
                }
            )
    return targets


def validate_parser_element(element: Dict[str, Any]) -> Dict[str, Any]:
    """Validate the stable deterministic parser element contract."""
    missing = [field for field in PARSER_REQUIRED_FIELDS if field not in element]
    type_errors: List[str] = []
    list_fields = [
        "support_span",
        "subject",
        "action",
        "conditions",
        "condition_details",
        "temporal_constraints",
        "temporal_constraint_details",
        "exceptions",
        "exception_details",
        "override_clauses",
        "override_clause_details",
        "cross_references",
        "cross_reference_details",
        "resolved_cross_references",
        "enforcement_links",
        "conflict_links",
        "enumerated_items",
        "defined_term_refs",
        "ontology_terms",
        "kg_relationship_hints",
        "monetary_amounts",
        "monetary_amount_details",
        "hierarchy_path",
        "hierarchy_details",
        "parser_warnings",
    ]
    for field in list_fields:
        if field in element and not isinstance(element[field], list):
            type_errors.append(field)
    if "section_context" in element and not isinstance(element["section_context"], dict):
        type_errors.append("section_context")
    for field in [
        "definition_scope",
        "export_readiness",
        "field_spans",
        "formal_terms",
        "legal_frame",
        "logic_frame",
        "llm_repair",
        "penalty",
        "procedure",
    ]:
        if field in element and not isinstance(element[field], dict):
            type_errors.append(field)
    if "support_span" in element and len(element["support_span"]) != 2:
        type_errors.append("support_span")
    return {
        "valid": not missing and not type_errors,
        "missing_fields": missing,
        "type_errors": type_errors,
        "schema_version": element.get("schema_version", PARSER_SCHEMA_VERSION),
    }


def migrate_parser_element(element: Dict[str, Any]) -> Dict[str, Any]:
    """Upgrade an older deterministic parser element to the current schema."""
    migrated = dict(element or {})
    migrated["previous_schema_version"] = migrated.get("schema_version", "unknown")
    migrated["schema_version"] = PARSER_SCHEMA_VERSION
    text = str(migrated.get("text") or migrated.get("source_text") or "")
    support_text = str(migrated.get("support_text") or text)
    migrated.setdefault("text", text)
    migrated.setdefault("support_text", support_text)
    migrated.setdefault("support_span", [0, len(support_text)])
    migrated.setdefault("subject", [])
    migrated.setdefault("action", [])
    migrated.setdefault("modal", "")
    migrated.setdefault("norm_type", "unknown")
    migrated.setdefault("deontic_operator", "")
    migrated.setdefault("document_type", "statute")
    migrated.setdefault("extraction_method", "migrated_legacy_parser_element")
    migrated.setdefault("confidence_floor", 0.1)
    migrated.setdefault("conditions", [])
    migrated.setdefault("exceptions", [])
    migrated.setdefault("override_clauses", [])
    migrated.setdefault("cross_references", [])
    migrated.setdefault("enumerated_items", [])
    for field, default in LEGACY_SCHEMA_DEFAULTS.items():
        migrated.setdefault(field, list(default) if isinstance(default, list) else dict(default))
    migrated["condition_details"] = migrated["condition_details"] or _legacy_clause_details(
        migrated.get("conditions", []), "condition"
    )
    migrated["exception_details"] = migrated["exception_details"] or _legacy_clause_details(
        migrated.get("exceptions", []), "exception"
    )
    migrated["override_clause_details"] = migrated[
        "override_clause_details"
    ] or _legacy_clause_details(migrated.get("override_clauses", []), "override")
    migrated["cross_reference_details"] = migrated[
        "cross_reference_details"
    ] or _legacy_cross_reference_details(migrated.get("cross_references", []))
    migrated["temporal_constraint_details"] = migrated[
        "temporal_constraint_details"
    ] or _legacy_temporal_details(migrated.get("temporal_constraints", []))
    migrated.setdefault("temporal_constraints", [])
    migrated["actor_type"] = migrated.get("actor_type") or classify_legal_entity(
        (migrated.get("subject") or [""])[0] if migrated.get("subject") else ""
    )
    migrated["entity_type"] = migrated.get("entity_type") or migrated["actor_type"]
    action_text = (migrated.get("action") or [""])[0] if migrated.get("action") else ""
    migrated["action_verb"] = migrated.get("action_verb") or _first_verb(action_text)
    migrated["action_object"] = migrated.get("action_object") or _action_object(action_text)
    migrated["action_recipient"] = migrated.get("action_recipient") or extract_action_recipient(
        action_text
    )
    if not migrated.get("field_spans"):
        migrated["field_spans"] = _complete_field_spans(
            text,
            (migrated.get("subject") or [""])[0] if migrated.get("subject") else "",
            action_text,
            {},
        )
    return _finalize_element(migrated)


def _legacy_clause_details(values: List[str], slot_type: str) -> List[Dict[str, Any]]:
    return [
        {
            "type": slot_type,
            "clause_type": "legacy",
            "raw_text": str(value),
            "normalized_text": str(value).lower(),
            "span": [],
            "clause_span": [],
        }
        for value in values or []
    ]


def _legacy_cross_reference_details(refs: List[Dict[str, str]]) -> List[Dict[str, Any]]:
    return [
        {
            "type": ref.get("type", "reference"),
            "value": ref.get("value", ""),
            "raw_text": f"{ref.get('type', 'reference')} {ref.get('value', '')}".strip(),
            "normalized_text": f"{ref.get('type', 'reference')} {ref.get('value', '')}".strip().lower(),
            "span": [],
        }
        for ref in refs or []
        if isinstance(ref, dict)
    ]


def _legacy_temporal_details(items: List[Dict[str, str]]) -> List[Dict[str, Any]]:
    return [
        {
            "type": item.get("type", "temporal"),
            "temporal_kind": "legacy",
            "value": item.get("value", ""),
            "anchor": "",
            "raw_text": item.get("value", ""),
            "normalized_text": item.get("value", "").lower(),
            "span": [],
        }
        for item in items or []
        if isinstance(item, dict)
    ]


def _deterministic_ir_repair_resolution(element: Dict[str, Any]) -> Dict[str, Any]:
    """Return formula-layer repair clearance when it is explicitly deterministic."""

    try:
        from ipfs_datasets_py.logic.deontic.formula_builder import parser_element_to_formula_record
    except Exception:
        return {}

    try:
        formula_record = parser_element_to_formula_record(element)
    except Exception:
        return {}

    deterministic_resolution = formula_record.get("deterministic_resolution") or {}
    if not deterministic_resolution:
        return {}
    if formula_record.get("proof_ready") is not True:
        return {}
    if formula_record.get("requires_validation") is True:
        return {}
    if formula_record.get("repair_required") is True:
        return {}
    return deterministic_resolution


def build_llm_repair_payload(element: Dict[str, Any]) -> Dict[str, Any]:
    """Build a deterministic handoff payload for optional llm_router repair."""
    reasons = list(element.get("parser_warnings", []))
    if element.get("schema_valid") is False:
        reasons.append("schema_validation_failed")
    if element.get("quality_label") == "low":
        reasons.append("low_scaffold_quality")
    if element.get("promotable_to_theorem") is False and not reasons:
        reasons.append("not_promotable_to_theorem")

    deterministic_resolution = _deterministic_ir_repair_resolution(element)
    if deterministic_resolution:
        return _inactive_deterministic_repair_payload(element, deterministic_resolution)
    required = bool(reasons)
    prompt_context = {
        "source_text": element.get("text", ""),
        "source_id": element.get("source_id", ""),
        "canonical_citation": element.get("canonical_citation", ""),
        "support_text": element.get("support_text", ""),
        "support_span": element.get("support_span", []),
        "source_span": element.get("source_span", []),
        "section_context": element.get("section_context", {}),
        "hierarchy_path": element.get("hierarchy_path", []),
        "hierarchy_details": element.get("hierarchy_details", []),
        "legal_frame": element.get("legal_frame", {}),
        "formal_terms": element.get("formal_terms", {}),
        "deontic_operator": element.get("deontic_operator", ""),
        "norm_type": element.get("norm_type", ""),
        "subject": element.get("subject", []),
        "action": element.get("action", []),
        "conditions": element.get("condition_details", []),
        "exceptions": element.get("exception_details", []),
        "temporal_constraints": element.get("temporal_constraint_details", []),
        "cross_references": element.get("cross_reference_details", []),
        "resolved_cross_references": element.get("resolved_cross_references", []),
        "enforcement_links": element.get("enforcement_links", []),
        "conflict_links": element.get("conflict_links", []),
        "defined_term_refs": element.get("defined_term_refs", []),
        "kg_relationship_hints": element.get("kg_relationship_hints", []),
        "ontology_terms": element.get("ontology_terms", []),
        "parser_warnings": reasons,
        "deterministically_resolved": bool(deterministic_resolution),
        "deterministic_resolution": deterministic_resolution,
    }
    prompt_hash = hashlib.sha256(
        json.dumps(prompt_context, sort_keys=True, default=str).encode("utf-8")
    ).hexdigest()
    return {
        "required": required,
        "reasons": reasons,
        "target_schema_version": PARSER_SCHEMA_VERSION,
        "suggested_router": "llm_router",
        "allow_llm_repair": required,
        "deterministically_resolved": bool(deterministic_resolution),
        "deterministic_resolution": deterministic_resolution,
        "prompt_template": "legal_deontic_parser_repair_v1",
        "prompt_hash": prompt_hash,
        "prompt_context": prompt_context,
    }


def _inactive_deterministic_repair_payload(
    element: Dict[str, Any],
    deterministic_resolution: Dict[str, Any],
) -> Dict[str, Any]:
    """Return an inactive repair payload for deterministic no-LLM resolutions.

    Parser warnings and theorem-promotion gates remain conservative, but raw
    parser consumers should not see an active llm_router prompt after the typed
    IR/formula layer has explicitly resolved the blocked slot.
    """

    return {
        "required": False,
        "reasons": [],
        "target_schema_version": PARSER_SCHEMA_VERSION,
        "suggested_router": "",
        "allow_llm_repair": False,
        "deterministically_resolved": True,
        "deterministic_resolution": dict(deterministic_resolution),
        "prompt_template": "legal_deontic_parser_repair_v1",
        "prompt_hash": "",
        "prompt_context": {},
    }


def build_logic_frame(element: Dict[str, Any]) -> Dict[str, Any]:
    """Build an intermediate representation for formal-logic exporters."""
    action_text = (element.get("action") or [""])[0]
    return {
        "schema_version": PARSER_SCHEMA_VERSION,
        "source_id": element.get("source_id", ""),
        "canonical_citation": element.get("canonical_citation", ""),
        "actor": (element.get("subject") or [""])[0],
        "actor_type": element.get("actor_type", "unknown"),
        "modality": element.get("deontic_operator", ""),
        "norm_type": element.get("norm_type", ""),
        "action_text": action_text,
        "action_predicate": normalize_predicate_name(_action_without_mental_state(action_text)),
        "object": element.get("action_object", ""),
        "recipient": element.get("action_recipient", ""),
        "conditions": element.get("condition_details", []),
        "exceptions": element.get("exception_details", []),
        "temporal_constraints": element.get("temporal_constraint_details", []),
        "cross_references": element.get("cross_reference_details", []),
        "resolved_cross_references": element.get("resolved_cross_references", []),
        "enforcement_links": element.get("enforcement_links", []),
        "conflict_links": element.get("conflict_links", []),
        "defined_terms": element.get("defined_term_refs", []),
        "violation": element.get("legal_frame", {}).get("category") == "violation",
        "penalty": element.get("penalty", {}),
        "procedure": element.get("procedure", {}),
        "formal_terms": element.get("formal_terms", {}),
        "field_spans": element.get("field_spans", {}),
        "source_text": element.get("text", ""),
        "readiness": {
            "schema_valid": element.get("schema_valid"),
            "parser_warnings": element.get("parser_warnings", []),
            "promotable_to_theorem": element.get("promotable_to_theorem", False),
        },
    }


def build_export_readiness(element: Dict[str, Any]) -> Dict[str, Any]:
    """Declare which downstream artifacts are safe from this parser element."""
    blockers = list(element.get("parser_warnings", []))
    if element.get("schema_valid") is False:
        blockers.append("schema_validation_failed")
    if element.get("llm_repair", {}).get("required"):
        blockers.append("llm_repair_required")
    blockers = list(dict.fromkeys(blockers))

    allowed_exports = ["canonical_parquet", "bm25", "embeddings", "knowledge_graph"]
    formal_logic_targets: List[str] = []
    requires_validation: List[str] = []
    has_temporal_or_procedure = bool(
        element.get("temporal_constraint_details") or element.get("procedure")
    )

    if element.get("schema_valid") is False:
        allowed_exports = []
        requires_validation.append("schema_repair")
    elif blockers:
        if has_temporal_or_procedure:
            formal_logic_targets = [
                "deontic",
                "fol",
                "frame_logic",
                "temporal_logic",
                "event_calculus",
            ]
        allowed_exports.append("llm_repair_queue")
        requires_validation.extend(["llm_router_repair", "human_or_llm_semantic_review"])
    else:
        formal_logic_targets = ["deontic", "fol", "frame_logic"]
        if has_temporal_or_procedure:
            formal_logic_targets.append("temporal_logic")
            formal_logic_targets.append("event_calculus")
        allowed_exports.extend(["formal_logic_scaffold", "proof_candidate"])

    theorem_promotable = bool(
        element.get("promotable_to_theorem")
        and not blockers
        and element.get("schema_valid") is True
    )
    if not theorem_promotable and "human_or_llm_semantic_review" not in requires_validation:
        requires_validation.append("human_or_llm_semantic_review")

    return {
        "kg_ready": element.get("schema_valid") is True,
        "logic_ready": bool(formal_logic_targets),
        "proof_ready": theorem_promotable,
        "theorem_promotable": theorem_promotable,
        "allowed_exports": allowed_exports,
        "formal_logic_targets": formal_logic_targets,
        "blockers": blockers,
        "requires_validation": requires_validation,
        "source": "deterministic_parser",
    }


def infer_definition_scope(sentence: str) -> Dict[str, str]:
    text = str(sentence or "")
    lowered = text.lower()
    if re.search(r"\bas used in this (section|chapter|title)\b", lowered):
        match = re.search(r"\bas used in this (section|chapter|title)\b", lowered)
        return {"scope_type": match.group(1), "raw_text": match.group(0)}
    if re.search(r"\bin this section\b", lowered):
        return {"scope_type": "section", "raw_text": "in this section"}
    if re.search(r"\bin this chapter\b", lowered):
        return {"scope_type": "chapter", "raw_text": "in this chapter"}
    if re.search(r"\bin this title\b", lowered):
        return {"scope_type": "title", "raw_text": "in this title"}
    if re.search(r"\bfor purposes of this (section|chapter|title)\b", lowered):
        match = re.search(r"\bfor purposes of this (section|chapter|title)\b", lowered)
        return {"scope_type": match.group(1), "raw_text": match.group(0)}
    return {"scope_type": "unknown", "raw_text": ""}


def extract_ontology_terms(text: str) -> List[Dict[str, str]]:
    raw = str(text or "")
    terms: List[Dict[str, str]] = []
    seen: set[tuple[str, str]] = set()
    patterns = [
        (
            "government_actor",
            r"\b(?:Director|Bureau|City|Administrator|Commission|Council|Mayor|Department|Auditor|City\s+Attorney|City\s+Engineer|Code\s+Hearings\s+Officer|Hearings\s+Officer)\b",
        ),
        (
            "legal_person",
            r"\b(?:applicant|person|owner|tenant|employee|contractor|resident|permittee|licensee|operator|vendor)\b",
        ),
        (
            "legal_instrument",
            r"\b(?:permit|license|certificate|registration|approval|variance|franchise|easement|order)\b",
        ),
        (
            "legal_event",
            r"\b(?:notice|hearing|decision|appeal|inspection|violation|penalty|fee|citation|complaint|review|revocation|suspension)\b",
        ),
        (
            "regulated_property",
            r"\b(?:premises|sidewalk|street|vehicle|building|facility|property|right-of-way|right\s+of\s+way|sewer|tree|park)\b",
        ),
        (
            "regulated_activity",
            r"\b(?:operate|file|submit|inspect|revoke|suspend|issue|appeal|maintain|remove|install|construct)\b",
        ),
    ]
    for term_type, pattern in patterns:
        for match in re.finditer(pattern, raw, flags=re.IGNORECASE):
            value = match.group(0)
            key = (term_type, value.lower())
            if key in seen:
                continue
            seen.add(key)
            terms.append({"term": value, "type": term_type, "span": [match.start(), match.end()]})
    return terms


def merge_ontology_terms(
    existing_terms: List[Dict[str, Any]],
    defined_refs: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    merged = list(existing_terms or [])
    seen = {(str(item.get("term", "")).lower(), str(item.get("type", ""))) for item in merged}
    for ref in defined_refs:
        key = (str(ref.get("term", "")).lower(), "defined_term")
        if key in seen:
            continue
        seen.add(key)
        merged.append(
            {
                "term": ref.get("term", ""),
                "type": "defined_term",
                "definition_body": ref.get("definition_body", ""),
                "span": ref.get("span", []),
            }
        )
    return merged


def _enrich_legal_frame(element: Dict[str, Any]) -> None:
    text = str(element.get("text") or "")
    action = (element.get("action") or [""])[0]
    subject = (element.get("subject") or [""])[0]
    category = classify_legal_frame(element)
    element["legal_frame"] = {
        "source_id": element.get("source_id", ""),
        "canonical_citation": element.get("canonical_citation", ""),
        "category": category,
        "actor": subject,
        "actor_id": normalize_symbol(subject),
        "actor_type": element.get("actor_type", "unknown"),
        "action": action,
        "action_predicate": normalize_predicate_name(_action_without_mental_state(action)),
        "object": element.get("action_object", ""),
        "recipient": element.get("action_recipient", ""),
        "norm_type": element.get("norm_type", ""),
        "deontic_operator": element.get("deontic_operator", ""),
    }
    element["monetary_amounts"] = extract_monetary_amounts(text)
    element["monetary_amount_details"] = extract_monetary_amount_details(text)
    existing_penalty = element.get("penalty") or {}
    penalty = extract_penalty_details(text, action)
    if existing_penalty.get("recurrence") and not penalty.get("recurrence"):
        penalty["recurrence"] = existing_penalty["recurrence"]
    element["penalty"] = penalty
    element["procedure"] = extract_procedure_details(text, action)
    element["kg_relationship_hints"] = build_kg_relationship_hints(element)


def classify_legal_frame(element: Dict[str, Any]) -> str:
    text = str(element.get("text") or "").lower()
    action = " ".join(element.get("action", [])).lower()
    norm_type = element.get("norm_type")
    subject = " ".join(element.get("subject", [])).lower()
    if norm_type == "applicability":
        return "applicability"
    if norm_type == "exemption":
        return "exemption"
    if norm_type == "instrument_lifecycle":
        return "instrument_lifecycle"
    if norm_type == "purpose":
        return "purpose"
    if norm_type == "definition":
        return "definition"
    if norm_type == "penalty" or "punishable" in text or "fine" in text or "penalty" in text:
        return "penalty"
    if norm_type == "violation" or "violation" in text or "offense" in text or "infraction" in text:
        return "violation"
    if element.get("entity_type") == "legal_event" and subject in _LEGAL_EVENT_ENTITIES:
        return "procedure"
    if re.search(
        r"\b(?:appeal|appealed|hearing|notice|decision|inspect|inspection|revoke|revocation|suspend|suspension)\b",
        action,
    ):
        return "procedure"
    if subject in _LEGAL_INSTRUMENT_ENTITIES or any(
        term in text for term in ["permit", "license", "certificate", "registration"]
    ):
        return "permit_or_license"
    if extract_legal_instrument_target(action):
        return "permit_or_license"
    if "fee" in text or element.get("monetary_amounts"):
        return "fee"
    if action.startswith(("file", "submit", "apply", "provide")):
        return "filing_requirement"
    return "norm"


def extract_monetary_amounts(text: str) -> List[Dict[str, str]]:
    amounts: List[Dict[str, str]] = []
    for match in _MONEY_RE.finditer(str(text or "")):
        amounts.append({"raw_text": match.group(0).strip(), "span": [match.start(), match.end()]})
    return amounts


def extract_monetary_amount_details(text: str) -> List[Dict[str, Any]]:
    details: List[Dict[str, Any]] = []
    for match in _MONEY_RE.finditer(str(text or "")):
        raw_text = match.group(0).strip()
        numeric = re.sub(r"[^\d.]", "", raw_text)
        details.append(
            {
                "type": "money",
                "raw_text": raw_text,
                "normalized_text": raw_text.lower(),
                "numeric_value": numeric,
                "currency": "USD" if "$" in raw_text or "dollar" in raw_text.lower() else "",
                "span": [match.start(), match.end()],
            }
        )
    return details


def extract_penalty_details(text: str, action: str = "") -> Dict[str, Any]:
    combined = f"{text} {action}".strip()
    lower = combined.lower()
    if not any(
        term in lower
        for term in [
            "fine",
            "penalty",
            "punishable",
            "imprison",
            "violation",
            "offense",
            "infraction",
        ]
    ):
        return {}
    amounts = extract_monetary_amount_details(combined)
    minimum_amount = _penalty_bound(combined, "minimum")
    maximum_amount = _penalty_bound(combined, "maximum")
    sanction_class = classify_sanction_class(combined)
    sanction_modality = classify_sanction_modality(combined)
    # "excessive fines" is the prohibited act, not a sanction attached to another duty.
    if (
        not sanction_class
        and not amounts
        and not re.search(r"\b(?:jail|imprison|imprisonment|custody)\b", lower)
    ):
        return {}
    return {
        "raw_text": combined,
        "sanction_class": sanction_class,
        "classification": sanction_class,
        "sanction_modality": sanction_modality,
        "monetary_amounts": extract_monetary_amounts(combined),
        "monetary_amount_details": amounts,
        "minimum_amount": minimum_amount,
        "maximum_amount": maximum_amount,
        "has_range": bool(minimum_amount and maximum_amount),
        "recurrence": extract_penalty_recurrence(combined),
        "imprisonment_duration": extract_imprisonment_duration(combined),
        "has_imprisonment": bool(re.search(r"\b(?:jail|imprison|imprisonment|custody)\b", lower)),
        "has_fine": "fine" in lower or bool(amounts),
    }


def classify_sanction_class(text: str) -> str:
    lower = str(text or "").lower()
    if re.search(r"\bcriminal\s+(?:fine|penalty|offense|violation|sanction)\b", lower):
        return "criminal"
    if re.search(r"\bcivil\s+(?:fine|penalty|violation|infraction|sanction)\b", lower):
        return "civil"
    if re.search(r"\badministrative\s+(?:fine|penalty|sanction|citation)\b", lower):
        return "administrative"
    if re.search(r"\bimprison|jail|custody\b", lower):
        return "criminal"
    return ""


def classify_sanction_modality(text: str) -> str:
    lower = str(text or "").lower()
    if re.search(
        r"\bmay\s+(?:be\s+)?(?:impose|imposed|punish|punished|fine|fined|assess|assessed)\b", lower
    ):
        return "discretionary"
    if re.search(r"\b(?:is|shall\s+be)\s+(?:punishable\s+by|subject\s+to)\b", lower):
        return "mandatory"
    if re.search(r"\bmust\s+(?:pay|serve)\b", lower):
        return "mandatory"
    return ""


def _penalty_bound(text: str, bound: str) -> Dict[str, Any]:
    if bound == "minimum":
        pattern = r"\b(?:not\s+less\s+than|minimum(?:\s+of)?)\s+(\$\s?\d[\d,]*(?:\.\d{2})?|\d[\d,]*\s+dollars?)"
    else:
        pattern = r"\b(?:not\s+more\s+than|maximum(?:\s+of)?|up\s+to)\s+(\$\s?\d[\d,]*(?:\.\d{2})?|\d[\d,]*\s+dollars?)"
    match = re.search(pattern, text, flags=re.IGNORECASE)
    if not match:
        return {}
    raw_text = match.group(1).strip()
    return {
        "raw_text": raw_text,
        "numeric_value": re.sub(r"[^\d.]", "", raw_text),
        "currency": "USD" if "$" in raw_text or "dollar" in raw_text.lower() else "",
        "span": [match.start(1), match.end(1)],
    }


def extract_penalty_recurrence(text: str) -> Dict[str, Any]:
    patterns = [
        (
            "per_day",
            r"\b(?:each|every)\s+day\s+(?:constitutes|is)\s+(?:a\s+)?separate\s+violation\b",
        ),
        ("per_violation", r"\b(?:per|for each)\s+violation\b"),
        ("per_offense", r"\b(?:per|for each)\s+offense\b"),
    ]
    for recurrence_type, pattern in patterns:
        match = re.search(pattern, text, flags=re.IGNORECASE)
        if match:
            return {
                "type": recurrence_type,
                "raw_text": match.group(0),
                "span": [match.start(), match.end()],
            }
    return {}


def extract_imprisonment_duration(text: str) -> Dict[str, Any]:
    pattern = r"\b(?:imprisonment|jail|custody)\s+(?:for\s+)?(?:a\s+term\s+of\s+)?(?:not\s+more\s+than|up\s+to|for)?\s*(\d+)\s+(days?|months?|years?)\b"
    match = re.search(pattern, str(text or ""), flags=re.IGNORECASE)
    if not match:
        return {}
    return {
        "raw_text": match.group(0).strip(),
        "quantity": int(match.group(1)),
        "unit": match.group(2).lower().rstrip("s"),
        "span": [match.start(), match.end()],
    }


def extract_procedure_details(text: str, action: str = "") -> Dict[str, Any]:
    combined = f"{text} {action}".strip()
    lower = combined.lower()
    events = [
        event
        for event in _PROCEDURE_EVENT_ORDER
        if re.search(_PROCEDURE_EVENT_PATTERNS[event], lower)
    ]
    if not events:
        return {}
    event_mentions = extract_procedure_event_mentions(combined)
    event_relations = extract_procedure_event_relations(combined, action, events)
    # One verb, such as "issue a writ", is the act. A procedure needs a chain.
    if len(events) < 2 and not event_relations:
        return {}
    return {
        "events": events,
        "event_chain": [
            {
                "event": event,
                "order": index + 1,
                "mentions": [
                    mention for mention in event_mentions if mention.get("event") == event
                ],
                "relations": [
                    relation
                    for relation in event_relations
                    if relation.get("event") == event or relation.get("anchor_event") == event
                ],
            }
            for index, event in enumerate(events)
        ],
        "event_mentions": event_mentions,
        "event_relations": event_relations,
        "trigger_event": _infer_trigger_event(events, event_relations),
        "terminal_event": _infer_terminal_event(events, event_relations),
        "raw_text": combined,
    }


def extract_procedure_event_mentions(text: str) -> List[Dict[str, Any]]:
    mentions: List[Dict[str, Any]] = []
    seen: set[tuple[str, int, int]] = set()
    for event in _PROCEDURE_EVENT_ORDER:
        pattern = _PROCEDURE_EVENT_PATTERNS[event]
        for match in re.finditer(pattern, str(text or ""), flags=re.IGNORECASE):
            key = (event, match.start(), match.end())
            if key in seen:
                continue
            seen.add(key)
            mentions.append(
                {
                    "event": event,
                    "raw_text": match.group(0),
                    "span": [match.start(), match.end()],
                }
            )
    return sorted(
        mentions, key=lambda item: (item["span"][0], _PROCEDURE_EVENT_ORDER.index(item["event"]))
    )


def extract_procedure_event_relations(
    text: str, action: str = "", events: Optional[List[str]] = None
) -> List[Dict[str, Any]]:
    """Extract deterministic event ordering relations from procedural connectors."""
    combined = str(text or "")
    known_events = events or [
        event
        for event in _PROCEDURE_EVENT_ORDER
        if re.search(_PROCEDURE_EVENT_PATTERNS[event], combined, flags=re.IGNORECASE)
    ]
    action_event = _infer_event_from_phrase(action) or (known_events[-1] if known_events else "")
    relations: List[Dict[str, Any]] = []

    def add_relation(
        event: str, relation: str, anchor_event: str, match: re.Match[str], raw_text: str = ""
    ) -> None:
        if not event and not anchor_event:
            return
        relation_record = {
            "event": event,
            "relation": relation,
            "anchor_event": anchor_event,
            "raw_text": (raw_text or match.group(0)).strip(),
            "span": [match.start(), match.end()],
        }
        if relation_record not in relations:
            relations.append(relation_record)

    for match in re.finditer(
        r"\bupon\s+receipt\s+of\s+(?P<object>[^,.;]+)", combined, flags=re.IGNORECASE
    ):
        anchor_event = _infer_event_from_phrase(match.group("object")) or "receipt"
        add_relation(action_event, "triggered_by_receipt_of", anchor_event, match)
        add_relation("receipt", "receives", anchor_event, match)

    for match in re.finditer(
        r"\bafter\s+(?P<events>[^,.;]+?)(?=\s+(?:and\s+)?(?:shall|must|may|before|within)\b|[,.;]|$)",
        combined,
        flags=re.IGNORECASE,
    ):
        for anchor_event in _events_from_phrase(match.group("events")):
            add_relation(action_event, "after", anchor_event, match)

    for match in re.finditer(
        r"\bbefore\s+(?P<events>[^,.;]+?)(?=\s+(?:and\s+)?(?:shall|must|may|after|within)\b|[,.;]|$)",
        combined,
        flags=re.IGNORECASE,
    ):
        for anchor_event in _events_from_phrase(match.group("events")):
            add_relation(action_event, "before", anchor_event, match)

    return relations


def _infer_trigger_event(events: List[str], relations: List[Dict[str, Any]]) -> str:
    for relation in relations:
        if (
            relation.get("relation") in {"triggered_by_receipt_of", "after"}
            and relation.get("anchor_event") in events
        ):
            return relation["anchor_event"]
    return events[0] if events else ""


def _infer_terminal_event(events: List[str], relations: List[Dict[str, Any]]) -> str:
    before_events = [
        relation.get("anchor_event")
        for relation in relations
        if relation.get("relation") == "before"
    ]
    for event in reversed(events):
        if event not in before_events:
            return event
    return events[-1] if events else ""


def _events_from_phrase(phrase: str) -> List[str]:
    events = []
    for part in re.split(r"\s*(?:,|and|or)\s*", str(phrase or "")):
        event = _infer_event_from_phrase(part)
        if event and event not in events:
            events.append(event)
    return events


def _infer_event_from_phrase(phrase: str) -> str:
    normalized = str(phrase or "").lower()
    aliases = {
        "approval": "issuance",
        "approve": "issuance",
        "grant": "issuance",
        "receipt": "receipt",
        "receive": "receipt",
        "received": "receipt",
    }
    for token, event in aliases.items():
        if re.search(rf"\b{re.escape(token)}\b", normalized):
            return event
    for event in _PROCEDURE_EVENT_ORDER:
        if re.search(_PROCEDURE_EVENT_PATTERNS[event], normalized):
            return event
    return ""


def build_kg_relationship_hints(element: Dict[str, Any]) -> List[Dict[str, str]]:
    subject = (element.get("subject") or [""])[0]
    action = (element.get("action") or [""])[0]
    category = (element.get("legal_frame") or {}).get("category", "")
    instrument_target = extract_legal_instrument_target(action)
    relationships: List[Dict[str, str]] = []
    if subject and action:
        predicate = {
            "obligation": "imposesDutyOn",
            "permission": "authorizes",
            "prohibition": "prohibits",
            "violation": "definesViolationFor",
            "penalty": "createsPenaltyFor",
            "definition": "definesTerm",
            "applicability": "appliesTo",
            "exemption": "exemptsFrom",
            "instrument_lifecycle": "setsLifecycleFor",
        }.get(element.get("norm_type"), "regulates")
        relationships.append({"subject": "law", "predicate": predicate, "object": subject})
        relationships.append({"subject": subject, "predicate": "performsAction", "object": action})
    if category == "instrument_lifecycle" and subject:
        relationships.append({"subject": "law", "predicate": "setsLifecycleFor", "object": subject})
    if category == "permit_or_license" and action:
        relationships.append(
            {
                "subject": action,
                "predicate": "requiresLegalInstrument",
                "object": instrument_target or subject,
            }
        )
    if element.get("action_recipient"):
        relationships.append(
            {"subject": subject, "predicate": "directedTo", "object": element["action_recipient"]}
        )
    procedure = element.get("procedure") or {}
    events = set(procedure.get("events") or [])
    if "notice" in events:
        relationships.append(
            {
                "subject": subject,
                "predicate": "providesNoticeTo",
                "object": element.get("action_recipient") or action,
            }
        )
    if "hearing" in events:
        relationships.append(
            {
                "subject": subject,
                "predicate": "holdsHearingFor",
                "object": element.get("action_recipient") or action,
            }
        )
    if "decision" in events:
        relationships.append({"subject": subject, "predicate": "issuesDecision", "object": action})
    if "appeal" in events:
        relationships.append(
            {"subject": action or subject, "predicate": "mayAppealDecision", "object": subject}
        )
    if "inspection" in events:
        relationships.append(
            {
                "subject": subject,
                "predicate": "mayInspect",
                "object": element.get("action_object") or action,
            }
        )
    if "revocation" in events:
        relationships.append(
            {
                "subject": subject,
                "predicate": "mayRevokeInstrument",
                "object": instrument_target or element.get("action_object") or action,
            }
        )
    if "suspension" in events:
        relationships.append(
            {
                "subject": subject,
                "predicate": "maySuspendInstrument",
                "object": instrument_target or element.get("action_object") or action,
            }
        )
    for link in element.get("enforcement_links", []):
        if link.get("type") == "defines_violation_of":
            relationships.append(
                {
                    "subject": "violation",
                    "predicate": "violatesSection",
                    "object": link.get("target_section", ""),
                }
            )
        if link.get("type") == "penalizes_violation_of":
            relationships.append(
                {
                    "subject": "penalty",
                    "predicate": "penalizesViolationOf",
                    "object": link.get("target_section", ""),
                }
            )
    for ref in element.get("defined_term_refs", []):
        relationships.append(
            {
                "subject": ref.get("term", ""),
                "predicate": "definedBy",
                "object": ref.get("definition_body") or ref.get("definition_text", ""),
            }
        )
    resolved_refs = element.get("resolved_cross_references") or []
    if resolved_refs:
        for ref in resolved_refs:
            if ref.get("type") == "section_range":
                predicate = (
                    "referencesResolvedSectionRange"
                    if ref.get("resolution_status") == "resolved"
                    else "referencesUnresolvedSectionRange"
                )
                relationships.append(
                    {"subject": "law", "predicate": predicate, "object": ref.get("value", "")}
                )
                continue
            target = ref.get("target_section") or ref.get("value", "")
            predicate = (
                "referencesResolvedSection"
                if ref.get("resolution_status") == "resolved"
                else "referencesUnresolvedSection"
            )
            relationships.append(
                {"subject": "law", "predicate": predicate, "object": f"{ref.get('type')}:{target}"}
            )
    else:
        for ref in element.get("cross_references", []):
            relationships.append(
                {
                    "subject": "law",
                    "predicate": "references",
                    "object": f"{ref.get('type')}:{ref.get('value')}",
                }
            )
    for amount in element.get("monetary_amounts", []):
        relationships.append(
            {"subject": "law", "predicate": "mentionsAmount", "object": amount.get("raw_text", "")}
        )
    return relationships


def build_kg_triples(element: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Convert KG relationship hints into parquet-friendly triple rows."""
    triples: List[Dict[str, Any]] = []
    source_id = element.get("source_id") or build_source_id(element)
    citation = element.get("canonical_citation") or build_canonical_citation(element)
    for index, relationship in enumerate(element.get("kg_relationship_hints") or []):
        subject = relationship.get("subject", "")
        predicate = relationship.get("predicate", "")
        object_value = relationship.get("object", "")
        triple_identity = {
            "source_id": source_id,
            "index": index,
            "subject": subject,
            "predicate": predicate,
            "object": object_value,
        }
        triple_hash = hashlib.sha256(
            json.dumps(triple_identity, sort_keys=True, default=str).encode("utf-8")
        ).hexdigest()
        triples.append(
            {
                "triple_id": f"kg:{triple_hash[:24]}",
                "source_id": source_id,
                "canonical_citation": citation,
                "subject": subject,
                "subject_id": normalize_symbol(subject),
                "predicate": predicate,
                "predicate_id": normalize_symbol(predicate),
                "object": object_value,
                "object_id": normalize_symbol(object_value),
                "norm_type": element.get("norm_type", ""),
                "legal_category": (element.get("legal_frame") or {}).get("category", ""),
                "confidence_floor": element.get("confidence_floor", 0.0),
                "provenance": {
                    "text": element.get("text", ""),
                    "source_span": element.get("source_span", []),
                    "support_span": element.get("support_span", []),
                    "field_spans": element.get("field_spans", {}),
                },
            }
        )
    return triples


def extract_legal_instrument_target(action: str) -> str:
    match = re.search(
        r"\b(?:permit|license|certificate|registration|approval|variance|franchise|easement|order)\b",
        str(action or ""),
        flags=re.IGNORECASE,
    )
    return match.group(0).lower() if match else ""


def classify_modal(modal: str) -> tuple[str, str]:
    modal = re.sub(r"\s+", " ", str(modal or "").lower()).strip()
    # Prohibitions must be checked before bare "shall"/"must"/"may".
    if modal in {
        "shall not",
        "must not",
        "may not",
        "cannot",
        "can not",
        "is prohibited from",
        "are prohibited from",
        "is hereby prohibited",
        "are hereby prohibited",
        "is forbidden to",
        "are forbidden to",
    }:
        return "prohibition", "F"
    if modal in {
        "may",
        "is authorized to",
        "are authorized to",
        "is permitted to",
        "are permitted to",
        "is entitled to",
        "are entitled to",
    }:
        return "permission", "P"
    return "obligation", "O"


def _clean_phrase(value: str) -> str:
    text = re.sub(r"\s+", " ", str(value or "")).strip(" ,;:")
    text = _LEADING_DETERMINERS_RE.sub("", text).strip()
    return text


def _has_leading_negated_subject(value: Any) -> bool:
    text = re.sub(r"\s+", " ", str(value or "")).strip(" ,;:").lower()
    return bool(re.match(
        r"^(?:(?:then|and|or|but)\s+)*(?:that\s+)?(?:no|none|neither)\b",
        text,
    ))


def _clean_negated_subject_phrase(value: Any) -> str:
    text = re.sub(r"\s+", " ", str(value or "")).strip(" ,;:")
    text = re.sub(r"^(?:(?:then|and|or|but)\s+)*(?:that\s+)?", "", text, flags=re.IGNORECASE).strip()
    # "No Person" must not be repeated. "Neither A nor B" names both actors, so it stays.
    text = re.sub(r"^(?:no|none)\s+", "", text, flags=re.IGNORECASE).strip()
    return _clean_phrase(text)


def _trim_embedded_heading_subject(value: str) -> str:
    """Drop catchline text accidentally glued before a determiner-led actor.

    ``of the Electors`` is not a catchline. That mention stays inside the
    subject. The F-logic fixture records it; it does not become the actor.
    """

    text = _clean_phrase(value)
    matches = list(
        re.finditer(
            r"\b(?:[Tt]he|[Aa]|[Aa]n|[Ee]ach|[Aa]ny)\s+"
            r"(?P<actor>[A-Z][A-Za-z0-9'’\-]*(?:\s+[A-Z][A-Za-z0-9'’\-]*){0,8})$",
            text,
        )
    )
    if not matches:
        return text
    prefix = text[: matches[-1].start()]
    if re.search(r"\b(?:of|by|from|having|who|which|nor|neither)\b", prefix, re.I):
        return text
    actor = _clean_phrase(matches[-1].group("actor"))
    if actor and classify_legal_entity(actor) in {
        "government_actor",
        "legal_person",
        "organization",
        "legal_entity",
    }:
        return actor
    return text


_PAREN_INTERRUPTER_RE = re.compile(
    r"\bshall\s*,?\s*(?P<pre>[^,]{0,80}?)\s*,\s*"
    r"(?P<kind>except|without|unless)\s+"
    r"(?P<body>.+?)\s*,\s*"
    r"(?P<rest>(?:be|accept|have|make|take|do|give|receive|pay|hold|grant|enter|pass|discharge|lay|keep|engage)\b[^;.]*)",
    re.IGNORECASE,
)
_SHALL_COMMA_VERB_RE = re.compile(
    r"\bshall\s*,\s*(?P<pre>.+?)\s*,\s*(?P<rest>be\b[^;.]*)",
    re.IGNORECASE,
)
_INVERTED_SHALL_RE = re.compile(
    r"\b(?P<lead>nor|and|but|or)\s+(?P<modal>shall(?:\s+not)?|must(?:\s+not)?)\s+(?P<rest>.+)$",
    re.IGNORECASE,
)
_INVERTED_SUBJECT_RE = re.compile(
    r"^(?P<subject>(?:any|a|an|the|no|each|every|such|private)\s+[^,;]{0,80}?)\s+"
    r"(?P<action>(?:be|deprive|deny|hold|make|have|take|accept|grant|lay|enter|pass|receive|enjoy|issue|appoint|nominate|subject)\b.+)$",
    re.IGNORECASE,
)
# "nor shall Vessels bound to, or from, one State, be obliged"
_INVERTED_COMMA_SUBJECT_RE = re.compile(
    r"^(?P<subject>.+?)\s*,\s*"
    r"(?P<action>(?:be|deprive|deny|hold|make|have|take|accept|grant|lay|enter|pass|receive|enjoy|issue|appoint|nominate|subject)\b.+)$",
    re.IGNORECASE,
)
_EMBEDDED_RELATIVE_SUBJECT_RE = re.compile(r"^(?:and|or|but)\s+those\b", re.IGNORECASE)
_INFINITIVE_SUBJECT_RE = re.compile(r"^to\s+[A-Za-z]+$", re.IGNORECASE)
_CLAUSE_LEAD_RE = re.compile(
    r"(?:^|[;:])\s*(?:(?:and|but|nor|or)\s+)?(?P<lead>for\s+[^,;:]{3,160})\s*,\s*$",
    re.IGNORECASE,
)
_LEADING_CASE_RE = re.compile(
    r"^(?:in\s+(?:all|every)\b|before\b|thereafter\b|(?:but\s+)?in\s+\w+ing\b|in\s+\w+\s+at\b)",
    re.IGNORECASE,
)
_PROVIDED_THAT_NO_RE = re.compile(
    r"\bprovided\s+that\s+no\s+(?P<subject>.+?)\s+shall\s+(?P<action>.+?)"
    r"(?=;\s*and\s+that\b|[.]|$)",
    re.IGNORECASE | re.DOTALL,
)
# "The Migration or Importation of such Persons as any of the States shall think proper, shall not be prohibited"
_AS_THEN_SHALL_NOT_RE = re.compile(
    r"^(?P<subject>the\s+.+?\s+or\s+.+?)\s+(?P<as>as\s+any\s+of\s+.+?\s+shall\s+.+?),\s+"
    r"(?P<modal>shall\s+not)\s+(?P<action>.+)$",
    re.IGNORECASE | re.DOTALL,
)
# "Every Order, Resolution, or Vote to which ... may be necessary ... shall be presented"
_RELATIVE_HEAD_SHALL_RE = re.compile(
    r"^(?P<subject>.+?)\s+(?P<which>to\s+which\b.+?)\s+(?P<modal>shall(?:\s+not)?|must(?:\s+not)?)\s+(?P<action>.+)$",
    re.IGNORECASE,
)
# "before the Same shall take Effect, shall be approved ... or being disapproved ... shall be repassed"
_BEFORE_EFFECT_RE = re.compile(
    r"^(?:and\s+)?before\s+(?P<when>the\s+same\s+shall\s+.+?)\s*,\s*shall\s+(?P<rest>.+)$",
    re.IGNORECASE | re.DOTALL,
)


def _span_pair(value: object) -> tuple[int, int] | None:
    if isinstance(value, (list, tuple)) and len(value) == 2:
        return int(value[0]), int(value[1])
    return None


def _element_span(element: dict) -> tuple[int, int] | None:
    return _span_pair(element.get("support_span"))


def _overlaps(left: tuple[int, int], right: tuple[int, int]) -> bool:
    return not (left[1] <= right[0] or right[1] <= left[0])


def _mostly_inside(span: tuple[int, int], containers: list[tuple[int, int]]) -> bool:
    width = max(1, span[1] - span[0])
    for left, right in containers:
        overlap = min(span[1], right) - max(span[0], left)
        if overlap >= width * 0.6:
            return True
    return False


def _manner_shall(sentence: str, element: dict) -> bool:
    """``as they shall`` is a manner clause, not a second duty."""

    subject = " ".join(str(part) for part in element.get("subject") or []).casefold()
    if subject.startswith("in such manner") or re.search(
        r"\bas\s+(?:they|he|she|it|congress|the legislature)\s*$",
        subject,
    ):
        return True
    span = _element_span(element)
    if span is None:
        return False
    prefix = sentence[max(0, span[0] - 16) : span[0]].casefold()
    return bool(re.search(r"\bas\s+(?:each\s+|the\s+)?$", prefix))


def _detail_governs(kind: str, detail: tuple[int, int], element: dict, duties: list) -> bool:
    """A leading if goes to the next duty. A trailing unless goes to the previous one."""

    ours = _element_span(element)
    if ours is None:
        return False
    if _overlaps(detail, ours):
        return True
    if kind == "condition":
        overlapping = [
            item for item in duties
            if _overlaps(detail, _element_span(item) or (0, 0))
        ]
        if overlapping:
            return element in overlapping
        after = [item for item in duties if (_element_span(item) or (0, 0))[0] >= detail[1]]
        return bool(after) and after[0] is element
    if kind in {"exception", "temporal"}:
        before = [item for item in duties if (_element_span(item) or (0, 0))[1] <= detail[0]]
        if not before:
            after = [item for item in duties if (_element_span(item) or (0, 0))[0] >= detail[1]]
            return bool(after) and after[0] is element
        if before[-1] is not element:
            return False
        return not any(detail[0] > (_element_span(item) or (0, 0))[0] >= ours[1] for item in duties)
    return False


def _scope_details(sentence: str, elements: list) -> None:
    duties = [item for item in elements if _element_span(item)]
    duties.sort(key=lambda item: (_element_span(item) or (0, 0))[0])
    if len(duties) < 2:
        return
    groups = (
        ("condition", "condition_details", extract_condition_details(sentence)),
        ("exception", "exception_details", extract_exception_details(sentence)),
        ("temporal", "temporal_constraint_details", extract_temporal_constraint_details(sentence)),
    )
    for element in duties:
        action = " ".join(str(part) for part in element.get("action") or []).casefold()
        for kind, key, details in groups:
            scoped = []
            for item in element.get(key) or []:
                surface = str(item.get("normalized_text") or item.get("value") or "").casefold()
                if surface and surface in action:
                    continue
                span = _span_pair(item.get("span"))
                if span is not None and not _detail_governs(kind, span, element, duties):
                    continue
                scoped.append(item)
            element[key] = scoped
            legacy = {
                "condition_details": "conditions",
                "exception_details": "exceptions",
                "temporal_constraint_details": "temporal_constraints",
            }.get(key)
            if legacy:
                element[legacy] = scoped
        element["slot_details_scoped"] = True


def _drop_shalls_inside_conditions(sentence: str, elements: list) -> list:
    """A shall inside an if, until, or unless is not a second duty.

    Kept when every shall is inside a condition, as in "if he approve he shall sign."
    A manner clause (``as they shall``) is dropped when another duty remains.
    Each remaining duty keeps only the conditions and exceptions that govern it.
    """

    containers: list[tuple[int, int]] = []
    for item in list(extract_condition_details(sentence)) + list(extract_exception_details(sentence)):
        span = _span_pair(item.get("span"))
        if span is not None:
            containers.append(span)
    if len(elements) < 2:
        for element in elements:
            _dedupe_slot_surfaces(element)
        return elements
    kept = []
    for element in elements:
        span = _element_span(element)
        if element.get("extraction_method") == "deterministic_provided_that_no_v1":
            kept.append(element)
            continue
        if _contained_by_other(element, elements):
            continue
        if span is not None and containers and _mostly_inside(span, containers):
            continue
        if _manner_shall(sentence, element):
            continue
        kept.append(element)
    kept = kept or elements
    _scope_details(sentence, kept)
    for element in kept:
        _dedupe_slot_surfaces(element)
    return kept


def _dedupe_slot_surfaces(element: dict) -> None:
    """Coalesce competing prefix extractions of the *same* source clause.

    Text containment alone is not evidence of redundancy: ``revoked`` and
    ``not revoked`` at different locations can carry opposite conditions.
    Missing or inconsistent provenance is retained rather than guessed away.
    """

    def source_span(value):
        if (isinstance(value, (list, tuple)) and len(value) == 2
                and all(type(part) is int for part in value)
                and 0 <= value[0] < value[1]):
            return tuple(value)
        return None

    def same_source_prefix(short, long, surface, other):
        if not surface or not other.startswith(surface) or len(surface) >= len(other):
            return False
        if other[len(surface)].isalnum() or other[len(surface)] == "_":
            return False
        if not short.get("clause_type") or short.get("clause_type") != long.get("clause_type"):
            return False
        if not short.get("type") or short.get("type") != long.get("type"):
            return False
        a, b = source_span(short.get("span")), source_span(long.get("span"))
        ca, cb = source_span(short.get("clause_span")), source_span(long.get("clause_span"))
        return bool(a and b and ca and cb and a[0] == b[0] and a[1] < b[1]
                    and ca[0] == cb[0] <= a[0] and a[1] <= ca[1] <= cb[1]
                    and b[1] <= cb[1])

    pairs = (
        ("condition_details", "conditions"),
        ("exception_details", "exceptions"),
        ("temporal_constraint_details", "temporal_constraints"),
    )
    for key, legacy in pairs:
        details = list(element.get(key) or [])
        surfaces = [
            str(item.get("normalized_text") or item.get("value") or "").casefold()
            for item in details
        ]
        deduped = []
        for item, surface in zip(details, surfaces):
            if any(same_source_prefix(item, candidate, surface, other)
                   for candidate, other in zip(details, surfaces)):
                continue
            deduped.append(item)
        element[key] = deduped
        if legacy in element:
            element[legacy] = deduped


def _contained_by_other(element: dict, elements: list) -> bool:
    span = _element_span(element)
    if span is None:
        return False
    for other in elements:
        if other is element:
            continue
        other_span = _element_span(other)
        if other_span is None or other_span == span:
            continue
        if other_span[0] <= span[0] and span[1] <= other_span[1]:
            return True
    return False


def _split_inverted_action(action_text: str) -> tuple[str, str]:
    """``nor shall any person be subject`` stores the person, not ``nor``."""

    match = _INVERTED_SUBJECT_RE.match(action_text or "") or _INVERTED_COMMA_SUBJECT_RE.match(action_text or "")
    if not match:
        return "", ""
    return _clean_phrase(match.group("subject")), _clean_action(match.group("action"))


def _with_condition(element: dict, surface: str) -> dict:
    text = " ".join(str(surface or "").split())
    if not text:
        return element
    detail = {
        "type": "condition",
        "clause_type": "when",
        "raw_text": text,
        "normalized_text": text.lower(),
        "value": text.lower(),
        "span": [0, len(text)],
        "clause_span": [0, len(text)],
    }
    element["condition_details"] = list(element.get("condition_details") or []) + [detail]
    element["conditions"] = list(element.get("conditions") or []) + [text.lower()]
    return element


def _effect_before_approval_elements(sentence: str, document_type: str) -> list:
    """Split approval and repassage. ``before the Same shall take Effect`` is the time."""

    match = _BEFORE_EFFECT_RE.match(sentence.strip())
    if not match:
        return []
    when = " ".join(match.group("when").split())
    parts = re.split(
        r",\s*or\s+being\s+disapproved\s+by\s+him,\s*shall\s+",
        match.group("rest"),
        maxsplit=1,
        flags=re.IGNORECASE,
    )
    if len(parts) != 2:
        return []
    rows = []
    for action, extra in (
        (parts[0], ""),
        (parts[1], "being disapproved by him"),
    ):
        action_text = _clean_action(action)
        if not action_text:
            continue
        element = _finalize_element(
            _build_element(
                sentence=sentence,
                document_type=document_type,
                norm_type="obligation",
                deontic_operator="O",
                modal="shall",
                subject_text="the Same",
                action_text=action_text,
                support_span=match.span(),
                field_spans={},
                extraction_method="deterministic_before_effect_v1",
            )
        )
        _with_condition(element, f"before {when}")
        if extra:
            _with_condition(element, extra)
        rows.append(element)
    return rows


def _subject_without_except(subject: str) -> str:
    """``Person except a natural born Citizen`` names the person. The class is an exception."""

    parts = re.split(r"\bexcept\b", subject or "", maxsplit=1, flags=re.IGNORECASE)
    if len(parts) == 2 and parts[0].strip():
        return parts[0].strip(" ,")
    return subject


def _skip_subject(subject: str) -> bool:
    """Relative and continuation words are not the duty-bearer."""

    key = " ".join(str(subject or "").split()).lower()
    if key in {
        "and",
        "or",
        "nor",
        "but",
        "which",
        "who",
        "that",
        "or which",
        "and which",
        "on",
        "in",
        "at",
        "from",
        "after",
        "before",
        "by",
        "of",
        "for",
        "under",
        "during",
        "to",
    }:
        return True
    if key.startswith(("to which ", "to whom ", "in which ", "for which ", "of which ")):
        return True
    return key.startswith(("until ", "if ", "when ", "where "))


_INTERRUPTED_SHALL_RE = re.compile(
    r"(?P<subject>[A-Z][^.;]{0,400}?),\s+shall\s*,\s*(?P<pre>[^,]+),\s+"
    r"(?P<action>[A-Za-z][^;.]*)",
    re.IGNORECASE,
)


def _occupied(elements: list) -> list[tuple[int, int]]:
    spans = []
    for element in elements:
        span = element.get("support_span") or []
        if isinstance(span, list) and len(span) == 2:
            spans.append((int(span[0]), int(span[1])))
    return spans


def _modal_already_covered(spans: list[tuple[int, int]], start: int) -> bool:
    return any(left <= start < right for left, right in spans)


def _outer_comma_subject(subject: str) -> str:
    """Drop a whenever or except clause glued in front of the real actor."""

    text = re.sub(r",\s+whenever\b.+$", "", subject, flags=re.IGNORECASE).strip()
    text = re.sub(r",\s+except\b.+$", "", text, flags=re.IGNORECASE).strip()
    return text


def _enumerated_power_before(sentence: str, match: re.Match[str]) -> str:
    """``To raise and support Armies, but no Appropriation`` keeps the power."""

    window = sentence[: match.start("subject")] + (match.group("subject") or "")
    found = re.search(
        r"(?P<head>\bTo\s+[A-Za-z]+(?:\s+[A-Za-z]+){1,8})\s*,\s*but\s+no\b",
        window,
        flags=re.IGNORECASE,
    )
    if not found:
        return ""
    return " ".join(found.group("head").split())


def _keep_inhabitant_clause(sentence: str, action_text: str) -> str:
    """Keep ``who shall not, when elected, be an Inhabitant`` in the same duty."""

    match = re.search(r"\b(when elected, be an Inhabitant\b[^.]*)", sentence, re.IGNORECASE)
    if not match or "who shall not" not in action_text.lower():
        return action_text
    rest = match.group(1)
    if rest.lower() in action_text.lower():
        return action_text
    return action_text.rstrip(", ") + ", " + rest


def _keep_compared_clause(sentence: str, action_text: str) -> str:
    """``when compared with`` stays on the action. It is not ``if compared``."""

    match = re.search(
        r"\b(when\s+compared\b(?:\s+(?:with|to|against)\b)?[^.]*)",
        sentence,
        flags=re.IGNORECASE,
    )
    if not match:
        return action_text
    rest = " ".join(match.group(1).split()).rstrip(" ,;:")
    if not rest or rest.lower() in action_text.lower():
        return action_text
    return (action_text.rstrip(" ,") + " " + rest).strip()


def _coordinated_no_head(sentence: str, match: re.Match[str]) -> str:
    """``No Capitation, or other direct, Tax`` is one negated subject, not ``Tax``."""

    found = re.search(
        r"\b(?P<head>no\s+[^.;:]{0,80}?,\s+or\s+[^,;:]{0,60}),\s*$",
        sentence[: match.start("subject")],
        flags=re.IGNORECASE,
    )
    if not found:
        return ""
    return " ".join(found.group("head").split())


def _manner_phrase(sentence: str, match: re.Match[str]) -> str:
    """Keep manner adjuncts on the duty. They are not a second shall."""

    found = re.search(
        r"\bin such manner\b[^.;]*"
        r"|\bin (?:coordination|consultation|conjunction|concert) with\b[^.;]*",
        sentence[match.end() :],
        flags=re.IGNORECASE,
    )
    if not found:
        return ""
    return " ".join(found.group(0).split()).rstrip(" ,")


def _grant_without(sentence: str, match: re.Match[str], deontic_operator: str) -> str:
    """``without apportionment`` modifies a grant. It is not an exception to the grant.

    ``without the consent`` on a prohibition stays an exception and is not appended here.
    """

    if deontic_operator != "O":
        return ""
    found = re.match(
        r"\s*((?:without\s+(?!(?:the\s+)?(?:consent|approval|permission|leave|order|warrant)\b)[^.;]*)+)",
        sentence[match.end() :],
        flags=re.IGNORECASE,
    )
    if not found:
        return ""
    return " ".join(found.group(1).split()).rstrip(" ,")


def _drop_grant_without_exceptions(element: dict) -> None:
    """Do not render a grant-modifying ``without`` as ``unless``."""

    if element.get("deontic_operator") != "O":
        return
    kept = []
    texts = []
    for item in element.get("exception_details") or []:
        if not isinstance(item, dict):
            continue
        text = str(item.get("normalized_text") or item.get("value") or "")
        if str(item.get("clause_type") or "") == "without" and not re.match(
            r"(?:the\s+)?(?:consent|approval|permission|leave|order|warrant)\b",
            text,
            flags=re.IGNORECASE,
        ):
            continue
        kept.append(item)
        if text:
            texts.append(text)
    element["exception_details"] = kept
    element["exceptions"] = texts


def _keep_without_phrase(element: dict) -> None:
    """Keep an affirmative duty's ``without`` phrase on its action/object.

    A prohibition qualified by ``without consent`` has a consent exception.
    Keep that structured exception, and all explicit ``except`` clauses, so
    closed-vocabulary object projection cannot silently discard them.
    """

    withouts: list[str] = []
    kept = []
    texts = []
    prohibition = (
        element.get("norm_type") == "prohibition"
        or element.get("deontic_operator") == "F"
        or element.get("modality") == "F"
    )
    for item in element.get("exception_details") or []:
        if not isinstance(item, dict):
            continue
        kind = str(item.get("clause_type") or "")
        if kind != "without" or prohibition:
            kept.append(item)
            text = str(item.get("normalized_text") or item.get("value") or "")
            if text:
                texts.append(text)
            continue
        body = " ".join(str(item.get("raw_text") or item.get("normalized_text") or item.get("value") or "").split())
        if not body:
            continue
        if not body.lower().startswith(kind + " "):
            body = f"{kind} {body}"
        withouts.append(body)
    if not withouts:
        return
    element["exception_details"] = kept
    element["exceptions"] = texts
    obj = str(element.get("action_object") or "").strip()
    action = " ".join(str(part) for part in (element.get("action") or [])).strip()
    for phrase in withouts:
        if phrase.lower() in obj.lower() or phrase.lower() in action.lower():
            continue
        if obj:
            obj = f"{obj} {phrase}"
        elif action:
            action = f"{action} {phrase}"
        else:
            obj = phrase
    if obj:
        element["action_object"] = obj
    if action:
        element["action"] = [action]


def _colon_object(sentence: str, match: re.Match[str]) -> str:
    """The noun phrase after ``shall appoint:`` is the object, not a new duty.

    A colon before another shall stays a clause break. That text is not appended.
    """

    found = re.match(
        r"\s*:\s*(?P<object>[A-Z].+?)(?=;\s+[A-Za-z]|\.|$)",
        sentence[match.end() :],
        flags=re.DOTALL,
    )
    if not found:
        return ""
    object_text = " ".join(found.group("object").split()).rstrip(" ;")
    if not object_text or re.search(r"\b(?:shall|must|may)\b", object_text, flags=re.IGNORECASE):
        return ""
    return object_text


def _append_elliptical_nor(sentence: str, action_text: str, *, start: int) -> str:
    """``nor in time of war`` continues the same duty when no modal is repeated."""

    found = re.search(
        r"[,;]\s+(?P<tail>nor\s+(?!shall\b|must\b|may\b).+)$",
        sentence[start:],
        flags=re.IGNORECASE,
    )
    if not found:
        return action_text
    tail = " ".join(found.group("tail").split()).rstrip(".")
    if not tail or tail.lower() in action_text.lower():
        return action_text
    return f"{action_text}, {tail}"


def _clause_lead(sentence: str, match: re.Match[str]) -> str:
    """``for any Speech or Debate`` sits before the subject. It is part of that duty."""

    found = _CLAUSE_LEAD_RE.search(sentence[: match.start("subject")])
    if not found:
        return ""
    return " ".join(found.group("lead").split())


def _restore_otherwise(sentence: str, subject: str, match: re.Match[str]) -> str:
    """``otherwise, the President shall resume`` keeps otherwise."""

    if re.search(r"(?:^|[;])\s*otherwise,\s*$", sentence[: match.start("subject")], flags=re.IGNORECASE):
        return f"Otherwise, {subject}"
    return subject


def _flatten_relative_shall(action: str) -> str:
    """A qualification's inner shall is not a second duty.

    ``who shall not have attained`` stays in the same sentence without a modal
    the next compile would treat as another rule.
    """

    text = re.sub(r"\bshall\s+not\s+have\s+attained\b", "has not attained", action, flags=re.IGNORECASE)
    text = re.sub(
        r"\bshall\s+not\s*,\s*when\s+elected\s*,\s*be\b",
        "when elected, is not",
        text,
        flags=re.IGNORECASE,
    )
    text = re.sub(r"\b(he|she)\s+shall\s+be\b", r"\1 is", text, flags=re.IGNORECASE)
    text = re.sub(r"\b(who|which|that)\s+shall\s+not\b", r"\1 has not", text, flags=re.IGNORECASE)
    text = re.sub(r"\b(who|which|that)\s+shall\b", r"\1", text, flags=re.IGNORECASE)
    return text


def _as_follows_tail(sentence: str, match: re.Match[str]) -> str:
    """``be elected, as follows`` introduces the next clause. The words stay here."""

    if re.match(r"\s*,?\s*as\s+follows\b", sentence[match.end() :], flags=re.IGNORECASE):
        return "as follows"
    return ""


def _restore_provided_that(sentence: str, subject: str, match: re.Match[str]) -> str:
    """``Provided, That the legislature`` keeps Provided. It is not only ``That``."""

    if not re.match(r"that\b", subject or "", flags=re.IGNORECASE):
        return subject
    if re.search(r"provided,\s*$", sentence[: match.start("subject")], flags=re.IGNORECASE):
        return f"Provided, {subject}"
    return subject


def _expand_infinitive_subject(sentence: str, subject: str, match: re.Match[str]) -> str:
    """``the right of citizens ... to vote`` is the subject, not the bare infinitive.

    A subject that would swallow an earlier shall is left alone.
    """

    if not _INFINITIVE_SUBJECT_RE.match(subject or ""):
        return subject
    window = sentence[: match.end("subject")]
    expanded = re.search(
        r"(?P<full>(?:the|a|an)\s+.+?\s+" + re.escape(subject) + r")\s*$",
        window,
        flags=re.IGNORECASE | re.DOTALL,
    )
    if not expanded:
        return subject
    full = " ".join(expanded.group("full").split())
    if re.search(r"\b(?:shall|must|may)\b", full, flags=re.IGNORECASE):
        return subject
    return full


def _attach_leading_case(element: dict, sentence: str, match: re.Match[str]) -> None:
    """``In all Cases affecting Ambassadors`` governs the later shall. It is not dropped."""

    prefix = " ".join(sentence[: match.start("subject")].strip(" ,;").split())
    if not prefix or not _LEADING_CASE_RE.match(prefix):
        return
    blob = " ".join(str(part) for part in element.get("action") or []).casefold()
    if prefix.casefold() in blob:
        return
    detail = {
        "type": "condition",
        "clause_type": "when",
        "raw_text": prefix,
        "normalized_text": prefix.lower(),
        "value": prefix.lower(),
        "span": [0, match.start("subject")],
        "clause_span": [0, match.start("subject")],
    }
    element["condition_details"] = list(element.get("condition_details") or []) + [detail]
    element["conditions"] = list(element.get("conditions") or []) + [prefix.lower()]


def _restore_interrupted_action(
    sentence: str,
    action_text: str,
    *,
    span: tuple[int, int] | None = None,
) -> str:
    """Put the verb back when a parenthetical except/without sat in front of it.

    The repair belongs to the clause that contains the interrupter. A later
    shall does not inherit that verb.
    """

    match = _PAREN_INTERRUPTER_RE.search(sentence) or _SHALL_COMMA_VERB_RE.search(sentence)
    if not match:
        return action_text
    if span is not None and not (span[0] <= match.start() < span[1]):
        return action_text
    rest = _clean_phrase(match.group("rest"))
    pre = _clean_phrase(match.group("pre"))
    if not rest or rest.lower() in action_text.lower():
        return action_text
    combined = f"{pre} {rest}".strip() if pre else rest
    return _clean_action(combined)


def _clean_action(value: str) -> str:
    text = re.sub(r"\s+", " ", str(value or "")).strip(" ,;:")
    text = _TRAILING_NOISE_RE.sub("", text).strip()
    return text


def _looks_like_past_participle(word: str) -> bool:
    """True for verbal participles. Status adjectives stay copular complements."""

    token = str(word or "").lower()
    if not token or token in _COPULA_STATUS_COMPLEMENTS:
        return False
    if token in _PAST_PARTICIPLE_BASE or token in _IRREGULAR_PARTICIPLES:
        return True
    return len(token) > 4 and token.endswith(("ed", "en"))


def _copular_passive_verb(action: str) -> str:
    """Return ``be {participle}`` for copular passives such as ``be fulfilled``."""

    match = _COPULA_PASSIVE_RE.match(_action_without_mental_state(action) or "")
    if not match:
        return ""
    head = match.group("head").lower()
    if not _looks_like_past_participle(head):
        return ""
    particle = str(match.group("particle") or "").lower()
    return f"be {head} {particle}".strip() if particle else f"be {head}"


def _first_verb(action: str) -> str:
    copular = _copular_passive_verb(action)
    if copular:
        return copular
    words = re.findall(r"[A-Za-z][A-Za-z0-9'’\-]*", _action_without_mental_state(action) or "")
    return words[0].lower() if words else ""


# A duration numeral is kept only when a unit already follows it in the text.
# An ordinal already written in the token (12th) stays whole. Other
# digit-leading tokens stay dropped, so a missing numeral is not invented.
_OBJECT_TOKEN_RE = re.compile(
    r"\d+(?=\s+(?:(?:business|calendar)\s+)?(?:days?|weeks?|months?|years?)\b)"
    r"|\d+(?:st|nd|rd|th)\b"
    r"|\d+d\b"
    r"|[A-Za-z][A-Za-z0-9'’\-]*"
)


def _action_object(action: str) -> str:
    words = _OBJECT_TOKEN_RE.findall(_action_without_mental_state(action) or "")
    verb_words = _OBJECT_TOKEN_RE.findall(_first_verb(action) or "")
    skip = len(verb_words)
    if skip and [word.lower() for word in words[:skip]] != [word.lower() for word in verb_words]:
        skip = 1 if words else 0
    elif not skip:
        skip = 1 if words else 0
    return " ".join(words[skip:]).strip() if len(words) > skip else ""


def _mental_state(action: str) -> str:
    complex_split = _split_leading_complex_mental_state(action)
    if complex_split[0]:
        return complex_split[0].lower()
    words = re.findall(r"[A-Za-z][A-Za-z0-9'’\-]*", action or "")
    if words and words[0].lower() in _MENTAL_STATE_TERMS:
        return words[0].lower()
    return ""


def _action_without_mental_state(action: str) -> str:
    complex_split = _split_leading_complex_mental_state(action)
    if complex_split[0]:
        return complex_split[1]
    words = re.findall(r"[A-Za-z][A-Za-z0-9'’\-]*", action or "")
    if words and words[0].lower() in _MENTAL_STATE_TERMS:
        return " ".join(words[1:]).strip()
    return action


def _split_leading_complex_mental_state(action: str) -> tuple[str, str]:
    text = str(action or "").strip()
    match = _LEADING_COMPLEX_MENTAL_STATE_RE.match(text)
    if not match:
        match = _LEADING_COMPOUND_MENTAL_STATE_RE.match(text)
    if not match:
        return ("", "")
    state = _clean_phrase(match.group("state")).lower()
    operative_action = _clean_phrase(match.group("action"))
    if not state or not operative_action:
        return ("", "")
    return (state, operative_action)


def _normalize_passive_clause(subject_text: str, action_text: str) -> tuple[str, str]:
    match = _PASSIVE_BY_RE.match(action_text or "")
    if not match:
        return subject_text, action_text
    participle = match.group(1).lower()
    agent = _clean_phrase(match.group(2))
    verb = _PAST_PARTICIPLE_BASE.get(participle)
    if not verb:
        return subject_text, action_text
    object_text = _clean_phrase(subject_text)
    normalized_action = f"{verb} {object_text}".strip()
    return agent or subject_text, normalized_action


def classify_legal_entity(text: str) -> str:
    """Return a coarse actor/entity type for KG and frame-logic scaffolds."""
    normalized = re.sub(r"[^A-Za-z0-9\s]", " ", str(text or "").lower())
    tokens = set(normalized.split())
    if not tokens:
        return "unknown"
    if tokens & _GOVERNMENT_ACTORS:
        return "government_actor"
    if tokens & _ORGANIZATION_ACTORS:
        return "organization"
    if tokens & _LEGAL_PERSON_ACTORS:
        return "legal_person"
    if tokens & _LEGAL_INSTRUMENT_ENTITIES:
        return "legal_instrument"
    if tokens & _LEGAL_EVENT_ENTITIES:
        return "legal_event"
    if tokens & _PROPERTY_ENTITIES:
        return "regulated_property"
    if any(token.endswith("office") or token.endswith("board") for token in tokens):
        return "government_actor"
    return "legal_entity"


def extract_action_recipient(action: str) -> str:
    """Extract a likely beneficiary/recipient from an action phrase."""
    passive_match = _PASSIVE_BENEFIT_RECIPIENT_RE.search(str(action or "").strip())
    if passive_match:
        recipient = _clean_passive_benefit_recipient(passive_match.group(1))
        if recipient:
            return recipient

    match = _RECIPIENT_RE.search(str(action or "").strip())
    if not match:
        return ""
    if not _RECIPIENT_TRANSFER_RE.search(str(action or "")[: match.start()]):
        return ""
    raw_recipient = match.group(1).strip()
    head = _LEADING_DETERMINERS_RE.sub("", raw_recipient).split()
    head = head[0].lower() if head else ""
    if head in _NOT_RECIPIENT_HEAD:
        return ""
    recipient = _clean_phrase(raw_recipient)
    if recipient.lower() in {
        "law",
        "regulation",
        "section",
        "chapter",
        "title",
        "this section",
        "this chapter",
        "this title",
    }:
        return ""
    return recipient


def _clean_passive_benefit_recipient(value: str) -> str:
    """Return the beneficiary of passive grant phrases without trailing joins."""

    recipient = _clean_phrase(value)
    recipient = re.sub(r"\s*,?\s+(?:and|or)\s*$", "", recipient, flags=re.IGNORECASE)
    return recipient.strip(" ,.;:")


def extract_definition_body(sentence: str) -> str:
    match = _DEFINITION_BODY_RE.search(str(sentence or "").strip())
    if not match:
        return ""
    return match.group(1).strip(" .;:")


def score_scaffold_quality(element: Dict[str, Any]) -> Dict[str, Any]:
    """Score whether a deterministic parse is safe to promote without LLM repair."""
    warnings: List[str] = []
    norm_type = element.get("norm_type")
    subjects = [item for item in element.get("subject", []) if item]
    actions = [item for item in element.get("action", []) if item]
    action_text = actions[0] if actions else ""

    required_slots = ["deontic_operator", "subject", "action"]
    if norm_type == "definition":
        required_slots = ["defined_term", "definition_body"]
    elif norm_type == "purpose":
        required_slots = ["subject", "action"]

    filled_slots = 0
    for slot in required_slots:
        value = element.get(slot)
        if slot == "subject":
            value = subjects
        elif slot == "action":
            value = actions
        if value:
            filled_slots += 1
        else:
            warnings.append(f"missing_{slot}")

    slot_coverage = filled_slots / len(required_slots) if required_slots else 0.0
    score = 0.25 + (0.55 * slot_coverage)

    if element.get("conditions"):
        score += 0.04
    if element.get("temporal_constraints"):
        score += 0.04
    if element.get("action_recipient"):
        score += 0.03
    if element.get("actor_type") in {"government_actor", "legal_person", "organization"}:
        score += 0.03

    if element.get("enumerated_items"):
        warnings.append("enumerated_clause_requires_item_level_review")
        score -= 0.10
    if _unresolved_cross_references(element):
        warnings.append("cross_reference_requires_resolution")
        score -= 0.04
    if element.get("conflict_links"):
        warnings.append("normative_conflict_requires_resolution")
        score -= 0.12
    if element.get("exceptions"):
        warnings.append("exception_requires_scope_review")
        score -= 0.05
    if element.get("override_clauses"):
        warnings.append("override_clause_requires_precedence_review")
        score -= 0.05
    if (element.get("legal_frame") or {}).get("category") == "penalty" and not element.get(
        "penalty"
    ):
        warnings.append("penalty_requires_amount_or_sanction_review")
        score -= 0.05
    if (element.get("legal_frame") or {}).get("category") == "procedure" and element.get(
        "temporal_constraints"
    ):
        warnings.append("procedure_timeline_requires_event_order_review")
        score -= 0.04
    if norm_type != "purpose" and len(re.findall(r"[A-Za-z][A-Za-z0-9'’\-]*", action_text)) > 18:
        warnings.append("overlong_action_span")
        score -= 0.10
    if norm_type == "definition" and not element.get("defined_term"):
        warnings.append("definition_term_uncertain")
        score -= 0.10

    score = max(0.0, min(score, 0.95))
    # Promotion here means "safe to use as a deterministic theorem scaffold
    # without LLM repair"; any warning should keep it in the review lane.
    promotable = score >= 0.70 and not warnings
    if score >= 0.75:
        label = "high"
    elif score >= 0.50:
        label = "medium"
    else:
        label = "low"

    return {
        "score": round(score, 3),
        "label": label,
        "slot_coverage": round(slot_coverage, 3),
        "warnings": warnings,
        "promotable_to_theorem": promotable,
    }


def extract_legal_subject(sentence: str) -> List[str]:
    subjects: List[str] = []

    subject_patterns = [
        r"\b(?:citizens?|residents?|persons?|individuals?|people)\b",
        r"\b(?:companies?|corporations?|businesses?|entities?)\b",
        r"\b(?:developers?|operators?|providers?|controllers?|processors?)\b",
        r"\b(?:systems?|services?|platforms?|applications?|software)\b",
        r"\b(?:employees?|workers?|staff)\b",
        r"\b(?:drivers?|operators?|users?)\b",
        r"\b(?:owners?|lessees?|tenants?)\b",
        r"\b(?:students?|minors?|adults?)\b",
        r"\b(?:patients?|clients?|customers?)\b",
    ]

    for pattern in subject_patterns:
        subjects.extend(re.findall(pattern, sentence.lower()))

    capitalized_words = re.findall(r"\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\b", sentence)
    subjects.extend(capitalized_words[:2])

    acronyms = re.findall(r"\b[A-Z]{2,}\b", sentence)
    subjects.extend(acronyms[:2])
    acronym_phrases = re.findall(r"\b[A-Z]{2,}\s+[a-z]+(?:\s+[a-z]+)*\b", sentence)
    subjects.extend(acronym_phrases[:2])

    return list(set(subjects))


def extract_legal_action(sentence: str) -> List[str]:
    actions: List[str] = []

    modal_verb_pattern = r"(?:must|shall|may|can|cannot|must not|shall not)\s+(?:not\s+)?(\w+(?:\s+\w+)*?)(?:\s+(?:by|before|after|until|unless|except)|\.|$)"
    actions.extend([m.strip() for m in re.findall(modal_verb_pattern, sentence.lower())])

    prohibited_pattern = r"(?:prohibited from|prohibited to|forbidden to)\s+([^.]+?)(?:\s+(?:by|before|after|until|unless|except)|\.|$)"
    actions.extend([m.strip() for m in re.findall(prohibited_pattern, sentence.lower())])

    legal_action_patterns = [
        r"\b(?:pay|file|submit|provide|deliver|execute|perform)\s+([^.]+?)(?:\s+(?:by|before|after)|\.|$)",
        r"\b(?:comply with|adhere to|follow|observe)\s+([^.]+?)(?:\s+(?:by|before|after)|\.|$)",
        r"\b(?:obtain|acquire|secure|maintain)\s+([^.]+?)(?:\s+(?:by|before|after)|\.|$)",
    ]
    for pattern in legal_action_patterns:
        actions.extend([m.strip() for m in re.findall(pattern, sentence.lower())])

    return list(set(actions))


def extract_conditions(sentence: str) -> List[str]:
    return [item["normalized_text"] for item in extract_condition_details(sentence)]


def _is_qualification_when(sentence: str, item: Dict[str, Any]) -> bool:
    """``who ... when elected`` stays on the qualification. It is not ``if elected``."""

    if str(item.get("clause_type") or "") != "when":
        return False
    span = item.get("clause_span") or item.get("span") or []
    if not isinstance(span, (list, tuple)) or len(span) != 2:
        return False
    start = int(span[0])
    if not re.match(r"when\s+elected\b", sentence[start:], flags=re.IGNORECASE):
        return False
    prefix = sentence[:start]
    return bool(
        re.search(r"\b(?:shall|must|may)\b", prefix, flags=re.IGNORECASE)
        and re.search(r"\b(?:who|which|that)\b", prefix, flags=re.IGNORECASE)
    )


def _is_comparative_when(sentence: str, item: Dict[str, Any]) -> bool:
    """``when compared with`` qualifies the action. It is not ``if compared``."""

    if str(item.get("clause_type") or "") != "when":
        return False
    body = str(item.get("normalized_text") or item.get("raw_text") or item.get("value") or "")
    if re.match(r"(?:when\s+)?compared\b", body, flags=re.IGNORECASE):
        return True
    span = item.get("clause_span") or item.get("span") or []
    if not isinstance(span, (list, tuple)) or len(span) != 2:
        return False
    start = int(span[0])
    return bool(re.match(r"when\s+compared\b", sentence[start:], flags=re.IGNORECASE))


def extract_condition_details(sentence: str) -> List[Dict[str, Any]]:
    details = _extract_clause_details(sentence, _CONDITION_PATTERNS, "condition")
    return [
        item
        for item in details
        if not _is_qualification_when(sentence, item) and not _is_comparative_when(sentence, item)
    ]


def extract_override_clauses(sentence: str) -> List[str]:
    return [item["normalized_text"] for item in extract_override_clause_details(sentence)]


def extract_override_clause_details(sentence: str) -> List[Dict[str, Any]]:
    return _extract_clause_details(sentence, _OVERRIDE_PATTERNS, "override")


def extract_cross_references(sentence: str) -> List[Dict[str, str]]:
    return [
        {"type": item["type"], "value": item["value"]}
        for item in extract_cross_reference_details(sentence)
    ]


def extract_cross_reference_details(sentence: str) -> List[Dict[str, Any]]:
    refs: List[Dict[str, Any]] = []
    patterns = [
        (
            "section_range",
            r"\bsections?\s+([0-9][0-9A-Za-z.\-]*(?:\([a-z0-9]+\))*)\s+(?:through|thru|to|-)\s+([0-9][0-9A-Za-z.\-]*(?:\([a-z0-9]+\))*)",
        ),
        ("section", r"\bsection\s+([0-9][0-9A-Za-z.\-]*(?:\([a-z0-9]+\))*)"),
        ("section", r"§\s*([0-9][0-9A-Za-z.\-]*(?:\([a-z0-9]+\))*)"),
        ("section", r"\b(this\s+section)\b"),
        ("subsection", r"\bsubsection\s+((?:\([A-Za-z0-9]+\))+)"),
        ("subsection", r"\b(this\s+subsection)\b"),
        ("paragraph", r"\bparagraph\s+((?:\([A-Za-z0-9]+\))+)"),
        ("paragraph", r"\b(this\s+paragraph)\b"),
        ("subparagraph", r"\bsubparagraph\s+((?:\([A-Za-z0-9]+\))+)") ,
        ("clause", r"\bclause\s+((?:\([A-Za-z0-9]+\))+)"),
        ("chapter", r"\bchapter\s+([0-9A-Za-z][0-9A-Za-z.\-]*)"),
        ("chapter", r"\b(this\s+chapter)\b"),
        ("title", r"\btitle\s+([0-9A-Za-z]+)"),
        ("title", r"\b(this\s+title)\b"),
        ("usc", r"\b(\d+)\s+u\.?s\.?c\.?\s+(?:§|sec(?:tion)?\.?)?\s*([0-9A-Za-z.\-]+)"),
    ]
    seen: set[tuple[str, str]] = set()
    for ref_type, pattern in patterns:
        for match in re.finditer(pattern, sentence, flags=re.IGNORECASE):
            if _is_definition_scope_marker(sentence, match):
                continue
            if ref_type == "section_range":
                start_section = str(match.group(1) or "").strip().lower()
                end_section = str(match.group(2) or "").strip().lower()
                value = f"{start_section}-{end_section}"
            elif len(match.groups()) > 1:
                value = " ".join(part for part in match.groups() if part).strip().lower()
            else:
                value = str(match.group(1) or "").strip().lower()
            if re.fullmatch(r"\([a-z0-9]+\)", value):
                value = value[1:-1]
            if not value:
                continue
            key = (ref_type, value)
            if key in seen:
                continue
            seen.add(key)
            refs.append(
                {
                    "type": ref_type,
                    "value": value,
                    "raw_text": match.group(0).strip(),
                    "normalized_text": f"{ref_type} {value}",
                    "span": [match.start(), match.end()],
                }
            )
            if ref_type == "section_range":
                refs[-1]["start_section"] = start_section
                refs[-1]["end_section"] = end_section
    return refs


def _is_definition_scope_marker(sentence: str, match: re.Match[str]) -> bool:
    raw = match.group(0).lower()
    if not raw.startswith("this "):
        return False
    prefix = str(sentence or "")[: match.start()].lower()
    return bool(re.search(r"(?:\bin\s+|\bfor\s+purposes\s+of\s+)$", prefix))


def extract_enumerated_items(sentence: str) -> List[Dict[str, str]]:
    items: List[Dict[str, str]] = []
    matches = list(re.finditer(r"(?:^|\s)\(([A-Za-z0-9]+)\)\s+", sentence))
    for index, match in enumerate(matches):
        start = match.end()
        end = matches[index + 1].start() if index + 1 < len(matches) else len(sentence)
        text = sentence[start:end].strip(" ;,.")
        text = re.sub(r"\s+(?:and|or)$", "", text, flags=re.IGNORECASE).strip(" ;,.")
        if text:
            items.append({"label": match.group(1), "text": text})
    return items


def extract_temporal_constraints(sentence: str) -> List[Dict[str, str]]:
    return [
        {"type": item["type"], "value": item["value"]}
        for item in extract_temporal_constraint_details(sentence)
    ]


def extract_temporal_constraint_details(sentence: str) -> List[Dict[str, Any]]:
    details: List[Dict[str, Any]] = []
    seen: set[tuple[str, str, int, int]] = set()
    for constraint_type, temporal_kind, pattern in _TEMPORAL_PATTERNS:
        for match in re.finditer(pattern, sentence, flags=re.IGNORECASE):
            value = match.group(1).strip().lower()
            anchor = ""
            if " after " in value:
                value_part, anchor_part = value.split(" after ", 1)
                anchor = anchor_part.strip()
                value = f"{value_part.strip()} after {anchor}"
            display = value
            if temporal_kind == "within_duration" and not display.startswith("within "):
                display = f"within {display}"
            elif temporal_kind == "on_date" and not display.startswith("on "):
                display = f"on {display}"
            key = (constraint_type, display, match.start(), match.end())
            if key in seen:
                continue
            seen.add(key)
            details.append(
                {
                    "type": constraint_type,
                    "temporal_kind": temporal_kind,
                    "value": display,
                    "anchor": anchor,
                    **normalize_temporal_value(value),
                    "raw_text": match.group(0).strip(),
                    "normalized_text": display,
                    "span": [match.start(), match.end()],
                }
            )
    containers: list[tuple[int, int]] = []
    for item in extract_condition_details(sentence) + extract_exception_details(sentence):
        span = item.get("clause_span") or item.get("span") or []
        if isinstance(span, (list, tuple)) and len(span) == 2:
            containers.append((int(span[0]), int(span[1])))
    if not containers:
        return details
    kept: list[dict[str, Any]] = []
    for item in details:
        span = item.get("span") or []
        if not isinstance(span, (list, tuple)) or len(span) != 2:
            kept.append(item)
            continue
        start, end = int(span[0]), int(span[1])
        if any(left <= start and end <= right for left, right in containers):
            continue
        kept.append(item)
    return kept


def normalize_temporal_value(value: str) -> Dict[str, Any]:
    """Normalize a temporal phrase into atoms useful for temporal logic export."""
    normalized = str(value or "").strip().lower()
    duration = normalized.split(" after ", 1)[0].split(" before ", 1)[0].strip()
    match = re.match(
        r"(?P<quantity>\d+)\s+(?:(?P<calendar>business|calendar)\s+)?(?P<unit>days?|weeks?|months?|years?)\b",
        duration,
    )
    anchor_event = ""
    direction = ""
    if " after " in normalized:
        anchor_event = normalized.split(" after ", 1)[1].strip()
        direction = "after"
    elif " before " in normalized:
        anchor_event = normalized.split(" before ", 1)[1].strip()
        direction = "before"
    if not match:
        return {
            "quantity": None,
            "unit": "",
            "calendar": "",
            "anchor_event": anchor_event,
            "direction": direction,
        }
    return {
        "quantity": int(match.group("quantity")),
        "unit": match.group("unit").rstrip("s"),
        "calendar": match.group("calendar") or "calendar",
        "anchor_event": anchor_event,
        "direction": direction,
    }


def extract_exceptions(sentence: str) -> List[str]:
    return [item["normalized_text"] for item in extract_exception_details(sentence)]


def extract_exception_details(sentence: str) -> List[Dict[str, Any]]:
    return _extract_clause_details(sentence, _EXCEPTION_PATTERNS, "exception")


def _extract_clause_details(
    sentence: str,
    patterns: List[tuple[str, str]],
    slot_type: str,
) -> List[Dict[str, Any]]:
    details: List[Dict[str, Any]] = []
    seen: set[tuple[str, str, int, int]] = set()
    for clause_type, pattern in patterns:
        for match in re.finditer(pattern, sentence, flags=re.IGNORECASE):
            value = match.group(1).strip()
            end = match.end(1)
            start = match.start(1)
            if match.start() > 0 and sentence[match.start() - 1] == "(":
                paren = value.find(")")
                if paren >= 0:
                    value = value[:paren].strip()
                    end = start + paren
            normalized = value.lower()
            key = (clause_type, normalized, start, end)
            if key in seen:
                continue
            seen.add(key)
            details.append(
                {
                    "type": slot_type,
                    "clause_type": clause_type,
                    "raw_text": value,
                    "normalized_text": normalized,
                    "span": [start, end],
                    "clause_span": [match.start(), match.end()],
                }
            )
    return details


def build_formal_logic_record(element: Dict[str, Any]) -> Dict[str, Any]:
    """Build a single parquet-friendly row for formal-logic/proof pipelines."""
    source_id = element.get("source_id") or build_source_id(element)
    formula = build_deontic_formula(element)
    identity = {
        "source_id": source_id,
        "formula": formula,
        "schema": PARSER_SCHEMA_VERSION,
    }
    formula_hash = hashlib.sha256(
        json.dumps(identity, sort_keys=True, default=str).encode("utf-8")
    ).hexdigest()
    readiness = element.get("export_readiness") or build_export_readiness(element)
    return {
        "formula_id": f"formula:{formula_hash[:24]}",
        "source_id": source_id,
        "canonical_citation": element.get("canonical_citation", ""),
        "schema_version": PARSER_SCHEMA_VERSION,
        "logic_family": "deontic",
        "formula": formula,
        "formal_terms": element.get("formal_terms", {}),
        "logic_frame": element.get("logic_frame", {}),
        "legal_frame": element.get("legal_frame", {}),
        "proof_candidate": bool(readiness.get("proof_ready")),
        "formal_logic_targets": readiness.get("formal_logic_targets", []),
        "requires_validation": readiness.get("requires_validation", []),
        "parser_warnings": element.get("parser_warnings", []),
        "conflict_links": element.get("conflict_links", []),
        "enforcement_links": element.get("enforcement_links", []),
        "provenance": {
            "text": element.get("text", ""),
            "source_span": element.get("source_span", []),
            "support_text": element.get("support_text", ""),
            "support_span": element.get("support_span", []),
        },
    }


def build_procedure_event_records(element: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Flatten procedure event chains into event-calculus friendly rows."""
    procedure = element.get("procedure") or {}
    event_chain = procedure.get("event_chain") or []
    records: List[Dict[str, Any]] = []
    source_id = element.get("source_id") or build_source_id(element)
    temporal_details = element.get("temporal_constraint_details") or []
    for item in event_chain:
        event = item.get("event", "")
        order = item.get("order", 0)
        relations = item.get("relations") or []
        identity = {
            "source_id": source_id,
            "event": event,
            "order": order,
        }
        event_hash = hashlib.sha256(
            json.dumps(identity, sort_keys=True, default=str).encode("utf-8")
        ).hexdigest()
        anchors = [
            detail
            for detail in temporal_details
            if detail.get("anchor_event") == event or detail.get("anchor") == event
        ]
        records.append(
            {
                "event_id": f"event:{event_hash[:24]}",
                "source_id": source_id,
                "canonical_citation": element.get("canonical_citation", ""),
                "event": event,
                "event_symbol": normalize_predicate_name(event),
                "event_order": order,
                "is_trigger": event == procedure.get("trigger_event"),
                "is_terminal": event == procedure.get("terminal_event"),
                "event_mentions": item.get("mentions", []),
                "event_relations": relations,
                "relation_types": [relation.get("relation", "") for relation in relations],
                "anchor_events": [
                    relation.get("anchor_event", "")
                    for relation in relations
                    if relation.get("anchor_event")
                ],
                "temporal_anchors": anchors,
                "actor_id": (element.get("formal_terms") or {}).get("actor_id", ""),
                "action_predicate": (element.get("formal_terms") or {}).get("action_predicate", ""),
                "provenance": {
                    "text": element.get("text", ""),
                    "source_span": element.get("source_span", []),
                },
            }
        )
    return records


def build_proof_obligation_record(element: Dict[str, Any]) -> Dict[str, Any]:
    """Build a deterministic proof-queue row for theorem/proof backends."""
    formal_record = build_formal_logic_record(element)
    readiness = element.get("export_readiness") or build_export_readiness(element)
    identity = {
        "source_id": formal_record["source_id"],
        "formula_id": formal_record["formula_id"],
        "schema": PARSER_SCHEMA_VERSION,
    }
    proof_hash = hashlib.sha256(
        json.dumps(identity, sort_keys=True, default=str).encode("utf-8")
    ).hexdigest()
    proof_systems = ["deontic_tableau", "fol_resolution", "frame_logic"]
    if "temporal_logic" in readiness.get("formal_logic_targets", []):
        proof_systems.extend(["temporal_logic", "event_calculus"])
    return {
        "proof_obligation_id": f"proof:{proof_hash[:24]}",
        "source_id": formal_record["source_id"],
        "formula_id": formal_record["formula_id"],
        "canonical_citation": formal_record["canonical_citation"],
        "formula": formal_record["formula"],
        "proof_candidate": formal_record["proof_candidate"],
        "proof_systems": proof_systems,
        "blocked": not formal_record["proof_candidate"],
        "blockers": readiness.get("blockers", []),
        "requires_validation": readiness.get("requires_validation", []),
        "conflict_links": element.get("conflict_links", []),
        "enforcement_links": element.get("enforcement_links", []),
        "provenance": formal_record["provenance"],
    }


def build_clause_records(element: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Flatten conditions/exceptions/overrides into parquet-friendly clause rows."""
    records: List[Dict[str, Any]] = []
    source_id = element.get("source_id") or build_source_id(element)
    clause_groups = [
        ("condition", element.get("condition_details") or []),
        ("exception", element.get("exception_details") or []),
        ("override", element.get("override_clause_details") or []),
    ]
    for slot_type, clauses in clause_groups:
        for index, clause in enumerate(clauses):
            text = clause.get("normalized_text") or clause.get("raw_text", "")
            identity = {
                "source_id": source_id,
                "slot_type": slot_type,
                "index": index,
                "text": text,
                "span": clause.get("span", []),
            }
            clause_hash = hashlib.sha256(
                json.dumps(identity, sort_keys=True, default=str).encode("utf-8")
            ).hexdigest()
            records.append(
                {
                    "clause_id": f"clause:{clause_hash[:24]}",
                    "source_id": source_id,
                    "canonical_citation": element.get("canonical_citation", ""),
                    "slot_type": slot_type,
                    "clause_type": clause.get("clause_type", ""),
                    "raw_text": clause.get("raw_text", ""),
                    "normalized_text": text,
                    "predicate": normalize_predicate_name(text),
                    "span": clause.get("span", []),
                    "clause_span": clause.get("clause_span", []),
                    "effect": {
                        "condition": "antecedent",
                        "exception": "negated_antecedent",
                        "override": "precedence_modifier",
                    }.get(slot_type, "modifier"),
                    "provenance": {
                        "text": element.get("text", ""),
                        "source_span": element.get("source_span", []),
                    },
                }
            )
    return records


def build_reference_records(element: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Flatten cross-reference resolution into citation graph rows."""
    records: List[Dict[str, Any]] = []
    source_id = element.get("source_id") or build_source_id(element)
    refs = element.get("resolved_cross_references") or element.get("cross_reference_details") or []
    for index, ref in enumerate(refs):
        target_sections = ref.get("target_sections") or []
        if target_sections:
            targets = target_sections
        else:
            targets = [
                {
                    "section": ref.get("target_section", ""),
                    "heading": ref.get("target_heading", ""),
                    "hierarchy_path": ref.get("target_hierarchy_path", []),
                }
            ]
        for target_index, target in enumerate(targets):
            target_section = target.get("section", "") if isinstance(target, dict) else ""
            identity = {
                "source_id": source_id,
                "index": index,
                "target_index": target_index,
                "type": ref.get("type", ""),
                "value": ref.get("value", ""),
                "target_section": target_section,
            }
            ref_hash = hashlib.sha256(
                json.dumps(identity, sort_keys=True, default=str).encode("utf-8")
            ).hexdigest()
            records.append(
                {
                    "reference_id": f"ref:{ref_hash[:24]}",
                    "source_id": source_id,
                    "canonical_citation": element.get("canonical_citation", ""),
                    "reference_type": ref.get("type", ""),
                    "reference_value": ref.get("value", ""),
                    "raw_text": ref.get("raw_text", ""),
                    "normalized_text": ref.get("normalized_text", ""),
                    "resolution_status": ref.get("resolution_status", "unresolved"),
                    "target_exists": bool(ref.get("target_exists")),
                    "target_section": target_section,
                    "target_heading": target.get("heading", "") if isinstance(target, dict) else "",
                    "target_hierarchy_path": target.get("hierarchy_path", [])
                    if isinstance(target, dict)
                    else [],
                    "span": ref.get("span", []),
                    "provenance": {
                        "text": element.get("text", ""),
                        "source_span": element.get("source_span", []),
                    },
                }
            )
    return records


def build_sanction_records(element: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Flatten penalty details into sanction rows for proof/certificate layers."""
    penalty = element.get("penalty") or {}
    if not penalty:
        return []
    source_id = element.get("source_id") or build_source_id(element)
    records: List[Dict[str, Any]] = []

    def add_record(sanction_type: str, detail: Dict[str, Any], role: str = "") -> None:
        identity = {
            "source_id": source_id,
            "sanction_type": sanction_type,
            "role": role,
            "detail": detail,
        }
        sanction_hash = hashlib.sha256(
            json.dumps(identity, sort_keys=True, default=str).encode("utf-8")
        ).hexdigest()
        records.append(
            {
                "sanction_id": f"sanction:{sanction_hash[:24]}",
                "source_id": source_id,
                "canonical_citation": element.get("canonical_citation", ""),
                "sanction_type": sanction_type,
                "role": role,
                "detail": detail,
                "sanction_class": penalty.get("sanction_class", ""),
                "sanction_modality": penalty.get("sanction_modality", ""),
                "recurrence": penalty.get("recurrence", {}),
                "has_range": bool(penalty.get("has_range")),
                "enforcement_links": element.get("enforcement_links", []),
                "provenance": {
                    "text": element.get("text", ""),
                    "source_span": element.get("source_span", []),
                },
            }
        )

    seen_amounts: set[tuple[str, str, str]] = set()
    for amount in penalty.get("monetary_amount_details") or []:
        amount_key = (
            str(amount.get("raw_text", "")),
            str(amount.get("numeric_value", "")),
            str(amount.get("currency", "")),
        )
        if amount_key in seen_amounts:
            continue
        seen_amounts.add(amount_key)
        add_record("fine", amount, "amount")
    if penalty.get("minimum_amount"):
        add_record("fine", penalty["minimum_amount"], "minimum")
    if penalty.get("maximum_amount"):
        add_record("fine", penalty["maximum_amount"], "maximum")
    if penalty.get("imprisonment_duration"):
        add_record("imprisonment", penalty["imprisonment_duration"], "duration")
    if penalty.get("recurrence"):
        add_record("recurrence", penalty["recurrence"], "recurrence")
    return records


def build_ontology_entity_records(element: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Flatten ontology terms into entity rows for KG/entity parquet tables."""
    source_id = element.get("source_id") or build_source_id(element)
    records: List[Dict[str, Any]] = []
    seen: set[tuple[str, str, tuple[int, ...]]] = set()
    for term in element.get("ontology_terms") or []:
        value = str(term.get("term", ""))
        entity_type = str(term.get("type", ""))
        span = tuple(term.get("span") or [])
        key = (value.lower(), entity_type, span)
        if key in seen:
            continue
        seen.add(key)
        identity = {
            "source_id": source_id,
            "entity": value,
            "type": entity_type,
            "span": list(span),
        }
        entity_hash = hashlib.sha256(
            json.dumps(identity, sort_keys=True, default=str).encode("utf-8")
        ).hexdigest()
        records.append(
            {
                "entity_id": f"entity:{entity_hash[:24]}",
                "source_id": source_id,
                "canonical_citation": element.get("canonical_citation", ""),
                "term": value,
                "term_id": normalize_symbol(value),
                "entity_type": entity_type,
                "definition_body": term.get("definition_body", ""),
                "span": list(span),
                "provenance": {
                    "text": element.get("text", ""),
                    "source_span": element.get("source_span", []),
                },
            }
        )
    return records


def build_repair_queue_record(element: Dict[str, Any]) -> Dict[str, Any]:
    """Build a deterministic llm_router repair queue row when repair is needed."""
    repair = element.get("llm_repair") or build_llm_repair_payload(element)
    source_id = element.get("source_id") or build_source_id(element)
    identity = {
        "source_id": source_id,
        "prompt_hash": repair.get("prompt_hash", ""),
        "reasons": repair.get("reasons", []),
    }
    repair_hash = hashlib.sha256(
        json.dumps(identity, sort_keys=True, default=str).encode("utf-8")
    ).hexdigest()
    return {
        "repair_id": f"repair:{repair_hash[:24]}",
        "source_id": source_id,
        "canonical_citation": element.get("canonical_citation", ""),
        "required": bool(repair.get("required")),
        "reasons": repair.get("reasons", []),
        "suggested_router": repair.get("suggested_router", "llm_router"),
        "prompt_template": repair.get("prompt_template", ""),
        "prompt_hash": repair.get("prompt_hash", ""),
        "prompt_context": repair.get("prompt_context", {}),
        "schema_version": element.get("schema_version", PARSER_SCHEMA_VERSION),
        "quality_label": element.get("quality_label", ""),
        "scaffold_quality": element.get("scaffold_quality", 0.0),
    }


def build_export_record_bundle(element: Dict[str, Any]) -> Dict[str, Any]:
    """Build all deterministic parquet-oriented export rows for one element."""
    return {
        "source_id": element.get("source_id") or build_source_id(element),
        "canonical": dict(element),
        "formal_logic": [build_formal_logic_record(element)],
        "proof_obligations": [build_proof_obligation_record(element)],
        "knowledge_graph_triples": build_kg_triples(element),
        "clause_records": build_clause_records(element),
        "reference_records": build_reference_records(element),
        "procedure_event_records": build_procedure_event_records(element),
        "sanction_records": build_sanction_records(element),
        "ontology_entities": build_ontology_entity_records(element),
        "repair_queue": [build_repair_queue_record(element)]
        if (element.get("llm_repair") or {}).get("required")
        else [],
    }


def build_document_export_tables(elements: List[Dict[str, Any]]) -> Dict[str, List[Any]]:
    """Aggregate parser elements into named parquet-style export tables."""
    tables: Dict[str, List[Any]] = {
        "canonical": [],
        "formal_logic": [],
        "proof_obligations": [],
        "knowledge_graph_triples": [],
        "clause_records": [],
        "reference_records": [],
        "procedure_event_records": [],
        "sanction_records": [],
        "ontology_entities": [],
        "repair_queue": [],
    }
    for element in elements or []:
        bundle = build_export_record_bundle(element)
        tables["canonical"].append(bundle["canonical"])
        for table_name in tables:
            if table_name == "canonical":
                continue
            tables[table_name].extend(bundle.get(table_name, []))
    return tables


def build_document_export_manifest(
    elements: List[Dict[str, Any]],
    tables: Optional[Dict[str, List[Any]]] = None,
) -> Dict[str, Any]:
    """Build deterministic metadata for a parsed document export."""
    tables = tables or build_document_export_tables(elements)
    source_ids = [
        element.get("source_id") or build_source_id(element) for element in elements or []
    ]
    table_counts = {name: len(rows or []) for name, rows in tables.items()}
    identity = {
        "schema_version": PARSER_SCHEMA_VERSION,
        "source_ids": source_ids,
        "table_counts": table_counts,
    }
    manifest_hash = hashlib.sha256(
        json.dumps(identity, sort_keys=True, default=str).encode("utf-8")
    ).hexdigest()
    return {
        "manifest_id": f"manifest:{manifest_hash[:24]}",
        "schema_version": PARSER_SCHEMA_VERSION,
        "element_count": len(elements or []),
        "source_ids": source_ids,
        "table_counts": table_counts,
        "quality": {
            "proof_candidates": sum(
                1
                for element in elements or []
                if (element.get("export_readiness") or {}).get("proof_ready")
            ),
            "repair_required": sum(
                1 for element in elements or [] if (element.get("llm_repair") or {}).get("required")
            ),
            "schema_valid": sum(
                1 for element in elements or [] if element.get("schema_valid") is True
            ),
        },
    }


def validate_document_export_tables(tables: Dict[str, List[Any]]) -> Dict[str, Any]:
    """Validate basic integrity constraints for deterministic export tables."""
    required_tables = set(EXPORT_TABLE_SPECS)
    missing_tables = sorted(required_tables - set((tables or {}).keys()))
    errors: List[str] = []
    warnings: List[str] = []
    if missing_tables:
        errors.extend([f"missing_table:{name}" for name in missing_tables])
    canonical = list((tables or {}).get("canonical") or [])
    canonical_source_ids = {row.get("source_id") for row in canonical if isinstance(row, dict)}
    if any(not source_id for source_id in canonical_source_ids) or len(canonical_source_ids) != len(
        canonical
    ):
        errors.append("canonical_source_ids_missing_or_not_unique")
    for table_name, rows in (tables or {}).items():
        spec = EXPORT_TABLE_SPECS.get(table_name, {})
        primary_key = spec.get("primary_key", "")
        primary_values: List[Any] = []
        for index, row in enumerate(rows or []):
            if not isinstance(row, dict):
                errors.append(f"{table_name}[{index}]_row_not_dict")
                continue
            if primary_key:
                primary_value = row.get(primary_key)
                primary_values.append(primary_value)
                if not primary_value:
                    errors.append(f"{table_name}[{index}]_missing_{primary_key}")
            if spec.get("requires_source_id") and not row.get("source_id"):
                errors.append(f"{table_name}[{index}]_missing_source_id")
            if (
                table_name != "canonical"
                and row.get("source_id")
                and row.get("source_id") not in canonical_source_ids
            ):
                warnings.append(f"{table_name}[{index}]_source_id_not_in_canonical")
        if primary_key and len(set(primary_values)) != len(primary_values):
            errors.append(f"{table_name}_{primary_key}_not_unique")
    if len((tables or {}).get("formal_logic") or []) != len(canonical):
        errors.append("formal_logic_count_mismatch")
    if len((tables or {}).get("proof_obligations") or []) != len(canonical):
        errors.append("proof_obligations_count_mismatch")
    return {
        "valid": not errors,
        "errors": errors,
        "warnings": warnings,
        "table_counts": {name: len(rows or []) for name, rows in (tables or {}).items()},
    }


def get_export_table_specs() -> Dict[str, Dict[str, Any]]:
    """Return the deterministic export table primary-key contract."""
    return {name: dict(spec) for name, spec in EXPORT_TABLE_SPECS.items()}


def serialize_export_tables_for_parquet(
    tables: Dict[str, List[Any]],
    *,
    stringify_nested: bool = True,
) -> Dict[str, List[Dict[str, Any]]]:
    """Make export tables deterministic and safe for simple parquet writers."""
    serialized: Dict[str, List[Dict[str, Any]]] = {}
    for table_name, rows in (tables or {}).items():
        serialized_rows: List[Dict[str, Any]] = []
        for row in rows or []:
            if not isinstance(row, dict):
                continue
            serialized_rows.append(
                {
                    key: _parquet_cell(value, stringify_nested=stringify_nested)
                    for key, value in row.items()
                }
            )
        serialized[table_name] = serialized_rows
    return serialized


def write_document_export_parquet(
    elements: List[Dict[str, Any]],
    output_dir: str,
    *,
    stringify_nested: bool = True,
) -> Dict[str, Any]:
    """Write deterministic document export tables to parquet files using pandas."""
    try:
        import pandas as pd  # type: ignore
    except ImportError as exc:  # pragma: no cover - exercised only without pandas
        raise RuntimeError("pandas is required to write parquet export tables") from exc

    tables = build_document_export_tables(elements)
    validation = validate_document_export_tables(tables)
    if not validation["valid"]:
        raise ValueError(f"invalid export tables: {validation['errors']}")
    serialized = serialize_export_tables_for_parquet(tables, stringify_nested=stringify_nested)
    target_dir = Path(output_dir)
    target_dir.mkdir(parents=True, exist_ok=True)
    parquet_paths: Dict[str, str] = {}
    for table_name, rows in serialized.items():
        parquet_path = target_dir / f"{table_name}.parquet"
        pd.DataFrame(rows).to_parquet(parquet_path, index=False)
        parquet_paths[table_name] = str(parquet_path)
    manifest = build_document_export_manifest(elements, tables)
    manifest_path = target_dir / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, sort_keys=True, indent=2), encoding="utf-8")
    return {
        "output_dir": str(target_dir),
        "parquet_paths": parquet_paths,
        "manifest_path": str(manifest_path),
        "manifest": manifest,
        "validation": validation,
    }


def _parquet_cell(value: Any, *, stringify_nested: bool) -> Any:
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    if stringify_nested:
        return json.dumps(value, sort_keys=True, default=str)
    return value


def build_deontic_formula(element: Dict[str, Any]) -> str:
    from ipfs_datasets_py.logic.deontic.formula_builder import parser_element_to_formula

    return parser_element_to_formula(element)


def normalize_predicate_name(name: str) -> str:
    if not name:
        return "P"
    name = re.sub(r"[_\-]+", " ", name)
    name = re.sub(r"[^0-9A-Za-z\s]", "", name)
    words = name.strip().split()
    filtered_words = [
        w
        for w in words
        if w.lower() not in ["the", "a", "an", "of", "in", "on", "at", "to", "for", "with", "by"]
    ]
    if not filtered_words:
        return "P"
    return "".join(word.capitalize() for word in filtered_words)


def parser_elements_with_deterministic_ir_readiness(
    elements: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """Project deterministic IR/formula readiness onto parser elements.

    ``extract_normative_elements`` intentionally returns the conservative raw
    parser view: parser theorem promotion and legacy repair audit fields stay
    stable for existing callers. Some parser-boundary consumers, however, need
    the same source-grounded repair clearance already used by exports, metrics,
    and converter metadata. This helper provides that explicit opt-in without
    reparsing text and without invoking any LLM repair lane.

    The returned dictionaries are copies. ``promotable_to_theorem`` remains the
    parser gate, while ``export_readiness`` and ``llm_repair`` reflect whether
    the typed IR/formula layer has deterministically resolved stale repair noise
    such as local applicability, substantive exceptions represented in the
    formula antecedent, or pure precedence overrides.
    """

    from ipfs_datasets_py.logic.deontic.exports import parser_elements_with_ir_export_readiness

    return parser_elements_with_ir_export_readiness(elements)


def identify_obligations(elements: List[Dict[str, Any]]) -> Dict[str, Any]:
    categorized: Dict[str, Any] = {
        "obligations": [],
        "permissions": [],
        "prohibitions": [],
        "conditional_norms": [],
        "temporal_norms": [],
    }

    for element in elements:
        norm_type = element.get("norm_type")
        if norm_type == "obligation":
            categorized["obligations"].append(element)
        elif norm_type == "permission":
            categorized["permissions"].append(element)
        elif norm_type == "prohibition":
            categorized["prohibitions"].append(element)

        if element.get("conditions"):
            categorized["conditional_norms"].append(element)
        if element.get("temporal_constraints"):
            categorized["temporal_norms"].append(element)

    return categorized


def detect_normative_conflicts(elements: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Detect conflicts between normative statements.

    This function identifies four types of conflicts:
    1. Direct conflicts: O(p) ∧ F(p) (obligation vs prohibition)
    2. Permission conflicts: P(p) ∧ F(p) (permission vs prohibition)
    3. Conditional conflicts: Conflicting norms with overlapping conditions
    4. Temporal conflicts: Conflicting norms with overlapping time periods

    Args:
        elements: List of normative elements extracted from legal text

    Returns:
        List of detected conflicts with type, severity, and resolution strategies
    """
    conflicts: List[Dict[str, Any]] = []

    # Check each pair of normative elements
    for i, elem1 in enumerate(elements):
        for j, elem2 in enumerate(elements[i + 1 :], i + 1):
            conflict = _check_conflict_pair(elem1, elem2)
            if conflict:
                conflicts.append(
                    {
                        "type": conflict["type"],
                        "elements": [elem1, elem2],
                        "element_indices": [i, j],
                        "severity": conflict["severity"],
                        "description": conflict["description"],
                        "resolution_strategies": conflict["strategies"],
                    }
                )

    return conflicts


def _check_conflict_pair(elem1: Dict[str, Any], elem2: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Check if two normative elements conflict.

    Args:
        elem1: First normative element
        elem2: Second normative element

    Returns:
        Conflict details if conflict exists, None otherwise
    """
    # Extract relevant fields
    norm1_type = elem1.get("norm_type")
    norm2_type = elem2.get("norm_type")
    action1 = _first_text(elem1.get("action")).lower().strip()
    action2 = _first_text(elem2.get("action")).lower().strip()
    subject1 = _first_text(elem1.get("subject")).lower().strip()
    subject2 = _first_text(elem2.get("subject")).lower().strip()

    # Skip if missing critical information
    if not all([norm1_type, norm2_type, action1, action2]):
        return None

    # Check if actions are similar (exact match or high similarity)
    actions_match = _actions_similar(action1, action2)
    subjects_match = _subjects_similar(subject1, subject2)

    if not (actions_match and subjects_match):
        return None

    # Check for temporal conflicts first (more specific than direct conflicts)
    temporal_conflict = _check_temporal_conflict(elem1, elem2)
    if temporal_conflict:
        return temporal_conflict

    # Check for direct conflicts: O(p) ∧ F(p)
    if (norm1_type == "obligation" and norm2_type == "prohibition") or (
        norm1_type == "prohibition" and norm2_type == "obligation"
    ):
        return {
            "type": "direct_conflict",
            "severity": "high",
            "description": f"Direct conflict: {norm1_type} conflicts with {norm2_type} for same action",
            "strategies": ["lex_superior", "lex_specialis", "lex_posterior"],
        }

    # Check for permission conflicts: P(p) ∧ F(p)
    if (norm1_type == "permission" and norm2_type == "prohibition") or (
        norm1_type == "prohibition" and norm2_type == "permission"
    ):
        return {
            "type": "permission_conflict",
            "severity": "medium",
            "description": f"Permission conflict: {norm1_type} conflicts with {norm2_type} for same action",
            "strategies": ["prohibition_prevails", "context_dependent"],
        }

    # Check for conditional conflicts
    conditional_conflict = _check_conditional_conflict(elem1, elem2)
    if conditional_conflict:
        return conditional_conflict

    return None


def _actions_similar(action1: str, action2: str) -> bool:
    """Check if two actions are similar enough to conflict.

    Args:
        action1: First action string
        action2: Second action string

    Returns:
        True if actions are similar, False otherwise
    """
    if not action1 or not action2:
        return False

    # Exact match
    if action1 == action2:
        return True

    # Normalize and check for overlap
    words1 = set(action1.split())
    words2 = set(action2.split())

    # If there's significant word overlap (>50%), consider similar
    if words1 and words2:
        overlap = len(words1 & words2) / min(len(words1), len(words2))
        return overlap > 0.5

    return False


def _first_text(value: Any) -> str:
    if isinstance(value, list):
        return str(value[0]) if value else ""
    return str(value or "")


def _subjects_similar(subject1: str, subject2: str) -> bool:
    """Check if two subjects are similar enough to conflict.

    Args:
        subject1: First subject string
        subject2: Second subject string

    Returns:
        True if subjects are similar, False otherwise
    """
    if not subject1 or not subject2:
        # If either subject is empty, assume they refer to same general subject
        return True

    # Exact match
    if subject1 == subject2:
        return True

    # Check for subset relationship
    if subject1 in subject2 or subject2 in subject1:
        return True

    # Normalize and check for overlap
    words1 = set(subject1.split())
    words2 = set(subject2.split())

    if words1 and words2:
        overlap = len(words1 & words2) / min(len(words1), len(words2))
        return overlap > 0.5

    return False


def _check_temporal_conflict(
    elem1: Dict[str, Any], elem2: Dict[str, Any]
) -> Optional[Dict[str, Any]]:
    """Check for temporal conflicts between two normative elements.

    Args:
        elem1: First normative element
        elem2: Second normative element

    Returns:
        Conflict details if temporal conflict exists, None otherwise
    """
    temporal1 = elem1.get("temporal_constraints", [])
    temporal2 = elem2.get("temporal_constraints", [])

    # Only check if both have temporal constraints
    if not (temporal1 and temporal2):
        return None

    # Check if temporal periods overlap and norms conflict
    norm1_type = elem1.get("norm_type")
    norm2_type = elem2.get("norm_type")

    # If norms are conflicting types and have overlapping time periods
    conflicting_types = {
        ("obligation", "prohibition"),
        ("prohibition", "obligation"),
        ("permission", "prohibition"),
        ("prohibition", "permission"),
    }

    if (norm1_type, norm2_type) in conflicting_types:
        # Simple check: if both have temporal constraints, assume potential overlap
        # A more sophisticated implementation would parse actual dates/times
        return {
            "type": "temporal_conflict",
            "severity": "medium",
            "description": "Conflicting norms with overlapping temporal constraints",
            "strategies": ["temporal_precedence", "latest_applies"],
        }

    return None


def _check_conditional_conflict(
    elem1: Dict[str, Any], elem2: Dict[str, Any]
) -> Optional[Dict[str, Any]]:
    """Check for conditional conflicts between two normative elements.

    Args:
        elem1: First normative element
        elem2: Second normative element

    Returns:
        Conflict details if conditional conflict exists, None otherwise
    """
    conditions1 = elem1.get("conditions", [])
    conditions2 = elem2.get("conditions", [])

    # Only check if both have conditions
    if not (conditions1 and conditions2):
        return None

    norm1_type = elem1.get("norm_type")
    norm2_type = elem2.get("norm_type")

    # Check if conditions overlap
    # Simple check: if conditions share words, they might overlap
    cond1_text = " ".join(str(c).lower() for c in conditions1)
    cond2_text = " ".join(str(c).lower() for c in conditions2)

    words1 = set(cond1_text.split())
    words2 = set(cond2_text.split())

    if words1 and words2:
        overlap = len(words1 & words2) / min(len(words1), len(words2))

        # If conditions overlap significantly and norms conflict
        if overlap > 0.3:
            conflicting_types = {
                ("obligation", "prohibition"),
                ("prohibition", "obligation"),
                ("permission", "prohibition"),
                ("prohibition", "permission"),
            }

            if (norm1_type, norm2_type) in conflicting_types:
                return {
                    "type": "conditional_conflict",
                    "severity": "low",
                    "description": "Conflicting norms with overlapping conditions",
                    "strategies": ["specificity_analysis", "context_evaluation"],
                }

    return None


_extract_normative_elements_without_substantive_exception_projection = extract_normative_elements


def extract_normative_elements(*args: Any, **kwargs: Any) -> List[Dict[str, Any]]:
    """Extract parser elements and clear deterministic substantive-exception repair.

    The parser still records ``exception_requires_scope_review`` as an audit
    warning and keeps ``promotable_to_theorem`` conservative.  A single plain
    substantive exception such as ``unless approval is denied`` is already
    represented in the IR formula as a negated antecedent, so it should not stay
    in the active LLM repair lane at the raw parser boundary.
    """

    elements = _extract_normative_elements_without_substantive_exception_projection(*args, **kwargs)
    for element in elements:
        _normalize_authorized_and_directed_obligation(element)
        _normalize_instruction_order_obligation(element)
        _normalize_express_duty_obligation(element)
        _normalize_authority_grant_permission(element)
        _clear_standard_substantive_exception_active_repair(element)
        _clear_local_applicability_active_repair(element)
        _clear_pure_precedence_override_active_repair(element)
    _apply_active_repair_status(elements)
    return elements


def _normalize_authorized_and_directed_obligation(element: Dict[str, Any]) -> None:
    """Classify hybrid authority-direction clauses as mandatory duties.

    Statutes often grant authority and impose a duty in the same modal phrase,
    e.g. ``is authorized and directed to``. The directive component is the
    operative deontic force, so the clause should export as an obligation while
    still retaining authority provenance in KG hints.
    """

    modal = str(element.get("modal") or "").strip().lower()
    if not re.search(
        r"\b(?:is|are)\s+authorized\s+and\s+directed\s+to\b",
        modal,
        re.IGNORECASE,
    ):
        return
    actor = _parser_slot_first_text(element.get("subject"))
    action = _parser_slot_first_text(element.get("action"))
    if not actor or not action:
        return

    element["norm_type"] = "obligation"
    element["deontic_operator"] = "O"
    element["modality"] = "O"

    formal_terms = dict(element.get("formal_terms") or {})
    formal_terms["norm_predicate"] = "Obligation"
    element["formal_terms"] = formal_terms

    legal_frame = dict(element.get("legal_frame") or {})
    legal_frame["category"] = "authority_duty"
    legal_frame["norm_type"] = "obligation"
    legal_frame["deontic_operator"] = "O"
    element["legal_frame"] = legal_frame

    hints = list(element.get("kg_relationship_hints") or [])
    duty_hint = {
        "subject": "law",
        "predicate": "imposesDutyOn",
        "object": actor,
    }
    if duty_hint not in hints:
        hints.append(duty_hint)
    authority_hint = {"subject": "law", "predicate": "grantsAuthorityTo", "object": actor}
    if authority_hint not in hints:
        hints.append(authority_hint)
    action_hint = {"subject": actor, "predicate": "hasAuthorityFor", "object": action}
    if action_hint not in hints:
        hints.append(action_hint)
    element["kg_relationship_hints"] = hints


def _normalize_instruction_order_obligation(element: Dict[str, Any]) -> None:
    """Classify instruction/order/mandate directive clauses as duties."""

    modal = str(element.get("modal") or "").strip().lower()
    if not re.search(
        r"\b(?:is|are)\s+(?:instructed|ordered|mandated|commanded)\s+to\b",
        modal,
        re.IGNORECASE,
    ):
        return
    actor = _parser_slot_first_text(element.get("subject"))
    action = _parser_slot_first_text(element.get("action"))
    if not actor or not action:
        return

    element["norm_type"] = "obligation"
    element["deontic_operator"] = "O"
    element["modality"] = "O"

    formal_terms = dict(element.get("formal_terms") or {})
    formal_terms["norm_predicate"] = "Obligation"
    element["formal_terms"] = formal_terms

    legal_frame = dict(element.get("legal_frame") or {})
    legal_frame["category"] = "directive_duty"
    legal_frame["norm_type"] = "obligation"
    legal_frame["deontic_operator"] = "O"
    element["legal_frame"] = legal_frame

    hints = list(element.get("kg_relationship_hints") or [])
    duty_hint = {"subject": "law", "predicate": "imposesDutyOn", "object": actor}
    if duty_hint not in hints:
        hints.append(duty_hint)
    action_hint = {"subject": actor, "predicate": "performsAction", "object": action}
    if action_hint not in hints:
        hints.append(action_hint)
    element["kg_relationship_hints"] = hints


def _normalize_express_duty_obligation(element: Dict[str, Any]) -> None:
    """Classify express obligated/under-duty/accountability clauses as obligations."""

    modal = str(element.get("modal") or "").strip().lower()
    if not re.search(
        r"\b(?:is|are)\s+(?:(?:(?:required|obligated|compelled|bound)\s+by\s+law|legally\s+(?:required|obligated|compelled)|obligated|compelled|under\s+a\s+(?:legal\s+)?duty|liable|bound|duty-bound|duty\s+bound)\s+to|subject\s+to\s+(?:a\s+|the\s+)?duty\s+to|(?:responsible|accountable|answerable)\s+for|(?:tasked|entrusted)\s+with)\b|\b(?:has|have)\s+(?:a\s+|the\s+)?responsibility\s+to\b|\b(?:owes|owe)\s+(?:a\s+|the\s+)?duty\s+to\b|\b(?:bears|bear)\s+(?:a\s+|the\s+)?responsibility\s+for\b|\b(?:bears|bear)\s+(?:an?\s+|the\s+)?obligation\s+to\b",
        modal,
        re.IGNORECASE,
    ):
        return
    actor = _parser_slot_first_text(element.get("subject"))
    action = _parser_slot_first_text(element.get("action"))
    if not actor or not action:
        return

    element["norm_type"] = "obligation"
    element["deontic_operator"] = "O"
    element["modality"] = "O"

    formal_terms = dict(element.get("formal_terms") or {})
    formal_terms["norm_predicate"] = "Obligation"
    element["formal_terms"] = formal_terms

    legal_frame = dict(element.get("legal_frame") or {})
    legal_frame["category"] = "duty_assignment"
    legal_frame["norm_type"] = "obligation"
    legal_frame["deontic_operator"] = "O"
    element["legal_frame"] = legal_frame

    _clear_subject_to_duty_condition_noise(element)
    hints = list(element.get("kg_relationship_hints") or [])
    duty_hint = {"subject": "law", "predicate": "imposesDutyOn", "object": actor}
    if duty_hint not in hints:
        hints.append(duty_hint)
    action_hint = {"subject": actor, "predicate": "performsAction", "object": action}
    if action_hint not in hints:
        hints.append(action_hint)
    element["kg_relationship_hints"] = hints


def _clear_subject_to_duty_condition_noise(element: Dict[str, Any]) -> None:
    """Remove condition noise created by the generic ``subject to`` pattern.

    In clauses such as ``The owner is subject to a duty to maintain the
    sidewalk``, ``subject to`` is part of the modal phrase, not a separate
    condition. The parser should preserve the operative action without adding a
    duplicate ``DutyMaintainSidewalk`` antecedent to the formula.
    """

    modal = str(element.get("modal") or "").strip().lower()
    if not re.search(
        r"\b(?:is|are)\s+subject\s+to\s+(?:a\s+|the\s+)?duty\s+to\b",
        modal,
        re.IGNORECASE,
    ):
        return

    action = _parser_slot_first_text(element.get("action")).strip().lower()
    if not action:
        return

    def is_noise(value: Any) -> bool:
        text = str(value or "").strip().lower()
        text = re.sub(r"^(?:a|the)\s+", "", text)
        return text == f"duty to {action}"

    conditions = [
        condition for condition in element.get("conditions") or [] if not is_noise(condition)
    ]
    element["conditions"] = conditions

    condition_details = [
        detail
        for detail in element.get("condition_details") or []
        if not is_noise(_parser_slot_text(detail) if isinstance(detail, dict) else detail)
    ]
    element["condition_details"] = condition_details

    if not conditions and not condition_details:
        field_spans = dict(element.get("field_spans") or {})
        field_spans.pop("conditions", None)
        field_spans.pop("condition", None)
        element["field_spans"] = field_spans


def _normalize_authority_grant_permission(element: Dict[str, Any]) -> None:
    """Classify express authority and power grants as permission norms."""

    modal = str(element.get("modal") or "").strip().lower()
    if not re.search(
        r"\b(?:has|have)\s+(?:the\s+)?(?:authority|power)\s+to\b|\b(?:is|are)\s+(?:(?:(?:delegated|granted|conferred)\s+(?:the\s+)?(?:authority|power))|(?:vested\s+with\s+(?:the\s+)?(?:authority|power))|empowered)\s+to\b",
        modal,
        re.IGNORECASE,
    ):
        return
    if not _parser_slot_first_text(element.get("subject")):
        return
    if not _parser_slot_first_text(element.get("action")):
        return

    element["norm_type"] = "permission"
    element["deontic_operator"] = "P"
    element["modality"] = "P"

    formal_terms = dict(element.get("formal_terms") or {})
    formal_terms["norm_predicate"] = "Permission"
    element["formal_terms"] = formal_terms

    legal_frame = dict(element.get("legal_frame") or {})
    legal_frame["category"] = "authority"
    legal_frame["norm_type"] = "permission"
    legal_frame["deontic_operator"] = "P"
    element["legal_frame"] = legal_frame

    hints = list(element.get("kg_relationship_hints") or [])
    actor = _parser_slot_first_text(element.get("subject"))
    action = _parser_slot_first_text(element.get("action"))
    grant_hint = {
        "subject": "law",
        "predicate": "grantsAuthorityTo",
        "object": actor,
    }
    if grant_hint not in hints:
        hints.append(grant_hint)
    action_hint = {"subject": actor, "predicate": "hasAuthorityFor", "object": action}
    if action_hint not in hints:
        hints.append(action_hint)
    element["kg_relationship_hints"] = hints


def _clear_standard_substantive_exception_active_repair(element: Dict[str, Any]) -> None:
    if element.get("norm_type") not in {"obligation", "permission", "prohibition"}:
        return
    if element.get("deontic_operator") not in {"O", "P", "F"}:
        return
    if not _parser_slot_first_text(element.get("subject")) or not _parser_slot_first_text(
        element.get("action")
    ):
        return
    if element.get("conditions") or element.get("condition_details"):
        return
    if element.get("override_clauses") or element.get("override_clause_details"):
        return
    if element.get("cross_references") or element.get("cross_reference_details"):
        return

    warnings = list(element.get("parser_warnings") or [])
    if warnings != ["exception_requires_scope_review"]:
        return

    exception = _single_parser_exception_record(element)
    if not exception:
        return
    exception_text = _parser_slot_text(exception)
    if not exception_text or _substantive_exception_requires_external_resolution(exception_text):
        return

    resolution = {
        "type": "standard_substantive_exception",
        "resolved_blockers": ["exception_requires_scope_review"],
        "exception": exception_text,
        "exception_span": list(exception.get("span") or []),
        "reason": "single substantive exception is represented as a negated formula antecedent",
    }

    llm_repair = dict(element.get("llm_repair") or {})
    llm_repair["required"] = False
    llm_repair["allow_llm_repair"] = False
    llm_repair["reasons"] = []
    llm_repair["deterministic_resolution"] = resolution
    element["llm_repair"] = llm_repair

    export_readiness = dict(element.get("export_readiness") or {})
    export_readiness["formula_proof_ready"] = True
    export_readiness["formula_requires_validation"] = False
    export_readiness["formula_repair_required"] = False
    export_readiness["export_requires_validation"] = False
    export_readiness["export_repair_required"] = False
    export_readiness["deterministic_resolution"] = resolution
    element["export_readiness"] = export_readiness


def _clear_local_applicability_active_repair(element: Dict[str, Any]) -> None:
    """Clear active repair for exact local self-scope applicability clauses."""

    if not _is_local_applicability_element(element):
        return

    local_records = _local_applicability_reference_records(element)
    if not local_records:
        return

    resolution = {
        "type": "local_scope_applicability",
        "scopes": sorted(
            {record.get("value", "") for record in local_records if record.get("value")}
        ),
        "reason": "local applicability subject is a self-scope reference exported as provenance",
    }

    element["resolved_cross_references"] = local_records

    llm_repair = dict(element.get("llm_repair") or {})
    llm_repair["required"] = False
    llm_repair["allow_llm_repair"] = False
    llm_repair["reasons"] = []
    llm_repair["deterministic_resolution"] = resolution
    element["llm_repair"] = llm_repair

    export_readiness = dict(element.get("export_readiness") or {})
    export_readiness["formula_proof_ready"] = True
    export_readiness["formula_requires_validation"] = False
    export_readiness["formula_repair_required"] = False
    export_readiness["deterministic_resolution"] = resolution
    element["export_readiness"] = export_readiness


def _clear_pure_precedence_override_active_repair(element: Dict[str, Any]) -> None:
    """Clear active repair for source-grounded pure precedence overrides."""

    if element.get("norm_type") not in {"obligation", "permission", "prohibition"}:
        return
    if element.get("deontic_operator") not in {"O", "P", "F"}:
        return
    if not _parser_slot_first_text(element.get("subject")) or not _parser_slot_first_text(
        element.get("action")
    ):
        return
    if element.get("conditions") or element.get("condition_details"):
        return
    if element.get("exceptions") or element.get("exception_details"):
        return
    if not element.get("override_clauses") and not element.get("override_clause_details"):
        return

    warnings = set(element.get("parser_warnings") or [])
    required_warnings = {
        "cross_reference_requires_resolution",
        "override_clause_requires_precedence_review",
    }
    if not required_warnings.issubset(warnings):
        return
    if warnings - required_warnings:
        return

    precedence_records = _precedence_override_reference_records(element)
    if not precedence_records:
        return

    resolution = {
        "type": "pure_precedence_override",
        "resolved_blockers": sorted(required_warnings),
        "references": [
            record.get("normalized_text") or record.get("raw_text") or record.get("value")
            for record in precedence_records
        ],
        "reason": "override reference is retained as precedence provenance outside the operative formula",
    }

    element["resolved_cross_references"] = precedence_records

    llm_repair = dict(element.get("llm_repair") or {})
    llm_repair["required"] = False
    llm_repair["allow_llm_repair"] = False
    llm_repair["reasons"] = []
    llm_repair["prompt_context"] = {}
    llm_repair["prompt_hash"] = ""
    llm_repair["suggested_router"] = ""
    llm_repair["deterministically_resolved"] = True
    llm_repair["deterministic_resolution"] = resolution
    element["llm_repair"] = llm_repair

    export_readiness = dict(element.get("export_readiness") or {})
    export_readiness["metric_requires_validation"] = False
    export_readiness["metric_repair_required"] = False
    export_readiness["deterministic_resolution"] = resolution
    element["export_readiness"] = export_readiness


def _single_parser_exception_record(element: Dict[str, Any]) -> Dict[str, Any]:
    details = element.get("exception_details")
    if isinstance(details, list) and len(details) == 1 and isinstance(details[0], dict):
        return dict(details[0])

    exceptions = element.get("exceptions")
    if isinstance(exceptions, list) and len(exceptions) == 1:
        value = exceptions[0]
        if isinstance(value, dict):
            return dict(value)
        if value:
            return {"value": str(value)}
    return {}


def _parser_slot_first_text(value: Any) -> str:
    if isinstance(value, list):
        return str(value[0]).strip() if value else ""
    return str(value or "").strip()


def _parser_slot_text(record: Dict[str, Any]) -> str:
    for key in ("value", "normalized_text", "raw_text", "text"):
        value = record.get(key)
        if value:
            return str(value).strip()
    return ""


def _substantive_exception_requires_external_resolution(text: str) -> bool:
    normalized = str(text or "").strip().lower()
    if not normalized:
        return True
    if re.search(
        r"(?:\b(?:section|subsection|chapter|title|article|part)\s+|§\s*)"
        r"[0-9][0-9A-Za-z.\-]*(?:\([a-z0-9]+\))*\b",
        normalized,
    ):
        return True
    return normalized.startswith(
        (
            "as otherwise provided",
            "as provided",
            "otherwise provided in",
            "provided in",
            "under ",
            "pursuant to ",
            "notwithstanding ",
        )
    )
