# decoder-eight-source-preconditioning-20261004

Retained endpoints: 6. Historical completed updates: 340.

Experimental formula decoder; no vector reconstruction, optimizer resume, semantic/proof authority or production qualification is claimed.
