# native4096-conditioning-20261004

Retained endpoints: 3. Historical completed updates: 600.

Experimental formula decoder; no vector reconstruction, optimizer resume, semantic/proof authority or production qualification is claimed.
